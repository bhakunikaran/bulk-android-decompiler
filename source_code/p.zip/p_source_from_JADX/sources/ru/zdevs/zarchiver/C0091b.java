package ru.zdevs.zarchiver;

import android.content.Context;
import android.content.Intent;
import ru.zdevs.zarchiver.fs.MyUri;

/* renamed from: ru.zdevs.zarchiver.b */
public class C0091b {
    /* renamed from: a */
    public static void m357a(Context context, int i, boolean z, boolean z2) {
        Intent intent = new Intent("ru.zdevs.zarchiver.action.EXTERNAL");
        intent.addCategory("ru.zdevs.zarchiver.category.CALLBACK");
        intent.putExtra("ru.zdevs.zarchiver.field.ID", i);
        intent.putExtra("ru.zdevs.zarchiver.field.ACTION", z ? "ru.zdevs.zarchiver.category.COMPRESS" : "ru.zdevs.zarchiver.category.EXTRACT");
        intent.putExtra("ru.zdevs.zarchiver.field.SUCESSFULL", z2);
        context.sendBroadcast(intent);
    }

    /* renamed from: a */
    public static boolean m358a(Intent intent) {
        return "ru.zdevs.zarchiver.action.EXTERNAL".equals(intent.getAction());
    }

    /* renamed from: b */
    public static boolean m359b(Intent intent) {
        return intent.getCategories() == null ? false : intent.getCategories().contains("ru.zdevs.zarchiver.category.COMPRESS");
    }

    /* renamed from: c */
    public static boolean m360c(Intent intent) {
        return (intent.getStringExtra("ru.zdevs.zarchiver.field.ARCHIVEPATH") == null || intent.getStringExtra("ru.zdevs.zarchiver.field.TYPE") == null || intent.getStringExtra("ru.zdevs.zarchiver.field.FILEPATH") == null || intent.getStringArrayExtra("ru.zdevs.zarchiver.field.FILELIST") == null) ? false : true;
    }

    /* renamed from: d */
    public static boolean m361d(Intent intent) {
        return intent.getCategories() == null ? false : intent.getCategories().contains("ru.zdevs.zarchiver.category.EXTRACT");
    }

    /* renamed from: e */
    public static boolean m362e(Intent intent) {
        return (intent.getStringExtra("ru.zdevs.zarchiver.field.ARCHIVEPATH") == null || intent.getStringExtra("ru.zdevs.zarchiver.field.EXTRACTTO") == null) ? false : true;
    }

    /* renamed from: f */
    public static int m363f(Intent intent) {
        int intExtra = intent.getIntExtra("ru.zdevs.zarchiver.field.ID", 0);
        return intExtra == 0 ? (int) ((2.147483647E9d * Math.random()) + 1.0d) : intExtra;
    }

    /* renamed from: g */
    public static String m364g(Intent intent) {
        return intent.getStringExtra("ru.zdevs.zarchiver.field.ARCHIVEPATH");
    }

    /* renamed from: h */
    public static String m365h(Intent intent) {
        return intent.getStringExtra("ru.zdevs.zarchiver.field.EXTRACTTO");
    }

    /* renamed from: i */
    public static int m366i(Intent intent) {
        return intent.getIntExtra("ru.zdevs.zarchiver.field.LAVEL", 5);
    }

    /* renamed from: j */
    public static String m367j(Intent intent) {
        return intent.getStringExtra("ru.zdevs.zarchiver.field.TYPE");
    }

    /* renamed from: k */
    public static MyUri m368k(Intent intent) {
        return new MyUri(intent.getStringExtra("ru.zdevs.zarchiver.field.FILEPATH"));
    }

    /* renamed from: l */
    public static String[] m369l(Intent intent) {
        return intent.getStringArrayExtra("ru.zdevs.zarchiver.field.FILELIST");
    }

    /* renamed from: m */
    public static boolean m370m(Intent intent) {
        return intent.getCategories() == null ? false : intent.getCategories().contains("ru.zdevs.zarchiver.category.OPEN");
    }
}
