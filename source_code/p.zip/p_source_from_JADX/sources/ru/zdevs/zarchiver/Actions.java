package ru.zdevs.zarchiver;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.DeadObjectException;
import android.os.Parcelable;
import android.util.Log;
import android.widget.Toast;
import java.io.File;
import java.io.FileReader;
import java.io.LineNumberReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import ru.zdevs.zarchiver.archiver.AskOverwriteInfo;
import ru.zdevs.zarchiver.archiver.C0061a;
import ru.zdevs.zarchiver.archiver.C0071e;
import ru.zdevs.zarchiver.archiver.C0072g;
import ru.zdevs.zarchiver.dialog.ZAddFavorite;
import ru.zdevs.zarchiver.dialog.ZAskOverwriteDialog;
import ru.zdevs.zarchiver.dialog.ZCompressDialog;
import ru.zdevs.zarchiver.dialog.ZDialog;
import ru.zdevs.zarchiver.dialog.ZDialog.OnCancelListener;
import ru.zdevs.zarchiver.dialog.ZDialog.OnOkListener;
import ru.zdevs.zarchiver.dialog.ZEnterPwdDialog;
import ru.zdevs.zarchiver.dialog.ZEnterTextDialog;
import ru.zdevs.zarchiver.dialog.ZFileInfoDialog;
import ru.zdevs.zarchiver.dialog.ZFileSelect;
import ru.zdevs.zarchiver.dialog.ZMainOptionDialog;
import ru.zdevs.zarchiver.dialog.ZMenuDialog;
import ru.zdevs.zarchiver.dialog.ZMessageDialog;
import ru.zdevs.zarchiver.dialog.ZPermissionDialog;
import ru.zdevs.zarchiver.dialog.ZProcDialog;
import ru.zdevs.zarchiver.dialog.ZProgDialog;
import ru.zdevs.zarchiver.dialog.ZRootWarningDialog;
import ru.zdevs.zarchiver.dialog.ZSavedPwdDialog;
import ru.zdevs.zarchiver.fs.FSArchive;
import ru.zdevs.zarchiver.fs.FSLocal;
import ru.zdevs.zarchiver.fs.MyUri;
import ru.zdevs.zarchiver.p003a.C0044c;
import ru.zdevs.zarchiver.p003a.C0046h;
import ru.zdevs.zarchiver.p003a.C0047d;
import ru.zdevs.zarchiver.p003a.C0049e;
import ru.zdevs.zarchiver.p003a.C0052g;
import ru.zdevs.zarchiver.p004b.C0073a;
import ru.zdevs.zarchiver.p004b.C0075c;
import ru.zdevs.zarchiver.p004b.C0076d;
import ru.zdevs.zarchiver.p004b.C0077e;
import ru.zdevs.zarchiver.service.C0144e;
import ru.zdevs.zarchiver.settings.Favorites;
import ru.zdevs.zarchiver.settings.Settings;
import ru.zdevs.zarchiver.tool.C0166c;
import ru.zdevs.zarchiver.tool.C0167d;
import ru.zdevs.zarchiver.tool.C0178g;
import ru.zdevs.zarchiver.tool.C0184j;
import ru.zdevs.zarchiver.tool.C0185k;
import ru.zdevs.zarchiver.tool.C0187l;
import ru.zdevs.zarchiver.tool.C0199n;
import ru.zdevs.zarchiver.tool.C0200o;
import ru.zdevs.zarchiver.tool.C0201p;
import ru.zdevs.zarchiver.tool.C0202q;
import ru.zdevs.zarchiver.tool.C0204s;
import ru.zdevs.zarchiver.widget.bottomsheet.ViewDragHelper;

public class Actions extends BroadcastReceiver implements OnCancelListener, OnOkListener {
    public static final char ACTION_CREATE_ARCHIVE = '\"';
    public static final char ACTION_EXTRACT = '\t';
    public static final char ACTION_EXTRACT_FROM_ARC = '\u0011';
    public static final char ACTION_MODE_MASKS = '\u0007';
    public static final char ACTION_MODE_NONE = '\u0000';
    public static final char ACTION_MODE_SELECT_FILE = '\u0004';
    public static final char ACTION_MODE_SELECT_FILES = '\u0002';
    public static final char ACTION_MODE_SELECT_FOLDER = '\u0001';
    public static final char ACTION_NONE = '\u0000';
    public static final char ACTION_PAST = 'A';
    public static final int CHECK_ACTION_DECOMPRESS_CUR = 2;
    public static final int CHECK_ACTION_DECOMPRESS_NAM = 3;
    public static final int CHECK_ACTION_DEFAULT = 0;
    public static final int CHECK_ACTION_PAST = 1;
    public static final int CHECK_ACTION_PERMISSION = 5;
    public static final int CHECK_ACTION_REMOVE = 4;
    public static final int CHECK_ACTION_RENAME = 6;
    public static final char DLG_ADD_FAVORITE = '\u0015';
    public static final char DLG_ADD_FILES = '\u0005';
    public static final char DLG_ADD_FOLDER = '\u0006';
    public static final char DLG_COMPRESS_FILE = '\n';
    public static final char DLG_CONFIRM_CANCEL = '\t';
    public static final char DLG_CONFIRM_DEL_FRM_ARC = '\u0004';
    public static final char DLG_CONFIRM_DEL_FRM_FS = '\u0003';
    public static final char DLG_DELETE_FILE_7Z = '\u000e';
    public static final char DLG_DELETE_FILE_ZIP = '\r';
    public static final char DLG_HELP_MESSAGE = '\u0014';
    public static final char DLG_MODIFY_FILE_IN_ARCHIVE = '\u000f';
    public static final char DLG_NEW_ARCHIVE = '\u000b';
    public static final char DLG_NEW_FOLDER = '\u0001';
    public static final char DLG_OVERWRITE_ARCHIVE = '\u0011';
    public static final char DLG_REMOVE_PASSWORD = '\u0013';
    public static final char DLG_RENAME_FAVORITE = '\u0016';
    public static final char DLG_RENAME_FILE = '\f';
    public static final char DLG_WHITE_COPY_ATTACHMENT = '\u0012';
    public static final byte OVERWRITE_APPEND = (byte) 2;
    public static final byte OVERWRITE_QUESTION = (byte) 0;
    public static final byte OVERWRITE_YES = (byte) 1;
    public static final char REQUEST_CODE_SET_EXTSD_NO_CHECK_URI = 'j';
    public static final char REQUEST_CODE_SET_EXTSD_URI = 'i';
    private static final String TAG = "Actions";
    public static Object bWaitService = null;
    public String mArchiveFileOpen = "";
    private C0136e mCS = null;
    public String[] mFileListAction = null;
    public MyUri mFileListActionPath = null;
    public MyUri[] mFileListActionPathS = null;
    public String[] mFileListCopy = null;
    public boolean mFileListCopyCut = false;
    public MyUri mFileListCopyPath = null;
    public MyUri[] mFileListCopyPathS = null;
    private Toast mLastToastMessage;
    public final BroadcastReceiver mMessageReceiver = new C00031(this);
    private boolean mNewArchiveDeleteFile = false;
    private String mNewArchiveFormat = "";
    private String mNewArchiveParam = "";
    private String mNewArchivePath = "";
    protected C0144e mService = null;
    private ZArchiver mZA = null;

    /* renamed from: ru.zdevs.zarchiver.Actions$1 */
    class C00031 extends BroadcastReceiver {
        /* renamed from: a */
        final /* synthetic */ Actions f17a;

        C00031(Actions actions) {
            this.f17a = actions;
        }

        public synchronized void onReceive(Context context, Intent intent) {
            int i = R.string.MES_ADD_TO_ARCHIVE;
            AskOverwriteInfo askOverwriteInfo = null;
            synchronized (this) {
                if (!(this.f17a.mZA == null || intent == null || intent.getExtras() == null || this.f17a.mCS == null)) {
                    Bundle extras = intent.getExtras();
                    int i2 = extras.getInt("iTaskID");
                    int i3 = extras.getInt("iTaskType");
                    ZProgDialog zProgDialog;
                    switch (extras.getInt("iAction")) {
                        case 1:
                            if (this.f17a.mCS.m398a(i2, 2) == null) {
                                switch (i3) {
                                    case -127:
                                    case 1:
                                    case 5:
                                        i = R.string.MES_DECOMPRESS_FILE_PROCESS;
                                        break;
                                    case -121:
                                    case ZArchiverExtInterface.COMPRESSION_LAVEL_MAX /*7*/:
                                    case 12:
                                        break;
                                    case -117:
                                    case 11:
                                        i = R.string.MES_TEST_FILE_PROCESS;
                                        break;
                                    case 4:
                                        i = R.string.MES_COPY_FILE;
                                        break;
                                    case Actions.CHECK_ACTION_RENAME /*6*/:
                                        i = R.string.MES_REMOVE_FILE;
                                        break;
                                    case ViewDragHelper.EDGE_BOTTOM /*8*/:
                                        i = R.string.MES_DEL_FROM_ARCHIVE;
                                        break;
                                    case 9:
                                        i = R.string.MES_MOVE_FILE;
                                        break;
                                    case 10:
                                        i = R.string.MES_MOVE_FILE;
                                        break;
                                    default:
                                        i = R.string.MES_COMPRESS_FILE_PROCESS;
                                        break;
                                }
                                ZDialog zProgDialog2 = new ZProgDialog(this.f17a.mCS, this.f17a.mZA, i);
                                zProgDialog2.setTaskID(i2);
                                zProgDialog2.setOnOkListener(this.f17a);
                                zProgDialog2.setOnCancelListener(this.f17a);
                                zProgDialog2.show();
                                break;
                            }
                            break;
                        case 2:
                            this.f17a.mCS.m402a(i2, extras.getInt("iDialogType", 2), -1);
                            break;
                        case 3:
                            zProgDialog = (ZProgDialog) this.f17a.mCS.m398a(i2, 2);
                            if (zProgDialog != null) {
                                zProgDialog.setText(extras.getString("sText"));
                                break;
                            }
                            break;
                        case 4:
                            zProgDialog = (ZProgDialog) this.f17a.mCS.m398a(i2, 2);
                            if (zProgDialog != null) {
                                zProgDialog.setProgress(extras.getInt("iProgress", 0));
                                break;
                            }
                            break;
                        case 5:
                            if (((ZEnterPwdDialog) this.f17a.mCS.m398a(i2, 12)) == null) {
                                ZEnterPwdDialog zEnterPwdDialog = new ZEnterPwdDialog(this.f17a.mCS, this.f17a.mZA);
                                zEnterPwdDialog.setTaskID(i2);
                                zEnterPwdDialog.setOnOkListener(this.f17a);
                                zEnterPwdDialog.setOnCancelListener(this.f17a);
                                zEnterPwdDialog.show();
                                break;
                            }
                            break;
                        case Actions.CHECK_ACTION_RENAME /*6*/:
                            if (!this.f17a.mCS.f356g) {
                                this.f17a.mZA.onUpdateList(true);
                                break;
                            } else {
                                this.f17a.mZA.onCheckSearchResult();
                                break;
                            }
                        case ViewDragHelper.EDGE_BOTTOM /*8*/:
                            try {
                                askOverwriteInfo = this.f17a.mService.GetAskOverwrite(i2);
                            } catch (Throwable e) {
                                C0166c.m556a(e);
                            }
                            if (askOverwriteInfo != null) {
                                if (((ZAskOverwriteDialog) this.f17a.mCS.m398a(i2, 9)) == null) {
                                    ZAskOverwriteDialog zAskOverwriteDialog = new ZAskOverwriteDialog(this.f17a.mCS, this.f17a.mZA, askOverwriteInfo);
                                    zAskOverwriteDialog.setTaskID(i2);
                                    zAskOverwriteDialog.setOnOkListener(this.f17a);
                                    zAskOverwriteDialog.setOnCancelListener(this.f17a);
                                    zAskOverwriteDialog.show();
                                    break;
                                }
                            }
                            break;
                        case 11:
                            this.f17a.mZA.setComment(extras.getBoolean("bState", false));
                            break;
                        case ViewDragHelper.EDGE_ALL /*15*/:
                            if ((i3 & -128) == -128) {
                                zProgDialog = (ZProgDialog) this.f17a.mCS.m398a(i2, 2);
                                if (zProgDialog != null) {
                                    zProgDialog.setCaption(extras.getString("sText"));
                                    break;
                                }
                            }
                            break;
                        case 18:
                            switch (extras.getInt("iType")) {
                                case 1:
                                    if (this.f17a.mLastToastMessage != null) {
                                        this.f17a.mLastToastMessage.cancel();
                                    }
                                    this.f17a.mLastToastMessage = Toast.makeText(this.f17a.mZA, extras.getString("sText"), 0);
                                    this.f17a.mLastToastMessage.show();
                                    break;
                                case 2:
                                    this.f17a.mLastToastMessage = null;
                                    Toast.makeText(this.f17a.mZA, extras.getString("sText"), 0).show();
                                    if (this.f17a.mZA != null) {
                                        this.f17a.mZA.onOperationComplete(true);
                                        break;
                                    }
                                    break;
                                default:
                                    this.f17a.mLastToastMessage = null;
                                    Toast.makeText(this.f17a.mZA, extras.getString("sText"), 0).show();
                                    break;
                            }
                        case 19:
                            File file = new File("sFilePath");
                            if (file.exists() && !extras.getBoolean("bEditFile")) {
                                file.setReadOnly();
                            }
                            if (extras.getBoolean("bEditFile") || extras.getBoolean("bProtectFile")) {
                                this.f17a.mArchiveFileOpen = extras.getString("sFilePath");
                                Intent a = C0202q.m723a(this.f17a.mArchiveFileOpen, extras.getBoolean("bOpenAs"));
                                List queryIntentActivities;
                                try {
                                    queryIntentActivities = this.f17a.mZA.getPackageManager().queryIntentActivities(a, 0);
                                    Intent createChooser = (queryIntentActivities == null || queryIntentActivities.size() <= 1) ? Intent.createChooser(a, "") : a;
                                    this.f17a.mZA.startActivity(createChooser);
                                } catch (Exception e2) {
                                    try {
                                        a.setType("*/*");
                                        queryIntentActivities = this.f17a.mZA.getPackageManager().queryIntentActivities(a, 0);
                                        if (queryIntentActivities == null || queryIntentActivities.size() <= 1) {
                                            a = Intent.createChooser(a, "");
                                        }
                                        this.f17a.mZA.startActivity(a);
                                    } catch (Throwable e3) {
                                        C0166c.m556a(e3);
                                    }
                                }
                            } else if (extras.getBoolean("bOpenAs")) {
                                C0202q.m742c(this.f17a.mZA, extras.getString("sFilePath"));
                            } else {
                                C0202q.m739b(this.f17a.mZA, extras.getString("sFilePath"));
                            }
                            this.f17a.mZA.startClearTempService();
                            break;
                        case 20:
                            if (this.f17a.mArchiveFileOpen != null && this.f17a.mArchiveFileOpen.length() > 0 && this.f17a.mArchiveFileOpen.endsWith("/" + extras.getString("sFilePath"))) {
                                new File(this.f17a.mArchiveFileOpen + ".hash").delete();
                                new File(this.f17a.mArchiveFileOpen).delete();
                                this.f17a.mArchiveFileOpen = "";
                                break;
                            }
                        case 21:
                            new ZMessageDialog(this.f17a.mCS, this.f17a.mZA, (byte) 4, extras.getString("sText")).show();
                            break;
                        default:
                            break;
                    }
                }
            }
        }
    }

    /* renamed from: ru.zdevs.zarchiver.Actions$a */
    private class C0005a extends AsyncTask<Void, Void, String> {
        /* renamed from: a */
        final /* synthetic */ Actions f19a;
        /* renamed from: b */
        private final Uri f20b;
        /* renamed from: c */
        private final Context f21c;

        /* renamed from: ru.zdevs.zarchiver.Actions$a$1 */
        class C00041 implements OnCancelListener {
            /* renamed from: a */
            final /* synthetic */ C0005a f18a;

            C00041(C0005a c0005a) {
                this.f18a = c0005a;
            }

            public void onCancel(ZDialog zDialog) {
                this.f18a.f19a.mZA.finish();
            }
        }

        C0005a(Actions actions, Context context, Uri uri) {
            this.f19a = actions;
            this.f20b = uri;
            this.f21c = context;
        }

        /* renamed from: a */
        protected String m19a(Void... voidArr) {
            String uri = this.f20b.toString();
            if (uri == null) {
                return null;
            }
            File a = C0185k.m653a(this.f21c, this.f20b);
            if (a != null) {
                return a.getAbsolutePath();
            }
            String str = "\"*+,:;<=>?\\[]|";
            str = uri.replace("content://", "/uri/");
            for (int i = 0; i < "\"*+,:;<=>?\\[]|".length(); i++) {
                str = str.replace(String.valueOf("\"*+,:;<=>?\\[]|".charAt(i)), String.format(Locale.ENGLISH, "$%02d", new Object[]{Integer.valueOf(i)}));
            }
            return str.replace("%2F", "%2F/").replace("%3A", "%3A/");
        }

        /* renamed from: a */
        protected void m20a(String str) {
            if (str != null) {
                try {
                    if (str.length() > 0) {
                        this.f19a.mZA.setCurrentPath(new MyUri(FSArchive.SCHEME, "", str, "/"));
                        this.f19a.mCS.m417m();
                    }
                } catch (Throwable e) {
                    C0166c.m556a(e);
                }
            }
            try {
                if (this.f19a.mCS != null) {
                    ZDialog b = this.f19a.mCS.m405b(-1, 1, 18);
                    if (b != null) {
                        b.close();
                    }
                }
            } catch (Throwable e2) {
                C0166c.m556a(e2);
            }
        }

        protected /* synthetic */ Object doInBackground(Object[] objArr) {
            return m19a((Void[]) objArr);
        }

        protected /* synthetic */ void onPostExecute(Object obj) {
            m20a((String) obj);
        }

        protected void onPreExecute() {
            ZProcDialog zProcDialog = new ZProcDialog(this.f19a.mCS, this.f19a.mZA, R.string.MES_WHITE_START_SERVICE);
            zProcDialog.setSubType(18);
            zProcDialog.setOnCancelListener(new C00041(this));
            zProcDialog.show();
        }
    }

    /* renamed from: ru.zdevs.zarchiver.Actions$b */
    private class C0007b extends AsyncTask<Void, Void, Boolean> {
        /* renamed from: a */
        final /* synthetic */ Actions f23a;
        /* renamed from: b */
        private final Context f24b;
        /* renamed from: c */
        private final Intent f25c;
        /* renamed from: d */
        private final boolean f26d;

        /* renamed from: ru.zdevs.zarchiver.Actions$b$1 */
        class C00061 implements OnCancelListener {
            /* renamed from: a */
            final /* synthetic */ C0007b f22a;

            C00061(C0007b c0007b) {
                this.f22a = c0007b;
            }

            public void onCancel(ZDialog zDialog) {
                this.f22a.f23a.mZA.finish();
            }
        }

        C0007b(Actions actions, Context context, Intent intent, boolean z) {
            this.f23a = actions;
            this.f25c = intent;
            this.f24b = context;
            this.f26d = z;
        }

        /* renamed from: a */
        protected Boolean m21a(Void... voidArr) {
            File a;
            ArrayList arrayList;
            int i = 0;
            ArrayList arrayList2;
            if ("android.intent.action.SEND".equals(this.f25c.getAction())) {
                arrayList2 = new ArrayList();
                Parcelable parcelableExtra = this.f25c.getParcelableExtra("android.intent.extra.STREAM");
                if (parcelableExtra != null && (parcelableExtra instanceof Uri)) {
                    a = C0185k.m653a(this.f24b, (Uri) parcelableExtra);
                    if (a != null) {
                        arrayList2.add(a);
                    }
                }
                arrayList = arrayList2;
            } else if ("android.intent.action.SEND_MULTIPLE".equals(this.f25c.getAction())) {
                arrayList2 = new ArrayList();
                arrayList = this.f25c.getParcelableArrayListExtra("android.intent.extra.STREAM");
                if (arrayList != null && arrayList.size() > 0 && (arrayList.get(0) instanceof Uri)) {
                    Iterator it = arrayList.iterator();
                    while (it.hasNext()) {
                        a = C0185k.m653a(this.f24b, (Uri) ((Parcelable) it.next()));
                        if (a != null) {
                            arrayList2.add(a);
                        }
                    }
                }
                arrayList = arrayList2;
            } else {
                arrayList = null;
            }
            if (arrayList == null || arrayList.size() <= 0) {
                return Boolean.valueOf(false);
            }
            this.f23a.mFileListAction = new String[arrayList.size()];
            this.f23a.mFileListActionPathS = new MyUri[arrayList.size()];
            this.f23a.mFileListActionPath = null;
            Iterator it2 = arrayList.iterator();
            while (it2.hasNext()) {
                a = (File) it2.next();
                this.f23a.mFileListAction[i] = a.getName();
                this.f23a.mFileListActionPathS[i] = new MyUri(FSLocal.SCHEME, a.getParent());
                i++;
            }
            return Boolean.valueOf(true);
        }

        /* renamed from: a */
        protected void m22a(Boolean bool) {
            try {
                if (this.f23a.mCS != null) {
                    ZDialog b = this.f23a.mCS.m405b(-1, 1, 18);
                    if (b != null) {
                        b.close();
                    }
                }
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
            if (bool.booleanValue()) {
                try {
                    if (this.f23a.mCS != null) {
                        this.f23a.mCS.m403a(new MyUri(FSLocal.SCHEME, this.f23a.mFileListActionPathS[0].getPath()));
                        ((ZArchiver) this.f24b).onUpdateList(true);
                    }
                } catch (Throwable e2) {
                    C0166c.m556a(e2);
                }
                this.f23a.onMenuSelect((ZArchiver) this.f24b, 7);
                return;
            }
            Toast.makeText(this.f24b, R.string.ERROR_DATA_ERROR, 0).show();
            if (this.f26d) {
                ((ZArchiver) this.f24b).finish();
            }
        }

        protected /* synthetic */ Object doInBackground(Object[] objArr) {
            return m21a((Void[]) objArr);
        }

        protected /* synthetic */ void onPostExecute(Object obj) {
            m22a((Boolean) obj);
        }

        protected void onPreExecute() {
            ZProcDialog zProcDialog = new ZProcDialog(this.f23a.mCS, this.f23a.mZA, R.string.MES_WHITE_START_SERVICE);
            zProcDialog.setSubType(18);
            zProcDialog.setOnCancelListener(new C00061(this));
            zProcDialog.show();
        }
    }

    public Actions(C0136e c0136e) {
        this.mCS = c0136e;
        this.mLastToastMessage = null;
    }

    private boolean archiveExtract(String str, boolean z, boolean z2) {
        return (this.mFileListActionPath == null && this.mFileListActionPathS == null) ? false : archiveExtract(0, str, z, z2);
    }

    private void archiveNew(String str, boolean z) {
        if (this.mZA != null && this.mFileListActionPath != null && this.mFileListActionPath.isStorage()) {
            StringBuilder stringBuilder = new StringBuilder();
            String str2 = this.mFileListAction.length == 1 ? this.mFileListAction[0] + "." + str : this.mFileListActionPath.getName() + "." + str;
            if (str.equals(ZArchiverExtInterface.ARCHIVE_TYPE_ZIP)) {
                stringBuilder.append("\\-mx=").append(Settings.sLevelZip);
            } else if (str.equals(ZArchiverExtInterface.ARCHIVE_TYPE_7Z)) {
                stringBuilder.append("\\-mx=").append(Settings.sLevel7z);
                if ((Settings.s7zOptions & 1) == 0) {
                    stringBuilder.append("\\-m0=LZMA");
                }
                if ((Settings.s7zOptions & 2) != 0) {
                    stringBuilder.append("\\-ms=").append(C0071e.m292b()).append('m');
                } else {
                    stringBuilder.append("\\-ms=off");
                }
                stringBuilder.append("\\-mf=off");
                int c = C0071e.m294c();
                if (c > 0) {
                    stringBuilder.append("\\-md=").append(c).append("m");
                }
            }
            archiveNew(str, stringBuilder.toString(), str2, z, (byte) 0, false);
        }
    }

    private boolean archiveNew(String str, String str2, String str3, boolean z, byte b, boolean z2) {
        if (this.mFileListAction == null) {
            return false;
        }
        r4 = !str3.startsWith("/") ? Settings.sArchiveDir != null ? Settings.sArchiveDir + "/" + str3 : this.mFileListActionPath != null ? this.mFileListActionPath.toLocalPath() + "/" + str3 : this.mCS.m412h() + "/" + str3 : str3;
        return archiveNew(0, str, str2, r4, z, b, z2);
    }

    private boolean archiveNewFolder(String str, String str2, String str3) {
        if (this.mService == null) {
            return false;
        }
        StringBuilder stringBuilder = new StringBuilder();
        if (C0061a.m223i(str) && C0072g.m300a(str)) {
            stringBuilder.append("\\-p").append(C0072g.m297a(str, true));
            if (C0072g.m301a(str, 1)) {
                stringBuilder.append("\\-mhe");
            }
        }
        if (str2.length() > 0 && str2.charAt(0) == '/') {
            str2 = str2.substring(1);
        }
        if (str2.length() > 0) {
            stringBuilder.append("\\-spp").append(str2).append('/');
        }
        if (C0061a.m207a(str, true) && Settings.sCPUCoreN != null) {
            stringBuilder.append("\\-mmt=").append(Settings.sCPUCoreN);
        }
        String substring = str.substring(str.lastIndexOf(47) + 1);
        boolean z = Settings.sRoot && C0073a.m304f();
        int i = (z && C0200o.m709a(this.mZA, new MyUri(str)) == (byte) 2) ? 1 : 0;
        try {
            this.mService.ArchiveCreateFolder(substring, str, stringBuilder.toString(), str3, i);
            return true;
        } catch (Throwable e) {
            C0166c.m556a(e);
            return false;
        }
    }

    private boolean archiveOpenFile(boolean z) {
        if (this.mService == null) {
            return false;
        }
        if (this.mFileListActionPath != null && !this.mFileListActionPath.isArchive()) {
            return false;
        }
        if (this.mFileListActionPathS != null && (this.mFileListActionPathS.length != 1 || !this.mFileListActionPathS[0].isArchive())) {
            return false;
        }
        if (this.mFileListActionPath == null && this.mFileListActionPathS == null) {
            return false;
        }
        String str;
        MyUri myUri = this.mFileListActionPath != null ? this.mFileListActionPath : this.mFileListActionPathS[0];
        String fragment = myUri.getFragment();
        if (fragment.length() > 0 && fragment.charAt(0) == '/') {
            fragment = fragment.substring(1, fragment.length());
        }
        if (fragment.endsWith("/")) {
            fragment = fragment.substring(0, fragment.length() - 1);
        }
        StringBuilder stringBuilder = new StringBuilder();
        if (C0061a.m207a(myUri.getPath(), true) && Settings.sCPUCoreN != null) {
            stringBuilder.append("\\-mmt=").append(Settings.sCPUCoreN);
        }
        if (C0072g.m300a(myUri.getPath())) {
            stringBuilder.append("\\-p").append(C0072g.m298a(true));
        }
        if (fragment.length() > 0) {
            stringBuilder.append("\\-z").append(fragment);
            str = fragment + "/" + this.mFileListAction[0];
        } else {
            str = this.mFileListAction[0];
        }
        int i = z ? 8 : 0;
        boolean z2 = Settings.sRoot && C0073a.m304f();
        int i2 = (z2 && C0200o.m711a(this.mFileListActionPath.getPath()) == (byte) 2) ? i | 1 : i;
        try {
            this.mService.ArchiveOpenFile(this.mFileListAction[0], this.mFileListActionPath.getPath(), stringBuilder.toString(), str, C0202q.m727a(this.mZA), i2);
            return true;
        } catch (Throwable e) {
            C0166c.m556a(e);
            return false;
        }
    }

    private boolean archiveRemoveFiles() {
        if (this.mService == null) {
            return false;
        }
        if (this.mFileListActionPath != null && !this.mFileListActionPath.isArchive()) {
            return false;
        }
        if (this.mFileListActionPathS != null && !this.mFileListActionPathS[0].isArchive()) {
            return false;
        }
        if (this.mFileListActionPath == null && this.mFileListActionPathS == null) {
            return false;
        }
        String fragment;
        String path = this.mFileListActionPath != null ? this.mFileListActionPath.getPath() : this.mFileListActionPathS[0].getPath();
        StringBuilder stringBuilder = new StringBuilder();
        if (this.mFileListActionPath != null) {
            String fragment2 = this.mFileListActionPath.getFragment();
            if (fragment2.length() > 0 && fragment2.charAt(0) == '/') {
                fragment2 = fragment2.substring(1);
            }
            if (fragment2.length() > 0 && !fragment2.endsWith("/")) {
                fragment2 = fragment2 + "/";
            }
            for (String append : this.mFileListAction) {
                stringBuilder.append("\\").append(fragment2).append(append);
            }
        } else {
            for (int i = 0; i < this.mFileListActionPathS.length; i++) {
                fragment = this.mFileListActionPathS[i].getFragment();
                if (fragment.length() > 0 && fragment.charAt(0) == '/') {
                    fragment = fragment.substring(1);
                }
                if (fragment.length() > 0 && !fragment.endsWith("/")) {
                    fragment = fragment + "/";
                }
                stringBuilder.append("\\").append(fragment).append(this.mFileListAction[i]);
            }
        }
        StringBuilder stringBuilder2 = new StringBuilder();
        if (C0061a.m223i(path) && C0072g.m300a(path)) {
            stringBuilder2.append("\\-p").append(C0072g.m297a(path, true));
            if (C0072g.m301a(path, 1)) {
                stringBuilder2.append("\\-mhe");
            }
        }
        if (C0061a.m207a(path, true) && Settings.sCPUCoreN != null) {
            stringBuilder2.append("\\-mmt=").append(Settings.sCPUCoreN);
        }
        fragment = path.substring(path.lastIndexOf(47) + 1);
        boolean z = Settings.sRoot && C0073a.m304f();
        int i2 = (z && C0200o.m709a(this.mZA, new MyUri(path)) == (byte) 2) ? 1 : 0;
        try {
            this.mService.ArchiveDelFiles(fragment, path, stringBuilder2.toString(), stringBuilder.toString(), i2);
            return true;
        } catch (Throwable e) {
            C0166c.m556a(e);
            return false;
        }
    }

    private boolean archiveRenameFile(String str, String str2, String str3) {
        if (this.mService == null) {
            return false;
        }
        StringBuilder stringBuilder = new StringBuilder();
        if (C0061a.m223i(str) && C0072g.m300a(str)) {
            stringBuilder.append("\\-p").append(C0072g.m297a(str, true));
            if (C0072g.m301a(str, 1)) {
                stringBuilder.append("\\-mhe");
            }
        }
        if (C0061a.m207a(str, true) && Settings.sCPUCoreN != null) {
            stringBuilder.append("\\-mmt=").append(Settings.sCPUCoreN);
        }
        String substring = str.substring(str.lastIndexOf(47) + 1);
        String substring2 = str2.startsWith("/") ? str2.substring(1) : str2;
        String substring3 = str3.startsWith("/") ? str3.substring(1) : str3;
        boolean z = Settings.sRoot && C0073a.m304f();
        int i = (z && C0200o.m709a(this.mZA, new MyUri(str)) == (byte) 2) ? 1 : 0;
        try {
            this.mService.ArchiveRenFile(substring, str, stringBuilder.toString(), substring2, substring3, i);
            return true;
        } catch (Throwable e) {
            C0166c.m556a(e);
            return false;
        }
    }

    private void archiveUpdateFile(String str) {
        Throwable e;
        String str2;
        String str3;
        String str4 = null;
        File file = new File(str + ".hash");
        if (file.exists()) {
            String readLine;
            String readLine2;
            String str5;
            File file2;
            MyUri myUri;
            String str6 = "";
            try {
                Reader fileReader = new FileReader(file);
                LineNumberReader lineNumberReader = new LineNumberReader(fileReader);
                lineNumberReader.readLine();
                readLine = lineNumberReader.readLine();
                try {
                    readLine2 = lineNumberReader.readLine();
                } catch (Exception e2) {
                    e = e2;
                    str6 = null;
                    str5 = null;
                    readLine2 = null;
                    C0166c.m556a(e);
                    str2 = str5;
                    str3 = readLine2;
                    readLine2 = readLine;
                    readLine = str3;
                    if (str6 != null) {
                    }
                    str4 = C0201p.m720a(new String(C0201p.m722a(str6)), "HelloCoolHacker!");
                    str6 = str2;
                    file2 = new File(str);
                    myUri = new MyUri(file2.getParentFile());
                    str5 = "";
                    str5 = str5 + "\\-p" + str4;
                    if (str6.charAt(0) == 'a') {
                        str5 = str5 + "\\-mhe";
                        C0072g.m299a(readLine2, str4, 1);
                    }
                    if (readLine != null) {
                    }
                    if (str4.length() > file2.getName().length()) {
                        str4 = str4.substring(0, str4.length() - file2.getName().length());
                    }
                    readLine = str4.endsWith("/") ? str4.length() <= 1 ? str4.substring(0, str4.length() - 1) : "" : str4;
                    archiveAddFiles(myUri, "\\" + file2.getName(), str5, readLine2, readLine);
                }
                try {
                    str5 = lineNumberReader.readLine();
                    try {
                        str6 = lineNumberReader.readLine();
                    } catch (Exception e3) {
                        e = e3;
                        str6 = null;
                        C0166c.m556a(e);
                        str2 = str5;
                        str3 = readLine2;
                        readLine2 = readLine;
                        readLine = str3;
                        if (str6 != null) {
                        }
                        str4 = C0201p.m720a(new String(C0201p.m722a(str6)), "HelloCoolHacker!");
                        str6 = str2;
                        file2 = new File(str);
                        myUri = new MyUri(file2.getParentFile());
                        str5 = "";
                        str5 = str5 + "\\-p" + str4;
                        if (str6.charAt(0) == 'a') {
                            str5 = str5 + "\\-mhe";
                            C0072g.m299a(readLine2, str4, 1);
                        }
                        if (readLine != null) {
                        }
                        if (str4.length() > file2.getName().length()) {
                            str4 = str4.substring(0, str4.length() - file2.getName().length());
                        }
                        if (str4.endsWith("/")) {
                            if (str4.length() <= 1) {
                            }
                        }
                        archiveAddFiles(myUri, "\\" + file2.getName(), str5, readLine2, readLine);
                    }
                    try {
                        lineNumberReader.close();
                        fileReader.close();
                        str2 = str5;
                        str3 = readLine2;
                        readLine2 = readLine;
                        readLine = str3;
                    } catch (Exception e4) {
                        e = e4;
                        C0166c.m556a(e);
                        str2 = str5;
                        str3 = readLine2;
                        readLine2 = readLine;
                        readLine = str3;
                        if (str6 != null) {
                        }
                        str4 = C0201p.m720a(new String(C0201p.m722a(str6)), "HelloCoolHacker!");
                        str6 = str2;
                        file2 = new File(str);
                        myUri = new MyUri(file2.getParentFile());
                        str5 = "";
                        str5 = str5 + "\\-p" + str4;
                        if (str6.charAt(0) == 'a') {
                            str5 = str5 + "\\-mhe";
                            C0072g.m299a(readLine2, str4, 1);
                        }
                        if (readLine != null) {
                        }
                        if (str4.length() > file2.getName().length()) {
                            str4 = str4.substring(0, str4.length() - file2.getName().length());
                        }
                        if (str4.endsWith("/")) {
                            if (str4.length() <= 1) {
                            }
                        }
                        archiveAddFiles(myUri, "\\" + file2.getName(), str5, readLine2, readLine);
                    }
                } catch (Exception e5) {
                    e = e5;
                    str6 = null;
                    str5 = null;
                    C0166c.m556a(e);
                    str2 = str5;
                    str3 = readLine2;
                    readLine2 = readLine;
                    readLine = str3;
                    if (str6 != null) {
                    }
                    str4 = C0201p.m720a(new String(C0201p.m722a(str6)), "HelloCoolHacker!");
                    str6 = str2;
                    file2 = new File(str);
                    myUri = new MyUri(file2.getParentFile());
                    str5 = "";
                    str5 = str5 + "\\-p" + str4;
                    if (str6.charAt(0) == 'a') {
                        str5 = str5 + "\\-mhe";
                        C0072g.m299a(readLine2, str4, 1);
                    }
                    if (readLine != null) {
                    }
                    if (str4.length() > file2.getName().length()) {
                        str4 = str4.substring(0, str4.length() - file2.getName().length());
                    }
                    if (str4.endsWith("/")) {
                    }
                    archiveAddFiles(myUri, "\\" + file2.getName(), str5, readLine2, readLine);
                }
            } catch (Exception e6) {
                e = e6;
                str5 = null;
                readLine2 = null;
                readLine = str6;
                str6 = null;
                C0166c.m556a(e);
                str2 = str5;
                str3 = readLine2;
                readLine2 = readLine;
                readLine = str3;
                if (str6 != null) {
                }
                str4 = C0201p.m720a(new String(C0201p.m722a(str6)), "HelloCoolHacker!");
                str6 = str2;
                file2 = new File(str);
                myUri = new MyUri(file2.getParentFile());
                str5 = "";
                str5 = str5 + "\\-p" + str4;
                if (str6.charAt(0) == 'a') {
                    str5 = str5 + "\\-mhe";
                    C0072g.m299a(readLine2, str4, 1);
                }
                if (readLine != null) {
                }
                if (str4.length() > file2.getName().length()) {
                    str4 = str4.substring(0, str4.length() - file2.getName().length());
                }
                if (str4.endsWith("/")) {
                }
                archiveAddFiles(myUri, "\\" + file2.getName(), str5, readLine2, readLine);
            }
            if (str6 != null || (str6.length() > 0 && !str6.equals("---"))) {
                str4 = C0201p.m720a(new String(C0201p.m722a(str6)), "HelloCoolHacker!");
                str6 = str2;
            } else {
                str6 = null;
            }
            file2 = new File(str);
            myUri = new MyUri(file2.getParentFile());
            str5 = "";
            if (!(!C0061a.m223i(readLine2) || str4 == null || str6 == null)) {
                str5 = str5 + "\\-p" + str4;
                if (str6.charAt(0) == 'a') {
                    str5 = str5 + "\\-mhe";
                    if (!(this.mZA == null || C0072g.m300a(readLine2))) {
                        C0072g.m299a(readLine2, str4, 1);
                    }
                }
            }
            str4 = (readLine != null || readLine.length() <= file2.getName().length()) ? "" : readLine;
            if (str4.length() > file2.getName().length()) {
                str4 = str4.substring(0, str4.length() - file2.getName().length());
            }
            if (str4.endsWith("/")) {
                if (str4.length() <= 1) {
                }
            }
            archiveAddFiles(myUri, "\\" + file2.getName(), str5, readLine2, readLine);
        }
    }

    private void clearActionBuf() {
        this.mFileListAction = null;
        this.mFileListActionPath = null;
        this.mFileListActionPathS = null;
    }

    private void clearCopyBuf() {
        this.mFileListCopy = null;
        this.mFileListCopyPath = null;
        this.mFileListCopyCut = false;
        this.mFileListCopyPathS = null;
    }

    private boolean fileRemove() {
        if (this.mService == null || this.mFileListAction == null) {
            return false;
        }
        if (this.mFileListActionPath != null && !this.mFileListActionPath.isStorage()) {
            return false;
        }
        if (this.mFileListActionPathS != null && !this.mFileListActionPathS[0].isStorage()) {
            return false;
        }
        if (this.mFileListActionPath == null && this.mFileListActionPathS == null) {
            return false;
        }
        List list;
        String str;
        boolean z;
        boolean z2 = Settings.sRoot && C0073a.m304f();
        if (this.mFileListActionPath != null) {
            List asList = Arrays.asList(this.mFileListAction);
            String toLocalPath = this.mFileListActionPath.toLocalPath();
            if (z2 && C0200o.m709a(this.mZA, this.mFileListActionPath) == (byte) 2) {
                list = asList;
                str = toLocalPath;
                z = true;
            } else {
                list = asList;
                str = toLocalPath;
                z = false;
            }
        } else {
            List arrayList = new ArrayList();
            String str2 = "";
            int i = 0;
            z = false;
            while (i < this.mFileListAction.length) {
                arrayList.add(this.mFileListActionPathS[i].toLocalPath() + "/" + this.mFileListAction[i]);
                if (z2 && !r4 && C0200o.m709a(this.mZA, this.mFileListActionPathS[i]) == (byte) 2) {
                    z = true;
                }
                i++;
            }
            list = arrayList;
            str = str2;
        }
        int i2 = this.mFileListActionPath == null ? 2 : 0;
        try {
            this.mService.Remove(str, list, z ? i2 | 1 : i2);
            return true;
        } catch (Throwable e) {
            C0166c.m556a(e);
            return false;
        }
    }

    public void archiveAddFiles() {
        if (this.mCS.m408d() && this.mFileListAction != null) {
            if (this.mFileListActionPath != null && !this.mFileListActionPath.isStorage()) {
                return;
            }
            if (this.mFileListActionPathS != null && !this.mFileListActionPathS[0].isStorage()) {
                return;
            }
            if (this.mFileListActionPath != null || this.mFileListActionPathS != null) {
                List list;
                List asList;
                if (this.mFileListActionPath != null || this.mFileListActionPathS == null) {
                    list = null;
                } else {
                    asList = Arrays.asList(this.mFileListActionPathS);
                    Collections.sort(asList);
                    int i = 1;
                    while (i < asList.size()) {
                        if (((MyUri) asList.get(i - 1)).compareTo((MyUri) asList.get(i)) == 0) {
                            asList.remove(i);
                        } else {
                            i++;
                        }
                    }
                    if (asList.size() == 1) {
                        this.mFileListActionPath = (MyUri) asList.get(0);
                        this.mFileListActionPathS = null;
                    }
                    list = asList;
                }
                if (this.mFileListActionPath != null) {
                    archiveAddFiles(this.mFileListActionPath, C0071e.m290a(this.mFileListAction), "", this.mCS.m411g().getPath(), this.mCS.m411g().getFragment());
                } else if (list != null) {
                    String fragment = this.mCS.m411g().getFragment();
                    StringBuilder stringBuilder = new StringBuilder();
                    if (C0061a.m217e(fragment)) {
                        stringBuilder.append("\\-mf=off");
                    }
                    if (fragment.length() > 0 && fragment.charAt(0) == '/') {
                        fragment = fragment.substring(1);
                    }
                    if (fragment.length() > 0) {
                        stringBuilder.append("\\-spp").append(fragment).append('/');
                    }
                    String path = this.mCS.m411g().getPath();
                    if (C0202q.m743d(path).length() < 1) {
                        fragment = C0061a.m215d(path);
                        if (fragment != null && fragment.length() > 0) {
                            stringBuilder.append("\\-t").append(fragment).append('/');
                        }
                    }
                    if (this.mZA != null) {
                        try {
                            if (C0072g.m300a(path) && C0072g.m301a(path, 1)) {
                                stringBuilder.append("\\-p").append(C0072g.m297a(path, true)).append("\\-mhe");
                            }
                        } catch (Throwable e) {
                            C0166c.m556a(e);
                        }
                    }
                    if (C0061a.m207a(path, true) && Settings.sCPUCoreN != null) {
                        stringBuilder.append("\\-mmt=").append(Settings.sCPUCoreN);
                    }
                    String substring = path.substring(path.lastIndexOf(47) + 1);
                    asList = new ArrayList();
                    List arrayList = new ArrayList();
                    for (int i2 = 0; i2 < list.size(); i2++) {
                        StringBuilder stringBuilder2 = new StringBuilder();
                        for (int i3 = 0; i3 < this.mFileListActionPathS.length; i3++) {
                            if (this.mFileListActionPathS[i3].compareTo((MyUri) list.get(i2)) == 0) {
                                stringBuilder2.append('\\').append(this.mFileListAction[i3]);
                            }
                        }
                        arrayList.add(((MyUri) list.get(i2)).toLocalPath());
                        asList.add(stringBuilder2.toString());
                    }
                    boolean z = Settings.sRoot && C0073a.m304f();
                    int i4 = (z && C0200o.m709a(this.mZA, new MyUri(path)) == (byte) 2) ? 1 : 0;
                    archiveAddFilesMulti(substring, path, stringBuilder.toString(), asList, arrayList, i4);
                }
            }
        }
    }

    public void archiveAddFiles(MyUri myUri, String str, String str2, String str3, String str4) {
        int i = 1;
        if (myUri.isStorage()) {
            String d;
            StringBuilder stringBuilder = new StringBuilder();
            if (C0061a.m217e(str4)) {
                stringBuilder.append("\\-mf=off");
            }
            if (str4.length() > 0 && str4.charAt(0) == '/') {
                str4 = str4.substring(1);
            }
            if (str4.length() > 0) {
                stringBuilder.append("\\-spp").append(str4).append('/');
            }
            if (C0061a.m207a(str3, true) && Settings.sCPUCoreN != null) {
                stringBuilder.append("\\-mmt=").append(Settings.sCPUCoreN);
            }
            if (C0202q.m743d(str3).length() < 1) {
                d = C0061a.m215d(str3);
                if (d != null && d.length() > 0) {
                    stringBuilder.append("\\-t").append(d);
                }
            }
            d = str3.substring(str3.lastIndexOf(47) + 1);
            if (str2 != null && str2.length() > 0) {
                stringBuilder.append(str2);
            }
            int i2 = (Settings.sRoot && C0073a.m304f()) ? 1 : 0;
            if (i2 == 0 || C0200o.m709a(this.mZA, new MyUri(str3)) != (byte) 2) {
                i = 0;
            }
            if (str2 != null) {
                try {
                    if (!(str2.contains("\\-p") || this.mZA == null)) {
                        try {
                            if (C0072g.m300a(str3) && C0072g.m301a(str3, 1)) {
                                stringBuilder.append("\\-p").append(C0072g.m297a(str3, true)).append("\\-mhe");
                            }
                        } catch (Throwable e) {
                            C0166c.m556a(e);
                        }
                    }
                } catch (Throwable e2) {
                    C0166c.m556a(e2);
                    return;
                }
            }
            C0166c.m558c(TAG, "archiveAddFiles: params = " + stringBuilder);
            this.mService.ArchiveAddFiles(d, str3, stringBuilder.toString(), str, myUri.toLocalPath(), i);
        }
    }

    public void archiveAddFilesMulti(String str, String str2, String str3, List<String> list, List<String> list2, int i) {
        try {
            this.mService.ArchiveAddFilesMulti(str, str2, str3, list, list2, i);
        } catch (Throwable e) {
            C0166c.m556a(e);
        }
    }

    protected boolean archiveExtract(int i, String str, boolean z, boolean z2) {
        if (this.mFileListActionPath == null && this.mFileListActionPathS == null) {
            return false;
        }
        List arrayList = new ArrayList();
        List arrayList2 = new ArrayList();
        List arrayList3 = new ArrayList();
        List arrayList4 = new ArrayList();
        Object obj = (Settings.sRoot && C0073a.m304f()) ? 1 : null;
        if (!(obj == null || z2 || C0200o.m708a(this.mZA, str) == (byte) 1)) {
            z2 = true;
        }
        Object obj2 = (this.mCS == null || !this.mCS.m408d()) ? 1 : null;
        Object obj3 = obj2;
        for (int i2 = 0; i2 < this.mFileListAction.length; i2++) {
            String str2 = this.mFileListAction[i2];
            String str3 = this.mFileListActionPathS != null ? this.mFileListActionPathS[i2].toLocalPath() + "/" + str2 : this.mFileListActionPath.toLocalPath() + "/" + str2;
            if (!(obj == null || z2 || C0200o.m711a(str3) != (byte) 2)) {
                z2 = true;
            }
            Object obj4 = "";
            if (C0061a.m207a(str2, true) && Settings.sCPUCoreN != null) {
                obj4 = "\\-mmt=" + Settings.sCPUCoreN;
            }
            if (C0072g.m300a(str2)) {
                obj4 = obj4 + "\\-p" + C0072g.m298a(true);
            }
            if (!(obj3 == null || C0061a.m217e(str2) || C0061a.m221g(str2) || C0061a.m222h(str2))) {
                obj3 = null;
            }
            arrayList.add(str3);
            arrayList2.add(str2);
            arrayList3.add(obj4);
            if (z) {
                arrayList4.add(str + "/" + C0202q.m737b(str2));
            } else {
                arrayList4.add(str);
            }
        }
        if (obj3 != null) {
            C0061a.m216e();
        }
        int i3 = 0;
        if (z2) {
            i3 = 1;
        }
        try {
            if (this.mFileListAction.length == 1) {
                this.mService.ArchiveExtract(i, (String) arrayList2.get(0), (String) arrayList.get(0), (String) arrayList3.get(0), "", z ? str + "/" + C0202q.m737b((String) arrayList2.get(0)) : str, i3);
            } else {
                this.mService.ArchiveExtractMulti(i, arrayList2, arrayList, arrayList3, null, arrayList4, i3);
            }
            return true;
        } catch (Throwable e) {
            C0166c.m556a(e);
            return false;
        }
    }

    public boolean archiveExtractFiles(String str, boolean z) {
        if (this.mService == null) {
            return false;
        }
        if (this.mFileListActionPath != null && !this.mFileListActionPath.isArchive()) {
            return false;
        }
        if (this.mFileListActionPathS != null && !this.mFileListActionPathS[0].isArchive()) {
            return false;
        }
        if (this.mFileListActionPath == null && this.mFileListActionPathS == null) {
            return false;
        }
        int i;
        int i2;
        if (this.mFileListActionPath != null) {
            this.mFileListActionPathS = new MyUri[1];
            this.mFileListActionPathS[0] = this.mFileListActionPath;
        }
        List arrayList = new ArrayList();
        for (MyUri path : this.mFileListActionPathS) {
            arrayList.add(path.getPath().substring(this.mFileListActionPathS[0].getPath().lastIndexOf("/") + 1));
        }
        StringBuilder stringBuilder = new StringBuilder();
        if (C0061a.m207a(this.mFileListActionPathS[0].getPath(), true) && Settings.sCPUCoreN != null) {
            stringBuilder.append("\\-mmt=").append(Settings.sCPUCoreN);
        }
        if (C0072g.m300a(this.mFileListActionPathS[0].getPath())) {
            stringBuilder.append("\\-p").append(C0072g.m298a(true));
        }
        String stringBuilder2 = stringBuilder.toString();
        List arrayList2 = new ArrayList();
        List arrayList3 = new ArrayList();
        for (MyUri fragment : this.mFileListActionPathS) {
            String fragment2 = fragment.getFragment();
            if (fragment2.length() > 0 && fragment2.charAt(0) == '/') {
                fragment2 = fragment2.substring(1, fragment2.length());
            }
            if (fragment2.equals("/")) {
                fragment2 = "";
            }
            if (fragment2.endsWith("/")) {
                fragment2 = fragment2.substring(0, fragment2.length() - 1);
            }
            if (fragment2.length() > 0) {
                arrayList3.add("-z" + fragment2 + stringBuilder2);
            } else {
                arrayList3.add(stringBuilder2);
            }
            arrayList2.add(fragment2);
        }
        List arrayList4 = new ArrayList();
        if (this.mFileListActionPath != null) {
            StringBuilder stringBuilder3 = new StringBuilder();
            fragment2 = (String) arrayList2.get(0);
            if (fragment2.length() > 0) {
                fragment2 = fragment2 + '/';
            }
            for (String str2 : this.mFileListAction) {
                stringBuilder3.append('\\');
                stringBuilder3.append(fragment2);
                stringBuilder3.append(str2);
            }
            arrayList4.add(stringBuilder3.toString());
        } else {
            for (i2 = 0; i2 < this.mFileListAction.length; i2++) {
                fragment2 = (String) arrayList2.get(i2);
                if (fragment2.length() > 0) {
                    arrayList4.add("\\" + fragment2 + "/" + this.mFileListAction[i2]);
                } else {
                    arrayList4.add("\\" + this.mFileListAction[i2]);
                }
            }
        }
        stringBuilder2 = this.mFileListActionPathS[0].getPath();
        if (this.mFileListActionPath != null) {
            this.mFileListActionPathS = null;
        }
        boolean z2 = Settings.sRoot && C0073a.m304f();
        boolean z3 = (!z2 || z || C0200o.m708a(this.mZA, str) == (byte) 1) ? z : true;
        if (z2 && !z3 && C0200o.m711a(stringBuilder2) == (byte) 2) {
            z3 = true;
        }
        if (this.mCS == null || !this.mCS.m408d()) {
            z2 = C0061a.m217e(stringBuilder2) || C0061a.m221g(stringBuilder2) || C0061a.m222h(stringBuilder2);
            if (z2) {
                C0061a.m216e();
            }
        }
        int i3 = z3 ? 1 : 0;
        try {
            if (arrayList4.size() == 1) {
                this.mService.ArchiveExtract(0, (String) arrayList.get(0), stringBuilder2, (String) arrayList3.get(0), (String) arrayList4.get(0), str, i3);
            } else {
                arrayList2 = new ArrayList();
                for (i = 0; i < arrayList3.size(); i++) {
                    arrayList2.add(str);
                }
                List arrayList5 = new ArrayList();
                for (i = 0; i < arrayList3.size(); i++) {
                    arrayList5.add(stringBuilder2);
                }
                this.mService.ArchiveExtractMulti(0, arrayList, arrayList5, arrayList3, arrayList4, arrayList2, i3);
            }
            return true;
        } catch (Throwable e) {
            C0166c.m556a(e);
            return false;
        }
    }

    protected boolean archiveNew(int i, String str, String str2, String str3, boolean z, byte b, boolean z2) {
        if (this.mFileListAction == null || ((this.mFileListActionPath == null || !this.mFileListActionPath.isStorage()) && (this.mFileListActionPathS == null || !this.mFileListActionPathS[0].isStorage()))) {
            return false;
        }
        List asList;
        if (str3.contains("/")) {
            Object substring = str3.substring(str3.lastIndexOf(47) + 1);
        } else {
            String str4 = str3;
        }
        if (i == 0) {
            C0204s c0204s = new C0204s(str3);
            if (c0204s.m756i()) {
                if (b == (byte) 1) {
                    C0061a.m216e();
                    c0204s.m758k();
                } else if (b == (byte) 0) {
                    if (this.mZA == null) {
                        return false;
                    }
                    ZMessageDialog zMessageDialog = new ZMessageDialog(this.mCS, this.mZA, (byte) 2, this.mZA.getString(R.string.MES_OVERWRITE_ARCHIVE).replace("%1", substring));
                    zMessageDialog.setSubType(17);
                    zMessageDialog.setOnOkListener(this.mCS.f350a);
                    zMessageDialog.setStringData(0, str);
                    zMessageDialog.setStringData(1, str2);
                    zMessageDialog.setStringData(2, str3);
                    zMessageDialog.setStringData(3, z ? "1" : "0");
                    zMessageDialog.setStringData(4, z2 ? "1" : "0");
                    zMessageDialog.show();
                    return true;
                } else if (b == (byte) 2 && C0061a.m213c(str3)) {
                    C0061a.m216e();
                }
            }
        }
        String toLocalPath = this.mFileListActionPath != null ? this.mFileListActionPath.toLocalPath() : this.mCS.m412h();
        Object obj = (Settings.sRoot && C0073a.m304f()) ? 1 : null;
        if (!(z2 || obj == null || !str3.startsWith("/"))) {
            if (C0200o.m708a(this.mZA, str3) != (byte) 1) {
                z2 = true;
            } else if (C0200o.m711a(toLocalPath) == (byte) 2) {
                z2 = true;
            }
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("-t").append(str).append(str2);
        if (this.mFileListActionPath != null) {
            asList = Arrays.asList(this.mFileListAction);
        } else {
            asList = new ArrayList();
            int length = toLocalPath.length();
            for (int i2 = 0; i2 < this.mFileListAction.length; i2++) {
                String toLocalPath2 = this.mFileListActionPathS[i2].toLocalPath();
                if (toLocalPath2 != null && toLocalPath2.length() >= length) {
                    StringBuilder stringBuilder2 = new StringBuilder();
                    if (toLocalPath2.length() == length) {
                        stringBuilder2.append("./");
                    } else {
                        stringBuilder2.append("./").append(toLocalPath2.substring(length + 1)).append("/");
                    }
                    asList.add(stringBuilder2.append(this.mFileListAction[i2]).toString());
                }
            }
        }
        obj = (str.equals(ZArchiverExtInterface.ARCHIVE_TYPE_7Z) && (str2.contains("-mx=9") || str2.contains("-mx=7"))) ? 1 : null;
        if (obj != null || (str.startsWith("t") && !str.equals(ZArchiverExtInterface.ARCHIVE_TYPE_TAR))) {
            stringBuilder.append("\\-mmt=1");
        } else if (C0061a.m207a("name." + str, true) && Settings.sCPUCoreN != null) {
            stringBuilder.append("\\-mmt=").append(Settings.sCPUCoreN);
        }
        C0166c.m558c(TAG, "archiveNew: params = " + stringBuilder);
        if (obj != null) {
            C0061a.m216e();
        }
        int i3 = z ? 4 : 0;
        if (z2) {
            i3 |= 1;
        }
        try {
            this.mService.ArchiveCompress(i, substring, str3, stringBuilder.toString(), asList, toLocalPath, i3);
            return true;
        } catch (Throwable e) {
            C0166c.m556a(e);
            return false;
        }
    }

    protected boolean archiveNew(String str, String str2, String str3, boolean z, boolean z2) {
        if (this.mFileListAction == null || ((this.mFileListActionPath == null || !this.mFileListActionPath.isStorage()) && (this.mFileListActionPathS == null || !this.mFileListActionPathS[0].isStorage()))) {
            return false;
        }
        String toLocalPath = this.mFileListActionPath != null ? this.mFileListActionPath.toLocalPath() : this.mFileListActionPathS[0].toLocalPath();
        if (!str3.startsWith("/")) {
            str3 = Settings.sArchiveDir != null ? Settings.sArchiveDir + "/" + str3 : toLocalPath + "/" + str3;
        }
        Object obj = (Settings.sRoot && C0073a.m304f()) ? 1 : null;
        if (!(z2 || obj == null || !str3.startsWith("/"))) {
            if (C0200o.m709a(this.mZA, new MyUri(str3.replace("<name>", "1"))) != (byte) 1) {
                z2 = true;
            } else if (C0200o.m711a(toLocalPath) == (byte) 2) {
                z2 = true;
            }
        }
        obj = str3.contains("<name>") ? 1 : str3.contains("<name.ext>") ? 2 : null;
        List arrayList = new ArrayList();
        List arrayList2 = new ArrayList();
        for (String str4 : this.mFileListAction) {
            arrayList.add(str4);
            switch (obj) {
                case null:
                    arrayList2.add(str4);
                    break;
                case 1:
                    arrayList2.add(str3.replace("<name>", C0202q.m728a(str4)));
                    break;
                case 2:
                    arrayList2.add(str3.replace("<name.ext>", str4));
                    break;
                default:
                    break;
            }
        }
        String str5 = "-t" + str + str2;
        C0166c.m558c(TAG, "archiveNew: params = " + str5);
        obj = (str.equals(ZArchiverExtInterface.ARCHIVE_TYPE_7Z) && (str2.contains("-mx=9") || str2.contains("-mx=7"))) ? 1 : null;
        if (obj != null) {
            C0061a.m216e();
        }
        int i = z ? 4 : 0;
        if (z2) {
            i |= 1;
        }
        try {
            this.mService.ArchiveCompressMulti(arrayList2, str5, arrayList, toLocalPath, i);
            return true;
        } catch (Throwable e) {
            C0166c.m556a(e);
            return false;
        }
    }

    public boolean archiveOpenFile(MyUri myUri, String str) {
        if (this.mService == null || myUri == null || !myUri.isArchive()) {
            return false;
        }
        String str2;
        String fragment = myUri.getFragment();
        if (fragment.length() > 0 && fragment.charAt(0) == '/') {
            fragment = fragment.substring(1, fragment.length());
        }
        if (fragment.endsWith("/")) {
            fragment = fragment.substring(0, fragment.length() - 1);
        }
        StringBuilder stringBuilder = new StringBuilder();
        if (C0061a.m207a(myUri.getPath(), true) && Settings.sCPUCoreN != null) {
            stringBuilder.append("\\-mmt=").append(Settings.sCPUCoreN);
        }
        if (C0072g.m300a(myUri.getPath())) {
            stringBuilder.append("\\-p").append(C0072g.m298a(true));
        }
        if (fragment.length() > 0) {
            stringBuilder.append("\\-z").append(fragment);
            str2 = fragment + "/" + str;
        } else {
            str2 = str;
        }
        boolean z = Settings.sRoot && C0073a.m304f();
        int i = (z && C0200o.m711a(myUri.getPath()) == (byte) 2) ? 1 : 0;
        try {
            this.mService.ArchiveOpenFile(str, myUri.getPath(), stringBuilder.toString(), str2, C0202q.m727a(this.mZA), i);
            return true;
        } catch (Throwable e) {
            C0166c.m556a(e);
            return false;
        }
    }

    public boolean archiveTest() {
        if (this.mService == null || this.mFileListAction == null) {
            return false;
        }
        if (this.mFileListActionPath != null && !this.mFileListActionPath.isStorage()) {
            return false;
        }
        if (this.mFileListActionPathS != null && !this.mFileListActionPathS[0].isStorage()) {
            return false;
        }
        if (this.mFileListActionPath == null && this.mFileListActionPathS == null) {
            return false;
        }
        List arrayList = new ArrayList();
        List arrayList2 = new ArrayList();
        List arrayList3 = new ArrayList();
        for (int i = 0; i < this.mFileListAction.length; i++) {
            String str;
            if (this.mFileListActionPath != null) {
                str = this.mFileListActionPath.getPath() + "/" + this.mFileListAction[i];
            } else if (this.mFileListActionPathS != null) {
                str = this.mFileListActionPathS[i].getPath() + "/" + this.mFileListAction[i];
            }
            Object obj = "";
            if (C0061a.m207a(str, true) && Settings.sCPUCoreN != null) {
                obj = "\\-mmt=" + Settings.sCPUCoreN;
            }
            if (C0072g.m300a(str)) {
                obj = obj + "\\-p" + C0072g.m298a(true);
            }
            arrayList.add(this.mFileListAction[i]);
            arrayList2.add(str);
            arrayList3.add(obj);
        }
        try {
            if (this.mFileListAction.length == 1) {
                this.mService.ArchiveTest(this.mFileListAction[0], (String) arrayList2.get(0), (String) arrayList3.get(0));
            } else {
                this.mService.ArchiveTestMulti(arrayList, arrayList2, arrayList3);
            }
            return true;
        } catch (Throwable e) {
            C0166c.m556a(e);
            return false;
        }
    }

    public boolean checkCurrentPath(Context context, int i) {
        if (this.mCS.m397a(context) != (byte) 1) {
            if (!this.mCS.m404a()) {
                return this.mCS.m409e();
            } else {
                if (!Settings.sRoot || !C0073a.m304f()) {
                    Toast.makeText(context, R.string.MES_PATH_READ_ONLY, 1).show();
                    return false;
                } else if (this.mCS.m397a(context) != (byte) 2) {
                    Toast.makeText(context, R.string.MES_NEED_REMOUNT, 1).show();
                    return false;
                } else if (this.mCS.f350a.isRootWarning(context, i, this.mCS.m412h())) {
                    return false;
                }
            }
        }
        return true;
    }

    public void compressSend(ZArchiver zArchiver, Intent intent, boolean z) {
        new C0007b(this, zArchiver, intent, z).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Void[0]);
    }

    public void copy(boolean z) {
        if (this.mFileListAction != null) {
            this.mFileListCopy = this.mFileListAction;
            this.mFileListCopyPath = this.mFileListActionPath;
            this.mFileListCopyCut = z;
            this.mFileListCopyPathS = this.mFileListActionPathS;
            clearActionBuf();
        }
    }

    public void dialogsUpdate() {
        if (this.mService != null) {
            List<ZDialog> arrayList = new ArrayList();
            synchronized (this.mCS.f358i) {
                arrayList.addAll(this.mCS.f358i);
            }
            for (ZDialog zDialog : arrayList) {
                try {
                    if (zDialog.getTaskID() >= 0) {
                        int taskID = zDialog.getTaskID();
                        if ((this.mService.GetStatusTask(taskID) & 1048576) == 1048576) {
                            zDialog.close();
                        } else if (zDialog.getType() == 2) {
                            ZProgDialog zProgDialog = (ZProgDialog) zDialog;
                            zProgDialog.setText(this.mService.GetProgText(taskID));
                            zProgDialog.setProgress(this.mService.GetProgPercent(taskID));
                        }
                    }
                } catch (DeadObjectException e) {
                    zDialog.close();
                } catch (Throwable e2) {
                    C0166c.m556a(e2);
                }
            }
        }
    }

    public boolean fileCopy(String str, boolean z, boolean z2) {
        if (this.mService == null || this.mFileListAction == null) {
            return false;
        }
        if (this.mFileListActionPath != null && !this.mFileListActionPath.isStorage()) {
            return false;
        }
        if (this.mFileListActionPathS != null && !this.mFileListActionPathS[0].isStorage()) {
            return false;
        }
        if (this.mFileListActionPath == null && this.mFileListActionPathS == null) {
            return false;
        }
        String str2;
        List list;
        int i;
        boolean z3 = Settings.sRoot && C0073a.m304f();
        if (!(!z3 || z2 || C0200o.m708a(this.mZA, str) == (byte) 1)) {
            z2 = true;
        }
        if (this.mFileListActionPath != null) {
            String toLocalPath = this.mFileListActionPath.toLocalPath();
            List asList = Arrays.asList(this.mFileListAction);
            if (z3 && !r12 && C0200o.m712a(this.mFileListActionPath) == (byte) 2) {
                str2 = toLocalPath;
                z2 = true;
                list = asList;
            } else {
                str2 = toLocalPath;
                list = asList;
            }
        } else {
            str2 = "";
            list = new ArrayList();
            i = 0;
            while (i < this.mFileListAction.length) {
                list.add(this.mFileListActionPathS[i].toLocalPath() + "/" + this.mFileListAction[i]);
                if (z3 && !r12 && C0200o.m712a(this.mFileListActionPathS[i]) == (byte) 2) {
                    z2 = true;
                }
                i++;
            }
        }
        try {
            i = this.mFileListActionPath == null ? 2 : 0;
            if (z2) {
                i |= 1;
            }
            if (z) {
                this.mService.Move(str2, str, list, i);
            } else {
                this.mService.Copy(str2, str, list, i);
            }
            return true;
        } catch (Throwable e) {
            C0166c.m556a(e);
            return false;
        }
    }

    public void fillFileListAction(int[] iArr, boolean z) {
        if (z) {
            fillFileListActionFind(iArr);
        } else {
            fillFileListActionFS(iArr);
        }
    }

    public void fillFileListActionFS(int[] iArr) {
        this.mFileListAction = new String[iArr.length];
        this.mFileListActionPath = new MyUri(this.mCS.m411g());
        this.mFileListActionPathS = null;
        int length = iArr.length;
        int i = 0;
        int i2 = 0;
        while (i < length) {
            int i3 = i2 + 1;
            this.mFileListAction[i2] = ((C0049e) this.mCS.f351b.get(iArr[i])).mo28e();
            i++;
            i2 = i3;
        }
        C0166c.m558c(TAG, "fillFileListActionFS: LEN(FileList) = " + this.mFileListAction.length + "; Path = " + this.mFileListActionPath.toString());
    }

    public void fillFileListActionFind(int[] iArr) {
        this.mFileListAction = new String[iArr.length];
        this.mFileListActionPathS = new MyUri[iArr.length];
        this.mFileListActionPath = null;
        int i = 0;
        for (int i2 : iArr) {
            this.mFileListAction[i] = ((C0052g) this.mCS.f354e.get(i2)).mo28e();
            this.mFileListActionPathS[i] = ((C0052g) this.mCS.f354e.get(i2)).m133l();
            i++;
        }
        C0166c.m558c(TAG, "fillFileListActionFind: LEN(FileList) = " + this.mFileListAction.length);
    }

    public boolean isCopy() {
        return (this.mFileListCopy == null || (this.mFileListCopyPath == null && this.mFileListCopyPathS == null)) ? false : true;
    }

    @SuppressLint({"SdCardPath"})
    public boolean isRootWarning(Context context, int i, String str) {
        if (!Settings.sRootWarning || (Settings.sShowHelp & 16) == 0) {
            return false;
        }
        if (str != null && (str.startsWith("/storage/usb") || str.startsWith("/storage/sdcard") || str.startsWith("/storage/ExtSd") || str.startsWith("/sdcard") || str.startsWith("/mnt/sdcard"))) {
            return false;
        }
        ZRootWarningDialog zRootWarningDialog = new ZRootWarningDialog(this.mCS, context);
        if (i != 0) {
            zRootWarningDialog.setStringData(1, "" + i);
        }
        zRootWarningDialog.setOnOkListener(this);
        zRootWarningDialog.show();
        return true;
    }

    public void onCancel(ZDialog zDialog) {
        switch (zDialog.getType()) {
            case 1:
            case 2:
                if (!Settings.sConfirmCancel) {
                    if (this.mZA != null) {
                        this.mZA.onOperationComplete(false);
                    }
                    try {
                        this.mService.SetStatusTask(zDialog.getTaskID(), 15);
                        return;
                    } catch (Throwable e) {
                        C0166c.m556a(e);
                        return;
                    }
                } else if (this.mZA != null) {
                    ZMessageDialog zMessageDialog = new ZMessageDialog(this.mCS, this.mZA, (byte) 1, this.mZA.getString(R.string.MES_CONFIRM_CANCEL));
                    zMessageDialog.setSubType(9);
                    zMessageDialog.setTaskID(zDialog.getTaskID());
                    zMessageDialog.setOnOkListener(this);
                    zMessageDialog.setOnCancelListener(this);
                    zMessageDialog.showWithoutCancel();
                    return;
                } else {
                    return;
                }
            case 4:
                ZMessageDialog zMessageDialog2 = (ZMessageDialog) zDialog;
                switch (zMessageDialog2.getSubType()) {
                    case 3:
                    case 9:
                        return;
                    case 13:
                        archiveNew(ZArchiverExtInterface.ARCHIVE_TYPE_ZIP, false);
                        return;
                    case 14:
                        archiveNew(ZArchiverExtInterface.ARCHIVE_TYPE_7Z, false);
                        return;
                    case ViewDragHelper.EDGE_ALL /*15*/:
                        String stringData = zMessageDialog2.getStringData(0);
                        if (stringData != null) {
                            new File(stringData + ".hash").delete();
                            new File(stringData).delete();
                            this.mArchiveFileOpen = "";
                            return;
                        }
                        return;
                    default:
                        return;
                }
            case 9:
                int i;
                ZAskOverwriteDialog zAskOverwriteDialog = (ZAskOverwriteDialog) zDialog;
                if (zAskOverwriteDialog.isCancel()) {
                    i = 8;
                } else {
                    i = 2;
                    if (zAskOverwriteDialog.isToAll()) {
                        i = 18;
                    }
                }
                try {
                    this.mService.SetOverwrite(zAskOverwriteDialog.getTaskID(), i);
                    this.mService.HideNotification(zAskOverwriteDialog.getTaskID());
                    return;
                } catch (Throwable e2) {
                    C0166c.m556a(e2);
                    return;
                }
            case 10:
                if (this.mZA != null) {
                    this.mZA.onOperationComplete(false);
                    return;
                }
                return;
            case 12:
                ZEnterPwdDialog zEnterPwdDialog = (ZEnterPwdDialog) zDialog;
                try {
                    this.mService.SetStatusTask(zDialog.getTaskID(), 15);
                    this.mService.SetPassword(zDialog.getTaskID(), "");
                    this.mService.HideNotification(zEnterPwdDialog.getTaskID());
                    return;
                } catch (Throwable e22) {
                    C0166c.m556a(e22);
                    return;
                }
            default:
                return;
        }
    }

    public boolean onFinishActionMode(Context context, boolean z) {
        if (this.mCS.m414j() == '\u0000') {
            return true;
        }
        if (z) {
            switch (this.mCS.m414j()) {
                case '\t':
                    if (!this.mCS.m406b()) {
                        C0166c.m557b(TAG, "Actions::onFinishActionMode: Extract 1 not found handler");
                        break;
                    } else if (checkCurrentPath(context, 0)) {
                        archiveExtract(this.mCS.m412h(), false, this.mCS.m407c());
                        break;
                    } else {
                        return false;
                    }
                case '\u0011':
                    if (!this.mCS.m406b()) {
                        C0166c.m557b(TAG, "Actions::onFinishActionMode: Extract 1 not found handler");
                        break;
                    } else if (checkCurrentPath(context, 0)) {
                        archiveExtractFiles(this.mCS.m412h(), this.mCS.m407c());
                        break;
                    } else {
                        return false;
                    }
                case '\"':
                    if (this.mCS.m397a(context) == (byte) 1) {
                        if (context instanceof ZArchiver) {
                            C0046h listAdapter = ((ZArchiver) context).getListAdapter();
                            if (listAdapter != null && listAdapter.mo26i() == (byte) 0) {
                                fillFileListAction(listAdapter.mo23f(), false);
                                archiveNew(0, this.mNewArchiveFormat, this.mNewArchiveParam, this.mNewArchivePath, this.mNewArchiveDeleteFile, (byte) 0, false);
                                break;
                            }
                        }
                    }
                    Toast.makeText(context, R.string.MES_PATH_READ_ONLY, 1).show();
                    return false;
                    break;
                case 'A':
                    if (context != null) {
                        if (this.mCS.m408d()) {
                            if (!C0061a.m205a(context, this.mCS.m411g().getPath())) {
                                Toast.makeText(context, R.string.MES_DONT_SUPPORT_EDIT, 0).show();
                                return false;
                            }
                        } else if (!checkCurrentPath(context, 0)) {
                            return false;
                        }
                        if (context instanceof ZArchiver) {
                            ((ZArchiver) context).onToolbarClick(R.id.bPast);
                            break;
                        }
                    }
                    break;
            }
        }
        this.mCS.m399a('\u0000');
        return true;
    }

    public void onMenuSelect(ZArchiver zArchiver, int i) {
        onMenuSelect(zArchiver, null, i);
    }

    public void onMenuSelect(ZArchiver zArchiver, ZMenuDialog zMenuDialog, int i) {
        int i2 = 5;
        byte b = (byte) 2;
        int i3 = 0;
        if (zArchiver != null && this.mCS != null) {
            ZMessageDialog zMessageDialog;
            int i4;
            boolean b2;
            switch (i) {
                case 1:
                case 18:
                    if (this.mFileListAction != null && this.mFileListAction.length == 1) {
                        if (!(this.mFileListActionPath == null && this.mFileListActionPathS == null) && this.mCS.m406b()) {
                            MyUri myUri = this.mFileListActionPath != null ? new MyUri(FSArchive.SCHEME, "", this.mFileListActionPath.toLocalPath() + "/" + this.mFileListAction[0], "/") : new MyUri(FSArchive.SCHEME, "", this.mFileListActionPathS[0].toLocalPath() + "/" + this.mFileListAction[0], "/");
                            C0061a.m210b(myUri.getPath());
                            zArchiver.setCurrentPath(myUri);
                            return;
                        }
                        return;
                    }
                    return;
                case 2:
                    if (this.mFileListAction != null && this.mFileListAction.length == 1) {
                        if (this.mFileListActionPath != null || this.mFileListActionPathS != null) {
                            if (this.mFileListActionPath == null) {
                                this.mFileListActionPath = this.mFileListActionPathS[0];
                            }
                            if (this.mFileListActionPath.isArchive()) {
                                archiveOpenFile(false);
                                return;
                            } else if (this.mFileListActionPath.isLocalFS()) {
                                C0202q.m739b((Context) zArchiver, this.mFileListActionPath.toLocalPath() + "/" + this.mFileListAction[0]);
                                return;
                            } else {
                                return;
                            }
                        }
                        return;
                    }
                    return;
                case 3:
                case 19:
                    if (this.mFileListAction != null && this.mFileListAction.length == 1) {
                        if (this.mFileListActionPath != null || this.mFileListActionPathS != null) {
                            if (this.mFileListActionPath == null) {
                                this.mFileListActionPath = this.mFileListActionPathS[0];
                            }
                            if (this.mFileListActionPath.isArchive()) {
                                archiveOpenFile(true);
                                return;
                            } else if (this.mFileListActionPath.isLocalFS()) {
                                C0202q.m742c(zArchiver, this.mFileListActionPath.toLocalPath() + "/" + this.mFileListAction[0]);
                                return;
                            } else {
                                return;
                            }
                        }
                        return;
                    }
                    return;
                case 4:
                    if (this.mCS.m408d()) {
                        zArchiver.setActionMode('\u0011');
                        return;
                    } else {
                        zArchiver.setActionMode('\t');
                        return;
                    }
                case 5:
                    if ((this.mCS.m404a() || this.mCS.m409e()) && checkCurrentPath(zArchiver, 2)) {
                        archiveExtract(this.mCS.m412h(), false, this.mCS.m407c());
                        return;
                    }
                    return;
                case CHECK_ACTION_RENAME /*6*/:
                    if ((this.mCS.m404a() || this.mCS.m409e()) && checkCurrentPath(zArchiver, 3)) {
                        archiveExtract(this.mCS.m412h(), true, this.mCS.m407c());
                        return;
                    }
                    return;
                case ZArchiverExtInterface.COMPRESSION_LAVEL_MAX /*7*/:
                    if (this.mFileListAction == null) {
                        return;
                    }
                    if (this.mFileListActionPath != null || this.mFileListActionPathS != null) {
                        if ((this.mFileListActionPath != null && this.mFileListActionPath.isStorage()) || (this.mFileListActionPathS != null && this.mFileListActionPathS[0].isStorage())) {
                            boolean z;
                            String str;
                            if (this.mFileListActionPath != null) {
                                z = C0200o.m712a(this.mFileListActionPath) == (byte) 2;
                            } else {
                                z = C0200o.m712a(this.mFileListActionPathS[0]) == (byte) 2;
                            }
                            if (this.mFileListAction.length == 1) {
                                str = this.mFileListAction[0];
                                b2 = (this.mFileListActionPath != null ? new C0204s(this.mFileListActionPath, str) : new C0204s(this.mFileListActionPathS[0], str)).m749b();
                            } else {
                                str = new C0204s(this.mCS.m411g().getPath()).m751d();
                                b2 = true;
                            }
                            ZCompressDialog zCompressDialog = new ZCompressDialog(this.mCS, zArchiver, str, this.mFileListAction.length == 1, b2, z);
                            zCompressDialog.setSubType(10);
                            zCompressDialog.setOnOkListener(this);
                            zCompressDialog.show();
                            return;
                        }
                        return;
                    }
                    return;
                case ViewDragHelper.EDGE_BOTTOM /*8*/:
                case 9:
                    if (Settings.sRemoveAfterCompress) {
                        zMessageDialog = new ZMessageDialog(this.mCS, zArchiver, (byte) 1, zArchiver.getString(R.string.MES_REMOTHE_AFTER_COMPRESS));
                        zMessageDialog.setSubType(i == 8 ? 13 : 14);
                        zMessageDialog.setOnOkListener(this);
                        zMessageDialog.setOnCancelListener(this);
                        zMessageDialog.show();
                        return;
                    }
                    archiveNew(i == 8 ? ZArchiverExtInterface.ARCHIVE_TYPE_ZIP : ZArchiverExtInterface.ARCHIVE_TYPE_7Z, false);
                    return;
                case 10:
                    archiveTest();
                    return;
                case 14:
                    zArchiver.onToolbarClick(R.id.bSelectAll);
                    return;
                case ViewDragHelper.EDGE_ALL /*15*/:
                    zArchiver.onToolbarClick(R.id.bSelectClear);
                    return;
                case 16:
                    zArchiver.onToolbarClick(R.id.bSelectInvert);
                    return;
                case 20:
                    if (this.mFileListAction == null || this.mFileListAction.length <= 1) {
                        if (this.mFileListActionPath != null && this.mFileListActionPath.isLocalFS()) {
                            C0202q.m731a((Context) zArchiver, this.mFileListActionPath.toLocalPath() + "/" + this.mFileListAction[0]);
                            return;
                        } else if (this.mFileListActionPathS[0] != null && this.mFileListActionPathS[0].isLocalFS()) {
                            C0202q.m731a((Context) zArchiver, this.mFileListActionPathS[0].toLocalPath() + "/" + this.mFileListAction[0]);
                            return;
                        } else {
                            return;
                        }
                    } else if (this.mFileListActionPath != null && this.mFileListActionPath.isLocalFS()) {
                        C0202q.m732a((Context) zArchiver, C0202q.m729a(this.mFileListAction, this.mFileListActionPath.toLocalPath()));
                        return;
                    } else if (this.mFileListActionPathS[0] != null && this.mFileListActionPathS[0].isLocalFS()) {
                        C0202q.m732a((Context) zArchiver, C0202q.m730a(this.mFileListAction, this.mFileListActionPathS));
                        return;
                    } else {
                        return;
                    }
                case 22:
                    if (this.mFileListAction == null) {
                        return;
                    }
                    if (this.mFileListActionPath != null || this.mFileListActionPathS != null) {
                        (this.mFileListActionPath != null ? new ZFileInfoDialog(this.mCS, (Context) zArchiver, this.mFileListActionPath, this.mFileListAction) : new ZFileInfoDialog(this.mCS, (Context) zArchiver, this.mFileListActionPathS, this.mFileListAction)).show();
                        return;
                    }
                    return;
                case 23:
                    if (!checkCurrentPath(zArchiver, 4)) {
                        return;
                    }
                    break;
                case 24:
                    zArchiver.onToolbarClick(R.id.bCopy);
                    return;
                case 25:
                    zArchiver.onToolbarClick(R.id.bCut);
                    return;
                case 26:
                    zArchiver.onToolbarClick(R.id.bPast);
                    return;
                case 27:
                    if (this.mFileListAction != null && this.mFileListAction.length == 1 && checkCurrentPath(zArchiver, 6)) {
                        C0204s c0204s = null;
                        if (this.mFileListActionPath != null) {
                            c0204s = new C0204s(this.mFileListActionPath.toLocalPath() + "/" + this.mFileListAction[0]);
                        } else if (this.mFileListActionPathS != null && this.mFileListActionPathS.length >= 1) {
                            c0204s = new C0204s(this.mFileListActionPathS[0].toLocalPath() + "/" + this.mFileListAction[0]);
                        }
                        if (c0204s != null && c0204s.m756i()) {
                            ZEnterTextDialog zEnterTextDialog = new ZEnterTextDialog(this.mCS, (Context) zArchiver, c0204s.m751d(), (int) R.string.REN_ENTER_NEW_NAME);
                            zEnterTextDialog.show();
                            zEnterTextDialog.setSubType(12);
                            zEnterTextDialog.setText(c0204s.m751d());
                            if (c0204s.m746a()) {
                                zEnterTextDialog.setSelection(0, c0204s.m751d().lastIndexOf("."));
                            } else {
                                zEnterTextDialog.setSelection(0, c0204s.m751d().length());
                            }
                            zEnterTextDialog.setOnOkListener(this);
                            return;
                        }
                        return;
                    }
                    return;
                case 56:
                    break;
                case 57:
                    if (this.mFileListAction != null && this.mFileListAction.length == 1) {
                        ZEnterTextDialog zEnterTextDialog2 = new ZEnterTextDialog(this.mCS, (Context) zArchiver, this.mFileListAction[0], (int) R.string.REN_ENTER_NEW_NAME);
                        zEnterTextDialog2.show();
                        zEnterTextDialog2.setSubType(12);
                        zEnterTextDialog2.setText(this.mFileListAction[0]);
                        zEnterTextDialog2.setSelection(0, this.mFileListAction[0].length());
                        zEnterTextDialog2.setOnOkListener(this);
                        return;
                    }
                    return;
                case 70:
                    if (this.mFileListAction != null && this.mFileListAction.length == 1 && this.mCS.m406b()) {
                        ZAddFavorite zAddFavorite = new ZAddFavorite(this.mCS, zArchiver, this.mFileListAction[0], this.mCS.m412h() + "/" + this.mFileListAction[0]);
                        zAddFavorite.setSubType(21);
                        zAddFavorite.setOnOkListener(this);
                        zAddFavorite.show();
                        return;
                    }
                    return;
                case 71:
                    if (zMenuDialog != null) {
                        Favorites.delFavorite(zArchiver, Integer.parseInt(zMenuDialog.getStringData(0)));
                        zArchiver.UpdateFavoriteList();
                        return;
                    }
                    return;
                case 72:
                    if (zMenuDialog != null) {
                        int parseInt = Integer.parseInt(zMenuDialog.getStringData(0));
                        C0044c item = Favorites.getItem(parseInt);
                        if (item != null) {
                            ZAddFavorite zAddFavorite2 = new ZAddFavorite(this.mCS, (Context) zArchiver, item.f112a, item.f113b, item.f114c);
                            zAddFavorite2.setSubType(22);
                            zAddFavorite2.setStringData(0, Integer.toString(parseInt));
                            zAddFavorite2.setOnOkListener(this);
                            zAddFavorite2.show();
                            return;
                        }
                        return;
                    }
                    return;
                case 81:
                case 82:
                    if (this.mCS.m408d()) {
                        String path = this.mCS.m411g().getPath();
                        if (C0061a.m205a((Context) zArchiver, path)) {
                            C0136e c0136e;
                            ZFileSelect zFileSelect;
                            boolean i5 = C0061a.m223i(path);
                            byte b3 = C0061a.m217e(path) ? (byte) 1 : C0061a.m219f(path) ? (byte) 2 : (byte) 0;
                            if (i5) {
                                try {
                                    if (C0072g.m300a(path) && C0072g.m301a(path, 1)) {
                                        i5 = false;
                                    }
                                    b2 = i5;
                                } catch (Throwable e) {
                                    C0166c.m556a(e);
                                }
                                c0136e = this.mCS;
                                i4 = i != 82 ? R.string.ADD_TTL_FOLDER : R.string.ADD_TTL_FILE;
                                if (i != 82) {
                                    b = (byte) 5;
                                }
                                zFileSelect = new ZFileSelect(c0136e, zArchiver, i4, b, b2, b3);
                                if (i == 82) {
                                    i2 = 6;
                                }
                                zFileSelect.setSubType(i2);
                                zFileSelect.show();
                                zFileSelect.setOnOkListener(this);
                                return;
                            }
                            b2 = i5;
                            c0136e = this.mCS;
                            if (i != 82) {
                            }
                            if (i != 82) {
                                b = (byte) 5;
                            }
                            zFileSelect = new ZFileSelect(c0136e, zArchiver, i4, b, b2, b3);
                            if (i == 82) {
                                i2 = 6;
                            }
                            zFileSelect.setSubType(i2);
                            zFileSelect.show();
                            zFileSelect.setOnOkListener(this);
                            return;
                        }
                        new ZMessageDialog(this.mCS, zArchiver, (byte) 4, zArchiver.getString(R.string.MES_DONT_SUPPORT_EDIT)).show();
                        return;
                    }
                    return;
                case 90:
                    zArchiver.onToolbarClick(R.id.bSettings);
                    return;
                case 91:
                    zArchiver.onToolbarClick(R.id.bMultiSelect);
                    return;
                case 92:
                case 93:
                case 94:
                    onFinishActionMode(zArchiver, true);
                    if (zArchiver.mActionMode != null) {
                        zArchiver.mActionMode.finish();
                        return;
                    }
                    return;
                case 95:
                case 96:
                    onFinishActionMode(zArchiver, false);
                    if (zArchiver.mActionMode != null) {
                        zArchiver.mActionMode.finish();
                        return;
                    }
                    return;
                case 97:
                    zArchiver.onToolbarClick(R.id.bExit);
                    return;
                case 98:
                    if (this.mFileListAction != null && this.mFileListAction.length <= 1) {
                        if (!(this.mFileListActionPath == null && this.mFileListActionPathS == null) && checkCurrentPath(zArchiver, 5)) {
                            ZPermissionDialog zPermissionDialog = this.mFileListActionPath != null ? new ZPermissionDialog(this.mCS, (Context) zArchiver, this.mFileListActionPath, this.mFileListAction) : new ZPermissionDialog(this.mCS, (Context) zArchiver, this.mFileListActionPathS, this.mFileListAction);
                            zPermissionDialog.setOnOkListener(this);
                            zPermissionDialog.show();
                            return;
                        }
                        return;
                    }
                    return;
                default:
                    return;
            }
            if (this.mFileListAction == null) {
                return;
            }
            if (this.mFileListActionPath != null || this.mFileListActionPathS != null) {
                StringBuilder stringBuilder = new StringBuilder();
                String[] strArr = this.mFileListAction;
                i4 = strArr.length;
                while (i3 < i4) {
                    String str2 = strArr[i3];
                    if (stringBuilder.length() != 0) {
                        stringBuilder.append(", ");
                    }
                    stringBuilder.append(str2);
                    i3++;
                }
                zMessageDialog = new ZMessageDialog(this.mCS, zArchiver, (byte) 1, zArchiver.getString(R.string.MES_QUESTION_REMOVE).replace("%1", stringBuilder.toString()));
                if (i == 56) {
                    zMessageDialog.setSubType(4);
                } else {
                    zMessageDialog.setSubType(3);
                }
                zMessageDialog.setOnOkListener(this);
                zMessageDialog.setOnCancelListener(this);
                zMessageDialog.show();
            }
        }
    }

    public void onOk(ZDialog zDialog) {
        String trim;
        byte b = (byte) 2;
        int i = 1;
        MyUri myUri;
        String trim2;
        String str;
        String stringData;
        String stringData2;
        switch (zDialog.getType()) {
            case 2:
                if (this.mZA != null) {
                    this.mZA.onOperationComplete(false);
                    return;
                }
                return;
            case 3:
                ZEnterTextDialog zEnterTextDialog = (ZEnterTextDialog) zDialog;
                switch (zEnterTextDialog.getSubType()) {
                    case 1:
                        trim = zEnterTextDialog.getText().trim();
                        if (this.mCS.m404a()) {
                            myUri = new MyUri(this.mCS.m411g());
                            myUri.add(trim);
                            C0167d.m563a(myUri.toLocalPath());
                            if (this.mCS.m415k() == '\u0001') {
                                this.mCS.m403a(myUri);
                            }
                        } else if (this.mCS.m409e()) {
                            myUri = new MyUri(this.mCS.m411g());
                            myUri.add(trim);
                            C0187l.m669c(myUri.getPath());
                            if (this.mCS.m415k() == '\u0001') {
                                this.mCS.m403a(myUri);
                            }
                        } else if (this.mCS.m408d()) {
                            myUri = new MyUri(this.mCS.m411g());
                            archiveNewFolder(myUri.getPath(), myUri.getFragment(), trim);
                        }
                        if (this.mZA != null && !this.mCS.m408d()) {
                            this.mZA.onUpdateList(true);
                            return;
                        }
                        return;
                    case 12:
                        trim2 = zEnterTextDialog.getText().trim();
                        if (trim2.length() > 0 && this.mFileListAction != null && this.mFileListAction.length == 1) {
                            if (this.mCS.m404a()) {
                                File file;
                                byte a;
                                if (this.mFileListActionPath != null) {
                                    file = new File(this.mFileListActionPath.toLocalPath() + "/" + this.mFileListAction[0]);
                                    a = C0200o.m709a(this.mZA, this.mFileListActionPath);
                                } else if (this.mFileListActionPathS == null || this.mFileListActionPathS.length < 1) {
                                    file = null;
                                    a = (byte) 4;
                                } else {
                                    file = new File(this.mFileListActionPathS[0].toLocalPath() + "/" + this.mFileListAction[0]);
                                    a = C0200o.m709a(this.mZA, this.mFileListActionPathS[0]);
                                }
                                if (file != null && file.exists()) {
                                    if (a == (byte) 1) {
                                        if (!C0167d.m564a(this.mZA, file.getParent(), file.getName(), trim2)) {
                                            Toast.makeText(this.mZA, R.string.MES_END_WITH_ERROR, 0).show();
                                        }
                                    } else if (!C0167d.m568b(this.mZA, file.getParent(), file.getName(), trim2)) {
                                        Toast.makeText(this.mZA, R.string.MES_END_WITH_ERROR, 0).show();
                                    }
                                } else {
                                    return;
                                }
                            } else if (this.mCS.m409e()) {
                                if (this.mFileListActionPath != null) {
                                    C0187l.m665a(this.mFileListActionPath, this.mFileListAction[0], trim2);
                                } else {
                                    C0187l.m665a(this.mFileListActionPathS[0], this.mFileListAction[0], trim2);
                                }
                            } else if (this.mCS.m408d()) {
                                if (this.mFileListActionPath.getFragment().length() > 1) {
                                    str = this.mFileListActionPath.getFragment() + "/" + this.mFileListAction[0];
                                    trim = this.mFileListActionPath.getFragment() + "/" + trim2;
                                } else {
                                    str = this.mFileListAction[0];
                                    trim = trim2;
                                }
                                archiveRenameFile(this.mFileListActionPath.getPath(), str, trim);
                            } else {
                                Log.e(TAG, "Rename: not found handler!");
                                return;
                            }
                            C0178g h = C0047d.m85h();
                            if (h != null) {
                                h.m617a(this.mFileListAction[0], trim2);
                            }
                            if (this.mZA != null && !this.mCS.m408d()) {
                                this.mZA.onUpdateList(true);
                                return;
                            }
                            return;
                        }
                        return;
                    default:
                        return;
                }
            case 4:
                ZMessageDialog zMessageDialog = (ZMessageDialog) zDialog;
                switch (zMessageDialog.getSubType()) {
                    case 3:
                        fileRemove();
                        return;
                    case 4:
                        archiveRemoveFiles();
                        return;
                    case 9:
                        if (this.mZA != null) {
                            this.mZA.onOperationComplete(false);
                        }
                        try {
                            this.mService.SetStatusTask(zDialog.getTaskID(), 15);
                            return;
                        } catch (Throwable e) {
                            C0166c.m556a(e);
                            return;
                        }
                    case 13:
                        archiveNew(ZArchiverExtInterface.ARCHIVE_TYPE_ZIP, true);
                        return;
                    case 14:
                        archiveNew(ZArchiverExtInterface.ARCHIVE_TYPE_7Z, true);
                        return;
                    case ViewDragHelper.EDGE_ALL /*15*/:
                        trim = zMessageDialog.getStringData(0);
                        if (trim != null) {
                            archiveUpdateFile(trim);
                            return;
                        }
                        return;
                    case 17:
                        String stringData3 = zDialog.getStringData(0);
                        stringData = zDialog.getStringData(1);
                        stringData2 = zDialog.getStringData(2);
                        trim = zDialog.getStringData(3);
                        trim2 = zDialog.getStringData(4);
                        if (stringData3 != null && stringData != null && stringData2 != null && trim != null && trim2 != null) {
                            archiveNew(0, stringData3, stringData, stringData2, trim.equals("1"), (byte) 1, trim2.equals("1"));
                            return;
                        }
                        return;
                    case 19:
                        trim2 = zMessageDialog.getStringData(1);
                        if (trim2 != null && trim2.length() > 0) {
                            try {
                                Settings.removeSavedPwd(Integer.parseInt(trim2));
                                Settings.savePassword(this.mZA);
                                ZSavedPwdDialog zSavedPwdDialog = (ZSavedPwdDialog) this.mCS.m398a(zMessageDialog.getTaskID(), 13);
                                if (zSavedPwdDialog != null) {
                                    zSavedPwdDialog.updateList();
                                    return;
                                }
                                return;
                            } catch (Throwable e2) {
                                C0166c.m556a(e2);
                                return;
                            }
                        }
                        return;
                    case 20:
                        if (this.mZA != null) {
                            this.mZA.showStartMessage(true);
                            return;
                        }
                        return;
                    default:
                        return;
                }
            case 5:
                ZCompressDialog zCompressDialog = (ZCompressDialog) zDialog;
                switch (zCompressDialog.getSubType()) {
                    case 10:
                        if (zCompressDialog.getSeparated()) {
                            archiveNew(zCompressDialog.getFormat(), zCompressDialog.getParam(), zCompressDialog.getArcName(), zCompressDialog.getDeleteFile(), false);
                            return;
                        }
                        stringData = zCompressDialog.getFormat();
                        stringData2 = zCompressDialog.getParam();
                        String arcName = zCompressDialog.getArcName();
                        boolean deleteFile = zCompressDialog.getDeleteFile();
                        if (!zCompressDialog.isAppendArchive()) {
                            b = (byte) 0;
                        }
                        archiveNew(stringData, stringData2, arcName, deleteFile, b, false);
                        return;
                    case 11:
                        this.mZA.setActionMode(ACTION_CREATE_ARCHIVE);
                        this.mNewArchivePath = this.mCS.m412h() + "/" + zCompressDialog.getArcName();
                        this.mNewArchiveFormat = zCompressDialog.getFormat();
                        this.mNewArchiveParam = zCompressDialog.getParam();
                        this.mNewArchiveDeleteFile = zCompressDialog.getDeleteFile();
                        Toast.makeText(this.mZA, this.mZA.getString(R.string.MES_SELECT_FILES), 0).show();
                        return;
                    default:
                        return;
                }
            case CHECK_ACTION_RENAME /*6*/:
                onCancel(zDialog);
                break;
            case ZArchiverExtInterface.COMPRESSION_LAVEL_MAX /*7*/:
                ZFileSelect zFileSelect = (ZFileSelect) zDialog;
                trim = "";
                if (zFileSelect.getPassword(false).length() > 0) {
                    trim = trim + "\\-p" + zFileSelect.getPassword(true);
                    switch (zFileSelect.getEncType()) {
                        case 1:
                            trim = trim + "\\-mem=AES128";
                            break;
                        case 2:
                            trim = trim + "\\-mem=AES192";
                            break;
                        case 3:
                            trim = trim + "\\-mem=AES256";
                            break;
                    }
                }
                String str2 = zFileSelect.getCompressionLevel() >= 0 ? trim + "\\-mx=" + zFileSelect.getCompressionLevel() : trim;
                if (zFileSelect.getSubType() == 6) {
                    C0204s c0204s = new C0204s(zFileSelect.getPath());
                    if (c0204s.m749b()) {
                        archiveAddFiles(new MyUri(c0204s.m752e()), "\\" + c0204s.m751d(), str2, this.mCS.m411g().getPath(), this.mCS.m411g().getFragment());
                        return;
                    }
                    return;
                }
                str = zFileSelect.getSelectedFiles("\\");
                if (str.length() > 0) {
                    archiveAddFiles(new MyUri(zFileSelect.getPath()), str, str2, this.mCS.m411g().getPath(), this.mCS.m411g().getFragment());
                    return;
                }
                return;
            case ViewDragHelper.EDGE_BOTTOM /*8*/:
                ZMainOptionDialog zMainOptionDialog = (ZMainOptionDialog) zDialog;
                if (Settings.setSelectedMainOptions(this.mZA, zMainOptionDialog.getTheme(), zMainOptionDialog.getIconTheme(), zMainOptionDialog.getLanguage(), zMainOptionDialog.getOEMCP())) {
                    try {
                        this.mZA.restartGUI();
                        return;
                    } catch (Throwable e22) {
                        C0166c.m556a(e22);
                        return;
                    }
                } else if (this.mZA != null) {
                    this.mZA.showStartMessage(true);
                    return;
                } else {
                    return;
                }
            case 9:
                ZAskOverwriteDialog zAskOverwriteDialog = (ZAskOverwriteDialog) zDialog;
                if (zAskOverwriteDialog.isToAll()) {
                    i = 17;
                }
                try {
                    this.mService.SetOverwrite(zAskOverwriteDialog.getTaskID(), i);
                    this.mService.HideNotification(zAskOverwriteDialog.getTaskID());
                    return;
                } catch (Throwable e222) {
                    C0166c.m556a(e222);
                    return;
                }
            case 10:
                ZMenuDialog zMenuDialog = (ZMenuDialog) zDialog;
                if (this.mZA != null) {
                    onMenuSelect(this.mZA, zMenuDialog, zMenuDialog.getSelectMenuItemID());
                    return;
                }
                return;
            case 11:
                ZAddFavorite zAddFavorite = (ZAddFavorite) zDialog;
                trim = zAddFavorite.getText();
                int icon = zAddFavorite.getIcon();
                if (zAddFavorite.getSubType() == 21) {
                    if (this.mFileListActionPath != null && this.mFileListAction.length == 1 && trim.length() > 0 && this.mFileListActionPath.isStorage()) {
                        MyUri myUri2 = new MyUri(this.mFileListActionPath);
                        myUri2.add(this.mFileListAction[0]);
                        try {
                            Favorites.addFavorite(this.mZA, icon, trim, myUri2.toLocalPath());
                        } catch (Throwable e2222) {
                            C0166c.m556a(e2222);
                        }
                    } else {
                        return;
                    }
                } else if (zAddFavorite.getSubType() == 22) {
                    try {
                        Favorites.renameFavorite(this.mZA, Integer.parseInt(zAddFavorite.getStringData(0)), icon, trim);
                    } catch (Throwable e22222) {
                        C0166c.m556a(e22222);
                    }
                }
                try {
                    this.mZA.UpdateFavoriteList();
                    return;
                } catch (Throwable e222222) {
                    C0166c.m556a(e222222);
                    return;
                }
            case 12:
                ZEnterPwdDialog zEnterPwdDialog = (ZEnterPwdDialog) zDialog;
                try {
                    this.mService.SetPassword(zEnterPwdDialog.getTaskID(), zEnterPwdDialog.getPassword());
                    this.mService.HideNotification(zEnterPwdDialog.getTaskID());
                    return;
                } catch (Throwable e2222222) {
                    C0166c.m556a(e2222222);
                    return;
                }
            case ViewDragHelper.EDGE_ALL /*15*/:
                break;
            case 16:
                ZPermissionDialog zPermissionDialog = (ZPermissionDialog) zDialog;
                if (zPermissionDialog.isPermissionChange() || zPermissionDialog.isUIDGIDChange()) {
                    C0073a c0075c = new C0075c();
                    if (c0075c.mo52b()) {
                        MyUri[] path = zPermissionDialog.getPath();
                        String[] names = zPermissionDialog.getNames();
                        for (int i2 = 0; i2 < names.length; i2++) {
                            myUri = path.length > 1 ? new MyUri(path[i2]) : new MyUri(path[0]);
                            myUri.add(names[i2]);
                            if (zPermissionDialog.isPermissionChange()) {
                                C0076d.m331a(c0075c, myUri.toLocalPath(), zPermissionDialog.getPermission());
                            }
                            if (zPermissionDialog.isUIDGIDChange()) {
                                C0077e.m332a(c0075c, myUri.toLocalPath(), "" + zPermissionDialog.getUID(), "" + zPermissionDialog.getGID());
                            }
                        }
                        c0075c.mo54c();
                        return;
                    }
                    return;
                }
                return;
            default:
                return;
        }
        Settings.sRootWarning = false;
        trim = zDialog.getStringData(1);
        if (trim != null) {
            if (this.mZA != null) {
                switch (Integer.parseInt(trim)) {
                    case 1:
                        this.mZA.onToolbarClick(R.id.bPast);
                        return;
                    case 2:
                        onMenuSelect(this.mZA, 5);
                        return;
                    case 3:
                        onMenuSelect(this.mZA, 6);
                        return;
                    case 4:
                        onMenuSelect(this.mZA, 23);
                        return;
                    case 5:
                        onMenuSelect(this.mZA, 98);
                        return;
                    case CHECK_ACTION_RENAME /*6*/:
                        onMenuSelect(this.mZA, 27);
                        return;
                    default:
                        return;
                }
            }
        } else if (this.mCS.m414j() != '\u0000' && this.mCS.f350a.onFinishActionMode(this.mZA, true)) {
            this.mZA.mActionMode.finish();
        }
    }

    public void onReceive(Context context, Intent intent) {
        Throwable e;
        int i = 0;
        if (this.mZA != null) {
            String action = intent.getAction();
            if (action != null) {
                if (action.equals("android.intent.action.MEDIA_MOUNTED")) {
                    C0199n.m692a(this.mZA, 255);
                    this.mZA.UpdateFavoriteList();
                    return;
                } else if (action.equals("android.intent.action.MEDIA_UNMOUNTED") || action.equals("android.intent.action.MEDIA_EJECT") || action.equals("android.intent.action.MEDIA_REMOVED") || action.equals("android.intent.action.MEDIA_BAD_REMOVAL")) {
                    if (!(intent.getData() == null || intent.getData().getPath() == null)) {
                        action = intent.getData().getPath();
                        C0199n.m702c(action);
                        C0184j.m645b();
                        if (this.mCS.m411g().getPath() != null && this.mCS.m411g().getPath().startsWith(action)) {
                            this.mCS.m403a(new MyUri(Settings.sHomeDir));
                            this.mZA.onUpdateList(i);
                            this.mCS.m418n();
                        }
                    }
                    this.mZA.UpdateFavoriteList();
                    return;
                }
            }
            int intExtra = intent.getIntExtra("ZArchiver.iCMD", i);
            int intExtra2 = intent.getIntExtra("iTaskID", i);
            Intent intent2;
            switch (intExtra) {
                case 21:
                    C0166c.m558c(TAG, "Show PROG DLG!!!");
                    Intent intent3 = new Intent("ZArchiver.iMES");
                    intent3.putExtra("iTaskID", intExtra2);
                    intent3.putExtra("iTaskType", intent.getIntExtra("iTaskType", i));
                    intent3.putExtra("iAction", 1);
                    this.mMessageReceiver.onReceive(this.mZA, intent3);
                    if (this.mService != null) {
                        String str = "";
                        try {
                            action = this.mService.GetProgText(intExtra2);
                            try {
                                i = this.mService.GetProgPercent(intExtra2);
                            } catch (Exception e2) {
                                e = e2;
                                C0166c.m556a(e);
                                intent3.putExtra("iProgress", i);
                                intent3.putExtra("sText", action);
                                intent3.putExtra("iAction", 4);
                                this.mMessageReceiver.onReceive(this.mZA, intent3);
                                intent3.putExtra("iAction", 3);
                                this.mMessageReceiver.onReceive(this.mZA, intent3);
                                return;
                            }
                        } catch (Throwable e3) {
                            Throwable th = e3;
                            action = str;
                            e = th;
                            C0166c.m556a(e);
                            intent3.putExtra("iProgress", i);
                            intent3.putExtra("sText", action);
                            intent3.putExtra("iAction", 4);
                            this.mMessageReceiver.onReceive(this.mZA, intent3);
                            intent3.putExtra("iAction", 3);
                            this.mMessageReceiver.onReceive(this.mZA, intent3);
                            return;
                        }
                        intent3.putExtra("iProgress", i);
                        intent3.putExtra("sText", action);
                        intent3.putExtra("iAction", 4);
                        this.mMessageReceiver.onReceive(this.mZA, intent3);
                        intent3.putExtra("iAction", 3);
                        this.mMessageReceiver.onReceive(this.mZA, intent3);
                        return;
                    }
                    return;
                case 22:
                    C0166c.m558c(TAG, "Show PWD DLG!!!");
                    intent2 = new Intent("ZArchiver.iMES");
                    intent2.putExtra("iTaskID", intExtra2);
                    intent2.putExtra("iAction", 5);
                    this.mMessageReceiver.onReceive(this.mZA, intent2);
                    return;
                case 23:
                    C0166c.m558c(TAG, "Show OVERW DLG!!!");
                    intent2 = new Intent("ZArchiver.iMES");
                    intent2.putExtra("iTaskID", intExtra2);
                    intent2.putExtra("iAction", 8);
                    this.mMessageReceiver.onReceive(this.mZA, intent2);
                    return;
                case 24:
                    C0166c.m558c(TAG, "Show MES DLG!!!");
                    intent2 = new Intent("ZArchiver.iMES");
                    intent2.putExtra("iTaskID", intExtra2);
                    intent2.putExtra("iAction", 21);
                    intent2.putExtra("sText", intent.getStringExtra("iText"));
                    this.mMessageReceiver.onReceive(this.mZA, intent2);
                    return;
                default:
                    return;
            }
        }
    }

    public void openContent(Context context, Uri uri) {
        new C0005a(this, context, uri).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Void[0]);
    }

    public void past() {
        if (this.mFileListCopy != null) {
            this.mFileListAction = this.mFileListCopy;
            this.mFileListActionPath = this.mFileListCopyPath;
            this.mFileListActionPathS = this.mFileListCopyPathS;
            clearCopyBuf();
        }
    }

    public void serviceSetRun() {
        if (bWaitService != null) {
            synchronized (bWaitService) {
                bWaitService.notifyAll();
                bWaitService = null;
            }
        }
    }

    public void serviceWait() {
        if (this.mService == null) {
            C0166c.m558c(TAG, "wait app service...");
            if (bWaitService == null) {
                bWaitService = new Object();
            }
            try {
                synchronized (bWaitService) {
                    bWaitService.wait(5000);
                }
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
            bWaitService = null;
        }
    }

    public void setZArchiver(ZArchiver zArchiver, C0144e c0144e) {
        this.mZA = zArchiver;
        this.mService = c0144e;
        this.mLastToastMessage = null;
    }
}
