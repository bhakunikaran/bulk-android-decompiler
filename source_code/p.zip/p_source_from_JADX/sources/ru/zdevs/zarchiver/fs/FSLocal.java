package ru.zdevs.zarchiver.fs;

import android.content.Context;
import android.os.AsyncTask;
import java.io.File;
import java.util.List;
import java.util.Locale;
import ru.zdevs.zarchiver.Actions;
import ru.zdevs.zarchiver.R;
import ru.zdevs.zarchiver.ZArchiverExtInterface;
import ru.zdevs.zarchiver.fs.ZViewFS.FSFileInfo;
import ru.zdevs.zarchiver.fs.ZViewFS.FindResultListener;
import ru.zdevs.zarchiver.p003a.C0049e;
import ru.zdevs.zarchiver.p004b.C0073a;
import ru.zdevs.zarchiver.settings.Settings;
import ru.zdevs.zarchiver.tool.C0166c;
import ru.zdevs.zarchiver.tool.C0167d;
import ru.zdevs.zarchiver.tool.C0199n;
import ru.zdevs.zarchiver.tool.C0200o;
import ru.zdevs.zarchiver.tool.MimeTool;

public class FSLocal extends ZViewFS {
    private static final byte OVERLAY_APP_APP = (byte) 7;
    private static final byte OVERLAY_APP_DATA = (byte) 6;
    private static final byte OVERLAY_DEVICE = (byte) 2;
    private static final byte OVERLAY_MEDIA = (byte) 5;
    private static final byte OVERLAY_NONE = (byte) 0;
    private static final byte OVERLAY_ROOT = (byte) 3;
    private static final byte OVERLAY_STORAGE = (byte) 1;
    private static final byte OVERLAY_SYSTEM = (byte) 4;
    public static final String SCHEME = "local";
    private int mMes = 0;

    private FSFileInfo getFilesInfo(File file, String[] strArr, AsyncTask<?, ?, ?> asyncTask) {
        if (file == null || strArr == null) {
            return null;
        }
        FSFileInfo fSFileInfo = new FSFileInfo();
        fSFileInfo.mSize = 0;
        String absolutePath = file.getAbsolutePath();
        for (String str : strArr) {
            if (str != null) {
                File file2 = new File(absolutePath, str);
                if (!file2.isDirectory()) {
                    fSFileInfo.mSize = file2.length() + fSFileInfo.mSize;
                    fSFileInfo.mFileCount++;
                } else if (asyncTask != null) {
                    C0167d.m561a(file2, fSFileInfo, asyncTask);
                }
            }
        }
        return fSFileInfo;
    }

    private byte getOverlay(String str, byte b) {
        if (str == null || b == (byte) 0) {
            return (byte) 0;
        }
        switch (b) {
            case (byte) 1:
                if (str.equalsIgnoreCase("Alarms")) {
                    return (byte) 2;
                }
                if (str.equals("Android")) {
                    return (byte) 1;
                }
                if (str.equals("DCIM")) {
                    return (byte) 6;
                }
                if (str.equalsIgnoreCase("documents")) {
                    return (byte) 8;
                }
                if (str.equalsIgnoreCase("Download")) {
                    return (byte) 9;
                }
                if (str.equalsIgnoreCase("Movies")) {
                    return ZFileInfo.OVERLAY_TYPE_VIDEO;
                }
                if (str.equalsIgnoreCase("Music")) {
                    return (byte) 11;
                }
                if (str.equalsIgnoreCase("Notifications")) {
                    return (byte) 12;
                }
                if (str.equalsIgnoreCase("Pictures")) {
                    return (byte) 14;
                }
                if (str.equalsIgnoreCase("Podcasts")) {
                    return (byte) 15;
                }
                if (str.equalsIgnoreCase("Ringtones")) {
                    return (byte) 16;
                }
                if (str.equalsIgnoreCase("bluetooth")) {
                    return ZFileInfo.OVERLAY_TYPE_BLUETOOTH;
                }
                if (str.equalsIgnoreCase("book") || str.equalsIgnoreCase("books")) {
                    return ZFileInfo.OVERLAY_TYPE_BOOK;
                }
            case (byte) 3:
                if (str.equals("cache") || str.equals("data")) {
                    return (byte) 1;
                }
                if (str.equals("dev")) {
                    return (byte) 7;
                }
                if (str.equals("etc")) {
                    return (byte) 19;
                }
                if (str.equals("mnt") || str.equals(FSStorage.SCHEME)) {
                    return ZFileInfo.OVERLAY_TYPE_STORAGE;
                }
                if (str.equals(FSRoot.SCHEME)) {
                    return (byte) 17;
                }
                if (str.equals("bin") || str.equals("sbin")) {
                    return (byte) 5;
                }
                if (str.equals("system")) {
                    return (byte) 19;
                }
                break;
            case (byte) 4:
                if (str.equals("bin") || str.equals("sbin") || str.equals("xbin")) {
                    return (byte) 5;
                }
                if (str.equals("app") || str.equals("priv-app")) {
                    return (byte) 3;
                }
                if (str.equals("etc")) {
                    return (byte) 19;
                }
                if (str.equals("lost+found")) {
                    return ZFileInfo.OVERLAY_TYPE_TRASH;
                }
                if (str.equals("framework")) {
                    return ZFileInfo.OVERLAY_TYPE_FRAMEWORK;
                }
                if (str.equals("fonts")) {
                    return ZFileInfo.OVERLAY_TYPE_FONT;
                }
                break;
            case (byte) 5:
                if (str.equals("audio") || str.equals("ui")) {
                    return (byte) 11;
                }
                if (str.equals("alarms")) {
                    return (byte) 2;
                }
                if (str.equals("ringtones")) {
                    return (byte) 16;
                }
                if (str.equals("notifications")) {
                    return (byte) 12;
                }
                break;
            case Actions.CHECK_ACTION_RENAME /*6*/:
                return ZFileInfo.OVERLAY_TYPE_APP_DATA;
            case ZArchiverExtInterface.COMPRESSION_LAVEL_MAX /*7*/:
                return ZFileInfo.OVERLAY_TYPE_APP_APP;
        }
        return (byte) 0;
    }

    private byte getOverlayByPath(File file, byte b) {
        if (Settings.sArchiveDir != null) {
            try {
                if (Settings.sArchiveDir.equalsIgnoreCase(file.getCanonicalPath())) {
                    return ZFileInfo.OVERLAY_TYPE_ARCHIVE;
                }
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
        }
        return (byte) 0;
    }

    private byte getOverlayScheme(File file) {
        try {
            String canonicalPath = file.getCanonicalPath();
            if (canonicalPath.equals("/")) {
                return (byte) 3;
            }
            if (canonicalPath.equals("/storage") || canonicalPath.equals("/mnt")) {
                return (byte) 2;
            }
            if (canonicalPath.equals("/system") || canonicalPath.equals("/data/system") || canonicalPath.equals("/system/vendor") || canonicalPath.equals("/vendor")) {
                return (byte) 4;
            }
            if (canonicalPath.startsWith("/system/media")) {
                return (byte) 5;
            }
            if (canonicalPath.equals("/system/app") || canonicalPath.equals("/system/priv-app")) {
                return (byte) 7;
            }
            if (!canonicalPath.startsWith("/storage/") && !canonicalPath.startsWith("/mnt/")) {
                if (C0199n.m690a(canonicalPath) != null) {
                    return (byte) 1;
                }
                return (byte) 0;
            } else if (canonicalPath.endsWith("/Android/data") || canonicalPath.endsWith("/Android/obb")) {
                return (byte) 6;
            } else {
                File file2 = new File(canonicalPath);
                canonicalPath = file2.getParent();
                if (canonicalPath != null) {
                    if (canonicalPath.equals("/storage") || canonicalPath.equals("/storage/emulated")) {
                        return (byte) 1;
                    }
                    if (canonicalPath.equals("/mnt") && file2.canRead()) {
                        return (byte) 1;
                    }
                }
                return (byte) 0;
            }
        } catch (Throwable e) {
            C0166c.m556a(e);
        }
    }

    private void search_file(Thread thread, File file, String str, FindResultListener findResultListener) {
        if (file != null) {
            if (thread != null) {
                try {
                    if (thread.isInterrupted()) {
                        return;
                    }
                } catch (Throwable e) {
                    C0166c.m556a(e);
                    return;
                }
            }
            if (file.getName().toLowerCase(Locale.getDefault()).matches(str)) {
                FSFileInfo fSFileInfo = new FSFileInfo();
                fSFileInfo.mIsFile = file.isFile();
                fSFileInfo.mLastMod = file.lastModified();
                fSFileInfo.mSize = fSFileInfo.mIsFile ? file.length() : -1;
                findResultListener.onFoundNewFile(fSFileInfo, new MyUri(file.getParent()), file.getName());
            }
            if (file.isDirectory()) {
                File[] listFiles = file.listFiles();
                int length = listFiles.length;
                int i = 0;
                while (i < length) {
                    search_file(thread, listFiles[i], str, findResultListener);
                    if (thread == null || !thread.isInterrupted()) {
                        i++;
                    } else {
                        return;
                    }
                }
            }
        }
    }

    public FSFileInfo getFileInfo(MyUri myUri, AsyncTask<?, ?, ?> asyncTask) {
        if (myUri == null || !myUri.isLocalFS()) {
            return null;
        }
        try {
            File toFile = myUri.toFile();
            if (toFile == null || !toFile.exists()) {
                return null;
            }
            FSFileInfo fSFileInfo = new FSFileInfo();
            fSFileInfo.mIsFile = toFile.isFile();
            fSFileInfo.mLastMod = toFile.lastModified();
            if (!toFile.isDirectory()) {
                fSFileInfo.mSize = toFile.length();
                fSFileInfo.mFileCount++;
            } else if (asyncTask != null && C0200o.m711a(toFile.getAbsolutePath()) == (byte) 1) {
                C0167d.m561a(toFile, fSFileInfo, asyncTask);
            }
            fSFileInfo.mIsLink = C0167d.m565a(toFile);
            if (!fSFileInfo.mIsLink) {
                return fSFileInfo;
            }
            fSFileInfo.mLinkTo = toFile.getCanonicalFile().getAbsolutePath();
            return fSFileInfo;
        } catch (Throwable e) {
            C0166c.m556a(e);
            return null;
        }
    }

    public FSFileInfo getFilesInfo(MyUri myUri, String[] strArr, AsyncTask<?, ?, ?> asyncTask) {
        return (myUri == null || !myUri.isLocalFS()) ? null : getFilesInfo(myUri.toFile(), strArr, (AsyncTask) asyncTask);
    }

    public FSFileInfo getFilesInfo(MyUri[] myUriArr, String[] strArr, AsyncTask<?, ?, ?> asyncTask) {
        int i = 0;
        if (myUriArr == null || myUriArr.length <= 0 || !myUriArr[0].isLocalFS() || strArr == null || myUriArr.length != strArr.length) {
            return null;
        }
        FSFileInfo fSFileInfo = new FSFileInfo();
        fSFileInfo.mSize = 0;
        while (i < strArr.length) {
            if (!(myUriArr[i] == null || strArr[i] == null)) {
                File file = new File(myUriArr[i].toLocalPath(), strArr[i]);
                if (!file.isDirectory()) {
                    fSFileInfo.mSize = file.length() + fSFileInfo.mSize;
                } else if (asyncTask != null) {
                    fSFileInfo.mSize = C0167d.m566b(file, asyncTask) + fSFileInfo.mSize;
                }
            }
            i++;
        }
        return fSFileInfo;
    }

    public int getMessage() {
        return this.mMes;
    }

    public boolean getSearchFile(Thread thread, MyUri myUri, String str, FindResultListener findResultListener) {
        File toFile = myUri.toFile();
        if (toFile == null || !toFile.isDirectory() || findResultListener == null) {
            return false;
        }
        findResultListener.onStartFind();
        try {
            File[] listFiles = toFile.listFiles();
            int length = listFiles.length;
            int i = 0;
            for (File search_file : listFiles) {
                search_file(thread, search_file, str, findResultListener);
                if (thread != null && thread.isInterrupted()) {
                    return false;
                }
                i++;
                findResultListener.onSetFindProcess((i * 100) / length);
            }
        } catch (Throwable e) {
            C0166c.m556a(e);
        }
        findResultListener.onEndFind();
        return true;
    }

    public boolean list(Context context, MyUri myUri, List<C0049e> list, int i) {
        this.mMes = 0;
        File toFile = myUri.toFile();
        if (toFile == null || !toFile.isDirectory()) {
            return false;
        }
        list.clear();
        byte overlayScheme = getOverlayScheme(toFile);
        Object obj = !toFile.getAbsolutePath().startsWith("/storage/emulated") ? 1 : null;
        try {
            File[] listFiles = toFile.listFiles();
            if (listFiles != null) {
                for (File file : listFiles) {
                    if (sFMHideFile || file.getName().length() <= 0 || file.getName().charAt(0) != '.') {
                        byte b;
                        byte overlay;
                        long j;
                        if (file.isDirectory()) {
                            b = (byte) 2;
                            overlay = getOverlay(file.getName(), overlayScheme);
                            if (overlay == (byte) 0) {
                                overlay = getOverlayByPath(file, overlayScheme);
                            }
                            j = (obj == null || !C0167d.m565a(file)) ? 0 : -2;
                        } else {
                            String name = file.getName();
                            if (!file.isFile() && Settings.sRoot && C0073a.m304f() && (i & 2) == 0 && !name.equals(".android_secure")) {
                                return false;
                            }
                            b = ZFileInfo.getFileType(name);
                            overlay = (byte) 0;
                            if (b == (byte) 0) {
                                switch (MimeTool.m546a(file.getAbsolutePath())) {
                                    case 1:
                                        b = (byte) 7;
                                        overlay = ZFileInfo.OVERLAY_TYPE_ASSUMPTION;
                                        break;
                                    case 2:
                                        b = (byte) 8;
                                        overlay = ZFileInfo.OVERLAY_TYPE_ASSUMPTION;
                                        break;
                                }
                            }
                            j = (obj == null || !C0167d.m565a(file)) ? file.length() : -2;
                        }
                        list.add(new C0049e(file.getName(), b, overlay, file.lastModified(), j));
                    }
                }
                if (list.size() <= 0) {
                    this.mMes = R.string.MES_EMPTY_FOLDER;
                }
                ZViewFS.sort(list);
                if (toFile.getParent() != null && (sAddFolderUp || (i & 4) != 0)) {
                    list.add(0, new C0049e("..", (byte) 1, 0, 0));
                }
                myUri.setScheme(SCHEME);
                return true;
            } else if ((i & 2) == 0) {
                return false;
            } else {
                this.mMes = R.string.MES_ACCESS_DENIED;
                return true;
            }
        } catch (Exception e) {
            return false;
        }
    }
}
