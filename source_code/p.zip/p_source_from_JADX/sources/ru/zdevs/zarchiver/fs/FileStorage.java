package ru.zdevs.zarchiver.fs;

import android.content.Context;
import java.util.ArrayList;
import java.util.List;
import ru.zdevs.zarchiver.C0093d;
import ru.zdevs.zarchiver.C0136e;
import ru.zdevs.zarchiver.R;
import ru.zdevs.zarchiver.dialog.ZMenuDialog;
import ru.zdevs.zarchiver.p003a.C0049e;
import ru.zdevs.zarchiver.p003a.C0052g;
import ru.zdevs.zarchiver.settings.Settings;

public class FileStorage extends ZOpenFile {
    public C0136e mCS;

    public FileStorage(C0136e c0136e) {
        this.mCS = c0136e;
    }

    public boolean open(Context context, MyUri myUri, int[] iArr, List<C0049e> list, int i, int i2) {
        if (this.mCS.m414j() != '\u0000' || !myUri.isExternal()) {
            return false;
        }
        List arrayList = new ArrayList();
        C0093d c0093d = new C0093d(context);
        Object obj = 1;
        int length = iArr.length;
        int i3 = 0;
        while (i3 < length) {
            int i4 = iArr[i3];
            if (((C0049e) list.get(i4)).m107b()) {
                obj = null;
                break;
            }
            byte h = ((C0049e) list.get(i4)).mo29h();
            Object obj2 = (h == (byte) 7 || h == (byte) 6 || h == (byte) 8) ? obj : null;
            i3++;
            obj = obj2;
        }
        if (obj != null) {
            if (iArr.length == 1) {
                c0093d.m374a(arrayList, 1);
            }
            c0093d.m374a(arrayList, 5);
            c0093d.m374a(arrayList, 6);
            c0093d.m374a(arrayList, 4);
            c0093d.m374a(arrayList, 10);
        }
        c0093d.m375a(arrayList, 8, "*.zip");
        c0093d.m375a(arrayList, 9, "*.7z");
        c0093d.m374a(arrayList, 7);
        ZMenuDialog zMenuDialog = new ZMenuDialog(this.mCS, context, arrayList, iArr.length > 1 ? context.getString(R.string.MENU_SELECTED_FILES) : ((C0049e) list.get(iArr[0])).mo28e(), i, i2);
        zMenuDialog.setOnOkListener(this.mCS.f350a);
        zMenuDialog.setOnCancelListener(this.mCS.f350a);
        zMenuDialog.show();
        this.mCS.f350a.fillFileListAction(iArr, false);
        return true;
    }

    public boolean open_find(Context context, MyUri myUri, int[] iArr, List<C0052g> list, int i, int i2) {
        if (this.mCS.m414j() != '\u0000' || !myUri.isExternal()) {
            return false;
        }
        List arrayList = new ArrayList();
        C0093d c0093d = new C0093d(context);
        Object obj = 1;
        Object obj2 = null;
        int length = iArr.length;
        int i3 = 0;
        while (i3 < length) {
            int i4 = iArr[i3];
            if (i4 >= list.size()) {
                return false;
            }
            if (((C0052g) list.get(i4)).m107b()) {
                Object obj3 = null;
                obj = null;
                break;
            }
            byte h = ((C0052g) list.get(i4)).mo29h();
            if (h != (byte) 7 && h != (byte) 6 && h != (byte) 8) {
                Object obj4 = obj2;
                obj2 = null;
                obj3 = obj4;
            } else if (h == (byte) 6) {
                obj3 = 1;
                obj2 = obj;
            } else {
                obj3 = obj2;
                obj2 = obj;
            }
            i3++;
            obj = obj2;
            obj2 = obj3;
        }
        int i5 = 1;
        if (obj3 != null && iArr.length == 1 && (obj == null || obj2 != null)) {
            c0093d.m374a(arrayList, 18);
        }
        if (obj != null) {
            if (iArr.length == 1) {
                c0093d.m374a(arrayList, 1);
            }
            c0093d.m374a(arrayList, 10);
            c0093d.m374a(arrayList, 4);
        }
        c0093d.m374a(arrayList, 7);
        c0093d.m374a(arrayList, 22);
        c0093d.m374a(arrayList, 24);
        c0093d.m374a(arrayList, 25);
        c0093d.m374a(arrayList, 23);
        ZMenuDialog zMenuDialog = new ZMenuDialog(this.mCS, context, arrayList, iArr.length > 1 ? context.getString(R.string.MENU_SELECTED_FILES) : ((C0052g) list.get(iArr[0])).mo28e(), i, i2);
        zMenuDialog.setOnOkListener(this.mCS.f350a);
        zMenuDialog.show();
        this.mCS.f350a.fillFileListAction(iArr, true);
        return true;
    }

    public boolean open_long(Context context, MyUri myUri, int[] iArr, List<C0049e> list, int i, int i2) {
        if (this.mCS.m414j() != '\u0000' || !myUri.isExternal()) {
            return false;
        }
        String string;
        List arrayList = new ArrayList();
        C0093d c0093d = new C0093d(context);
        Object obj;
        if (iArr.length > 1) {
            obj = 1;
            int length = iArr.length;
            int i3 = 0;
            while (i3 < length) {
                int i4 = iArr[i3];
                if (((C0049e) list.get(i4)).m107b()) {
                    obj = null;
                    break;
                }
                byte h = ((C0049e) list.get(i4)).mo29h();
                Object obj2 = (h == (byte) 7 || h == (byte) 6 || h == (byte) 8) ? obj : null;
                i3++;
                obj = obj2;
            }
            if (Settings.sOpenArchive && r1 != null) {
                c0093d.m374a(arrayList, 10);
                c0093d.m374a(arrayList, 5);
                c0093d.m374a(arrayList, 6);
                c0093d.m374a(arrayList, 4);
            }
            if (Settings.sOpenFile && r1 == null) {
                c0093d.m375a(arrayList, 8, "*.zip");
                c0093d.m375a(arrayList, 9, "*.7z");
            }
            c0093d.m374a(arrayList, 7);
            c0093d.m374a(arrayList, 22);
            c0093d.m374a(arrayList, 24);
            c0093d.m374a(arrayList, 25);
            c0093d.m374a(arrayList, 23);
            string = context.getString(R.string.MENU_SELECTED_FILES);
        } else if (iArr[0] < 0 || iArr[0] >= list.size()) {
            return false;
        } else {
            obj = ((C0049e) list.get(iArr[0])).mo29h() == (byte) 7 ? 1 : null;
            if (obj == null || !Settings.sOpenArchive) {
                c0093d.m374a(arrayList, 18);
                if (!Settings.sOpenFile) {
                    c0093d.m374a(arrayList, 7);
                }
            } else {
                c0093d.m374a(arrayList, 10);
                c0093d.m374a(arrayList, 5);
                c0093d.m374a(arrayList, 6);
                c0093d.m374a(arrayList, 4);
            }
            if (((C0049e) list.get(iArr[0])).mo29h() == (byte) 2 || Settings.sOpenFile) {
                if (obj == null) {
                    c0093d.m375a(arrayList, 8, ((C0049e) list.get(iArr[0])).mo28e() + ".zip");
                    c0093d.m375a(arrayList, 9, ((C0049e) list.get(iArr[0])).mo28e() + ".7z");
                }
                c0093d.m374a(arrayList, 7);
            }
            c0093d.m374a(arrayList, 22);
            c0093d.m374a(arrayList, 24);
            c0093d.m374a(arrayList, 25);
            c0093d.m374a(arrayList, 23);
            c0093d.m374a(arrayList, 27);
            string = ((C0049e) list.get(iArr[0])).mo28e();
        }
        ZMenuDialog zMenuDialog = new ZMenuDialog(this.mCS, context, arrayList, string, i, i2);
        zMenuDialog.setOnOkListener(this.mCS.f350a);
        zMenuDialog.show();
        this.mCS.f350a.fillFileListAction(iArr, false);
        return true;
    }
}
