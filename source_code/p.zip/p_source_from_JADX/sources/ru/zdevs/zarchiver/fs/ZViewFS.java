package ru.zdevs.zarchiver.fs;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Build.VERSION;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import ru.zdevs.zarchiver.p003a.C0049e;
import ru.zdevs.zarchiver.p003a.C0052g;
import ru.zdevs.zarchiver.tool.C0196m.C0188a;
import ru.zdevs.zarchiver.tool.C0196m.C0189b;
import ru.zdevs.zarchiver.tool.C0196m.C0190c;
import ru.zdevs.zarchiver.tool.C0196m.C0191d;
import ru.zdevs.zarchiver.tool.C0196m.C0192e;
import ru.zdevs.zarchiver.tool.C0196m.C0193f;
import ru.zdevs.zarchiver.tool.C0196m.C0194g;
import ru.zdevs.zarchiver.tool.C0196m.C0195h;

public class ZViewFS {
    public static final int LIST_FLAGS_FOLDERUP = 4;
    public static final int LIST_FLAGS_FORCE = 2;
    public static final int LIST_FLAGS_NONE = 0;
    public static final int LIST_FLAGS_UPDATE = 1;
    public static boolean sAddFolderUp = true;
    public static Comparator<C0049e> sComparator = null;
    public static Comparator<C0049e> sComparatorFast = null;
    public static boolean sFMHideFile = true;
    public static List<ZViewFS> sFS;

    public interface FindResultListener {
        void onEndFind();

        void onFoundNewFile(FSFileInfo fSFileInfo, MyUri myUri, String str);

        void onSetFindProcess(int i);

        void onStartFind();
    }

    public static class FSFileInfo {
        public int mFileCount = 0;
        public String mGID = null;
        public boolean mIsFile = false;
        public boolean mIsLink = false;
        public long mLastMod = 0;
        public String mLinkTo = null;
        public int mPermissions = -1;
        public long mSize = 0;
        public String mUID = null;
    }

    public static List<ZViewFS> get() {
        if (sFS == null) {
            sFS = new ArrayList();
            sFS.add(new FSArchive());
            sFS.add(new FSLocal());
            if (VERSION.SDK_INT > 22) {
                sFS.add(new FSStorage());
            }
            sFS.add(new FSRoot());
        }
        return sFS;
    }

    public static void setSort(int i, boolean z) {
        switch (i) {
            case 1:
                sComparator = new C0194g(z);
                sComparatorFast = new C0195h(z);
                return;
            case 2:
                sComparator = new C0192e(z);
                sComparatorFast = new C0193f(z);
                return;
            case 3:
                sComparator = new C0188a(z);
                sComparatorFast = new C0189b(z);
                return;
            default:
                sComparator = new C0190c(z);
                sComparatorFast = new C0191d(z);
                return;
        }
    }

    protected static void sort(List<C0049e> list) {
        if (list.size() > 10000) {
            if (sComparatorFast == null) {
                sComparatorFast = new C0191d(false);
            }
            Collections.sort(list, sComparatorFast);
            return;
        }
        if (sComparator == null) {
            sComparator = new C0190c(false);
        }
        Collections.sort(list, sComparator);
    }

    public static void sortFind(List<C0052g> list) {
        if (sComparator == null) {
            sComparatorFast = new C0191d(false);
        }
        Collections.sort(list, sComparatorFast);
    }

    public FSFileInfo getFileInfo(MyUri myUri, AsyncTask<?, ?, ?> asyncTask) {
        return null;
    }

    public FSFileInfo getFilesInfo(MyUri myUri, String[] strArr, AsyncTask<?, ?, ?> asyncTask) {
        return null;
    }

    public FSFileInfo getFilesInfo(MyUri[] myUriArr, String[] strArr, AsyncTask<?, ?, ?> asyncTask) {
        return null;
    }

    public int getMessage() {
        return 0;
    }

    public boolean getSearchFile(Thread thread, MyUri myUri, String str, FindResultListener findResultListener) {
        return false;
    }

    public boolean list(Context context, MyUri myUri, List<C0049e> list, int i) {
        return false;
    }
}
