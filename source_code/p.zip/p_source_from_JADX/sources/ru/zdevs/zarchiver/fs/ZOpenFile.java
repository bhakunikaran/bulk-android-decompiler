package ru.zdevs.zarchiver.fs;

import android.content.Context;
import java.util.List;
import ru.zdevs.zarchiver.p003a.C0049e;
import ru.zdevs.zarchiver.p003a.C0052g;

public class ZOpenFile {
    public boolean open(Context context, MyUri myUri, int[] iArr, List<C0049e> list, int i, int i2) {
        return false;
    }

    public boolean open_find(Context context, MyUri myUri, int[] iArr, List<C0052g> list, int i, int i2) {
        return false;
    }

    public boolean open_long(Context context, MyUri myUri, int[] iArr, List<C0049e> list, int i, int i2) {
        return false;
    }
}
