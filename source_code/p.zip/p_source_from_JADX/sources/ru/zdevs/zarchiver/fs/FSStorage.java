package ru.zdevs.zarchiver.fs;

import android.content.Context;
import android.os.AsyncTask;
import java.util.List;
import java.util.Locale;
import ru.zdevs.zarchiver.R;
import ru.zdevs.zarchiver.fs.ZViewFS.FSFileInfo;
import ru.zdevs.zarchiver.fs.ZViewFS.FindResultListener;
import ru.zdevs.zarchiver.p003a.C0049e;
import ru.zdevs.zarchiver.tool.C0166c;
import ru.zdevs.zarchiver.tool.C0187l;
import ru.zdevs.zarchiver.tool.C0187l.C0186a;

public class FSStorage extends ZViewFS {
    public static final String SCHEME = "storage";
    private int mMes = 0;

    private void searchFile(Thread thread, C0186a c0186a, String str, String str2, FindResultListener findResultListener) {
        if (c0186a != null) {
            if (thread != null) {
                try {
                    if (thread.isInterrupted()) {
                        return;
                    }
                } catch (Throwable e) {
                    C0166c.m556a(e);
                    return;
                }
            }
            if (c0186a.f527a.toLowerCase(Locale.getDefault()).matches(str2)) {
                FSFileInfo fSFileInfo = new FSFileInfo();
                fSFileInfo.mIsFile = !c0186a.f528b;
                fSFileInfo.mLastMod = c0186a.f529c;
                fSFileInfo.mSize = c0186a.f530d;
                findResultListener.onFoundNewFile(fSFileInfo, new MyUri(SCHEME, str), c0186a.f527a);
            }
            if (c0186a.f528b) {
                C0186a[] b = C0187l.m668b(c0186a);
                int length = b.length;
                int i = 0;
                while (i < length) {
                    searchFile(thread, b[i], str + "/" + c0186a.f527a, str2, findResultListener);
                    if (thread == null || !thread.isInterrupted()) {
                        i++;
                    } else {
                        return;
                    }
                }
            }
        }
    }

    public FSFileInfo getFileInfo(MyUri myUri, AsyncTask<?, ?, ?> asyncTask) {
        boolean z = false;
        if (!myUri.isExternal()) {
            return null;
        }
        try {
            C0186a b = C0187l.m667b(myUri.getPath());
            if (b == null) {
                return null;
            }
            FSFileInfo fSFileInfo = new FSFileInfo();
            if (!b.f528b) {
                z = true;
            }
            fSFileInfo.mIsFile = z;
            fSFileInfo.mLastMod = b.f529c;
            fSFileInfo.mSize = b.f528b ? 0 : b.f530d;
            fSFileInfo.mIsLink = false;
            return fSFileInfo;
        } catch (Exception e) {
            return null;
        }
    }

    public FSFileInfo getFilesInfo(MyUri myUri, String[] strArr, AsyncTask<?, ?, ?> asyncTask) {
        if (myUri == null || !myUri.isExternal()) {
            return null;
        }
        FSFileInfo fSFileInfo = new FSFileInfo();
        fSFileInfo.mSize = 0;
        for (String str : strArr) {
            C0186a b = C0187l.m667b(myUri.getPath() + "/" + str);
            if (b != null) {
                fSFileInfo.mSize += b.f530d;
            }
        }
        return fSFileInfo;
    }

    public FSFileInfo getFilesInfo(MyUri[] myUriArr, String[] strArr, AsyncTask<?, ?, ?> asyncTask) {
        int i = 0;
        if (myUriArr == null || !myUriArr[0].isExternal()) {
            return null;
        }
        FSFileInfo fSFileInfo = new FSFileInfo();
        fSFileInfo.mSize = 0;
        while (i < strArr.length) {
            C0186a b = C0187l.m667b(myUriArr[i].getPath() + "/" + strArr[i]);
            if (b != null) {
                fSFileInfo.mSize = b.f530d + fSFileInfo.mSize;
            }
            i++;
        }
        return fSFileInfo;
    }

    public int getMessage() {
        return this.mMes;
    }

    public boolean getSearchFile(Thread thread, MyUri myUri, String str, FindResultListener findResultListener) {
        if (!myUri.isExternal()) {
            return false;
        }
        C0186a b = C0187l.m667b(myUri.getPath());
        if (b == null || !b.f528b) {
            return false;
        }
        if (findResultListener != null) {
            findResultListener.onStartFind();
        }
        try {
            C0186a[] b2 = C0187l.m668b(b);
            int length = b2.length;
            int length2 = b2.length;
            int i = 0;
            int i2 = 0;
            while (i < length2) {
                searchFile(thread, b2[i], myUri.getPath(), str, findResultListener);
                if (thread != null && thread.isInterrupted()) {
                    return false;
                }
                int i3 = i2 + 1;
                if (findResultListener != null) {
                    findResultListener.onSetFindProcess((i3 * 100) / length);
                }
                i++;
                i2 = i3;
            }
        } catch (Throwable e) {
            C0166c.m556a(e);
        }
        if (findResultListener != null) {
            findResultListener.onEndFind();
        }
        return true;
    }

    public boolean list(Context context, MyUri myUri, List<C0049e> list, int i) {
        if (!myUri.isExternal()) {
            return false;
        }
        this.mMes = 0;
        list.clear();
        try {
            List<C0186a> a = C0187l.m664a(myUri.getPath());
            if (a == null) {
                myUri.setPath(myUri.getPath().replace("/SAF", "/mnt/media_rw"));
                myUri.setScheme(FSRoot.SCHEME);
                return false;
            }
            for (C0186a c0186a : a) {
                if (sFMHideFile || c0186a.f527a.length() <= 0 || c0186a.f527a.charAt(0) != '.') {
                    list.add(new C0049e(c0186a.f527a, c0186a.f528b ? (byte) 2 : ZFileInfo.getFileType(c0186a.f527a), (byte) 0, c0186a.f529c, c0186a.f530d));
                }
            }
            if (list.size() <= 0) {
                this.mMes = R.string.MES_EMPTY_FOLDER;
            }
            ZViewFS.sort(list);
            if (myUri.getPath().lastIndexOf(47) > 5 && (sAddFolderUp || (i & 4) != 0)) {
                list.add(0, new C0049e("..", (byte) 1, 0, 0));
            }
            myUri.setScheme(SCHEME);
            return true;
        } catch (Exception e) {
            this.mMes = R.string.MES_ACCESS_DENIED;
            return false;
        }
    }
}
