package ru.zdevs.zarchiver.service.p005a;

import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import ru.zdevs.zarchiver.archiver.C2JBridge;
import ru.zdevs.zarchiver.p004b.C0075c;
import ru.zdevs.zarchiver.service.C0161d;
import ru.zdevs.zarchiver.service.ZArchiverService;
import ru.zdevs.zarchiver.tool.C0166c;
import ru.zdevs.zarchiver.tool.C0182i;

/* renamed from: ru.zdevs.zarchiver.service.a.h */
public abstract class C0148h extends Thread {
    /* renamed from: a */
    protected ZArchiverService f402a;
    /* renamed from: b */
    protected byte f403b;
    /* renamed from: c */
    protected int f404c;

    public C0148h(ZArchiverService zArchiverService, byte b, int i, int i2) {
        super(new ThreadGroup(b + ""), null, "_za_task" + b, 2097152);
        this.f402a = zArchiverService;
        this.f403b = b;
        this.f404c = i;
        C0161d.f454b[this.f404c] = this.f403b;
        C0161d.f455c[this.f404c] = i2;
        m468a(0);
        C2JBridge.m195a(i);
    }

    /* renamed from: a */
    protected void m467a(byte b) {
        this.f403b = b;
        C0161d.f454b[this.f404c] = b;
    }

    /* renamed from: a */
    protected void m468a(int i) {
        C0161d.m542a(this.f402a, this.f404c, i);
    }

    public abstract void a_();

    /* renamed from: b */
    protected C0075c m469b() {
        C0075c c0075c = new C0075c();
        c0075c.m308a(this.f404c);
        return c0075c;
    }

    public void run() {
        PowerManager powerManager = (PowerManager) this.f402a.getSystemService("power");
        WakeLock newWakeLock = powerManager != null ? powerManager.newWakeLock(1, "ZArchiverTask[" + this.f403b + "]") : null;
        if (newWakeLock != null) {
            newWakeLock.acquire();
        }
        C0166c.m558c("TaskBase", C0161d.f456d[this.f404c]);
        m468a(0);
        this.f402a.m462c(this.f404c, 3);
        long currentTimeMillis = System.currentTimeMillis();
        a_();
        currentTimeMillis = System.currentTimeMillis() - currentTimeMillis;
        C0166c.m559d("TaskBase", "Perform time: " + (currentTimeMillis / 60000) + "min " + ((currentTimeMillis / 1000) % 60) + "sec " + (currentTimeMillis % 1000) + "msec");
        if (newWakeLock != null) {
            newWakeLock.release();
        }
        if ((C0161d.f453a[this.f404c] & 2097152) == 2097152) {
            m468a(2162688);
        }
        if ((C0161d.f453a[this.f404c] & 1048576) != 1048576) {
            m468a(1310720);
        }
        C0182i.m630a();
    }
}
