package ru.zdevs.zarchiver.service;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import ru.zdevs.zarchiver.tool.C0202q;

public class ZArchiverClearTemp extends Service {
    public IBinder onBind(Intent intent) {
        return null;
    }

    public void onTaskRemoved(Intent intent) {
        C0202q.m738b((Context) this);
        super.onTaskRemoved(intent);
    }
}
