package ru.zdevs.zarchiver.service.p005a;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import ru.zdevs.zarchiver.R;
import ru.zdevs.zarchiver.archiver.C2JBridge;
import ru.zdevs.zarchiver.p004b.C0075c;
import ru.zdevs.zarchiver.service.C0159b;
import ru.zdevs.zarchiver.service.C0161d;
import ru.zdevs.zarchiver.service.ZArchiverService;

/* renamed from: ru.zdevs.zarchiver.service.a.g */
public class C0155g extends C0148h {
    /* renamed from: d */
    private List<String> f435d;
    /* renamed from: e */
    private List<String> f436e;
    /* renamed from: f */
    private int f437f;
    /* renamed from: g */
    private List<String> f438g;

    public C0155g(ZArchiverService zArchiverService, int i) {
        this(zArchiverService, i, 0);
    }

    public C0155g(ZArchiverService zArchiverService, int i, int i2) {
        super(zArchiverService, (byte) 11, i, i2);
    }

    /* renamed from: a */
    public void m496a(String str) {
        this.f435d = new ArrayList();
        this.f435d.add(str);
    }

    /* renamed from: a */
    public void m497a(String str, int i) {
        this.f436e = new ArrayList();
        this.f436e.add(str);
        this.f437f = i;
    }

    /* renamed from: a */
    public void m498a(List<String> list) {
        this.f435d = list;
        if (this.f435d.size() > 1) {
            m467a((byte) -117);
        }
    }

    /* renamed from: a */
    public void m499a(List<String> list, int i) {
        this.f436e = list;
        this.f437f = i;
    }

    public void a_() {
        boolean z = true;
        if (this.f435d == null || this.f436e == null || this.f435d.size() != this.f436e.size()) {
            m468a(1179648);
            this.a.m461b(this.c, true, false);
            return;
        }
        C0075c b = (this.f437f & 1) == 1 ? m469b() : null;
        StringBuilder stringBuilder = this.f435d.size() > 1 ? new StringBuilder() : null;
        int i = 0;
        boolean z2 = true;
        while (i < this.f435d.size()) {
            if (this.f438g != null) {
                C2JBridge.f202g[this.c] = ((String) this.f438g.get(i)) + " (" + (i + 1) + "/" + this.f438g.size() + ")";
                this.a.m465d(this.c, C2JBridge.f202g[this.c]);
            }
            boolean a = (this.f437f & 1) == 1 ? C0159b.m528a(b, this.c, (String) this.f435d.get(i), (String) this.f436e.get(i)) : C2JBridge.cTest(this.c, (String) this.f435d.get(i), (String) this.f436e.get(i));
            if (!(stringBuilder == null || a)) {
                String name = this.f438g == null ? new File((String) this.f435d.get(i)).getName() : (String) this.f438g.get(i);
                if (stringBuilder.length() > 0) {
                    stringBuilder.append(", ").append(name);
                } else {
                    stringBuilder.append(name);
                }
            }
            a = z2 && a;
            i++;
            z2 = a;
        }
        if (b != null) {
            b.mo54c();
        }
        m468a(z2 ? 1179648 : 1114112);
        if (stringBuilder != null) {
            if ((C0161d.f453a[this.c] & 15) != 15) {
                z = false;
            }
            if (z2 || z) {
                this.a.m461b(this.c, z2, z);
            } else {
                this.a.m454a(this.c, (int) R.string.MES_ARCHIVE_WITH_ERROR, stringBuilder.toString());
            }
        }
    }

    /* renamed from: b */
    public void m500b(List<String> list) {
        this.f438g = list;
    }
}
