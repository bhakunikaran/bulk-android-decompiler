package ru.zdevs.zarchiver.service;

import android.content.Context;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import ru.zdevs.zarchiver.io.C0143a;
import ru.zdevs.zarchiver.p004b.C0075c;
import ru.zdevs.zarchiver.service.p005a.C0156i;
import ru.zdevs.zarchiver.tool.C0166c;
import ru.zdevs.zarchiver.tool.C0182i;
import ru.zdevs.zarchiver.tool.C0204s;

/* renamed from: ru.zdevs.zarchiver.service.a */
public class C0158a {

    /* renamed from: ru.zdevs.zarchiver.service.a$a */
    public interface C0147a {
        /* renamed from: a */
        Context mo103a();
    }

    /* renamed from: a */
    public static int m513a(C0156i c0156i, C0075c c0075c, String str, String str2, int i, int i2) {
        return C0158a.m514a(c0156i, c0075c, str, str2, i, i2, 0);
    }

    /* renamed from: a */
    private static int m514a(C0156i c0156i, C0075c c0075c, String str, String str2, int i, int i2, int i3) {
        C0204s c0204s = new C0204s(str);
        C0204s c0204s2 = new C0204s(str2);
        if (!c0204s2.m749b() && (i3 == 0 || !C0143a.m433c(c0204s2.m753f()))) {
            return -1;
        }
        C0204s c0204s3;
        int a;
        if (c0204s.m746a()) {
            c0156i.m503a(c0204s.m754g().substring(i2));
            c0156i.m502a(0.0f);
            c0204s3 = new C0204s(str2 + str.substring(str.lastIndexOf(47), str.length()));
            if (c0204s3.m756i()) {
                a = i == 0 ? c0156i.m501a(c0204s, c0204s3) : i;
                i = (a & 16) != 16 ? 0 : a;
                if ((a & 8) == 8) {
                    return -2;
                }
                if ((a & 1) != 1) {
                    c0156i.m508d();
                    return i;
                }
            }
            if (!C0158a.m520a(c0204s, c0204s3)) {
                if (!C0158a.m519a(c0156i, c0075c, c0204s, c0204s3)) {
                    return -1;
                }
                C0158a.m523b(c0204s);
            }
            c0156i.m508d();
            return i;
        } else if (!c0204s.m749b()) {
            return i;
        } else {
            String[] o = c0204s.m762o();
            if (o == null) {
                return -1;
            }
            String str3 = str2 + "/" + c0204s.m751d();
            a = o.length;
            c0204s3 = new C0204s(str3);
            if (!c0204s3.m756i() && !c0204s3.m757j() && a <= 0) {
                return -1;
            }
            int i4 = i;
            for (String str4 : o) {
                if (i3 < 50) {
                    i4 = C0158a.m514a(c0156i, c0075c, str + "/" + str4, str3, i4, i2, i3 + 1);
                }
                if (c0156i.m507c()) {
                    return -2;
                }
                if (i4 < 0) {
                    return i4;
                }
            }
            C0158a.m523b(c0204s);
            return i4;
        }
    }

    /* renamed from: a */
    public static long m515a(String str) {
        return C0158a.m516a(new C0204s(str), 0);
    }

    /* renamed from: a */
    private static long m516a(C0204s c0204s, int i) {
        long j = 0;
        if (c0204s.m746a()) {
            return 1;
        }
        if (!c0204s.m749b()) {
            return 0;
        }
        for (C0204s c0204s2 : c0204s.m763p()) {
            if (i < 50) {
                j += C0158a.m516a(c0204s2, i + 1);
            }
        }
        return j;
    }

    /* renamed from: a */
    public static void m517a(C0147a c0147a, String str, boolean z) {
        C0204s c0204s = new C0204s(str);
        if (!c0204s.m756i()) {
            return;
        }
        if (c0204s.m749b()) {
            C0158a.m518a(c0204s);
            if (z) {
                C0182i.m635c(c0147a.mo103a(), c0204s.m753f());
                return;
            }
            return;
        }
        c0204s.m758k();
        if (z) {
            C0182i.m633b(c0147a.mo103a(), c0204s.m753f());
        }
    }

    /* renamed from: a */
    private static void m518a(C0204s c0204s) {
        if (c0204s != null) {
            if (c0204s.m749b()) {
                C0204s[] p = c0204s.m763p();
                if (p != null) {
                    for (C0204s a : p) {
                        C0158a.m518a(a);
                    }
                }
            }
            c0204s.m758k();
        }
    }

    /* renamed from: a */
    private static boolean m519a(C0156i c0156i, C0075c c0075c, C0204s c0204s, C0204s c0204s2) {
        try {
            int e;
            int c;
            int i;
            int i2;
            if (c0156i.m509e() > 5) {
                e = c0156i.m509e();
                c = (int) (c0204s.m750c() / ((long) e));
                if (c < 1048576) {
                    e /= 5;
                    c *= 5;
                    if (c < 1048576) {
                        i = 0;
                        i2 = c;
                    }
                }
                i = e;
                i2 = c;
            } else {
                i = 0;
                boolean z = false;
            }
            BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(c0204s2.m759l());
            BufferedInputStream bufferedInputStream = new BufferedInputStream(c0204s.m760m());
            byte[] bArr = new byte[2048];
            if (i <= 0) {
                while (true) {
                    e = bufferedInputStream.read(bArr, 0, 2048);
                    if (e == -1) {
                        break;
                    }
                    bufferedOutputStream.write(bArr, 0, e);
                }
            } else {
                e = 0;
                c = 0;
                while (true) {
                    int read = bufferedInputStream.read(bArr, 0, 2048);
                    if (read == -1) {
                        break;
                    }
                    bufferedOutputStream.write(bArr, 0, read);
                    c += read;
                    if (c >= i2) {
                        e++;
                        c0156i.m502a(((float) e) / ((float) i));
                        if (c0156i.m507c()) {
                            break;
                        }
                        c = 0;
                    }
                }
            }
            bufferedOutputStream.flush();
            bufferedInputStream.close();
            bufferedOutputStream.close();
            if (c0156i.m507c()) {
                c0204s2.m758k();
                return false;
            }
            if (c0204s.m755h() >= 0) {
                c0204s2.m747a(c0075c, c0204s.m755h());
            }
            return true;
        } catch (Throwable e2) {
            C0166c.m556a(e2);
            if (e2.getLocalizedMessage() != null && e2.getLocalizedMessage().length() > 0) {
                c0156i.m506b(e2.getLocalizedMessage());
                return false;
            } else if (e2.getMessage() == null || e2.getMessage().length() <= 0) {
                return false;
            } else {
                c0156i.m506b(e2.getMessage());
                return false;
            }
        }
    }

    /* renamed from: a */
    private static boolean m520a(C0204s c0204s, C0204s c0204s2) {
        try {
            return c0204s.m748a(c0204s2);
        } catch (Exception e) {
            return false;
        }
    }

    /* renamed from: b */
    public static int m521b(C0156i c0156i, C0075c c0075c, String str, String str2, int i, int i2) {
        return C0158a.m522b(c0156i, c0075c, str, str2, i, i2, 0);
    }

    /* renamed from: b */
    private static int m522b(C0156i c0156i, C0075c c0075c, String str, String str2, int i, int i2, int i3) {
        C0204s c0204s = new C0204s(str);
        C0204s c0204s2 = new C0204s(str2);
        if (!c0204s2.m749b() && (i3 == 0 || !C0143a.m433c(c0204s2.m753f()))) {
            return -1;
        }
        String str3;
        int a;
        if (c0204s.m746a()) {
            C0204s c0204s3;
            c0156i.m503a(c0204s.m754g().substring(i2));
            c0156i.m502a(0.0f);
            String d = c0204s.m751d();
            c0204s2 = new C0204s(str2 + "/" + d);
            if (c0204s2.m756i()) {
                if (c0204s.equals(c0204s2)) {
                    String str4;
                    int lastIndexOf = d.lastIndexOf(46);
                    if (lastIndexOf < 0 || lastIndexOf + 1 >= d.length()) {
                        str3 = "";
                        str4 = d;
                    } else {
                        str4 = d.substring(0, lastIndexOf);
                        str3 = d.substring(lastIndexOf + 1);
                    }
                    int i4 = 1;
                    do {
                        c0204s3 = i4 == 1 ? new C0204s(str2 + "/" + str4 + " (Copy)." + str3) : new C0204s(str2 + "/" + str4 + " (Copy " + i4 + ")." + str3);
                        i4++;
                    } while (c0204s3.m756i());
                    if (C0158a.m519a(c0156i, c0075c, c0204s, c0204s3)) {
                        return -1;
                    }
                    c0156i.m508d();
                    return i;
                }
                a = i == 0 ? c0156i.m501a(c0204s, c0204s2) : i;
                i = (a & 16) != 16 ? 0 : a;
                if ((a & 8) == 8) {
                    return -2;
                }
                if ((a & 1) != 1) {
                    c0156i.m508d();
                    return i;
                }
            }
            c0204s3 = c0204s2;
            if (C0158a.m519a(c0156i, c0075c, c0204s, c0204s3)) {
                return -1;
            }
            c0156i.m508d();
            return i;
        } else if (!c0204s.m749b() || c0204s.m761n()) {
            return i;
        } else {
            String[] o = c0204s.m762o();
            if (o == null) {
                return -1;
            }
            String str5 = str2 + "/" + c0204s.m751d();
            int length = o.length;
            c0204s2 = new C0204s(str5);
            if (c0204s2.m756i() && c0204s.equals(c0204s2)) {
                str5 = c0204s.m751d();
                a = 1;
                do {
                    c0204s2 = a == 1 ? new C0204s(str2 + "/" + str5 + " (Copy)") : new C0204s(str2 + "/" + str5 + " (Copy " + a + ")");
                    a++;
                } while (c0204s2.m756i());
                str5 = c0204s2.m753f();
            }
            if (!c0204s2.m756i() && !c0204s2.m757j() && length <= 0) {
                return -1;
            }
            int i5 = i;
            for (String str32 : o) {
                if (i3 < 50) {
                    i5 = C0158a.m522b(c0156i, c0075c, str + "/" + str32, str5, i5, i2, i3 + 1);
                }
                if (c0156i.m507c()) {
                    return -2;
                }
                if (i5 < 0) {
                    return i5;
                }
            }
            return i5;
        }
    }

    /* renamed from: b */
    private static void m523b(C0204s c0204s) {
        try {
            c0204s.m758k();
        } catch (Throwable e) {
            C0166c.m556a(e);
        }
    }
}
