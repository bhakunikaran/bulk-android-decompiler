package ru.zdevs.zarchiver.service.p005a;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import ru.zdevs.zarchiver.archiver.C2JBridge;
import ru.zdevs.zarchiver.p004b.C0075c;
import ru.zdevs.zarchiver.service.C0159b;
import ru.zdevs.zarchiver.service.C0160c;
import ru.zdevs.zarchiver.service.C0161d;
import ru.zdevs.zarchiver.service.ZArchiverService;
import ru.zdevs.zarchiver.tool.C0166c;
import ru.zdevs.zarchiver.tool.C0168e;
import ru.zdevs.zarchiver.tool.C0182i;
import ru.zdevs.zarchiver.tool.C0200o;

/* renamed from: ru.zdevs.zarchiver.service.a.e */
public class C0153e extends C0148h {
    /* renamed from: d */
    private List<String> f423d;
    /* renamed from: e */
    private List<String> f424e;
    /* renamed from: f */
    private List<String> f425f;
    /* renamed from: g */
    private List<String> f426g;
    /* renamed from: h */
    private int f427h;
    /* renamed from: i */
    private boolean f428i;
    /* renamed from: j */
    private List<String> f429j;

    public C0153e(ZArchiverService zArchiverService, int i) {
        this(zArchiverService, i, 0);
    }

    public C0153e(ZArchiverService zArchiverService, int i, int i2) {
        super(zArchiverService, (byte) 1, i, i2);
        this.f427h = 0;
    }

    /* renamed from: a */
    public void m486a(String str) {
        this.f423d = new ArrayList();
        this.f423d.add(str);
    }

    /* renamed from: a */
    public void m487a(String str, String str2, int i) {
        this.f426g = new ArrayList();
        this.f426g.add(str);
        this.f424e = new ArrayList();
        this.f424e.add(str2);
        this.f427h = i;
    }

    /* renamed from: a */
    public void m488a(String str, boolean z) {
        this.f425f = new ArrayList();
        this.f425f.add(str);
        this.f428i = z;
        if (z) {
            m467a((byte) 5);
        }
    }

    /* renamed from: a */
    public void m489a(List<String> list) {
        this.f423d = list;
        if (this.f423d.size() > 1) {
            m467a((byte) -127);
        }
    }

    /* renamed from: a */
    public void m490a(List<String> list, List<String> list2, int i) {
        this.f426g = list;
        this.f424e = list2;
        this.f427h = i;
    }

    public void a_() {
        if (this.f423d == null || this.f426g == null || this.f424e == null || !((this.f425f == null || this.f423d.size() == this.f425f.size()) && this.f423d.size() == this.f426g.size() && this.f423d.size() == this.f424e.size())) {
            m468a(1179648);
            this.a.m461b(this.c, true, false);
            return;
        }
        C0075c b = (this.f427h & 1) == 1 ? m469b() : null;
        if (!this.f428i && C0160c.f450b && C2JBridge.f203h == null) {
            C2JBridge.f203h = new C0075c();
            if (!C2JBridge.f203h.mo52b()) {
                C2JBridge.f203h = null;
            }
        }
        int i = this.f428i ? 1 : (!C0160c.f450b || C2JBridge.f203h == null) ? 0 : 2;
        int i2 = 0;
        boolean z = false;
        boolean z2 = true;
        while (i2 < this.f423d.size()) {
            String b2;
            boolean z3;
            boolean z4;
            String str = (String) this.f426g.get(i2);
            if (!str.startsWith("/SAF")) {
                try {
                    b2 = C0168e.m572b(new File(str).getCanonicalPath());
                } catch (Throwable e) {
                    C0166c.m556a(e);
                }
                if (this.f429j != null) {
                    C2JBridge.f202g[this.c] = ((String) this.f429j.get(i2)) + " (" + (i2 + 1) + "/" + this.f429j.size() + ")";
                    this.a.m465d(this.c, C2JBridge.f202g[this.c]);
                }
                String str2 = this.f425f == null ? (String) this.f425f.get(i2) : "";
                z3 = z2 && ((this.f427h & 1) != 1 ? C0159b.m529a(b, this.c, (String) this.f423d.get(i2), (String) this.f424e.get(i2), str2, b2) : C2JBridge.cExtract(this.c, (String) this.f423d.get(i2), (String) this.f424e.get(i2), str2, b2, i));
                if (z) {
                    boolean z5 = (C0200o.m711a(b2) == (byte) 1 || b2.contains("/Android/data") || b2.contains("/Android/obb")) ? false : true;
                    z4 = z5;
                } else {
                    z4 = z;
                }
                i2++;
                z = z4;
                z2 = z3;
            }
            b2 = str;
            if (this.f429j != null) {
                C2JBridge.f202g[this.c] = ((String) this.f429j.get(i2)) + " (" + (i2 + 1) + "/" + this.f429j.size() + ")";
                this.a.m465d(this.c, C2JBridge.f202g[this.c]);
            }
            if (this.f425f == null) {
            }
            if ((this.f427h & 1) != 1) {
            }
            if (!z2) {
            }
            if (z) {
                z4 = z;
            } else {
                if (C0200o.m711a(b2) == (byte) 1) {
                }
                z4 = z5;
            }
            i2++;
            z = z4;
            z2 = z3;
        }
        if (!this.f428i && z) {
            C0182i.m631a(this.a);
        }
        if (b != null) {
            b.mo54c();
        }
        if (this.a != null) {
            if (this.f423d.size() > 1) {
                this.a.m461b(this.c, z2, (C0161d.f453a[this.c] & 15) == 15);
            }
            if (this.f428i) {
                str2 = "";
                if (this.f424e.contains("\\-p")) {
                    str2 = ((String) this.f424e.get(0)).substring(this.f424e.indexOf("\\-p") + 3);
                    if (str2.contains("\\")) {
                        str2 = str2.substring(0, str2.indexOf(92));
                    }
                }
                String str3 = (String) this.f425f.get(0);
                String substring = (str3.length() <= 0 || str3.charAt(0) != '\\') ? str3 : str3.substring(1);
                this.a.m456a(this.c, substring, (String) this.f423d.get(0), str2, (this.f427h & 8) == 8);
                return;
            }
            this.a.m453a(this.c);
        }
    }

    /* renamed from: b */
    public void m491b(List<String> list) {
        this.f425f = list;
    }

    /* renamed from: c */
    public void m492c(List<String> list) {
        this.f429j = list;
    }
}
