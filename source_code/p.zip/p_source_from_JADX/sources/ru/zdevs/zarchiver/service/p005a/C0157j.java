package ru.zdevs.zarchiver.service.p005a;

import android.content.Context;
import java.util.List;
import ru.zdevs.zarchiver.archiver.C2JBridge;
import ru.zdevs.zarchiver.p004b.C0075c;
import ru.zdevs.zarchiver.service.C0158a;
import ru.zdevs.zarchiver.service.C0158a.C0147a;
import ru.zdevs.zarchiver.service.C0159b;
import ru.zdevs.zarchiver.service.C0161d;
import ru.zdevs.zarchiver.service.ZArchiverService;
import ru.zdevs.zarchiver.tool.C0182i;
import ru.zdevs.zarchiver.tool.C0200o;

/* renamed from: ru.zdevs.zarchiver.service.a.j */
public class C0157j extends C0148h implements C0147a {
    /* renamed from: d */
    private String f445d;
    /* renamed from: e */
    private List<String> f446e;
    /* renamed from: f */
    private int f447f;

    public C0157j(ZArchiverService zArchiverService, int i) {
        this(zArchiverService, i, 0);
    }

    public C0157j(ZArchiverService zArchiverService, int i, int i2) {
        super(zArchiverService, (byte) 6, i, i2);
    }

    /* renamed from: a */
    public Context mo103a() {
        return this.a;
    }

    /* renamed from: a */
    public void m511a(String str, List<String> list) {
        this.f445d = str;
        this.f446e = list;
    }

    public void a_() {
        boolean z = true;
        if (this.f446e == null || this.f446e.size() <= 0) {
            m468a(1179648);
            this.a.m461b(this.c, true, false);
            return;
        }
        C0075c b = (this.f447f & 1) == 1 ? m469b() : null;
        String str = (this.f447f & 2) == 0 ? this.f445d + "/" : "";
        boolean z2 = (this.f447f & 1) == 0 && (str.length() < 0 || !(str.contains("/Android/data") || str.contains("/Android/obb")));
        boolean z3 = true;
        int i = 0;
        for (String str2 : this.f446e) {
            String substring = (this.f447f & 2) == 2 ? str2.substring(str2.lastIndexOf(47) + 1) : str2;
            C2JBridge.f199d[this.c] = substring;
            this.a.m455a(this.c, substring);
            this.a.m458b(this.c, (i * 100) / this.f446e.size());
            if (C0161d.f453a[this.c] == 15) {
                break;
            }
            boolean z4;
            if ((this.f447f & 1) == 1) {
                z4 = C0159b.m530a(b, new StringBuilder().append(str).append(str2).toString(), this.c) && z3;
            } else {
                C0158a.m517a(this, str + str2, z2);
                z4 = z3;
            }
            i++;
            z3 = z4;
        }
        if ((this.f447f & 1) == 1 && (str.length() < 0 || !(C0200o.m711a(str) != (byte) 1 || str.contains("/Android/data") || str.contains("/Android/obb")))) {
            C0182i.m631a(this.a);
        }
        m468a(z3 ? 1179648 : 1114112);
        if (b != null) {
            b.mo54c();
        }
        if (this.a != null) {
            ZArchiverService zArchiverService = this.a;
            int i2 = this.c;
            if ((C0161d.f453a[this.c] & 15) != 15) {
                z = false;
            }
            zArchiverService.m461b(i2, z3, z);
            this.a.m453a(this.c);
        }
    }

    /* renamed from: b */
    public void m512b(int i) {
        this.f447f = i;
    }
}
