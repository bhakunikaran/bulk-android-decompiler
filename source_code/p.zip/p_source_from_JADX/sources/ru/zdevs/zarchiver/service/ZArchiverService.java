package ru.zdevs.zarchiver.service;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.Notification.Builder;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build.VERSION;
import android.os.IBinder;
import android.os.PowerManager;
import android.util.Log;
import android.util.SparseArray;
import java.io.File;
import java.util.List;
import ru.zdevs.zarchiver.Actions;
import ru.zdevs.zarchiver.R;
import ru.zdevs.zarchiver.ZArchiver;
import ru.zdevs.zarchiver.ZArchiverExt;
import ru.zdevs.zarchiver.ZArchiverExtInterface;
import ru.zdevs.zarchiver.archiver.AskOverwriteInfo;
import ru.zdevs.zarchiver.archiver.C0071e;
import ru.zdevs.zarchiver.archiver.C2JBridge;
import ru.zdevs.zarchiver.io.C0143a;
import ru.zdevs.zarchiver.service.C0144e.C0145a;
import ru.zdevs.zarchiver.service.p005a.C0149a;
import ru.zdevs.zarchiver.service.p005a.C0150b;
import ru.zdevs.zarchiver.service.p005a.C0151c;
import ru.zdevs.zarchiver.service.p005a.C0152d;
import ru.zdevs.zarchiver.service.p005a.C0153e;
import ru.zdevs.zarchiver.service.p005a.C0154f;
import ru.zdevs.zarchiver.service.p005a.C0155g;
import ru.zdevs.zarchiver.service.p005a.C0156i;
import ru.zdevs.zarchiver.service.p005a.C0157j;
import ru.zdevs.zarchiver.tool.C0166c;
import ru.zdevs.zarchiver.tool.C0182i;
import ru.zdevs.zarchiver.tool.C0202q;
import ru.zdevs.zarchiver.widget.bottomsheet.ViewDragHelper;

public class ZArchiverService extends Service {
    /* renamed from: a */
    private int f398a = 0;
    /* renamed from: b */
    private NotificationManager f399b = null;
    /* renamed from: c */
    private SparseArray<Builder> f400c;
    /* renamed from: d */
    private final C0145a f401d = new C01461(this);

    /* renamed from: ru.zdevs.zarchiver.service.ZArchiverService$1 */
    class C01461 extends C0145a {
        /* renamed from: a */
        final /* synthetic */ ZArchiverService f397a;

        C01461(ZArchiverService zArchiverService) {
            this.f397a = zArchiverService;
        }

        public void ArchiveAddFiles(String str, String str2, String str3, String str4, String str5, int i) {
            int c = C0161d.m545c();
            if (c >= 0) {
                C0161d.f456d[c] = str;
                C0149a c0149a = new C0149a(this.f397a, c);
                c0149a.m470a(str2);
                c0149a.m471a(str3, i);
                c0149a.m472a(str4, str5);
                this.f397a.m447c(0, c, this.f397a.getString(R.string.NTF_ADD_FILES_TO_ARC).replace("%1", C0161d.f456d[c]));
                c0149a.start();
            }
        }

        public void ArchiveAddFilesMulti(String str, String str2, String str3, List<String> list, List<String> list2, int i) {
            int c = C0161d.m545c();
            if (c >= 0) {
                C0161d.f456d[c] = str;
                C0149a c0149a = new C0149a(this.f397a, c);
                c0149a.m470a(str2);
                c0149a.m471a(str3, i);
                c0149a.m473a((List) list, (List) list2);
                this.f397a.m447c(0, c, this.f397a.getString(R.string.NTF_ADD_FILES_TO_ARC).replace("%1", C0161d.f456d[c]));
                c0149a.start();
            }
        }

        public void ArchiveCompress(int i, String str, String str2, String str3, List<String> list, String str4, int i2) {
            int c = C0161d.m545c();
            if (c >= 0) {
                C0161d.f456d[c] = str;
                C0150b c0150b = new C0150b(this.f397a, c, i);
                c0150b.m476a(str2);
                c0150b.m479a((List) list, str4);
                c0150b.m477a(str3, i2);
                this.f397a.m447c(i, c, this.f397a.getString(R.string.NTF_COMPRESS).replace("%1", C0161d.f456d[c]));
                c0150b.start();
            }
        }

        public void ArchiveCompressMulti(List<String> list, String str, List<String> list2, String str2, int i) {
            int c = C0161d.m545c();
            if (c >= 0) {
                C0161d.f456d[c] = ((String) list.get(0)) + ", ...";
                C0150b c0150b = new C0150b(this.f397a, c);
                c0150b.m478a((List) list);
                c0150b.m479a((List) list2, str2);
                c0150b.m477a(str, i);
                this.f397a.m447c(0, c, this.f397a.getString(R.string.NTF_COMPRESS).replace("%1", new File((String) list.get(0)).getName() + " (1/" + list.size() + ")"));
                c0150b.start();
            }
        }

        public void ArchiveCreateFolder(String str, String str2, String str3, String str4, int i) {
            int c = C0161d.m545c();
            if (c >= 0) {
                C0161d.f456d[c] = str;
                C0151c c0151c = new C0151c(this.f397a, c);
                c0151c.m480a(str2);
                c0151c.m482b(str4);
                c0151c.m481a(str3, i);
                this.f397a.m447c(0, c, this.f397a.getString(R.string.NTF_ADD_FILES_TO_ARC).replace("%1", C0161d.f456d[c]));
                c0151c.start();
            }
        }

        public void ArchiveDelFiles(String str, String str2, String str3, String str4, int i) {
            int c = C0161d.m545c();
            if (c >= 0) {
                C0161d.f456d[c] = str;
                C0152d c0152d = new C0152d(this.f397a, c);
                c0152d.m483a(str2);
                c0152d.m485b(str4);
                c0152d.m484a(str3, i);
                this.f397a.m447c(0, c, this.f397a.getString(R.string.NTF_DEL_FILES_FROM_ARC).replace("%1", C0161d.f456d[c]));
                c0152d.start();
            }
        }

        public void ArchiveExtract(int i, String str, String str2, String str3, String str4, String str5, int i2) {
            int c = C0161d.m545c();
            if (c >= 0) {
                C0161d.f456d[c] = str;
                C0153e c0153e = new C0153e(this.f397a, c, i);
                c0153e.m486a(str2);
                c0153e.m488a(str4, false);
                c0153e.m487a(str5, str3, i2);
                this.f397a.m447c(i, c, this.f397a.getString(R.string.NTF_EXTRACT).replace("%1", C0161d.f456d[c]));
                c0153e.start();
            }
        }

        public void ArchiveExtractMulti(int i, List<String> list, List<String> list2, List<String> list3, List<String> list4, List<String> list5, int i2) {
            int c = C0161d.m545c();
            if (c >= 0) {
                C0161d.f456d[c] = ((String) list.get(0)) + ", ...";
                C0153e c0153e = new C0153e(this.f397a, c, i);
                c0153e.m489a((List) list2);
                c0153e.m491b(list4);
                c0153e.m490a((List) list5, (List) list3, i2);
                c0153e.m492c(list);
                this.f397a.m447c(i, c, this.f397a.getString(R.string.NTF_EXTRACT).replace("%1", ((String) list.get(0)) + " (1/" + list.size() + ")"));
                c0153e.start();
            }
        }

        public void ArchiveOpenFile(String str, String str2, String str3, String str4, String str5, int i) {
            int c = C0161d.m545c();
            if (c >= 0) {
                C0161d.f456d[c] = str;
                C0153e c0153e = new C0153e(this.f397a, c);
                c0153e.m486a(str2);
                c0153e.m488a(str4, true);
                c0153e.m487a(str5, str3, i);
                this.f397a.m447c(0, c, this.f397a.getString(R.string.NTF_OPEN_FILE_FROM_ARCHIVE).replace("%1", C0161d.f456d[c]));
                c0153e.start();
            }
        }

        public void ArchiveRenFile(String str, String str2, String str3, String str4, String str5, int i) {
            int c = C0161d.m545c();
            if (c >= 0) {
                C0161d.f456d[c] = str;
                C0154f c0154f = new C0154f(this.f397a, c);
                c0154f.m493a(str2);
                c0154f.m495a(str4, str5);
                c0154f.m494a(str3, i);
                this.f397a.m447c(0, c, this.f397a.getString(R.string.NTF_MOVE_FILE).replace("%1", C0161d.f456d[c]));
                c0154f.start();
            }
        }

        public void ArchiveTest(String str, String str2, String str3) {
            int c = C0161d.m545c();
            if (c >= 0) {
                C0161d.f456d[c] = str;
                C0155g c0155g = new C0155g(this.f397a, c);
                c0155g.m496a(str2);
                c0155g.m497a(str3, 0);
                c0155g.start();
                this.f397a.m447c(0, c, this.f397a.getString(R.string.NTF_TEST).replace("%1", C0161d.f456d[c]));
            }
        }

        public void ArchiveTestMulti(List<String> list, List<String> list2, List<String> list3) {
            int c = C0161d.m545c();
            if (c >= 0) {
                C0161d.f456d[c] = ((String) list.get(0)) + ", ...";
                C0155g c0155g = new C0155g(this.f397a, c);
                c0155g.m498a((List) list2);
                c0155g.m499a((List) list3, 0);
                c0155g.m500b(list);
                this.f397a.m447c(0, c, this.f397a.getString(R.string.NTF_TEST).replace("%1", ((String) list.get(0)) + " (1/" + list.size() + ")"));
                c0155g.start();
            }
        }

        public void Copy(String str, String str2, List<String> list, int i) {
            int c = C0161d.m545c();
            if (c >= 0) {
                C0161d.f456d[c] = "";
                C0156i c0156i = new C0156i(this.f397a, false, c);
                c0156i.m504a(str, list, str2);
                c0156i.m505b(i);
                this.f397a.m447c(0, c, this.f397a.getString(R.string.NTF_COPY_FILE));
                c0156i.start();
            }
        }

        public void GUIStatus(int i) {
            C0166c.m558c("ZArchiverService", "GUIStatus (" + Integer.toHexString(i) + ")");
            switch (i) {
                case 0:
                    this.f397a.f398a = this.f397a.f398a & 4;
                    break;
                case 1:
                    this.f397a.f398a = this.f397a.f398a | i;
                    break;
                case 4:
                    this.f397a.f398a = this.f397a.f398a | i;
                    break;
                case ViewDragHelper.EDGE_BOTTOM /*8*/:
                    this.f397a.f398a = this.f397a.f398a & 1;
                    break;
            }
            this.f397a.m452a();
        }

        public AskOverwriteInfo GetAskOverwrite(int i) {
            return C2JBridge.f201f[i];
        }

        public int GetProgPercent(int i) {
            return i >= 5 ? 0 : C2JBridge.f200e[i];
        }

        public String GetProgText(int i) {
            return i >= 5 ? "" : C2JBridge.f199d[i];
        }

        public int GetStatusTask(int i) {
            return i >= 5 ? 1048576 : C0161d.f453a[i];
        }

        public void HideNotification(int i) {
            this.f397a.m449d(i);
        }

        public void Move(String str, String str2, List<String> list, int i) {
            int c = C0161d.m545c();
            if (c >= 0) {
                C0161d.f456d[c] = "";
                C0156i c0156i = new C0156i(this.f397a, true, c);
                c0156i.m504a(str, list, str2);
                c0156i.m505b(i);
                this.f397a.m447c(0, c, this.f397a.getString(R.string.NTF_MOVE_FILE));
                c0156i.start();
            }
        }

        public void Remove(String str, List<String> list, int i) {
            int c = C0161d.m545c();
            if (c >= 0) {
                C0161d.f456d[c] = (list.size() > 1 ? new File(str) : new File(str, (String) list.get(0))).getName();
                C0157j c0157j = new C0157j(this.f397a, c);
                c0157j.m511a(str, list);
                c0157j.m512b(i);
                if (list.size() > 1) {
                    this.f397a.m447c(0, c, this.f397a.getString(R.string.NTF_REMOVE_FILES).replace("%1", C0161d.f456d[c]));
                } else {
                    this.f397a.m447c(0, c, this.f397a.getString(R.string.NTF_REMOVE_FILE).replace("%1", C0161d.f456d[c]));
                }
                c0157j.start();
            }
        }

        public void RestartGUI() {
            Intent intent = new Intent(this.f397a, ZArchiver.class);
            intent.setFlags(268435456);
            this.f397a.startActivity(intent);
        }

        public void SetOverwrite(int i, int i2) {
            C2JBridge.m196a(i, i2);
        }

        public void SetPassword(int i, String str) {
            C2JBridge.m197a(i, str);
        }

        public void SetSettings() {
            C0143a.m427a(null);
            C0143a.m427a(this.f397a);
            C0160c.m537a(this.f397a);
        }

        public void SetStatusTask(int i, int i2) {
            C0161d.m542a(this.f397a, i, i2);
        }
    }

    @SuppressLint({"NewApi"})
    /* renamed from: a */
    private Notification m437a(Builder builder) {
        return VERSION.SDK_INT >= 16 ? builder.build() : builder.getNotification();
    }

    /* renamed from: a */
    private void m438a(int i, int i2, String str, String str2) {
        Intent intent;
        if (i <= 0) {
            intent = new Intent(this, ZArchiver.class);
            intent.setFlags(537919488);
        } else {
            intent = new Intent();
        }
        Builder builder = new Builder(this);
        builder.setSmallIcon(R.drawable.ic_stat_notify);
        builder.setTicker(str2);
        builder.setContentTitle(str);
        builder.setContentText(str2);
        builder.setWhen(System.currentTimeMillis());
        builder.setAutoCancel(true);
        builder.setContentIntent(PendingIntent.getActivity(this, i2 + 80, intent, 134217728));
        if (i <= 0 && !m445b()) {
            builder.setLights(-16711681, 300, 3000);
        }
        Notification a = m437a(builder);
        if (this.f399b != null) {
            this.f399b.notify(i2 + 80, a);
        }
    }

    /* renamed from: a */
    private void m439a(int i, int i2, String str, String str2, int i3) {
        Intent intent = new Intent(this, i > 0 ? ZArchiverExt.class : ZArchiver.class);
        intent.setFlags(537919488);
        intent.putExtra("ZArchiver.iCMD", i3);
        intent.putExtra("iTaskID", i2);
        intent.putExtra("iTaskIDExt", i);
        intent.putExtra("iTaskType", C0161d.f454b[i2]);
        if (i3 == 24) {
            intent.putExtra("iText", str2);
        }
        Builder builder = new Builder(this);
        builder.setSmallIcon(R.drawable.ic_stat_notify);
        builder.setTicker(str2);
        builder.setContentTitle(str);
        builder.setContentText(str2);
        builder.setWhen(System.currentTimeMillis());
        builder.setContentIntent(PendingIntent.getActivity(this, i2 + 70, intent, 134217728));
        if (i3 == 24) {
            builder.setAutoCancel(true);
        }
        if (i <= 0 && !m445b()) {
            builder.setLights(-256, 300, 3000);
        }
        Notification a = m437a(builder);
        a.flags |= 32;
        if (this.f399b != null) {
            this.f399b.notify(i2 + 70, a);
        }
    }

    /* renamed from: a */
    private void m440a(int i, String str, boolean z, boolean z2) {
        if (m448c() && C0161d.f455c[i] == 0) {
            Intent a = m451a(i, 18);
            a.putExtra("sText", str);
            String str2 = "iType";
            int i2 = z ? 1 : z2 ? 2 : 0;
            a.putExtra(str2, i2);
            sendBroadcast(a);
            return;
        }
        m438a(C0161d.f455c[i], i, C0161d.f456d[i], str);
    }

    /* renamed from: a */
    private void m441a(Builder builder, int i) {
        if (VERSION.SDK_INT < 24) {
            builder.setNumber(i);
        }
    }

    /* renamed from: b */
    private void m443b(int i) {
        if (this.f399b != null) {
            C0166c.m557b("ZArchiverService", "Task to foreground " + i);
            Builder builder = (Builder) this.f400c.get(i);
            if (builder != null) {
                Notification a = m437a(builder);
                a.flags |= 64;
                startForeground(i + 60, a);
            }
        }
    }

    @SuppressLint({"NewApi"})
    /* renamed from: b */
    private boolean m445b() {
        PowerManager powerManager = (PowerManager) getSystemService("power");
        if (powerManager == null) {
            return true;
        }
        try {
            return VERSION.SDK_INT >= 21 ? powerManager.isInteractive() : powerManager.isScreenOn();
        } catch (Throwable e) {
            C0166c.m556a(e);
            return true;
        }
    }

    /* renamed from: c */
    private void m446c(int i) {
        this.f400c.remove(i);
        C0166c.m557b("ZArchiverService", "Hide progress " + i);
        if (C0161d.m544b(i)) {
            int a = C0161d.m540a(i);
            if (a >= 0) {
                m443b(a);
            }
        } else {
            stopForeground(true);
        }
        if (this.f399b != null) {
            this.f399b.cancel(i + 60);
        }
    }

    /* renamed from: c */
    private void m447c(int i, int i2, String str) {
        Intent intent = new Intent(this, i > 0 ? ZArchiverExt.class : ZArchiver.class);
        intent.setFlags(537919488);
        intent.putExtra("ZArchiver.iCMD", 21);
        intent.putExtra("iTaskID", i2);
        intent.putExtra("iTaskIDExt", i);
        intent.putExtra("iTaskType", C0161d.f454b[i2]);
        Builder builder = new Builder(this);
        builder.setSmallIcon(R.drawable.ic_stat_notify);
        builder.setTicker("ZArchiver");
        builder.setContentTitle("ZArchiver");
        builder.setContentText(str);
        m441a(builder, 0);
        builder.setProgress(100, 0, false);
        builder.setWhen(System.currentTimeMillis());
        builder.setOngoing(true);
        builder.setContentIntent(PendingIntent.getActivity(this, i2 + 60, intent, 134217728));
        Notification a = m437a(builder);
        a.flags |= 64;
        C0166c.m557b("ZArchiverService", "Show progress " + i2);
        startForeground(i2 + 60, a);
        this.f400c.put(i2, builder);
    }

    /* renamed from: c */
    private boolean m448c() {
        return this.f398a == 1 && m445b();
    }

    /* renamed from: d */
    private void m449d(int i) {
        if (this.f399b != null) {
            this.f399b.cancel(i + 70);
        }
    }

    /* renamed from: e */
    private void m450e(int i, int i2) {
        if (this.f399b != null) {
            Builder builder = (Builder) this.f400c.get(i);
            if (builder != null) {
                builder.setProgress(100, i2, false);
                m441a(builder, i2);
                Notification a = m437a(builder);
                a.flags |= 64;
                this.f399b.notify(i + 60, a);
            }
        }
    }

    /* renamed from: a */
    public Intent m451a(int i, int i2) {
        Intent intent = new Intent("ZArchiver.iMES");
        intent.putExtra("iTaskID", i);
        intent.putExtra("iTaskType", C0161d.f454b[i]);
        intent.putExtra("iAction", i2);
        intent.putExtra("iTaskIDExt", C0161d.f455c[i]);
        return intent;
    }

    /* renamed from: a */
    public void m452a() {
        if (!C0161d.m543b()) {
            if (C2JBridge.f203h != null) {
                C2JBridge.f203h.mo54c();
                C2JBridge.f203h = null;
            }
            if (this.f398a == 0 && !C0182i.m634b()) {
                Log.w("ZArchiverService", "Stop service...");
                C0182i.m630a();
                stopSelf();
            }
        }
    }

    /* renamed from: a */
    public synchronized void m453a(int i) {
        if ((this.f398a & 1) != 0) {
            Intent a = m451a(i, 0);
            a.putExtra("iAction", 6);
            sendBroadcast(a);
        }
    }

    /* renamed from: a */
    public void m454a(int i, int i2, String str) {
        String str2 = "";
        if (i2 != 0) {
            str2 = getString(R.string.MES_ARCHIVE_WITH_ERROR);
        }
        if (str != null && str.length() > 0) {
            str2 = str2.length() > 0 ? str2.replace("%1", str) : str;
        }
        if (this.f398a == 1 && C0161d.f455c[i] == 0 && m445b()) {
            Intent a = m451a(i, 21);
            a.putExtra("sText", str2);
            sendBroadcast(a);
            return;
        }
        m439a(C0161d.f455c[i], i, C0161d.f456d[i], str2, 24);
    }

    /* renamed from: a */
    public synchronized void m455a(int i, String str) {
        if ((this.f398a & 5) != 0) {
            Intent a = m451a(i, 3);
            a.putExtra("sText", str);
            sendBroadcast(a);
        }
    }

    /* renamed from: a */
    public synchronized void m456a(int i, String str, String str2, String str3, boolean z) {
        Intent a = m451a(i, 0);
        String str4 = C0161d.f456d[i];
        a.putExtra("iAction", 19);
        a.putExtra("sFilePath", C0202q.m727a((Context) this) + "/" + str4);
        a.putExtra("bOpenAs", z);
        if (str3 != null && str3.length() > 0) {
            a.putExtra("bProtectFile", true);
        }
        sendBroadcast(a);
    }

    /* renamed from: a */
    public void m457a(int i, boolean z, boolean z2) {
        if (z2) {
            m440a(i, getString(R.string.MES_CANCEL_PROCES), false, true);
        } else if (z) {
            switch ((byte) (C0161d.f454b[i] & 127)) {
                case (byte) 1:
                    m440a(i, getString(R.string.MES_SUCESSFUL_DECOMPRESS), false, true);
                    return;
                case (byte) 3:
                    m440a(i, getString(R.string.MES_SUCESSFUL_COMPRESS), false, true);
                    return;
                case (byte) 4:
                case Actions.CHECK_ACTION_RENAME /*6*/:
                case (byte) 10:
                    if (!m448c()) {
                        return;
                    }
                    return;
                case ZArchiverExtInterface.COMPRESSION_LAVEL_MAX /*7*/:
                    m440a(i, getString(R.string.MES_SUCESSFUL_ADD_FILE), false, true);
                    return;
                case ViewDragHelper.EDGE_BOTTOM /*8*/:
                    m440a(i, getString(R.string.MES_SUCESSFUL_DEL_FILE), false, true);
                    return;
                case (byte) 11:
                    if ((C0161d.f454b[i] & -128) != 0) {
                        m440a(i, getString(R.string.MES_SUCESSFUL_TESTS), false, true);
                        return;
                    } else {
                        m440a(i, getString(R.string.MES_SUCESSFUL_TEST), false, true);
                        return;
                    }
                default:
                    return;
            }
        } else if (C0161d.f454b[i] != (byte) -117) {
            m440a(i, getString(R.string.MES_END_WITH_ERROR), false, true);
        }
    }

    /* renamed from: b */
    public synchronized void m458b(int i, int i2) {
        m450e(i, i2);
        if ((this.f398a & 5) != 0) {
            Intent a = m451a(i, 4);
            a.putExtra("iProgress", i2);
            sendBroadcast(a);
        }
    }

    /* renamed from: b */
    public synchronized void m459b(int i, int i2, String str) {
        if ((C0161d.f454b[i] & 127) != 11 || (this.f398a == 1 && m445b())) {
            String a = C0071e.m288a((Context) this, i2);
            if (a != null) {
                str = a;
            } else if (i2 == 0) {
                str = getString(R.string.ERROR_ERROR) + str;
            }
            m440a(i, str, true, false);
        }
    }

    /* renamed from: b */
    public synchronized void m460b(int i, String str) {
        if ((this.f398a & 1) != 0) {
            Intent a = m451a(i, 0);
            a.putExtra("iAction", 20);
            a.putExtra("sFilePath", str);
            sendBroadcast(a);
        }
    }

    /* renamed from: b */
    public synchronized void m461b(int i, boolean z, boolean z2) {
        byte b = (byte) (C0161d.f454b[i] & 127);
        if (!z) {
            switch (b) {
                case (byte) 1:
                case (byte) 3:
                case (byte) 5:
                case (byte) 9:
                case (byte) 11:
                case (byte) 12:
                    m457a(i, false, z2);
                    break;
                default:
                    break;
            }
        }
        switch (b) {
            case (byte) 1:
            case (byte) 3:
            case (byte) 4:
            case Actions.CHECK_ACTION_RENAME /*6*/:
            case ZArchiverExtInterface.COMPRESSION_LAVEL_MAX /*7*/:
            case ViewDragHelper.EDGE_BOTTOM /*8*/:
            case (byte) 10:
                m457a(i, true, z2);
                break;
            case (byte) 11:
                m457a(i, true, z2);
                break;
        }
        if (C0161d.f455c[i] != 0) {
            Intent a = m451a(i, 0);
            a.putExtra("iAction", z ? 16 : 17);
            sendBroadcast(a);
        }
    }

    /* renamed from: c */
    public synchronized void m462c(int i, int i2) {
        switch (i2) {
            case 1:
                m439a(C0161d.f455c[i], i, C0161d.f456d[i], getString(R.string.NTF_REQUEST_PASSWORD), 22);
                break;
            case 2:
                m439a(C0161d.f455c[i], i, C0161d.f456d[i], getString(R.string.NTF_REQUEST_OVERWRITE), 23);
                break;
        }
        switch (i2) {
            case 1:
                if ((this.f398a & 5) != 0) {
                    sendBroadcast(m451a(i, 5));
                    break;
                }
                break;
            case 2:
                if ((this.f398a & 1) != 0) {
                    sendBroadcast(m451a(i, 8));
                    break;
                }
                break;
            case 3:
                if ((this.f398a & 5) != 0) {
                    sendBroadcast(m451a(i, 1));
                    break;
                }
                break;
        }
    }

    /* renamed from: c */
    public synchronized void m463c(int i, String str) {
        if ((this.f398a & 1) != 0) {
            Intent a = m451a(i, 11);
            String str2 = "bState";
            boolean z = str != null && str.length() > 0;
            a.putExtra(str2, z);
            sendBroadcast(a);
        }
    }

    /* renamed from: d */
    public synchronized void m464d(int i, int i2) {
        Intent a;
        switch (i2) {
            case 0:
                m449d(i);
                m446c(i);
                if ((this.f398a & 5) != 0) {
                    a = m451a(i, 2);
                    a.putExtra("iDialogType", -1);
                    sendBroadcast(a);
                    break;
                }
                break;
            case 1:
            case 2:
                m449d(i);
                break;
            case 3:
                m446c(i);
                if ((this.f398a & 5) != 0) {
                    a = m451a(i, 2);
                    a.putExtra("iDialogType", '\u0002');
                    sendBroadcast(a);
                    break;
                }
                break;
        }
    }

    /* renamed from: d */
    public synchronized void m465d(int i, String str) {
        switch ((byte) (C0161d.f454b[i] & 127)) {
            case (byte) 11:
                m447c(C0161d.f455c[i], i, getString(R.string.NTF_TEST).replace("%1", str));
                break;
            default:
                m447c(C0161d.f455c[i], i, getString(R.string.NTF_EXTRACT).replace("%1", str));
                break;
        }
        if ((this.f398a & 1) != 0) {
            Intent a = m451a(i, 15);
            a.putExtra("sText", str);
            sendBroadcast(a);
        }
    }

    public IBinder onBind(Intent intent) {
        return this.f401d;
    }

    public void onCreate() {
        C0161d.m541a();
        this.f399b = (NotificationManager) getSystemService("notification");
        this.f400c = new SparseArray();
        C2JBridge.m198a(this);
        C0143a.m427a((Context) this);
        C0160c.m537a(this);
        Log.d("ZArchiverService", "Service start");
    }

    public void onDestroy() {
        C2JBridge.m198a(null);
        C0143a.m427a(null);
        for (int i = 0; i < 5; i++) {
            this.f399b.cancel(i + 60);
            this.f399b.cancel(i + 70);
        }
        this.f399b = null;
        this.f400c = null;
        Log.d("ZArchiverService", "Service stop");
    }

    public void onStart(Intent intent, int i) {
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        if (intent == null) {
            Log.w("ZArchiverService", "Service restarted...");
            m452a();
        }
        return 1;
    }

    public void onTaskRemoved(Intent intent) {
        m452a();
    }
}
