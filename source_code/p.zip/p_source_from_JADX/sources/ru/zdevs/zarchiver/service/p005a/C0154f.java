package ru.zdevs.zarchiver.service.p005a;

import ru.zdevs.zarchiver.archiver.C2JBridge;
import ru.zdevs.zarchiver.p004b.C0075c;
import ru.zdevs.zarchiver.service.C0159b;
import ru.zdevs.zarchiver.service.ZArchiverService;

/* renamed from: ru.zdevs.zarchiver.service.a.f */
public class C0154f extends C0148h {
    /* renamed from: d */
    private String f430d;
    /* renamed from: e */
    private String f431e;
    /* renamed from: f */
    private String f432f;
    /* renamed from: g */
    private String f433g;
    /* renamed from: h */
    private int f434h;

    public C0154f(ZArchiverService zArchiverService, int i) {
        this(zArchiverService, i, 0);
    }

    public C0154f(ZArchiverService zArchiverService, int i, int i2) {
        super(zArchiverService, (byte) 9, i, i2);
    }

    /* renamed from: a */
    public void m493a(String str) {
        this.f430d = str;
    }

    /* renamed from: a */
    public void m494a(String str, int i) {
        this.f433g = str;
        this.f434h = i;
    }

    /* renamed from: a */
    public void m495a(String str, String str2) {
        this.f431e = str;
        this.f432f = str2;
    }

    public void a_() {
        boolean e;
        C0075c c0075c;
        if ((this.f434h & 1) == 1) {
            C0075c b = m469b();
            e = C0159b.m536e(b, this.c, this.f430d, this.f433g, this.f431e, this.f432f);
            c0075c = b;
        } else {
            c0075c = null;
            e = C2JBridge.cRename(this.c, this.f430d, this.f433g, this.f431e, this.f432f);
        }
        m468a(e ? 1179648 : 1114112);
        if (c0075c != null) {
            c0075c.mo54c();
        }
        if (this.a != null && e) {
            this.a.m453a(this.c);
        }
    }
}
