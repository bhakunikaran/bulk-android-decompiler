package ru.zdevs.zarchiver.activity;

import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.preference.PreferenceActivity;
import android.preference.PreferenceActivity.Header;
import android.preference.PreferenceFragment;
import android.view.KeyEvent;
import android.view.MenuItem;
import java.util.List;
import p000a.p001a.p002a.C0002a;
import ru.zdevs.zarchiver.R;
import ru.zdevs.zarchiver.ZArchiver;
import ru.zdevs.zarchiver.fs.FSRoot;
import ru.zdevs.zarchiver.settings.Settings;
import ru.zdevs.zarchiver.tool.C0202q;

public class SettingsDlg extends PreferenceActivity {

    public static class SettingsFragment extends PreferenceFragment {
        public void onCreate(Bundle bundle) {
            super.onCreate(bundle);
            String string = getArguments().getString("settings");
            if ("general".equals(string)) {
                addPreferencesFromResource(R.xml.pref_general);
            } else if ("gui".equals(string)) {
                addPreferencesFromResource(R.xml.pref_gui);
            } else if ("fm".equals(string)) {
                addPreferencesFromResource(R.xml.pref_fm);
            } else if ("compression".equals(string)) {
                addPreferencesFromResource(R.xml.pref_compression);
            } else if (FSRoot.SCHEME.equals(string)) {
                addPreferencesFromResource(R.xml.pref_root);
            }
        }
    }

    /* renamed from: a */
    private void m154a() {
        if (Settings.sActionbarColor != 0 && VERSION.SDK_INT < 21) {
            int b = C0202q.m735b((Context) this, (int) R.attr.colorPrimary);
            C0002a c0002a = new C0002a(this);
            c0002a.m15a(true);
            if (Settings.sGUIWideBar) {
                c0002a.m17b(true);
            }
            c0002a.m14a(b);
            ActionBar actionBar = getActionBar();
            if (actionBar != null) {
                Drawable colorDrawable = new ColorDrawable(b);
                actionBar.setBackgroundDrawable(colorDrawable);
                actionBar.setSplitBackgroundDrawable(colorDrawable);
            }
        }
    }

    @SuppressLint({"NewApi"})
    public void finishAndRemoveTask() {
        if (VERSION.SDK_INT < 21) {
            finish();
        } else {
            super.finishAndRemoveTask();
        }
    }

    public boolean isValidFragment(String str) {
        return true;
    }

    public void onBuildHeaders(List<Header> list) {
        loadHeadersFromResource(R.xml.pref_header, list);
    }

    protected void onCreate(Bundle bundle) {
        boolean z = false;
        if (Build.MANUFACTURER != null && Build.MANUFACTURER.contains("samsung") && VERSION.SDK_INT >= 21) {
            if ((getResources().getConfiguration().screenLayout & 15) >= 3) {
                z = true;
            }
            if (z) {
                setTheme(Settings.getTheme(1));
            }
        }
        if (!z) {
            setTheme(Settings.sThemeResource);
        }
        ZArchiver.setLanguage(this);
        super.onCreate(bundle);
        setTitle(R.string.OPT_TTL_SETTINGS);
        ActionBar actionBar = getActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
        m154a();
        Settings.sUpSetting = true;
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (i != 4) {
            return super.onKeyDown(i, keyEvent);
        }
        finishAndRemoveTask();
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 16908332) {
            return super.onOptionsItemSelected(menuItem);
        }
        finishAndRemoveTask();
        return true;
    }
}
