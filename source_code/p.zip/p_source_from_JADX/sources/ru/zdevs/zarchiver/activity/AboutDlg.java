package ru.zdevs.zarchiver.activity;

import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.app.ActionBar.OnNavigationListener;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import java.lang.reflect.Method;
import p000a.p001a.p002a.C0002a;
import ru.zdevs.zarchiver.C0058a;
import ru.zdevs.zarchiver.R;
import ru.zdevs.zarchiver.ZArchiver;
import ru.zdevs.zarchiver.settings.Settings;
import ru.zdevs.zarchiver.tool.C0166c;
import ru.zdevs.zarchiver.tool.C0202q;

public class AboutDlg extends Activity implements OnNavigationListener {
    /* renamed from: a */
    private int f179a;
    /* renamed from: b */
    private String f180b;

    /* renamed from: a */
    private void m151a() {
        if (Settings.sActionbarColor != 0 && VERSION.SDK_INT < 21) {
            int b = C0202q.m735b((Context) this, (int) R.attr.colorPrimary);
            C0002a c0002a = new C0002a(this);
            c0002a.m15a(true);
            if (Settings.sGUIWideBar) {
                c0002a.m17b(true);
            }
            c0002a.m14a(b);
            ActionBar actionBar = getActionBar();
            if (actionBar != null) {
                Drawable colorDrawable = new ColorDrawable(b);
                actionBar.setBackgroundDrawable(colorDrawable);
                actionBar.setSplitBackgroundDrawable(colorDrawable);
            }
        }
    }

    /* renamed from: a */
    private void m152a(int i) {
        if (this.f179a != i) {
            TextView textView;
            switch (i) {
                case 0:
                    setContentView(R.layout.dlg_about);
                    textView = (TextView) findViewById(R.id.tv_version);
                    if (textView != null) {
                        textView.setText(this.f180b);
                        return;
                    }
                    return;
                case 1:
                    setContentView(R.layout.dlg_donate);
                    textView = (TextView) findViewById(R.id.tv_tr);
                    if (textView != null) {
                        textView.setText(getString(R.string.DNT_TRANSLATE, new Object[]{getString(R.string.DNT_TRANSLATE_URL)}));
                        return;
                    }
                    return;
                default:
                    return;
            }
        }
    }

    /* renamed from: a */
    private void m153a(Menu menu) {
        if (menu != null && !C0058a.m145a()) {
            try {
                if (menu.getClass().getSimpleName().equals("MenuBuilder")) {
                    Method declaredMethod = menu.getClass().getDeclaredMethod("setOptionalIconsVisible", new Class[]{Boolean.TYPE});
                    if (declaredMethod != null) {
                        declaredMethod.setAccessible(true);
                        declaredMethod.invoke(menu, new Object[]{Boolean.valueOf(true)});
                    }
                }
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
        }
    }

    @SuppressLint({"NewApi"})
    public void finishAndRemoveTask() {
        if (VERSION.SDK_INT < 21) {
            finish();
        } else {
            super.finishAndRemoveTask();
        }
    }

    public MenuInflater getMenuInflater() {
        return VERSION.SDK_INT < 16 ? new MenuInflater(this) : super.getMenuInflater();
    }

    protected void onCreate(Bundle bundle) {
        setTheme(Settings.sThemeResource);
        ZArchiver.setLanguage(this);
        super.onCreate(bundle);
        try {
            PackageInfo packageInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
            this.f180b = packageInfo.versionName;
            if ((packageInfo.versionCode % 100) / 10 == 0) {
                this.f180b += " TEST";
            }
        } catch (Exception e) {
            this.f180b = "Unknown";
        }
        this.f179a = -1;
        m152a(0);
        m151a();
        ActionBar actionBar = getActionBar();
        if (actionBar != null) {
            SpinnerAdapter createFromResource = ArrayAdapter.createFromResource(actionBar.getThemedContext(), R.array.ABT_LOCATIONS, 17367048);
            createFromResource.setDropDownViewResource(R.layout.item_spinner);
            actionBar.setNavigationMode(1);
            actionBar.setListNavigationCallbacks(createFromResource, this);
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setDisplayShowTitleEnabled(false);
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_about, menu);
        return true;
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (i != 4) {
            return super.onKeyDown(i, keyEvent);
        }
        finishAndRemoveTask();
        return true;
    }

    public boolean onMenuOpened(int i, Menu menu) {
        if (i == 8) {
            m153a(menu);
        }
        return super.onMenuOpened(i, menu);
    }

    public boolean onNavigationItemSelected(int i, long j) {
        m152a(i);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 16908332) {
            return super.onOptionsItemSelected(menuItem);
        }
        finishAndRemoveTask();
        return true;
    }

    public void onToolbarItemClick(MenuItem menuItem) {
        if (menuItem != null) {
            Intent intent;
            switch (menuItem.getItemId()) {
                case R.id.bFeedback:
                    intent = new Intent("android.intent.action.SENDTO");
                    intent.setType("text/plain");
                    intent.putExtra("android.intent.extra.SUBJECT", "ZArchiver " + this.f180b + " feedback");
                    intent.putExtra("android.intent.extra.TEXT", " ");
                    intent.setData(Uri.parse("mailto:prozanton@gmail.com"));
                    try {
                        startActivity(Intent.createChooser(intent, getResources().getString(R.string.MENU_FEEDBACK)));
                        return;
                    } catch (Throwable e) {
                        C0166c.m556a(e);
                        return;
                    }
                case R.id.bRatingApp:
                    intent = new Intent("android.intent.action.VIEW");
                    intent.setData(Uri.parse("market://details?id=ru.zdevs.zarchiver"));
                    try {
                        startActivity(intent);
                        return;
                    } catch (Throwable e2) {
                        C0166c.m556a(e2);
                        return;
                    }
                case R.id.bShare:
                    intent = new Intent("android.intent.action.SEND");
                    intent.setType("text/plain");
                    intent.putExtra("android.intent.extra.SUBJECT", "Check out ZArchiver");
                    switch (C0058a.f178a) {
                        case 0:
                        case 2:
                            intent.putExtra("android.intent.extra.TEXT", "ZArchiver is fast and simple archive and file manager. Get it on https://play.google.com/store/apps/details?id=ru.zdevs.zarchiver");
                            break;
                        case 1:
                            intent.putExtra("android.intent.extra.TEXT", "ZArchiver is fast and simple archive and file manager. Get it on http://www.amazon.com/gp/mas/dl/android?p=ru.zdevs.zarchiver");
                            break;
                    }
                    try {
                        startActivity(Intent.createChooser(intent, getResources().getString(R.string.MENU_SHARE_APP)));
                        return;
                    } catch (Throwable e22) {
                        C0166c.m556a(e22);
                        return;
                    }
                default:
                    return;
            }
        }
    }
}
