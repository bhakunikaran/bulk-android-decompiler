package ru.zdevs.zarchiver;

import android.content.Context;
import android.content.res.Resources;
import android.os.Build;
import android.os.Build.VERSION;
import java.util.Locale;
import ru.zdevs.zarchiver.settings.Settings;

/* renamed from: ru.zdevs.zarchiver.a */
public class C0058a {
    /* renamed from: a */
    public static int f178a = 0;

    /* renamed from: a */
    public static boolean m145a() {
        String str = Build.DISPLAY;
        return str != null && str.toLowerCase(Locale.ENGLISH).contains("flyme");
    }

    /* renamed from: a */
    public static boolean m146a(Context context) {
        if (Settings.sGUIWideBar && VERSION.SDK_INT < 21) {
            Resources resources = context.getResources();
            int identifier = resources.getIdentifier("split_action_bar_is_narrow", "bool", "android");
            if (identifier != 0) {
                return resources.getBoolean(identifier);
            }
        }
        return false;
    }

    /* renamed from: b */
    public static boolean m147b() {
        String str = Build.MANUFACTURER;
        return str != null && str.toLowerCase(Locale.ENGLISH).contains("samsung");
    }

    /* renamed from: b */
    public static boolean m148b(Context context) {
        if (Settings.sGUIWideBar) {
            return false;
        }
        Resources resources = context.getResources();
        int identifier = resources.getIdentifier("max_action_buttons", "integer", "android");
        return identifier != 0 && resources.getInteger(identifier) <= 2;
    }

    /* renamed from: c */
    public static boolean m149c() {
        return VERSION.SDK_INT < 24 ? false : C0058a.m147b();
    }

    /* renamed from: c */
    public static boolean m150c(Context context) {
        return context.getResources().getConfiguration().orientation == 2;
    }
}
