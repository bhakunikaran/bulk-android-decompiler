package ru.zdevs.zarchiver.widget;

public interface IListView {
    public static final long ITEM_LEFT_CLICK = -8;
    public static final long ITEM_RIGHT_CLICK = -7;

    public interface OnListMeasure {
        void onListMeasure(int i, int i2);
    }

    int getClickRawX();

    int getClickRawY();

    int getFirsItemPosition();

    void setOnListMeasure(OnListMeasure onListMeasure);
}
