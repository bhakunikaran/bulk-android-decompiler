package ru.zdevs.zarchiver.widget.bottomsheet;

public interface BottomSheetListener {
    public static final int DISMISS_EVENT_CANCEL = -5;
    public static final int DISMISS_EVENT_MANUAL = -6;
    public static final int DISMISS_EVENT_SWIPE = -4;

    public @interface DismissEvent {
    }

    void onSheetDismissed(BottomSheet bottomSheet, @DismissEvent int i);

    void onSheetShown(BottomSheet bottomSheet);
}
