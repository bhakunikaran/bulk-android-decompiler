package ru.zdevs.zarchiver.widget;

import android.content.Context;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.text.method.PasswordTransformationMethod;
import android.util.AttributeSet;
import android.widget.EditText;
import ru.zdevs.zarchiver.R;
import ru.zdevs.zarchiver.tool.C0202q;

public class EditPassword extends EditText {
    private static final int EXTRA_TAPPABLE_AREA = 50;
    private boolean isRTL;
    private Drawable mDrawableHidePw;
    private Drawable mDrawableShowPw;
    private boolean mPasswordVisible;

    public EditPassword(Context context) {
        this(context, null);
        initFields();
    }

    public EditPassword(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        initFields();
    }

    public EditPassword(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        initFields();
    }

    private void handlePasswordInputVisibility() {
        int selectionStart = getSelectionStart();
        int selectionEnd = getSelectionEnd();
        if (this.mPasswordVisible) {
            setTransformationMethod(null);
        } else {
            setTransformationMethod(PasswordTransformationMethod.getInstance());
        }
        setSelection(selectionStart, selectionEnd);
    }

    private boolean isRTLLanguage() {
        boolean z = true;
        if (VERSION.SDK_INT < 17) {
            return false;
        }
        if (getResources().getConfiguration().getLayoutDirection() != 1) {
            z = false;
        }
        return z;
    }

    private void showPasswordIconVisibility() {
        Drawable drawable = this.mPasswordVisible ? this.mDrawableHidePw : this.mDrawableShowPw;
        Drawable drawable2 = this.isRTL ? drawable : null;
        if (this.isRTL) {
            drawable = null;
        }
        setCompoundDrawablesWithIntrinsicBounds(drawable2, null, drawable, null);
    }

    private void togglePasswordIconVisibility() {
        this.mPasswordVisible = !this.mPasswordVisible;
        handlePasswordInputVisibility();
        showPasswordIconVisibility();
    }

    public void initFields() {
        setMaxLines(1);
        this.mDrawableHidePw = getResources().getDrawable(R.drawable.ic_visibility_off_24dp).mutate();
        this.mDrawableShowPw = getResources().getDrawable(R.drawable.ic_visibility_24dp).mutate();
        int b = VERSION.SDK_INT < 21 ? C0202q.m735b(getContext(), 16843663) : C0202q.m735b(getContext(), 16843818);
        if (b == 0) {
            b = C0202q.m735b(getContext(), (int) R.attr.colorPrimary);
        }
        this.mDrawableHidePw.setColorFilter(b, Mode.SRC_IN);
        this.mDrawableShowPw.setColorFilter(b, Mode.SRC_IN);
        this.isRTL = isRTLLanguage();
        setInputType(128);
        handlePasswordInputVisibility();
        showPasswordIconVisibility();
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onTouchEvent(android.view.MotionEvent r4) {
        /*
        r3 = this;
        r0 = r4.getAction();
        r1 = 1;
        if (r0 != r1) goto L_0x0031;
    L_0x0007:
        r0 = r3.mDrawableShowPw;
        r0 = r0.getBounds();
        r1 = r4.getX();
        r1 = (int) r1;
        r2 = r3.isRTL;
        if (r2 == 0) goto L_0x0036;
    L_0x0016:
        r2 = r3.getLeft();
        r0 = r0.width();
        r0 = r0 + r2;
        r0 = r0 + 50;
    L_0x0021:
        r2 = r3.isRTL;
        if (r2 == 0) goto L_0x0043;
    L_0x0025:
        if (r1 > r0) goto L_0x0031;
    L_0x0027:
        r3.togglePasswordIconVisibility();
        r0 = 3;
        r4.setAction(r0);
        r3.performClick();
    L_0x0031:
        r0 = super.onTouchEvent(r4);
        return r0;
    L_0x0036:
        r2 = r3.getRight();
        r0 = r0.width();
        r0 = r2 - r0;
        r0 = r0 + -50;
        goto L_0x0021;
    L_0x0043:
        if (r1 < r0) goto L_0x0031;
    L_0x0045:
        goto L_0x0027;
        */
        throw new UnsupportedOperationException("Method not decompiled: ru.zdevs.zarchiver.widget.EditPassword.onTouchEvent(android.view.MotionEvent):boolean");
    }

    public boolean performClick() {
        return super.performClick();
    }

    public void setEnabled(boolean z) {
        super.setEnabled(z);
        if (z) {
            showPasswordIconVisibility();
        } else {
            setCompoundDrawablesWithIntrinsicBounds(null, null, null, null);
        }
    }
}
