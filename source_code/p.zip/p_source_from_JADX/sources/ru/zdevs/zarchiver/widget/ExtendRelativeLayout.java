package ru.zdevs.zarchiver.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.animation.Animation.AnimationListener;
import android.widget.RelativeLayout;

public class ExtendRelativeLayout extends RelativeLayout {
    private AnimationListener mListener = null;

    public ExtendRelativeLayout(Context context) {
        super(context);
    }

    public ExtendRelativeLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public ExtendRelativeLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    public void onAnimationEnd() {
        super.onAnimationEnd();
        if (this.mListener != null) {
            this.mListener.onAnimationEnd(getAnimation());
        }
    }

    public void onAnimationStart() {
        super.onAnimationStart();
        if (this.mListener != null) {
            this.mListener.onAnimationStart(getAnimation());
        }
    }

    public void setAnimationListener(AnimationListener animationListener) {
        this.mListener = animationListener;
    }
}
