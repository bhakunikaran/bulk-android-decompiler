package ru.zdevs.zarchiver;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.view.MotionEvent;
import ru.zdevs.zarchiver.dialog.ZDialog;
import ru.zdevs.zarchiver.service.C0144e;
import ru.zdevs.zarchiver.service.C0144e.C0145a;
import ru.zdevs.zarchiver.service.ZArchiverService;
import ru.zdevs.zarchiver.tool.C0166c;

public class ZArchiverExt extends Activity {
    public static ZArchiverExt sContext = null;
    private ActionsExt acs = null;
    public C0144e iService = null;
    private ServiceConnection mConnection = new C00321(this);
    private boolean mReconfigre = false;

    /* renamed from: ru.zdevs.zarchiver.ZArchiverExt$1 */
    class C00321 implements ServiceConnection {
        /* renamed from: a */
        final /* synthetic */ ZArchiverExt f69a;

        C00321(ZArchiverExt zArchiverExt) {
            this.f69a = zArchiverExt;
        }

        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            this.f69a.iService = C0145a.asInterface(iBinder);
            try {
                this.f69a.iService.GUIStatus(4);
                if (this.f69a.acs != null) {
                    this.f69a.acs.setZArchiver(null, this.f69a.iService);
                    this.f69a.acs.serviceSetRun();
                }
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
        }

        public void onServiceDisconnected(ComponentName componentName) {
            this.f69a.iService = null;
            if (this.f69a.acs != null) {
                this.f69a.acs.setZArchiver(null, null);
            }
        }
    }

    private void startZService() {
        if (this.iService == null) {
            Intent intent = new Intent(this, ZArchiverService.class);
            startService(intent);
            bindService(intent, this.mConnection, 4);
        }
    }

    private void stopZService() {
        if (this.iService != null) {
            try {
                if (!this.mReconfigre) {
                    this.iService.GUIStatus(8);
                }
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
            unbindService(this.mConnection);
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (sContext != null) {
            sContext.onNewIntent(getIntent());
            finish();
            return;
        }
        sContext = this;
        Log.d("ZArchiverExt", "onCreate");
        setContentView(R.layout.ext_bg);
        startZService();
        this.acs = (ActionsExt) getLastNonConfigurationInstance();
        if (this.acs == null) {
            this.acs = new ActionsExt();
        }
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("ZArchiver.iMES");
        registerReceiver(this.acs.mMesageReceiver, intentFilter);
        for (ZDialog reShow : this.acs.Dialogs) {
            reShow.reShow(this);
        }
        Intent intent = getIntent();
        if (intent != null) {
            this.acs.onProcessIntent(intent);
        }
    }

    protected void onDestroy() {
        if (this.acs != null) {
            sContext = null;
            if (this.acs != null) {
                for (ZDialog close : this.acs.Dialogs) {
                    close.close();
                }
                unregisterReceiver(this.acs.mMesageReceiver);
            }
            this.mReconfigre = false;
            stopZService();
        }
        super.onDestroy();
    }

    public void onNewIntent(Intent intent) {
        if (this.acs != null && intent != null) {
            this.acs.onReceive(this, intent);
        }
    }

    protected void onPause() {
        super.onPause();
    }

    public void onResume() {
        super.onResume();
    }

    public Object onRetainNonConfigurationInstance() {
        if (this.acs == null) {
            return null;
        }
        for (ZDialog hide : this.acs.Dialogs) {
            hide.hide();
        }
        this.mReconfigre = true;
        return this.acs;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        boolean onTouchEvent = super.onTouchEvent(motionEvent);
        if (this.acs == null || onTouchEvent) {
            return onTouchEvent;
        }
        this.acs.checkOnExite(false);
        return true;
    }
}
