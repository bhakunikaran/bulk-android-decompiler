package ru.zdevs.zarchiver.p003a;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import ru.zdevs.zarchiver.R;

/* renamed from: ru.zdevs.zarchiver.a.j */
public class C0054j extends BaseAdapter {
    /* renamed from: a */
    private final LayoutInflater f165a;
    /* renamed from: b */
    private List<C0056l> f166b = new ArrayList();

    /* renamed from: ru.zdevs.zarchiver.a.j$a */
    static class C0053a {
        /* renamed from: a */
        protected TextView f163a;
        /* renamed from: b */
        protected ImageView f164b;

        C0053a() {
        }
    }

    public C0054j(Context context) {
        this.f165a = (LayoutInflater) context.getSystemService("layout_inflater");
    }

    /* renamed from: a */
    public C0056l m135a(int i) {
        return (C0056l) this.f166b.get(i);
    }

    /* renamed from: a */
    public void m136a(C0056l c0056l) {
        this.f166b.add(c0056l);
    }

    public int getCount() {
        return this.f166b.size();
    }

    public /* synthetic */ Object getItem(int i) {
        return m135a(i);
    }

    public long getItemId(int i) {
        return (long) i;
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        C0056l a = m135a(i);
        if (view == null) {
            view = this.f165a.inflate(R.layout.item_icon, viewGroup, false);
            C0053a c0053a = new C0053a();
            c0053a.f163a = (TextView) view.findViewById(R.id.text);
            c0053a.f164b = (ImageView) view.findViewById(R.id.icon);
            view.setTag(c0053a);
        }
        C0053a c0053a2 = (C0053a) view.getTag();
        c0053a2.f163a.setText(a.f170a);
        if (a.f172c != null) {
            c0053a2.f164b.setImageDrawable(a.f172c);
            c0053a2.f164b.setVisibility(0);
        } else {
            c0053a2.f164b.setVisibility(8);
        }
        return view;
    }
}
