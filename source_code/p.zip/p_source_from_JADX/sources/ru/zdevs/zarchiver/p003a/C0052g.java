package ru.zdevs.zarchiver.p003a;

import ru.zdevs.zarchiver.fs.MyUri;
import ru.zdevs.zarchiver.tool.C0202q;

/* renamed from: ru.zdevs.zarchiver.a.g */
public class C0052g extends C0049e {
    /* renamed from: l */
    private MyUri f162l;

    public C0052g(MyUri myUri, String str, byte b, long j, long j2) {
        super(str, b, j2, j);
        this.f162l = myUri;
    }

    /* renamed from: l */
    public MyUri m133l() {
        return this.f162l;
    }

    /* renamed from: m */
    public String m134m() {
        StringBuilder stringBuilder = new StringBuilder();
        if (a) {
            stringBuilder.append(C0049e.f140d.format(Long.valueOf(this.j)));
        }
        if (c && this.g != (byte) 2) {
            if (a) {
                stringBuilder.append("\n");
            }
            stringBuilder.append(C0202q.m736b(this.k));
        }
        return stringBuilder.toString();
    }
}
