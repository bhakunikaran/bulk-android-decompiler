package ru.zdevs.zarchiver.p003a;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

/* renamed from: ru.zdevs.zarchiver.a.m */
public class C0057m extends BaseAdapter implements SpinnerAdapter {
    /* renamed from: a */
    private final LayoutInflater f175a;
    /* renamed from: b */
    private List<String> f176b = new ArrayList();
    /* renamed from: c */
    private List<Boolean> f177c = new ArrayList();

    public C0057m(Context context) {
        this.f175a = (LayoutInflater) context.getSystemService("layout_inflater");
    }

    /* renamed from: a */
    public void m140a() {
        this.f176b.clear();
        this.f177c.clear();
    }

    /* renamed from: a */
    public void m141a(int i, boolean z) {
        if (i < this.f177c.size()) {
            this.f177c.set(i, Boolean.valueOf(z));
        }
    }

    /* renamed from: a */
    public void m142a(String str) {
        this.f176b.add(str);
        this.f177c.add(Boolean.valueOf(true));
    }

    /* renamed from: a */
    public void m143a(boolean z) {
        int size = this.f177c.size();
        for (int i = 0; i < size; i++) {
            this.f177c.set(i, Boolean.valueOf(z));
        }
    }

    /* renamed from: a */
    public void m144a(String[] strArr) {
        if (strArr != null) {
            for (Object add : strArr) {
                this.f176b.add(add);
                this.f177c.add(Boolean.valueOf(true));
            }
        }
    }

    public int getCount() {
        return this.f176b.size();
    }

    public View getDropDownView(int i, View view, ViewGroup viewGroup) {
        View inflate = view == null ? this.f175a.inflate(17367049, viewGroup, false) : view;
        ((TextView) inflate).setText((CharSequence) this.f176b.get(i));
        inflate.setEnabled(isEnabled(i));
        return inflate;
    }

    public Object getItem(int i) {
        return this.f176b.get(i);
    }

    public long getItemId(int i) {
        return (long) i;
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        View inflate = view == null ? this.f175a.inflate(17367048, viewGroup, false) : view;
        ((TextView) inflate).setText((CharSequence) this.f176b.get(i));
        return inflate;
    }

    public boolean isEnabled(int i) {
        return ((Boolean) this.f177c.get(i)).booleanValue();
    }
}
