package ru.zdevs.zarchiver.p003a;

import java.text.DateFormat;
import ru.zdevs.zarchiver.fs.ZFileInfo;
import ru.zdevs.zarchiver.tool.C0202q;

/* renamed from: ru.zdevs.zarchiver.a.e */
public class C0049e implements C0048i {
    /* renamed from: a */
    public static boolean f137a = false;
    /* renamed from: b */
    public static boolean f138b = false;
    /* renamed from: c */
    public static boolean f139c = true;
    /* renamed from: d */
    public static DateFormat f140d = DateFormat.getDateInstance(3);
    /* renamed from: e */
    public static DateFormat f141e = DateFormat.getTimeInstance(3);
    /* renamed from: f */
    protected String f142f;
    /* renamed from: g */
    protected byte f143g;
    /* renamed from: h */
    protected byte f144h;
    /* renamed from: i */
    protected boolean f145i;
    /* renamed from: j */
    protected long f146j;
    /* renamed from: k */
    protected long f147k;

    public C0049e(String str, byte b, byte b2, long j, long j2) {
        this.f143g = b;
        this.f144h = b2;
        this.f142f = str;
        this.f146j = j;
        this.f147k = j2;
    }

    public C0049e(String str, byte b, long j, long j2) {
        this.f143g = b;
        this.f144h = (byte) 0;
        this.f142f = str;
        this.f146j = j;
        this.f147k = j2;
    }

    /* renamed from: a */
    public void m105a(boolean z) {
        this.f145i = z;
    }

    /* renamed from: a */
    public boolean mo27a() {
        return this.f145i;
    }

    /* renamed from: b */
    public boolean m107b() {
        return this.f143g == (byte) 2 || this.f143g == (byte) 1;
    }

    /* renamed from: c */
    public boolean m108c() {
        return this.f143g == (byte) 1;
    }

    /* renamed from: d */
    public boolean m109d() {
        return this.f143g != (byte) 1;
    }

    /* renamed from: e */
    public String mo28e() {
        return this.f142f;
    }

    /* renamed from: f */
    public String m111f() {
        if (!f137a) {
            return "";
        }
        String format = f140d.format(Long.valueOf(this.f146j));
        return f138b ? format + "\n" + f141e.format(Long.valueOf(this.f146j)) : format;
    }

    /* renamed from: g */
    public String m112g() {
        return (!f139c || this.f143g == (byte) 1) ? "" : this.f147k == -2 ? "<LINK>" : this.f143g == (byte) 2 ? "<DIR>" : C0202q.m736b(this.f147k);
    }

    /* renamed from: h */
    public byte mo29h() {
        if (this.f143g == (byte) 0) {
            this.f143g = ZFileInfo.getFileType(this.f142f);
        }
        return this.f143g;
    }

    /* renamed from: i */
    public byte m114i() {
        return this.f144h;
    }

    /* renamed from: j */
    public long m115j() {
        return this.f147k;
    }

    /* renamed from: k */
    public long m116k() {
        return this.f146j;
    }
}
