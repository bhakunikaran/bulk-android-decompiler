package ru.zdevs.zarchiver.p003a;

import ru.zdevs.zarchiver.fs.MyUri;

/* renamed from: ru.zdevs.zarchiver.a.c */
public class C0044c {
    /* renamed from: a */
    public int f112a;
    /* renamed from: b */
    public String f113b;
    /* renamed from: c */
    public MyUri f114c;
    /* renamed from: d */
    public String f115d;
    /* renamed from: e */
    public boolean f116e;

    public C0044c(int i, String str, MyUri myUri) {
        this.f112a = i;
        this.f113b = str;
        this.f114c = myUri;
        this.f115d = "";
        this.f116e = false;
    }

    public C0044c(int i, String str, MyUri myUri, boolean z) {
        this.f112a = i;
        this.f113b = str;
        this.f114c = myUri;
        this.f115d = "";
        this.f116e = z;
    }
}
