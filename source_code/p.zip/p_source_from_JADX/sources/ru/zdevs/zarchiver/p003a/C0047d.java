package ru.zdevs.zarchiver.p003a;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import ru.zdevs.zarchiver.R;
import ru.zdevs.zarchiver.fs.MyUri;
import ru.zdevs.zarchiver.fs.ZFileInfo;
import ru.zdevs.zarchiver.settings.Settings;
import ru.zdevs.zarchiver.tool.C0166c;
import ru.zdevs.zarchiver.tool.C0169f;
import ru.zdevs.zarchiver.tool.C0178g;
import ru.zdevs.zarchiver.tool.C0202q;

/* renamed from: ru.zdevs.zarchiver.a.d */
public class C0047d extends BaseAdapter implements OnClickListener, C0046h {
    /* renamed from: a */
    private static C0178g f122a;
    /* renamed from: b */
    private final LayoutInflater f123b;
    /* renamed from: c */
    private int f124c;
    /* renamed from: d */
    private int f125d;
    /* renamed from: e */
    private int f126e;
    /* renamed from: f */
    private int f127f;
    /* renamed from: g */
    private MyUri f128g;
    /* renamed from: h */
    private List<C0049e> f129h;
    /* renamed from: i */
    private int f130i;
    /* renamed from: j */
    private int f131j;
    /* renamed from: k */
    private int[] f132k;
    /* renamed from: l */
    private boolean f133l;
    /* renamed from: m */
    private boolean f134m;
    /* renamed from: n */
    private boolean f135n;
    /* renamed from: o */
    private C0031a f136o;

    /* renamed from: ru.zdevs.zarchiver.a.d$a */
    public interface C0031a {
        void onSelectItemChange(boolean z, int i);
    }

    /* renamed from: ru.zdevs.zarchiver.a.d$b */
    static class C0045b {
        /* renamed from: a */
        TextView f117a;
        /* renamed from: b */
        ImageView f118b;
        /* renamed from: c */
        TextView f119c;
        /* renamed from: d */
        TextView f120d;
        /* renamed from: e */
        View f121e;

        C0045b() {
        }
    }

    public C0047d(Context context) {
        this.f123b = (LayoutInflater) context.getSystemService("layout_inflater");
        m83a(context, Settings.sGUIGridView);
    }

    public C0047d(Context context, boolean z) {
        this.f123b = (LayoutInflater) context.getSystemService("layout_inflater");
        m83a(context, z);
    }

    /* renamed from: a */
    private void m83a(Context context, boolean z) {
        this.f124c = C0202q.m735b(context, (int) R.attr.defaultTextColorFileList);
        this.f127f = C0202q.m735b(context, (int) R.attr.backgroundColorFileListItem);
        if (Settings.sTheme == (byte) 0) {
            this.f126e = C0202q.m735b(context, (int) R.attr.colorPrimary);
        } else {
            this.f126e = C0202q.m735b(context, (int) R.attr.colorPrimaryLight);
        }
        if ((((this.f126e & 255) + ((this.f126e >> 8) & 255)) + ((this.f126e >> 16) & 255)) / 3 > 129) {
            this.f125d = -16777216;
        } else {
            this.f125d = -1;
        }
        this.f126e &= -1426063361;
        this.f128g = new MyUri("");
        this.f129h = new ArrayList();
        this.f131j = 0;
        this.f132k = null;
        this.f133l = true;
        this.f134m = z;
        this.f135n = false;
        if (this.f134m) {
            C0178g.m598a((int) (((double) ((context.getResources().getDisplayMetrics().heightPixels * context.getResources().getDisplayMetrics().widthPixels) / Settings.sFMItemSize)) / (((double) Settings.sFMItemSize) * 1.5d)));
        } else {
            C0178g.m598a((context.getResources().getDisplayMetrics().heightPixels / Settings.sFMItemSize) + 1);
        }
        if (this.f134m) {
            this.f130i = R.layout.item_fm_grid;
        } else if (Settings.sShortFileName) {
            this.f130i = R.layout.item_fm_single_line;
        } else {
            this.f130i = R.layout.item_fm;
        }
    }

    /* renamed from: a */
    public static void m84a(C0178g c0178g) {
        f122a = c0178g;
    }

    /* renamed from: h */
    public static C0178g m85h() {
        return f122a;
    }

    /* renamed from: a */
    public String m86a(String str) {
        StringBuilder stringBuilder = new StringBuilder();
        for (C0049e c0049e : this.f129h) {
            if (c0049e.mo27a()) {
                stringBuilder.append(str);
                stringBuilder.append(c0049e.mo28e());
            }
        }
        return stringBuilder.toString();
    }

    /* renamed from: a */
    public List<C0049e> m87a() {
        return this.f129h;
    }

    /* renamed from: a */
    public void mo13a(int i) {
        this.f126e = i;
    }

    /* renamed from: a */
    public void m89a(List<C0049e> list, MyUri myUri) {
        if (!(this.f128g.compareTo(myUri) == 0 || f122a == null)) {
            f122a.m620d();
        }
        this.f128g = myUri;
        this.f129h = list;
        this.f131j = 0;
        for (C0049e a : this.f129h) {
            if (a.mo27a()) {
                this.f131j++;
            }
        }
        this.f132k = null;
    }

    /* renamed from: a */
    public void mo14a(C0031a c0031a) {
        this.f136o = c0031a;
    }

    /* renamed from: a */
    public void mo15a(boolean z) {
        this.f133l = z;
    }

    /* renamed from: b */
    public int mo16b() {
        return this.f131j;
    }

    /* renamed from: b */
    public C0048i mo17b(int i) {
        return (C0048i) this.f129h.get(i);
    }

    /* renamed from: b */
    public void mo18b(boolean z) {
        this.f135n = z;
    }

    /* renamed from: c */
    public void mo19c() {
        boolean z = this.f131j > 0;
        for (C0049e c0049e : this.f129h) {
            if (c0049e.mo27a()) {
                c0049e.m105a(false);
            }
        }
        this.f131j = 0;
        this.f132k = null;
        if (!(this.f136o == null || z)) {
            this.f136o.onSelectItemChange(false, 0);
        }
        notifyDataSetChanged();
    }

    /* renamed from: c */
    public void mo20c(int i) {
        try {
            C0049e c0049e = (C0049e) this.f129h.get(i);
            if (c0049e != null && c0049e.m109d()) {
                if (c0049e.mo27a()) {
                    this.f131j--;
                } else {
                    this.f131j++;
                }
                c0049e.m105a(!c0049e.mo27a());
                this.f132k = null;
                if (this.f136o != null) {
                    this.f136o.onSelectItemChange(c0049e.mo27a(), this.f131j);
                }
                notifyDataSetChanged();
            }
        } catch (Throwable e) {
            C0166c.m556a(e);
        }
    }

    /* renamed from: d */
    public void mo21d() {
        boolean z = this.f131j > 0;
        int i = 0;
        for (C0049e c0049e : this.f129h) {
            int i2;
            if (c0049e.m109d()) {
                c0049e.m105a(true);
                i2 = i;
            } else {
                i2 = i + 1;
            }
            i = i2;
        }
        this.f131j = this.f129h.size() - i;
        this.f132k = null;
        if (!(this.f136o == null || z)) {
            this.f136o.onSelectItemChange(true, 1);
        }
        notifyDataSetChanged();
    }

    /* renamed from: e */
    public void mo22e() {
        int i = 0;
        int i2 = this.f131j > 0 ? 1 : 0;
        this.f131j = 0;
        for (C0049e c0049e : this.f129h) {
            if (c0049e.m109d()) {
                c0049e.m105a(!c0049e.mo27a());
                if (c0049e.mo27a()) {
                    this.f131j++;
                }
            }
        }
        this.f132k = null;
        if (this.f136o != null) {
            if (i2 != (this.f131j > 0 ? 1 : 0)) {
                C0031a c0031a = this.f136o;
                boolean z = i2 == 0;
                if (i2 == 0) {
                    i = 1;
                }
                c0031a.onSelectItemChange(z, i);
            }
        }
        notifyDataSetChanged();
    }

    /* renamed from: f */
    public int[] mo23f() {
        int i = 0;
        if (this.f132k != null) {
            return this.f132k;
        }
        this.f132k = new int[this.f131j];
        int size = this.f129h.size();
        int i2 = 0;
        while (i2 < size) {
            int i3;
            if (((C0049e) this.f129h.get(i2)).mo27a()) {
                i3 = i + 1;
                this.f132k[i] = i2;
            } else {
                i3 = i;
            }
            i2++;
            i = i3;
        }
        return this.f132k;
    }

    /* renamed from: g */
    public void mo24g() {
        notifyDataSetChanged();
    }

    public int getCount() {
        return this.f129h.size();
    }

    public /* synthetic */ Object getItem(int i) {
        return mo17b(i);
    }

    public long getItemId(int i) {
        return (long) i;
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        Bitmap a;
        C0049e c0049e = (C0049e) mo17b(i);
        if (view == null) {
            view = this.f123b.inflate(this.f130i, viewGroup, false);
            C0045b c0045b = new C0045b();
            c0045b.f121e = view;
            c0045b.f117a = (TextView) view.findViewById(R.id.label);
            c0045b.f119c = (TextView) view.findViewById(R.id.info_date);
            c0045b.f120d = (TextView) view.findViewById(R.id.info_size);
            c0045b.f118b = (ImageView) view.findViewById(R.id.icon);
            c0045b.f118b.setPadding(5, 0, 5, 0);
            LayoutParams layoutParams = c0045b.f118b.getLayoutParams();
            if (this.f134m) {
                layoutParams.width = (int) (((float) Settings.sFMItemSize) * 1.6f);
                layoutParams.height = (int) (((float) Settings.sFMItemSize) * 1.6f);
                c0045b.f117a.setTextSize(((float) Settings.sFMItemFontSize) * 0.8f);
            } else {
                layoutParams.width = Settings.sFMItemSize;
                layoutParams.height = Settings.sFMItemSize;
                c0045b.f117a.setTextSize((float) Settings.sFMItemFontSize);
                c0045b.f117a.setMinHeight(Settings.sFMItemSize);
                c0045b.f119c.setTextSize(0.6f * ((float) Settings.sFMItemFontSize));
                c0045b.f120d.setTextSize(0.62f * ((float) Settings.sFMItemFontSize));
                c0045b.f118b.setOnClickListener(this);
            }
            c0045b.f118b.setLayoutParams(layoutParams);
            if (c0045b.f120d != null && C0049e.f137a) {
                c0045b.f120d.setTypeface(null, 1);
            }
            view.setTag(c0045b);
        }
        C0045b c0045b2 = (C0045b) view.getTag();
        c0045b2.f118b.setTag(Integer.valueOf(i));
        c0045b2.f117a.setText(c0049e.mo28e());
        if (f122a != null) {
            if (this.f128g.isStorage() && ((c0049e.mo29h() == (byte) 11 && Settings.sFMShowThumbnails) || ((c0049e.mo29h() == (byte) 16 && Settings.sFMShowVideoThumb) || ((c0049e.mo29h() == (byte) 15 && Settings.sFMShowPdfThumb) || (c0049e.mo29h() == (byte) 6 && Settings.sFMShowApkIcon))))) {
                a = f122a.m612a(c0049e.mo29h(), c0049e.mo28e(), this.f128g.toLocalPath(), c0045b2.f118b, i, this, this.f135n);
                if (a == null) {
                    a = C0169f.f465a[c0049e.mo29h()];
                }
                c0045b2.f118b.setImageBitmap(C0169f.m575a(a, c0049e.m114i()));
                if (c0049e.mo27a()) {
                    c0045b2.f117a.setTextColor(this.f124c);
                    c0045b2.f121e.setBackgroundColor(this.f127f);
                } else {
                    c0045b2.f117a.setTextColor(this.f125d);
                    c0045b2.f121e.setBackgroundColor(this.f126e);
                }
                if (this.f130i != R.layout.item_fm_grid) {
                    if (c0049e.mo27a()) {
                        c0045b2.f119c.setTextColor(this.f124c);
                        c0045b2.f120d.setTextColor(this.f124c);
                    } else {
                        c0045b2.f119c.setTextColor(this.f125d);
                        c0045b2.f120d.setTextColor(this.f125d);
                    }
                    c0045b2.f119c.setText(c0049e.m111f());
                    c0045b2.f120d.setText(c0049e.m112g());
                }
                return view;
            } else if (this.f128g.isArchive() && Settings.sFMShowArchiveThumb && c0049e.mo29h() == (byte) 11) {
                a = f122a.m614a(this.f129h, i, this.f128g, (BaseAdapter) this, this.f135n);
                if (a == null) {
                    a = C0169f.f465a[c0049e.mo29h()];
                }
                c0045b2.f118b.setImageBitmap(C0169f.m575a(a, c0049e.m114i()));
                if (c0049e.mo27a()) {
                    c0045b2.f117a.setTextColor(this.f124c);
                    c0045b2.f121e.setBackgroundColor(this.f127f);
                } else {
                    c0045b2.f117a.setTextColor(this.f125d);
                    c0045b2.f121e.setBackgroundColor(this.f126e);
                }
                if (this.f130i != R.layout.item_fm_grid) {
                    if (c0049e.mo27a()) {
                        c0045b2.f119c.setTextColor(this.f124c);
                        c0045b2.f120d.setTextColor(this.f124c);
                    } else {
                        c0045b2.f119c.setTextColor(this.f125d);
                        c0045b2.f120d.setTextColor(this.f125d);
                    }
                    c0045b2.f119c.setText(c0049e.m111f());
                    c0045b2.f120d.setText(c0049e.m112g());
                }
                return view;
            } else {
                if (c0049e.m114i() == ZFileInfo.OVERLAY_TYPE_APP_APP) {
                    a = f122a.m613a(c0049e.mo28e(), this.f128g.toLocalPath(), c0045b2.f118b, i, (BaseAdapter) this, this.f135n);
                } else if (c0049e.m114i() == ZFileInfo.OVERLAY_TYPE_APP_DATA) {
                    a = f122a.m613a(c0049e.mo28e(), null, c0045b2.f118b, i, (BaseAdapter) this, this.f135n);
                }
                if (a == null) {
                    a = C0169f.f465a[c0049e.mo29h()];
                }
                c0045b2.f118b.setImageBitmap(C0169f.m575a(a, c0049e.m114i()));
                if (c0049e.mo27a()) {
                    c0045b2.f117a.setTextColor(this.f125d);
                    c0045b2.f121e.setBackgroundColor(this.f126e);
                } else {
                    c0045b2.f117a.setTextColor(this.f124c);
                    c0045b2.f121e.setBackgroundColor(this.f127f);
                }
                if (this.f130i != R.layout.item_fm_grid) {
                    if (c0049e.mo27a()) {
                        c0045b2.f119c.setTextColor(this.f125d);
                        c0045b2.f120d.setTextColor(this.f125d);
                    } else {
                        c0045b2.f119c.setTextColor(this.f124c);
                        c0045b2.f120d.setTextColor(this.f124c);
                    }
                    c0045b2.f119c.setText(c0049e.m111f());
                    c0045b2.f120d.setText(c0049e.m112g());
                }
                return view;
            }
        }
        a = null;
        if (a == null) {
            a = C0169f.f465a[c0049e.mo29h()];
        }
        c0045b2.f118b.setImageBitmap(C0169f.m575a(a, c0049e.m114i()));
        if (c0049e.mo27a()) {
            c0045b2.f117a.setTextColor(this.f124c);
            c0045b2.f121e.setBackgroundColor(this.f127f);
        } else {
            c0045b2.f117a.setTextColor(this.f125d);
            c0045b2.f121e.setBackgroundColor(this.f126e);
        }
        if (this.f130i != R.layout.item_fm_grid) {
            if (c0049e.mo27a()) {
                c0045b2.f119c.setTextColor(this.f124c);
                c0045b2.f120d.setTextColor(this.f124c);
            } else {
                c0045b2.f119c.setTextColor(this.f125d);
                c0045b2.f120d.setTextColor(this.f125d);
            }
            c0045b2.f119c.setText(c0049e.m111f());
            c0045b2.f120d.setText(c0049e.m112g());
        }
        return view;
    }

    /* renamed from: i */
    public byte mo26i() {
        return (byte) 0;
    }

    public void onClick(View view) {
        if (view != null && this.f133l && !this.f135n) {
            C0049e c0049e = (C0049e) this.f129h.get(((Integer) view.getTag()).intValue());
            if (c0049e != null && c0049e.m109d()) {
                if (c0049e.mo27a()) {
                    this.f131j--;
                } else {
                    this.f131j++;
                }
                c0049e.m105a(!c0049e.mo27a());
                this.f132k = null;
                if (this.f136o != null) {
                    this.f136o.onSelectItemChange(c0049e.mo27a(), this.f131j);
                }
                notifyDataSetChanged();
            }
        }
    }
}
