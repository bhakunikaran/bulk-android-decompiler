package ru.zdevs.zarchiver.dialog;

import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface.OnShowListener;
import android.text.InputFilter;
import android.text.InputFilter.LengthFilter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.LinearLayout;
import ru.zdevs.zarchiver.C0136e;
import ru.zdevs.zarchiver.R;
import ru.zdevs.zarchiver.widget.EditPassword;

public class ZEnterPwdDialog extends ZDialog implements OnCancelListener, OnClickListener, View.OnClickListener {
    private Context mContext;
    private Dialog mDlg;
    private EditPassword mEtPwd;
    private String mPwd = "";

    public ZEnterPwdDialog(C0136e c0136e, Context context) {
        this.mCS = c0136e;
        create(context);
        addDialog();
    }

    private void create(final Context context) {
        this.mContext = context;
        Builder builder = new Builder(context);
        builder.setTitle(R.string.PWD_TTL_PASSWORD);
        View inflate = LayoutInflater.from(context).inflate(R.layout.dlg_enter_pwd, new LinearLayout(context));
        this.mEtPwd = (EditPassword) inflate.findViewById(R.id.edt_text);
        this.mEtPwd.setFilters(new InputFilter[]{new LengthFilter(256)});
        builder.setView(inflate);
        builder.setPositiveButton(R.string.BTN_OK, this);
        builder.setNegativeButton(R.string.BTN_CANCEL, this);
        builder.setOnCancelListener(this);
        this.mDlg = builder.create();
        this.mDlg.setCanceledOnTouchOutside(false);
        this.mDlg.setOnShowListener(new OnShowListener(this) {
            /* renamed from: b */
            final /* synthetic */ ZEnterPwdDialog f299b;

            public void onShow(DialogInterface dialogInterface) {
                InputMethodManager inputMethodManager = (InputMethodManager) context.getSystemService("input_method");
                if (inputMethodManager != null) {
                    inputMethodManager.showSoftInput(this.f299b.mEtPwd, 0);
                }
                this.f299b.fixHoloTitle(this.f299b.mDlg);
            }
        });
    }

    public void close() {
        hide();
        delDialog();
    }

    public String getPassword() {
        return this.mPwd;
    }

    public int getType() {
        return 12;
    }

    public void hide() {
        if (this.mDlg != null) {
            this.mPwd = this.mEtPwd.getText().toString();
            this.mDlg.dismiss();
            this.mDlg = null;
        }
        this.mEtPwd = null;
        this.mContext = null;
    }

    public void onCancel(DialogInterface dialogInterface) {
        if (this.mOnCancelListener != null) {
            this.mOnCancelListener.onCancel(this);
        }
        close();
    }

    public void onClick(DialogInterface dialogInterface, int i) {
        if (this.mDlg != null) {
            this.mPwd = this.mEtPwd.getText().toString();
        }
        if (i == -1 && this.mOnOkListener != null) {
            this.mOnOkListener.onOk(this);
        }
        if (i == -2 && this.mOnCancelListener != null) {
            this.mOnCancelListener.onCancel(this);
        }
        close();
    }

    public void onClick(View view) {
    }

    public void reShow(Context context) {
        create(context);
        if (this.mDlg != null) {
            show();
            this.mEtPwd.setText(this.mPwd);
        }
    }

    public void setPassword(String str) {
        this.mPwd = str;
        if (this.mDlg != null) {
            this.mEtPwd.setText(str);
        }
    }

    public void setText(String str) {
        if (this.mDlg != null && this.mEtPwd != null) {
            this.mEtPwd.setText(str);
            this.mEtPwd.setSelection(str.length());
        }
    }

    public void show() {
        if (this.mDlg != null) {
            this.mDlg.show();
        }
    }
}
