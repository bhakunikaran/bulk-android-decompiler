package ru.zdevs.zarchiver.dialog;

import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface.OnShowListener;
import android.text.InputFilter;
import android.text.InputFilter.LengthFilter;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import ru.zdevs.zarchiver.C0136e;
import ru.zdevs.zarchiver.R;
import ru.zdevs.zarchiver.settings.Settings;
import ru.zdevs.zarchiver.widget.EditPassword;

public class ZAddPasswordDialog extends ZDialog implements OnCancelListener, OnClickListener {
    private Context mContext;
    private Dialog mDlg;
    private EditText mEtName;
    private EditPassword mEtPwd;
    private String mName;
    private String mPwd;

    /* renamed from: ru.zdevs.zarchiver.dialog.ZAddPasswordDialog$1 */
    class C00951 implements OnShowListener {
        /* renamed from: a */
        final /* synthetic */ ZAddPasswordDialog f288a;

        C00951(ZAddPasswordDialog zAddPasswordDialog) {
            this.f288a = zAddPasswordDialog;
        }

        public void onShow(DialogInterface dialogInterface) {
            this.f288a.fixHoloTitle(this.f288a.mDlg);
        }
    }

    public ZAddPasswordDialog(C0136e c0136e, Context context) {
        this.mCS = c0136e;
        String str = "";
        this.mPwd = str;
        this.mName = str;
        create(context);
        addDialog();
    }

    private void create(Context context) {
        this.mContext = context;
        Builder builder = new Builder(context);
        builder.setTitle(R.string.PWD_TTL_ADD_PASSWORD);
        View inflate = LayoutInflater.from(context).inflate(R.layout.dlg_add_pwd, new LinearLayout(context));
        this.mEtName = (EditText) inflate.findViewById(R.id.edt_name);
        this.mEtPwd = (EditPassword) inflate.findViewById(R.id.edt_pwd);
        this.mEtPwd.setFilters(new InputFilter[]{new LengthFilter(256)});
        builder.setView(inflate);
        builder.setPositiveButton(R.string.BTN_ADD, this);
        builder.setNegativeButton(R.string.BTN_CANCEL, this);
        builder.setOnCancelListener(this);
        this.mDlg = builder.create();
        this.mDlg.setCanceledOnTouchOutside(false);
        this.mDlg.setOnShowListener(new C00951(this));
    }

    public void close() {
        hide();
        delDialog();
    }

    public String getName() {
        return this.mName;
    }

    public String getPassword() {
        return this.mPwd;
    }

    public int getType() {
        return 14;
    }

    public void hide() {
        if (this.mDlg != null) {
            this.mName = this.mEtName.getText().toString();
            this.mPwd = this.mEtPwd.getText().toString();
            this.mDlg.dismiss();
            this.mDlg = null;
        }
        this.mContext = null;
    }

    public void onCancel(DialogInterface dialogInterface) {
        if (this.mOnCancelListener != null) {
            this.mOnCancelListener.onCancel(this);
        }
        close();
    }

    public void onClick(DialogInterface dialogInterface, int i) {
        if (this.mDlg != null) {
            this.mName = this.mEtName.getText().toString();
            this.mPwd = this.mEtPwd.getText().toString();
        }
        if (i == -1 && this.mName != null && this.mName.length() > 1 && this.mPwd != null && this.mPwd.length() > 1) {
            Settings.sSavedPassword.add(Settings.getSavedPwd(this.mName, this.mPwd));
            Settings.savePassword(this.mContext);
            ZEnterPwdDialog zEnterPwdDialog = (ZEnterPwdDialog) this.mCS.m398a(getTaskID(), 12);
            if (zEnterPwdDialog != null) {
                zEnterPwdDialog.setPassword(this.mPwd);
            }
        }
        if (i == -2 && this.mOnCancelListener != null) {
            this.mOnCancelListener.onCancel(this);
        }
        close();
    }

    public void reShow(Context context) {
        create(context);
        if (this.mDlg != null) {
            show();
            this.mEtName.setText(this.mName);
            this.mEtPwd.setText(this.mPwd);
        }
    }

    public void show() {
        if (this.mDlg != null) {
            this.mDlg.show();
        }
    }
}
