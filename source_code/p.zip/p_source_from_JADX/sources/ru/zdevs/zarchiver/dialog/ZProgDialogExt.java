package ru.zdevs.zarchiver.dialog;

import android.content.Context;
import ru.zdevs.zarchiver.ActionsExt;
import ru.zdevs.zarchiver.tool.C0166c;

public class ZProgDialogExt extends ZProgDialog {
    private static final String TAG = "ZProgDialogExt";
    private ActionsExt mExt;

    public ZProgDialogExt(ActionsExt actionsExt, Context context, int i) {
        super(null, context, i);
        this.mExt = actionsExt;
        this.mShowTitle = true;
        addDialog();
    }

    public void addDialog() {
        if (this.mExt != null) {
            this.mExt.Dialogs.add(this);
            C0166c.m558c(TAG, "add dlg ext - " + this.mExt.Dialogs.size());
        }
    }

    public void delDialog() {
        if (this.mExt != null) {
            this.mExt.Dialogs.remove(this);
            C0166c.m558c(TAG, "del dlg ext - " + this.mExt.Dialogs.size());
            if (this.mExt.Dialogs.size() <= 0) {
                this.mExt.onDlgClose();
            }
        }
    }
}
