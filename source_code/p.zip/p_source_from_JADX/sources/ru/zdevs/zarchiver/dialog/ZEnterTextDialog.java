package ru.zdevs.zarchiver.dialog;

import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface.OnShowListener;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import ru.zdevs.zarchiver.C0136e;
import ru.zdevs.zarchiver.R;

public class ZEnterTextDialog extends ZDialog implements OnCancelListener, OnClickListener {
    private String mCaption;
    private int mCaptionStrId;
    private Dialog mDlg;
    private EditText mEtText;
    private String mMes;
    private boolean mMultiLine;
    private String mText;

    public ZEnterTextDialog(C0136e c0136e, Context context, int i, int i2) {
        this.mCS = c0136e;
        this.mMultiLine = false;
        this.mCaptionStrId = i;
        this.mText = "";
        this.mMes = context.getString(i2);
        create(context);
        addDialog();
    }

    public ZEnterTextDialog(C0136e c0136e, Context context, String str, int i) {
        this.mCS = c0136e;
        this.mMultiLine = false;
        this.mCaptionStrId = 0;
        this.mCaption = str;
        this.mText = "";
        this.mMes = context.getString(i);
        create(context);
        addDialog();
    }

    public ZEnterTextDialog(C0136e c0136e, Context context, String str, String str2, boolean z) {
        this.mCS = c0136e;
        this.mMultiLine = z;
        this.mCaptionStrId = 0;
        this.mCaption = str;
        this.mText = "";
        this.mMes = str2;
        create(context);
        addDialog();
    }

    private void create(final Context context) {
        Builder builder = new Builder(context);
        if (this.mCaptionStrId != 0) {
            builder.setTitle(this.mCaptionStrId);
        } else {
            builder.setTitle(this.mCaption);
        }
        ViewGroup linearLayout = new LinearLayout(context);
        View inflate = this.mMultiLine ? LayoutInflater.from(context).inflate(R.layout.dlg_multi_text, linearLayout) : LayoutInflater.from(context).inflate(R.layout.dlg_enter_text, linearLayout);
        ((TextView) inflate.findViewById(R.id.tvText)).setText(this.mMes);
        this.mEtText = (EditText) inflate.findViewById(R.id.edt_text);
        builder.setView(inflate);
        builder.setPositiveButton(R.string.BTN_OK, this);
        if (!this.mMultiLine) {
            builder.setNegativeButton(R.string.BTN_CANCEL, this);
        }
        builder.setOnCancelListener(this);
        this.mDlg = builder.create();
        this.mDlg.setCanceledOnTouchOutside(false);
        this.mDlg.setOnShowListener(new OnShowListener(this) {
            /* renamed from: b */
            final /* synthetic */ ZEnterTextDialog f301b;

            public void onShow(DialogInterface dialogInterface) {
                this.f301b.mEtText.setFocusable(true);
                this.f301b.mEtText.requestFocus();
                InputMethodManager inputMethodManager = (InputMethodManager) context.getSystemService("input_method");
                if (inputMethodManager != null) {
                    inputMethodManager.showSoftInput(this.f301b.mEtText, 0);
                }
                this.f301b.fixHoloTitle(this.f301b.mDlg);
            }
        });
    }

    public void close() {
        hide();
        delDialog();
    }

    public String getText() {
        return this.mText;
    }

    public int getType() {
        return 3;
    }

    public void hide() {
        if (this.mDlg != null) {
            this.mText = this.mEtText.getText().toString();
            this.mDlg.dismiss();
            this.mDlg = null;
        }
    }

    public void onCancel(DialogInterface dialogInterface) {
        if (this.mOnCancelListener != null) {
            this.mOnCancelListener.onCancel(this);
        }
        close();
    }

    public void onClick(DialogInterface dialogInterface, int i) {
        if (this.mDlg != null) {
            this.mText = this.mEtText.getText().toString();
        }
        if (i == -1 && this.mOnOkListener != null) {
            this.mOnOkListener.onOk(this);
        }
        if (i == -2 && this.mOnCancelListener != null) {
            this.mOnCancelListener.onCancel(this);
        }
        close();
    }

    public void reShow(Context context) {
        create(context);
        if (this.mDlg != null) {
            show();
            this.mEtText.setText(this.mText);
        }
    }

    public void setSelection(int i, int i2) {
        if (this.mDlg != null && this.mEtText != null && i >= 0 && i < i2) {
            this.mEtText.setSelection(i, i2);
        }
    }

    public void setText(String str) {
        if (this.mDlg != null && this.mEtText != null) {
            this.mEtText.setText(str);
            this.mEtText.setSelection(str.length());
        }
    }

    public void show() {
        if (this.mDlg != null) {
            this.mDlg.show();
        }
    }
}
