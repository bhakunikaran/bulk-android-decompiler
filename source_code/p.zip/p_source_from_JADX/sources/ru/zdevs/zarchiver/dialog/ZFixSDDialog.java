package ru.zdevs.zarchiver.dialog;

import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface.OnShowListener;
import android.os.Build.VERSION;
import android.os.storage.StorageVolume;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;
import ru.zdevs.zarchiver.C0136e;
import ru.zdevs.zarchiver.R;
import ru.zdevs.zarchiver.ZArchiver;
import ru.zdevs.zarchiver.io.LollipopExtSD;
import ru.zdevs.zarchiver.settings.Settings;
import ru.zdevs.zarchiver.tool.C0199n;
import ru.zdevs.zarchiver.tool.C0199n.C0198a;

public class ZFixSDDialog extends ZDialog implements OnClickListener {
    private CheckBox mCbDontShow = null;
    private Context mContext;
    private Dialog mDlg;
    private StorageVolume mStorageVolume = null;

    /* renamed from: ru.zdevs.zarchiver.dialog.ZFixSDDialog$1 */
    class C01221 implements OnShowListener {
        /* renamed from: a */
        final /* synthetic */ ZFixSDDialog f327a;

        C01221(ZFixSDDialog zFixSDDialog) {
            this.f327a = zFixSDDialog;
        }

        public void onShow(DialogInterface dialogInterface) {
            this.f327a.fixHoloTitle(this.f327a.mDlg);
        }
    }

    public ZFixSDDialog(C0136e c0136e, Context context) {
        this.mCS = c0136e;
        create(context);
        addDialog();
    }

    private void create(Context context) {
        this.mContext = context;
        Builder builder = new Builder(context);
        builder.setTitle(R.string.FSD_TTL_FIX_SD);
        View inflate = LayoutInflater.from(context).inflate(R.layout.dlg_fix_sd, new LinearLayout(context));
        builder.setPositiveButton(R.string.BTN_OK, this);
        if (VERSION.SDK_INT >= 21) {
            builder.setNegativeButton(R.string.BTN_CANCEL, this);
            String unavailableStorageID = LollipopExtSD.getUnavailableStorageID();
            if (unavailableStorageID == null) {
                close();
                return;
            }
            C0198a b = C0199n.m696b(unavailableStorageID);
            if (b == null) {
                close();
                return;
            }
            CharSequence charSequence;
            if (b.f541a != null) {
                charSequence = "[" + b.f541a + "]";
            } else {
                Object obj = "";
            }
            if (VERSION.SDK_INT >= 24 && b.f545e == (byte) 4) {
                this.mStorageVolume = (StorageVolume) b.f546f;
            }
            TextView textView = (TextView) inflate.findViewById(R.id.tvText);
            if (textView != null) {
                if (this.mStorageVolume != null) {
                    textView.setText(context.getString(R.string.FSD_ALLOW_ACCESS_TO_EXT_SD).replace("%1", charSequence));
                } else {
                    textView.setText(context.getString(R.string.FSD_SELECT_PATH_TO_EXT_SD).replace("%1", charSequence));
                }
            }
        }
        this.mCbDontShow = (CheckBox) inflate.findViewById(R.id.cbDontShow);
        builder.setView(inflate);
        builder.setCancelable(false);
        this.mDlg = builder.create();
        this.mDlg.setCanceledOnTouchOutside(false);
        this.mDlg.setOnShowListener(new C01221(this));
    }

    public void close() {
        hide();
        delDialog();
    }

    public int getType() {
        return 4;
    }

    public void hide() {
        if (this.mDlg != null) {
            this.mDlg.dismiss();
            this.mDlg = null;
        }
        this.mContext = null;
    }

    public void onClick(DialogInterface dialogInterface, int i) {
        if (i == -1) {
            if (VERSION.SDK_INT >= 21) {
                if (this.mContext != null && (this.mContext instanceof ZArchiver)) {
                    ZArchiver zArchiver = (ZArchiver) this.mContext;
                    if (this.mStorageVolume != null) {
                        zArchiver.requestAccessExtSD(this.mStorageVolume);
                    } else {
                        zArchiver.selectExtSD();
                    }
                }
            } else if (this.mCbDontShow != null && this.mCbDontShow.isChecked()) {
                Settings.setShowSDWarning(this.mContext, false);
            }
        } else if (this.mCbDontShow != null && this.mCbDontShow.isChecked()) {
            Settings.setShowSDWarning(this.mContext, false);
        }
        close();
    }

    public void reShow(Context context) {
        create(context);
        if (this.mDlg != null) {
            show();
        }
    }

    public void show() {
        if (this.mDlg != null) {
            this.mDlg.show();
        }
    }
}
