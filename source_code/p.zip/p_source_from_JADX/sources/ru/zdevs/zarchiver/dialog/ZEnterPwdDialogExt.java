package ru.zdevs.zarchiver.dialog;

import android.content.Context;
import ru.zdevs.zarchiver.ActionsExt;
import ru.zdevs.zarchiver.tool.C0166c;

public class ZEnterPwdDialogExt extends ZEnterPwdDialog {
    private static final String TAG = "ZEnterPwdDialogExt";
    private ActionsExt mExt;

    public ZEnterPwdDialogExt(ActionsExt actionsExt, Context context) {
        super(null, context);
        this.mExt = actionsExt;
        addDialog();
    }

    public void addDialog() {
        if (this.mExt != null) {
            this.mExt.Dialogs.add(this);
            C0166c.m558c(TAG, "add dlg ext - " + this.mExt.Dialogs.size());
        }
    }

    public void delDialog() {
        if (this.mExt != null) {
            this.mExt.Dialogs.remove(this);
            this.mExt.onDlgClose();
            C0166c.m558c(TAG, "del dlg ext - " + this.mExt.Dialogs.size());
        }
    }
}
