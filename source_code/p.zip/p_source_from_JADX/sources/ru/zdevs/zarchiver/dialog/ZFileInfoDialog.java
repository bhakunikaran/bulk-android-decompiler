package ru.zdevs.zarchiver.dialog;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface.OnShowListener;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.media.ExifInterface;
import android.media.MediaMetadataRetriever;
import android.os.AsyncTask;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TextView;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import ru.zdevs.zarchiver.C0136e;
import ru.zdevs.zarchiver.R;
import ru.zdevs.zarchiver.archiver.C2JBridge;
import ru.zdevs.zarchiver.fs.FSRoot;
import ru.zdevs.zarchiver.fs.MyUri;
import ru.zdevs.zarchiver.fs.ZFileInfo;
import ru.zdevs.zarchiver.fs.ZViewFS;
import ru.zdevs.zarchiver.fs.ZViewFS.FSFileInfo;
import ru.zdevs.zarchiver.settings.Settings;
import ru.zdevs.zarchiver.tool.C0165b;
import ru.zdevs.zarchiver.tool.C0166c;
import ru.zdevs.zarchiver.tool.C0167d;
import ru.zdevs.zarchiver.tool.C0182i;
import ru.zdevs.zarchiver.tool.C0184j;
import ru.zdevs.zarchiver.tool.C0184j.C0183a;
import ru.zdevs.zarchiver.tool.C0200o;
import ru.zdevs.zarchiver.tool.C0202q;

public class ZFileInfoDialog extends ZDialog implements OnCancelListener, OnClickListener, View.OnClickListener, OnCheckedChangeListener {
    private static final int[] mMedia = new int[]{R.id.trMedia1, R.id.trMedia2, R.id.trMedia3, R.id.trMedia4, R.id.trMedia5};
    private static final int[] mMediaTitle = new int[]{R.id.tvTitlMedia1, R.id.tvTitlMedia2, R.id.tvTitlMedia3, R.id.tvTitlMedia4, R.id.tvTitlMedia5};
    private static final int[] mMediaValue = new int[]{R.id.tvMedia1, R.id.tvMedia2, R.id.tvMedia3, R.id.tvMedia4, R.id.tvMedia5};
    private static C0107b sArchiveInfo;
    private Context mContext;
    private Dialog mDlg;
    private List<AsyncTask<?, ?, ?>> mFileInfoTask;
    private String[] mName;
    private MyUri[] mPath;
    private String[] mSave = null;
    private int mType;
    private boolean mUpdateNomediaState;

    /* renamed from: ru.zdevs.zarchiver.dialog.ZFileInfoDialog$1 */
    class C01041 implements OnShowListener {
        /* renamed from: a */
        final /* synthetic */ ZFileInfoDialog f302a;

        C01041(ZFileInfoDialog zFileInfoDialog) {
            this.f302a = zFileInfoDialog;
        }

        public void onShow(DialogInterface dialogInterface) {
            this.f302a.fixHoloTitle(this.f302a.mDlg);
            Button button = ((AlertDialog) dialogInterface).getButton(-3);
            if (button != null) {
                button.setOnClickListener(this.f302a);
            }
        }
    }

    /* renamed from: ru.zdevs.zarchiver.dialog.ZFileInfoDialog$2 */
    class C01052 implements OnShowListener {
        /* renamed from: a */
        final /* synthetic */ ZFileInfoDialog f303a;

        C01052(ZFileInfoDialog zFileInfoDialog) {
            this.f303a = zFileInfoDialog;
        }

        public void onShow(DialogInterface dialogInterface) {
            this.f303a.fixHoloTitle(this.f303a.mDlg);
            Button button = ((AlertDialog) dialogInterface).getButton(-3);
            if (button != null) {
                button.setOnClickListener(this.f303a);
            }
        }
    }

    /* renamed from: ru.zdevs.zarchiver.dialog.ZFileInfoDialog$a */
    private class C0106a extends AsyncTask<String, Void, String[]> {
        /* renamed from: a */
        Context f304a;
        /* renamed from: b */
        final /* synthetic */ ZFileInfoDialog f305b;

        C0106a(ZFileInfoDialog zFileInfoDialog, Context context) {
            this.f305b = zFileInfoDialog;
            this.f304a = context;
        }

        /* renamed from: a */
        protected String[] m376a(String... strArr) {
            String[] strArr2 = new String[4];
            PackageManager packageManager = this.f304a.getPackageManager();
            this.f304a = null;
            try {
                PackageInfo packageArchiveInfo = packageManager.getPackageArchiveInfo(strArr[0], 1);
                strArr2[0] = packageArchiveInfo.packageName;
                strArr2[1] = packageArchiveInfo.versionName;
                strArr2[2] = "" + packageArchiveInfo.versionCode;
                strArr2[3] = "API " + packageArchiveInfo.applicationInfo.targetSdkVersion;
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
            return strArr2;
        }

        /* renamed from: b */
        protected void m377b(String[] strArr) {
            try {
                this.f305b.mFileInfoTask.remove(this);
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
            if (!isCancelled()) {
                this.f305b.setMediInformation(new int[]{R.string.FINFO_APK_NAME, R.string.FINFO_APK_VERSION, R.string.FINFO_APK_VERSION_CODE, R.string.FINFO_APK_SDK}, strArr);
            }
        }

        protected /* synthetic */ Object doInBackground(Object[] objArr) {
            return m376a((String[]) objArr);
        }

        protected /* synthetic */ void onPostExecute(Object obj) {
            m377b((String[]) obj);
        }
    }

    /* renamed from: ru.zdevs.zarchiver.dialog.ZFileInfoDialog$b */
    private static class C0107b {
        /* renamed from: a */
        public String f306a;
        /* renamed from: b */
        public int f307b;
        /* renamed from: c */
        public long f308c;
        /* renamed from: d */
        public int f309d;

        private C0107b() {
        }
    }

    /* renamed from: ru.zdevs.zarchiver.dialog.ZFileInfoDialog$c */
    private class C0108c extends AsyncTask<String, Void, String[]> {
        /* renamed from: a */
        final /* synthetic */ ZFileInfoDialog f310a;

        private C0108c(ZFileInfoDialog zFileInfoDialog) {
            this.f310a = zFileInfoDialog;
        }

        /* renamed from: a */
        protected String[] m378a(String... strArr) {
            C2JBridge.cSetOption(4, Settings.s7zOptions & 4);
            boolean cList = C2JBridge.cList(5, strArr[0], "");
            if (ZFileInfoDialog.sArchiveInfo == null || !cList) {
                return null;
            }
            String[] strArr2 = new String[5];
            strArr2[0] = ZFileInfoDialog.sArchiveInfo.f306a;
            if ((ZFileInfoDialog.sArchiveInfo.f309d & 3) != 0) {
                strArr2[1] = (ZFileInfoDialog.sArchiveInfo.f309d & 1) != 0 ? "+" : "-";
            }
            strArr2[2] = "" + ZFileInfoDialog.sArchiveInfo.f307b;
            strArr2[3] = C0202q.m736b(ZFileInfoDialog.sArchiveInfo.f308c) + " (" + ZFileInfoDialog.sArchiveInfo.f308c + C0202q.f556d + ")";
            if (ZFileInfoDialog.sArchiveInfo.f308c > 0) {
                File file = new File(strArr[0]);
                if (file.exists() && file.length() > 0) {
                    strArr2[4] = ((int) ((file.length() * 100) / ZFileInfoDialog.sArchiveInfo.f308c)) + "%";
                }
            }
            return strArr2;
        }

        /* renamed from: b */
        protected void m379b(String[] strArr) {
            try {
                this.f310a.mFileInfoTask.remove(this);
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
            if (!isCancelled()) {
                this.f310a.setMediInformation(new int[]{R.string.FINFO_ARCHIVE_TYPE, R.string.FINFO_ARCHIVE_SOLID, R.string.FINFO_ARCHIVE_FILE_COUNT, R.string.FINFO_ARCHIVE_SIZE, R.string.FINFO_COMPRESSION_RATIO}, strArr);
            }
        }

        protected /* synthetic */ Object doInBackground(Object[] objArr) {
            return m378a((String[]) objArr);
        }

        protected /* synthetic */ void onPostExecute(Object obj) {
            m379b((String[]) obj);
        }
    }

    /* renamed from: ru.zdevs.zarchiver.dialog.ZFileInfoDialog$d */
    private class C0109d extends AsyncTask<String, Void, String[]> {
        /* renamed from: a */
        final /* synthetic */ ZFileInfoDialog f311a;

        private C0109d(ZFileInfoDialog zFileInfoDialog) {
            this.f311a = zFileInfoDialog;
        }

        /* renamed from: a */
        protected String[] m380a(String... strArr) {
            String[] strArr2 = new String[5];
            try {
                MediaMetadataRetriever mediaMetadataRetriever = new MediaMetadataRetriever();
                mediaMetadataRetriever.setDataSource(strArr[0]);
                strArr2[0] = mediaMetadataRetriever.extractMetadata(7);
                strArr2[1] = mediaMetadataRetriever.extractMetadata(2);
                strArr2[2] = mediaMetadataRetriever.extractMetadata(6);
                strArr2[3] = mediaMetadataRetriever.extractMetadata(20);
                strArr2[4] = this.f311a.durationToText(mediaMetadataRetriever.extractMetadata(9));
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
            return strArr2;
        }

        /* renamed from: b */
        protected void m381b(String[] strArr) {
            try {
                this.f311a.mFileInfoTask.remove(this);
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
            if (!isCancelled()) {
                this.f311a.setMediInformation(new int[]{R.string.FINFO_MEDIA_TITLE, R.string.FINFO_MEDIA_ARTIST, R.string.FINFO_MEDIA_GENRE, R.string.FINFO_MEDIA_BITRATE, R.string.FINFO_MEDIA_DURATION}, strArr);
            }
        }

        protected /* synthetic */ Object doInBackground(Object[] objArr) {
            return m380a((String[]) objArr);
        }

        protected /* synthetic */ void onPostExecute(Object obj) {
            m381b((String[]) obj);
        }
    }

    /* renamed from: ru.zdevs.zarchiver.dialog.ZFileInfoDialog$e */
    private class C0110e extends AsyncTask<String, Void, String[]> {
        /* renamed from: a */
        final /* synthetic */ ZFileInfoDialog f312a;

        private C0110e(ZFileInfoDialog zFileInfoDialog) {
            this.f312a = zFileInfoDialog;
        }

        /* renamed from: a */
        protected String[] m382a(String... strArr) {
            String[] strArr2 = new String[2];
            try {
                C0165b c0165b = new C0165b();
                c0165b.m553a(strArr[0]);
                strArr2[0] = c0165b.m552a(0);
                strArr2[1] = c0165b.m552a(1);
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
            return strArr2;
        }

        /* renamed from: b */
        protected void m383b(String[] strArr) {
            try {
                this.f312a.mFileInfoTask.remove(this);
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
            if (!isCancelled()) {
                this.f312a.setMediInformation(new int[]{R.string.FINFO_BOOK_AUTOR, R.string.FINFO_BOOK_TITLE}, strArr);
            }
        }

        protected /* synthetic */ Object doInBackground(Object[] objArr) {
            return m382a((String[]) objArr);
        }

        protected /* synthetic */ void onPostExecute(Object obj) {
            m383b((String[]) obj);
        }
    }

    /* renamed from: ru.zdevs.zarchiver.dialog.ZFileInfoDialog$f */
    private class C0111f extends AsyncTask<String, Void, FSFileInfo> {
        /* renamed from: a */
        final /* synthetic */ ZFileInfoDialog f313a;
        /* renamed from: b */
        private MyUri f314b = null;
        /* renamed from: c */
        private MyUri[] f315c = null;

        C0111f(ZFileInfoDialog zFileInfoDialog, MyUri[] myUriArr) {
            this.f313a = zFileInfoDialog;
            if (myUriArr.length == 1) {
                this.f314b = myUriArr[0];
            } else {
                this.f315c = myUriArr;
            }
        }

        /* renamed from: a */
        protected FSFileInfo m384a(String... strArr) {
            FSFileInfo fSFileInfo = null;
            for (ZViewFS zViewFS : ZViewFS.get()) {
                fSFileInfo = this.f314b != null ? zViewFS.getFilesInfo(this.f314b, strArr, (AsyncTask) this) : zViewFS.getFilesInfo(this.f315c, strArr, (AsyncTask) this);
                if (fSFileInfo == null) {
                    if (isCancelled()) {
                        break;
                    }
                }
                break;
            }
            return fSFileInfo;
        }

        /* renamed from: a */
        protected void m385a(FSFileInfo fSFileInfo) {
            try {
                this.f313a.mFileInfoTask.remove(this);
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
            if (!isCancelled() && fSFileInfo != null) {
                try {
                    TextView textView = (TextView) this.f313a.mDlg.findViewById(R.id.tvFileSize);
                    if (textView != null) {
                        textView.setText(C0202q.m736b(fSFileInfo.mSize) + " (" + fSFileInfo.mSize + C0202q.f556d + ")");
                    }
                    if (fSFileInfo.mFileCount > 0) {
                        View findViewById = this.f313a.mDlg.findViewById(R.id.trFileCount);
                        textView = (TextView) this.f313a.mDlg.findViewById(R.id.tvFileCount);
                        if (textView != null && findViewById != null) {
                            findViewById.setVisibility(0);
                            textView.setText(Integer.toString(fSFileInfo.mFileCount));
                        }
                    }
                } catch (Throwable e2) {
                    C0166c.m556a(e2);
                }
            }
        }

        protected /* synthetic */ Object doInBackground(Object[] objArr) {
            return m384a((String[]) objArr);
        }

        protected /* synthetic */ void onPostExecute(Object obj) {
            m385a((FSFileInfo) obj);
        }
    }

    /* renamed from: ru.zdevs.zarchiver.dialog.ZFileInfoDialog$g */
    private class C0112g extends AsyncTask<String, Void, String[]> {
        /* renamed from: a */
        final /* synthetic */ ZFileInfoDialog f316a;

        private C0112g(ZFileInfoDialog zFileInfoDialog) {
            this.f316a = zFileInfoDialog;
        }

        /* renamed from: a */
        protected String[] m386a(String... strArr) {
            String[] strArr2 = new String[5];
            try {
                ExifInterface exifInterface = new ExifInterface(strArr[0]);
                int attributeInt = exifInterface.getAttributeInt("ImageWidth", 0);
                int attributeInt2 = exifInterface.getAttributeInt("ImageLength", 0);
                if (attributeInt <= 0 || attributeInt2 <= 0) {
                    Options options = new Options();
                    options.inJustDecodeBounds = true;
                    BitmapFactory.decodeFile(strArr[0], options);
                    if (!(options.outWidth == -1 || options.outHeight == -1)) {
                        strArr2[0] = "" + options.outWidth + "x" + options.outHeight;
                    }
                } else {
                    strArr2[0] = "" + attributeInt + "x" + attributeInt2;
                }
                strArr2[1] = exifInterface.getAttribute("Make");
                strArr2[2] = exifInterface.getAttribute("Model");
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
            return strArr2;
        }

        /* renamed from: b */
        protected void m387b(String[] strArr) {
            try {
                this.f316a.mFileInfoTask.remove(this);
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
            if (!isCancelled()) {
                this.f316a.setMediInformation(new int[]{R.string.FINFO_IMAGE_SIZE, R.string.FINFO_IMAGE_CAMERA_MAKE, R.string.FINFO_IMAGE_CAMERA_MODEL}, strArr);
            }
        }

        protected /* synthetic */ Object doInBackground(Object[] objArr) {
            return m386a((String[]) objArr);
        }

        protected /* synthetic */ void onPostExecute(Object obj) {
            m387b((String[]) obj);
        }
    }

    /* renamed from: ru.zdevs.zarchiver.dialog.ZFileInfoDialog$h */
    private class C0113h extends AsyncTask<String, Void, String> {
        /* renamed from: a */
        final /* synthetic */ ZFileInfoDialog f317a;

        private C0113h(ZFileInfoDialog zFileInfoDialog) {
            this.f317a = zFileInfoDialog;
        }

        /* renamed from: a */
        protected String m388a(String... strArr) {
            return C0167d.m560a(new File(strArr[0]), (AsyncTask) this);
        }

        /* renamed from: a */
        protected void m389a(String str) {
            try {
                this.f317a.mFileInfoTask.remove(this);
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
            if (!isCancelled()) {
                try {
                    TextView textView = (TextView) this.f317a.mDlg.findViewById(R.id.tvFileMD5);
                    if (textView != null) {
                        textView.setText(str);
                    }
                } catch (Throwable e2) {
                    C0166c.m556a(e2);
                }
            }
        }

        protected /* synthetic */ Object doInBackground(Object[] objArr) {
            return m388a((String[]) objArr);
        }

        protected /* synthetic */ void onPostExecute(Object obj) {
            m389a((String) obj);
        }
    }

    /* renamed from: ru.zdevs.zarchiver.dialog.ZFileInfoDialog$i */
    private class C0114i extends AsyncTask<File, Void, Void> {
        /* renamed from: a */
        final /* synthetic */ ZFileInfoDialog f318a;

        private C0114i(ZFileInfoDialog zFileInfoDialog) {
            this.f318a = zFileInfoDialog;
        }

        /* renamed from: a */
        protected Void m390a(File... fileArr) {
            try {
                C0182i.m631a(this.f318a.mContext);
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
            return null;
        }

        protected /* synthetic */ Object doInBackground(Object[] objArr) {
            return m390a((File[]) objArr);
        }
    }

    /* renamed from: ru.zdevs.zarchiver.dialog.ZFileInfoDialog$j */
    private class C0115j extends AsyncTask<String, Void, String[]> {
        /* renamed from: a */
        final /* synthetic */ ZFileInfoDialog f319a;

        private C0115j(ZFileInfoDialog zFileInfoDialog) {
            this.f319a = zFileInfoDialog;
        }

        /* renamed from: a */
        protected String[] m391a(String... strArr) {
            String[] strArr2 = new String[3];
            try {
                MediaMetadataRetriever mediaMetadataRetriever = new MediaMetadataRetriever();
                mediaMetadataRetriever.setDataSource(strArr[0]);
                strArr2[0] = mediaMetadataRetriever.extractMetadata(7);
                String extractMetadata = mediaMetadataRetriever.extractMetadata(19);
                String extractMetadata2 = mediaMetadataRetriever.extractMetadata(18);
                if (!(extractMetadata == null || extractMetadata2 == null)) {
                    strArr2[1] = extractMetadata2 + "x" + extractMetadata;
                }
                strArr2[2] = this.f319a.durationToText(mediaMetadataRetriever.extractMetadata(9));
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
            return strArr2;
        }

        /* renamed from: b */
        protected void m392b(String[] strArr) {
            try {
                this.f319a.mFileInfoTask.remove(this);
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
            if (!isCancelled()) {
                this.f319a.setMediInformation(new int[]{R.string.FINFO_MEDIA_TITLE, R.string.FINFO_IMAGE_SIZE, R.string.FINFO_MEDIA_DURATION}, strArr);
            }
        }

        protected /* synthetic */ Object doInBackground(Object[] objArr) {
            return m391a((String[]) objArr);
        }

        protected /* synthetic */ void onPostExecute(Object obj) {
            m392b((String[]) obj);
        }
    }

    public ZFileInfoDialog(C0136e c0136e, Context context, MyUri myUri, String str) {
        this.mCS = c0136e;
        this.mPath = new MyUri[]{myUri};
        this.mName = new String[]{str};
        this.mType = 0;
        this.mUpdateNomediaState = false;
        this.mFileInfoTask = new ArrayList();
        create(context);
        addDialog();
    }

    public ZFileInfoDialog(C0136e c0136e, Context context, MyUri myUri, String[] strArr) {
        this.mCS = c0136e;
        this.mPath = new MyUri[]{myUri};
        this.mName = (String[]) strArr.clone();
        this.mType = 0;
        this.mUpdateNomediaState = false;
        this.mFileInfoTask = new ArrayList();
        create(context);
        addDialog();
    }

    public ZFileInfoDialog(C0136e c0136e, Context context, MyUri[] myUriArr, String[] strArr) {
        this.mCS = c0136e;
        this.mPath = (MyUri[]) myUriArr.clone();
        this.mName = (String[]) strArr.clone();
        this.mType = 0;
        this.mUpdateNomediaState = false;
        this.mFileInfoTask = new ArrayList();
        create(context);
        addDialog();
    }

    private void create(Context context) {
        this.mContext = context;
        Builder builder = new Builder(context);
        builder.setTitle(R.string.FINFO_TTL_FILE_INFO);
        View inflate = LayoutInflater.from(context).inflate(R.layout.dlg_info, new LinearLayout(context));
        builder.setView(inflate);
        builder.setPositiveButton(R.string.BTN_OK, this);
        builder.setNeutralButton(R.string.BTN_COPY, this);
        builder.setOnCancelListener(this);
        this.mDlg = builder.create();
        this.mDlg.setOnShowListener(new C01041(this));
        TextView textView = (TextView) inflate.findViewById(R.id.tvFileName);
        TextView textView2 = (TextView) inflate.findViewById(R.id.tvFileType);
        TextView textView3 = (TextView) inflate.findViewById(R.id.tvFileSize);
        TextView textView4 = (TextView) inflate.findViewById(R.id.tvFileLastMod);
        TextView textView5 = (TextView) inflate.findViewById(R.id.tvFSPath);
        TextView textView6 = (TextView) inflate.findViewById(R.id.tvFSType);
        TextView textView7 = (TextView) inflate.findViewById(R.id.tvFileMD5);
        View findViewById = inflate.findViewById(R.id.trMD5);
        int i;
        if (this.mName.length == 1) {
            MyUri myUri = new MyUri(this.mPath[0]);
            myUri.add(this.mName[0]);
            Object obj = null;
            textView5.setText("-");
            textView6.setText("-");
            if (myUri.isLocalFS()) {
                String toLocalPath = this.mPath[0].toLocalPath();
                obj = C0200o.m711a(toLocalPath) == (byte) 2 ? 1 : null;
                C0183a a = C0184j.m642a(toLocalPath);
                if (a != null) {
                    textView5.setText(a.m637a());
                    textView6.setText(a.m638b());
                }
                if (obj == null && toLocalPath.startsWith("/storage")) {
                    File toFile = myUri.toFile();
                    if (toFile != null && toFile.isDirectory()) {
                        CheckBox checkBox = (CheckBox) inflate.findViewById(R.id.cbNomedia);
                        checkBox.setVisibility(0);
                        checkBox.setOnCheckedChangeListener(this);
                        checkBox.setChecked(new File(toFile, ".nomedia").exists());
                    }
                }
            } else if (myUri.isArchive()) {
                textView5.setText(myUri.getPath());
                textView6.setText(context.getString(R.string.FINFO_FS_TYPE_ARCHIVE));
            } else if (myUri.isExternal()) {
                textView5.setText("-");
                textView6.setText("Storage Access Framework");
            }
            FSFileInfo fSFileInfo = null;
            if (obj != null) {
                fSFileInfo = FSRoot.getFileInfo(myUri.toFile());
            }
            if (fSFileInfo == null) {
                for (ZViewFS fileInfo : ZViewFS.get()) {
                    fSFileInfo = fileInfo.getFileInfo(myUri, null);
                    if (fSFileInfo != null) {
                        break;
                    }
                }
            }
            if (this.mName[0] == null) {
                CharSequence myUri2 = myUri.toString();
                if (myUri2.endsWith("/")) {
                    myUri2 = myUri2.substring(0, myUri2.length() - 1);
                }
                if (myUri2.contains("/")) {
                    textView.setText(myUri2.substring(myUri2.lastIndexOf("/") + 1));
                } else if (myUri2.length() <= 0) {
                    textView.setText("/");
                } else {
                    textView.setText(myUri2);
                }
            } else {
                textView.setText(this.mName[0]);
            }
            if (fSFileInfo != null) {
                int i2;
                if (!fSFileInfo.mIsFile || fSFileInfo.mIsLink) {
                    if (fSFileInfo.mIsLink) {
                        textView2.setText(context.getString(R.string.FINFO_TYPE_LINK));
                        if (fSFileInfo.mLinkTo != null && fSFileInfo.mLinkTo.length() > 0) {
                            View findViewById2 = inflate.findViewById(R.id.trLinkTo);
                            if (findViewById2 != null) {
                                findViewById2.setVisibility(0);
                            }
                            textView = (TextView) inflate.findViewById(R.id.tvLinkTo);
                            if (textView != null) {
                                textView.setText(fSFileInfo.mLinkTo);
                            }
                        }
                    } else {
                        textView2.setText(R.string.FINFO_TYPE_FOLDER);
                    }
                    if (fSFileInfo.mSize > 0) {
                        textView3.setText(C0202q.m736b(fSFileInfo.mSize) + " (" + fSFileInfo.mSize + C0202q.f556d + ")");
                    } else if (fSFileInfo.mIsLink) {
                        textView3.setText("-");
                    } else {
                        textView3.setText("...");
                        this.mFileInfoTask.add(new C0111f(this, this.mPath).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, this.mName));
                    }
                    if (fSFileInfo.mFileCount > 0) {
                        View findViewById3 = inflate.findViewById(R.id.trFileCount);
                        textView = (TextView) inflate.findViewById(R.id.tvFileCount);
                        if (!(textView == null || findViewById3 == null)) {
                            findViewById3.setVisibility(0);
                            textView.setText(Integer.toString(fSFileInfo.mFileCount));
                        }
                    }
                    textView7.setVisibility(8);
                    findViewById.setVisibility(8);
                } else {
                    String c = C0202q.m740c(C0202q.m743d(this.mName[0]));
                    textView2.setText(c);
                    textView3.setText(C0202q.m736b(fSFileInfo.mSize) + " (" + fSFileInfo.mSize + C0202q.f556d + ")");
                    if (myUri.isLocalFS() && fSFileInfo.mIsFile) {
                        TableLayout tableLayout;
                        textView7.setText("...");
                        this.mFileInfoTask.add(new C0113h().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new String[]{myUri.toLocalPath()}));
                        i = 0;
                        if (c != null) {
                            if (C0202q.m743d(this.mName[0]).equalsIgnoreCase("apk")) {
                                i = R.string.FINFO_APK_INFO;
                            }
                            if (c.startsWith("video/")) {
                                i2 = R.string.FINFO_VIDEO_INFO;
                            } else if (c.startsWith("audio/")) {
                                i2 = R.string.FINFO_AUDIO_INFO;
                            } else if (c.startsWith("image/")) {
                                i2 = R.string.FINFO_IMAGE_INFO;
                            } else if (C0202q.m743d(this.mName[0]).equalsIgnoreCase("fb2") || C0202q.m743d(this.mName[0]).equalsIgnoreCase("epub")) {
                                i2 = R.string.FINFO_BOOK_INFO;
                            } else {
                                byte fileType = ZFileInfo.getFileType(this.mName[0]);
                                if (fileType == (byte) 7 || fileType == (byte) 8) {
                                    i2 = R.string.FINFO_ARCHIVE_INFO;
                                }
                            }
                            if (i2 != 0) {
                                tableLayout = (TableLayout) inflate.findViewById(R.id.tlMediaInfo);
                                if (tableLayout != null) {
                                    tableLayout.setVisibility(0);
                                }
                                textView = (TextView) inflate.findViewById(R.id.tvMediaHeader);
                                if (textView != null) {
                                    textView.setText(i2);
                                }
                            }
                            switch (i2) {
                                case R.string.FINFO_APK_INFO:
                                    this.mFileInfoTask.add(new C0106a(this, context).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new String[]{myUri.toLocalPath()}));
                                    break;
                                case R.string.FINFO_ARCHIVE_INFO:
                                    this.mFileInfoTask.add(new C0108c().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new String[]{myUri.toLocalPath()}));
                                    break;
                                case R.string.FINFO_AUDIO_INFO:
                                    this.mFileInfoTask.add(new C0109d().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new String[]{myUri.toLocalPath()}));
                                    break;
                                case R.string.FINFO_BOOK_INFO:
                                    this.mFileInfoTask.add(new C0110e().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new String[]{myUri.toLocalPath()}));
                                    break;
                                case R.string.FINFO_IMAGE_INFO:
                                    this.mFileInfoTask.add(new C0112g().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new String[]{myUri.toLocalPath()}));
                                    break;
                                case R.string.FINFO_VIDEO_INFO:
                                    this.mFileInfoTask.add(new C0115j().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new String[]{myUri.toLocalPath()}));
                                    break;
                            }
                            this.mType = i2;
                        }
                        i2 = i;
                        if (i2 != 0) {
                            tableLayout = (TableLayout) inflate.findViewById(R.id.tlMediaInfo);
                            if (tableLayout != null) {
                                tableLayout.setVisibility(0);
                            }
                            textView = (TextView) inflate.findViewById(R.id.tvMediaHeader);
                            if (textView != null) {
                                textView.setText(i2);
                            }
                        }
                        switch (i2) {
                            case R.string.FINFO_APK_INFO:
                                this.mFileInfoTask.add(new C0106a(this, context).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new String[]{myUri.toLocalPath()}));
                                break;
                            case R.string.FINFO_ARCHIVE_INFO:
                                this.mFileInfoTask.add(new C0108c().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new String[]{myUri.toLocalPath()}));
                                break;
                            case R.string.FINFO_AUDIO_INFO:
                                this.mFileInfoTask.add(new C0109d().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new String[]{myUri.toLocalPath()}));
                                break;
                            case R.string.FINFO_BOOK_INFO:
                                this.mFileInfoTask.add(new C0110e().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new String[]{myUri.toLocalPath()}));
                                break;
                            case R.string.FINFO_IMAGE_INFO:
                                this.mFileInfoTask.add(new C0112g().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new String[]{myUri.toLocalPath()}));
                                break;
                            case R.string.FINFO_VIDEO_INFO:
                                this.mFileInfoTask.add(new C0115j().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new String[]{myUri.toLocalPath()}));
                                break;
                        }
                        this.mType = i2;
                    } else {
                        textView7.setVisibility(8);
                        findViewById.setVisibility(8);
                    }
                }
                textView4.setText(formatDataTime(context, fSFileInfo));
                if (fSFileInfo.mGID != null && fSFileInfo.mGID.length() > 0 && fSFileInfo.mUID != null && fSFileInfo.mUID.length() > 0) {
                    inflate.findViewById(R.id.trUserGroup).setVisibility(0);
                    ((TextView) inflate.findViewById(R.id.tvUserGroup)).setText(fSFileInfo.mUID + "/" + fSFileInfo.mGID);
                }
                if (fSFileInfo.mPermissions >= 0) {
                    i2 = fSFileInfo.mPermissions;
                    StringBuilder stringBuilder = new StringBuilder();
                    for (i = 0; i < 3; i++) {
                        int i3 = i2 % 10;
                        i2 /= 10;
                        if ((i3 & 1) == 1) {
                            stringBuilder.insert(0, 'x');
                        } else {
                            stringBuilder.insert(0, '-');
                        }
                        if ((i3 & 2) == 2) {
                            stringBuilder.insert(0, 'w');
                        } else {
                            stringBuilder.insert(0, '-');
                        }
                        if ((i3 & 4) == 4) {
                            stringBuilder.insert(0, 'r');
                        } else {
                            stringBuilder.insert(0, '-');
                        }
                        stringBuilder.insert(0, ' ');
                    }
                    inflate.findViewById(R.id.trPermissions).setVisibility(0);
                    ((TextView) inflate.findViewById(R.id.tvPermissions)).setText(stringBuilder.toString());
                    return;
                }
                return;
            }
            return;
        }
        textView.setText(context.getString(R.string.FINFO_NAME_FILE_GROUP).replace("%1", "" + this.mName.length));
        textView2.setText(context.getString(R.string.FINFO_TYPE_FILE_GROUP));
        textView4.setText("-");
        textView5.setText("-");
        textView6.setText("-");
        for (i = 1; i < this.mPath.length; i++) {
            if (!this.mPath[0].equals(this.mPath[i])) {
                Object obj2 = null;
                break;
            }
        }
        i = 1;
        if (obj2 != null) {
            if (this.mPath[0].isLocalFS()) {
                C0183a a2 = C0184j.m642a(this.mPath[0].toLocalPath());
                if (a2 != null) {
                    textView5.setText(a2.m637a());
                    textView6.setText(a2.m638b());
                }
            } else if (this.mPath[0].isArchive()) {
                textView5.setText(this.mPath[0].getPath());
                textView6.setText(context.getString(R.string.FINFO_FS_TYPE_ARCHIVE));
            } else if (this.mPath[0].isExternal()) {
                textView5.setText("-");
                textView6.setText("Storage Access Framework");
            }
        }
        textView7.setVisibility(8);
        findViewById.setVisibility(8);
        this.mFileInfoTask.add(new C0111f(this, this.mPath).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, this.mName));
    }

    private void create(Context context, String[] strArr) {
        this.mContext = context;
        Builder builder = new Builder(context);
        builder.setTitle(R.string.FINFO_TTL_FILE_INFO);
        View inflate = LayoutInflater.from(context).inflate(R.layout.dlg_info, new LinearLayout(context));
        builder.setView(inflate);
        builder.setPositiveButton(R.string.BTN_OK, this);
        builder.setNeutralButton(R.string.BTN_COPY, this);
        builder.setOnCancelListener(this);
        this.mDlg = builder.create();
        this.mDlg.setOnShowListener(new C01052(this));
        TextView textView = (TextView) inflate.findViewById(R.id.tvFileName);
        TextView textView2 = (TextView) inflate.findViewById(R.id.tvFileType);
        TextView textView3 = (TextView) inflate.findViewById(R.id.tvFileSize);
        TextView textView4 = (TextView) inflate.findViewById(R.id.tvFileCount);
        View findViewById = inflate.findViewById(R.id.trFileCount);
        TextView textView5 = (TextView) inflate.findViewById(R.id.tvFileLastMod);
        TextView textView6 = (TextView) inflate.findViewById(R.id.tvFSPath);
        TextView textView7 = (TextView) inflate.findViewById(R.id.tvFSType);
        TextView textView8 = (TextView) inflate.findViewById(R.id.tvFileMD5);
        View findViewById2 = inflate.findViewById(R.id.trMD5);
        textView.setText(strArr[0]);
        textView2.setText(strArr[1]);
        textView3.setText(strArr[2]);
        if (strArr[3] != null) {
            textView4.setText(strArr[3]);
            findViewById.setVisibility(0);
        } else {
            findViewById.setVisibility(8);
        }
        textView5.setText(strArr[4]);
        textView6.setText(strArr[5]);
        textView7.setText(strArr[6]);
        if (strArr[7] != null) {
            textView8.setText(strArr[7]);
        } else {
            textView8.setVisibility(8);
            findViewById2.setVisibility(8);
        }
        if (strArr[8] != null) {
            inflate.findViewById(R.id.trUserGroup).setVisibility(0);
            ((TextView) inflate.findViewById(R.id.tvUserGroup)).setText(strArr[8]);
        }
        if (strArr[9] != null) {
            inflate.findViewById(R.id.trPermissions).setVisibility(0);
            ((TextView) inflate.findViewById(R.id.tvPermissions)).setText(strArr[9]);
        }
        if (strArr[10] != null) {
            CheckBox checkBox = (CheckBox) inflate.findViewById(R.id.cbNomedia);
            checkBox.setVisibility(0);
            checkBox.setOnCheckedChangeListener(this);
            checkBox.setChecked(strArr[10].equals("1"));
        }
        if (strArr[11] != null) {
            TableLayout tableLayout = (TableLayout) inflate.findViewById(R.id.tlMediaInfo);
            if (tableLayout != null) {
                tableLayout.setVisibility(0);
            }
            textView = (TextView) inflate.findViewById(R.id.tvMediaHeader);
            if (textView != null) {
                textView.setText(strArr[11]);
            }
            for (int i = 0; i < mMedia.length; i++) {
                if (strArr[(i * 2) + 12] != null) {
                    View findViewById3 = inflate.findViewById(mMedia[i]);
                    if (findViewById3 != null) {
                        findViewById3.setVisibility(0);
                    }
                    textView = (TextView) inflate.findViewById(mMediaTitle[i]);
                    if (textView != null) {
                        textView.setText(strArr[(i * 2) + 12]);
                    }
                    textView = (TextView) inflate.findViewById(mMediaValue[i]);
                    if (textView != null) {
                        textView.setText(strArr[((i * 2) + 12) + 1]);
                    }
                }
            }
        }
    }

    private String durationToText(String str) {
        Throwable e;
        if (str == null) {
            return null;
        }
        String str2 = "";
        String str3;
        try {
            long j /= 1000;
            str2 = (j % 60) + "." + String.format(Locale.ENGLISH, "%03d", new Object[]{Long.valueOf(Long.parseLong(str) % 1000)});
            j /= 60;
            if (j > 0) {
                str2 = (j % 60) + ":" + str2;
                j /= 60;
                str3 = str2;
            } else {
                str3 = str2;
            }
            if (j <= 0) {
                return str3;
            }
            try {
                return (j % 60) + ":" + str3;
            } catch (Exception e2) {
                e = e2;
                C0166c.m556a(e);
                return str3;
            }
        } catch (Throwable e3) {
            Throwable th = e3;
            str3 = str2;
            e = th;
            C0166c.m556a(e);
            return str3;
        }
    }

    private String formatDataTime(Context context, FSFileInfo fSFileInfo) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(DateFormat.getDateInstance(3).format(Long.valueOf(fSFileInfo.mLastMod))).append(" ");
        DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
        Configuration configuration = context.getResources().getConfiguration();
        if (displayMetrics.densityDpi >= 240 || configuration.orientation == 2 || (configuration.screenLayout & 15) >= 3) {
            stringBuilder.append(DateFormat.getTimeInstance(2).format(Long.valueOf(fSFileInfo.mLastMod)));
        } else {
            stringBuilder.append(DateFormat.getTimeInstance(3).format(Long.valueOf(fSFileInfo.mLastMod)));
        }
        return stringBuilder.toString();
    }

    private String[] save() {
        int i = 0;
        String[] strArr = new String[((mMedia.length * 2) + 12)];
        TextView textView = (TextView) this.mDlg.findViewById(R.id.tvFileName);
        if (textView != null) {
            strArr[0] = textView.getText().toString();
        }
        textView = (TextView) this.mDlg.findViewById(R.id.tvFileType);
        if (textView != null) {
            strArr[1] = textView.getText().toString();
        }
        textView = (TextView) this.mDlg.findViewById(R.id.tvFileSize);
        if (textView != null) {
            strArr[2] = textView.getText().toString();
        }
        View findViewById = this.mDlg.findViewById(R.id.trFileCount);
        textView = (TextView) this.mDlg.findViewById(R.id.tvFileCount);
        if (!(textView == null || findViewById == null || findViewById.getVisibility() != 0)) {
            strArr[3] = textView.getText().toString();
        }
        textView = (TextView) this.mDlg.findViewById(R.id.tvFileLastMod);
        if (textView != null) {
            strArr[4] = textView.getText().toString();
        }
        textView = (TextView) this.mDlg.findViewById(R.id.tvFSPath);
        if (textView != null) {
            strArr[5] = textView.getText().toString();
        }
        textView = (TextView) this.mDlg.findViewById(R.id.tvFSType);
        if (textView != null) {
            strArr[6] = textView.getText().toString();
        }
        textView = (TextView) this.mDlg.findViewById(R.id.tvFileMD5);
        if (textView != null && textView.getVisibility() == 0) {
            strArr[7] = textView.getText().toString();
        }
        findViewById = this.mDlg.findViewById(R.id.trUserGroup);
        textView = (TextView) this.mDlg.findViewById(R.id.tvUserGroup);
        if (!(textView == null || findViewById == null || findViewById.getVisibility() != 0)) {
            strArr[8] = textView.getText().toString();
        }
        findViewById = this.mDlg.findViewById(R.id.trPermissions);
        textView = (TextView) this.mDlg.findViewById(R.id.tvPermissions);
        if (!(textView == null || findViewById == null || findViewById.getVisibility() != 0)) {
            strArr[9] = textView.getText().toString();
        }
        View findViewById2 = this.mDlg.findViewById(R.id.cbNomedia);
        if (findViewById2 != null && findViewById2.getVisibility() == 0) {
            strArr[10] = ((CheckBox) findViewById2).isChecked() ? "1" : "0";
        }
        findViewById = this.mDlg.findViewById(R.id.tlMediaInfo);
        textView = (TextView) this.mDlg.findViewById(R.id.tvMediaHeader);
        if (!(textView == null || findViewById == null || findViewById.getVisibility() != 0)) {
            strArr[11] = textView.getText().toString();
            while (i < mMedia.length) {
                findViewById2 = this.mDlg.findViewById(mMedia[i]);
                if (findViewById2 != null && findViewById2.getVisibility() == 0) {
                    textView = (TextView) this.mDlg.findViewById(mMediaTitle[i]);
                    if (textView != null) {
                        strArr[(i * 2) + 12] = textView.getText().toString();
                    }
                    textView = (TextView) this.mDlg.findViewById(mMediaValue[i]);
                    if (textView != null) {
                        strArr[((i * 2) + 12) + 1] = textView.getText().toString();
                    }
                }
                i++;
            }
        }
        return strArr;
    }

    public static void setArchiveInfo(String str, int i, long j, int i2) {
        sArchiveInfo = new C0107b();
        sArchiveInfo.f306a = str;
        sArchiveInfo.f307b = i;
        sArchiveInfo.f308c = j;
        sArchiveInfo.f309d = i2;
    }

    private void setMediInformation(int[] iArr, String[] strArr) {
        if (iArr != null && strArr != null) {
            int i = 0;
            int i2 = 0;
            while (i < iArr.length) {
                try {
                    int i3;
                    if (strArr[i] == null || strArr[i].length() <= 0) {
                        i3 = i2;
                    } else {
                        View findViewById = this.mDlg.findViewById(mMedia[i2]);
                        if (findViewById != null) {
                            findViewById.setVisibility(0);
                        }
                        TextView textView = (TextView) this.mDlg.findViewById(mMediaTitle[i2]);
                        if (textView != null) {
                            textView.setText(this.mDlg.getContext().getString(iArr[i]));
                        }
                        textView = (TextView) this.mDlg.findViewById(mMediaValue[i2]);
                        if (textView != null) {
                            textView.setText(strArr[i]);
                        }
                        i3 = i2 + 1;
                    }
                    i++;
                    i2 = i3;
                } catch (Throwable e) {
                    C0166c.m556a(e);
                    return;
                }
            }
        }
    }

    public void close() {
        this.mContext = null;
        if (this.mDlg != null) {
            this.mDlg.dismiss();
            this.mDlg = null;
        }
        delDialog();
    }

    public int getType() {
        return 6;
    }

    public void hide() {
        this.mContext = null;
        if (this.mDlg != null) {
            this.mSave = save();
            if (this.mDlg != null) {
                this.mDlg.dismiss();
                this.mDlg = null;
            }
        }
    }

    public void onCancel(DialogInterface dialogInterface) {
        if (this.mOnCancelListener != null) {
            this.mOnCancelListener.onCancel(this);
        }
        if (this.mFileInfoTask.size() > 0) {
            C2JBridge.cSetStatus(5, 15);
            for (AsyncTask cancel : this.mFileInfoTask) {
                cancel.cancel(true);
            }
            this.mFileInfoTask.clear();
        }
        this.mDlg = null;
    }

    public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
        if (compoundButton.getId() == R.id.cbNomedia && this.mPath != null && this.mPath.length == 1 && this.mPath[0] != null && this.mPath[0].isLocalFS()) {
            File toFile = (this.mName == null || this.mName.length < 1 || this.mName[0] == null) ? this.mPath[0].toFile() : new File(this.mPath[0].toFile(), this.mName[0]);
            if (toFile != null && toFile.isDirectory()) {
                try {
                    File file = new File(toFile, ".nomedia");
                    CheckBox checkBox;
                    if (z) {
                        try {
                            file.createNewFile();
                            this.mUpdateNomediaState = true;
                        } catch (IOException e) {
                            checkBox = (CheckBox) this.mDlg.findViewById(R.id.cbNomedia);
                            if (checkBox.isEnabled()) {
                                checkBox.setChecked(false);
                            }
                            checkBox.setEnabled(false);
                        }
                    } else if (file.delete()) {
                        this.mUpdateNomediaState = true;
                    } else {
                        checkBox = (CheckBox) this.mDlg.findViewById(R.id.cbNomedia);
                        if (checkBox.isEnabled()) {
                            checkBox.setChecked(true);
                        }
                        checkBox.setEnabled(false);
                    }
                } catch (Throwable e2) {
                    C0166c.m556a(e2);
                }
            }
        }
    }

    public void onClick(DialogInterface dialogInterface, int i) {
        if (this.mUpdateNomediaState) {
            File toFile = (this.mName == null || this.mName.length < 1 || this.mName[0] == null) ? this.mPath[0].toFile() : new File(this.mPath[0].toFile(), this.mName[0]);
            if (toFile != null && toFile.isDirectory()) {
                new C0114i().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new File[]{toFile});
            }
        }
        if (i == -1 && this.mOnOkListener != null) {
            this.mOnOkListener.onOk(this);
        }
        if (i == -2 && this.mOnCancelListener != null) {
            this.mOnCancelListener.onCancel(this);
        }
        close();
    }

    public void onClick(View view) {
        if (this.mContext != null) {
            ClipboardManager clipboardManager = (ClipboardManager) this.mContext.getSystemService("clipboard");
            if (clipboardManager != null) {
                StringBuilder stringBuilder = new StringBuilder();
                TextView textView = (TextView) this.mDlg.findViewById(R.id.tvFileName);
                if (textView != null) {
                    stringBuilder.append(textView.getText().toString()).append('\n');
                }
                textView = (TextView) this.mDlg.findViewById(R.id.tvFileSize);
                if (textView != null) {
                    stringBuilder.append(this.mContext.getString(R.string.FINFO_SIZE)).append(' ').append(textView.getText().toString()).append('\n');
                }
                textView = (TextView) this.mDlg.findViewById(R.id.tvFileMD5);
                if (textView != null) {
                    stringBuilder.append(this.mContext.getString(R.string.FINFO_MD5)).append(' ').append(textView.getText().toString()).append('\n');
                }
                if (this.mType != 0) {
                    for (int i = 0; i < mMedia.length; i++) {
                        View findViewById = this.mDlg.findViewById(mMedia[i]);
                        if (findViewById != null && findViewById.getVisibility() == 0) {
                            textView = (TextView) this.mDlg.findViewById(mMediaTitle[i]);
                            if (textView != null) {
                                stringBuilder.append(textView.getText().toString()).append(' ');
                            }
                            textView = (TextView) this.mDlg.findViewById(mMediaValue[i]);
                            if (textView != null) {
                                stringBuilder.append(textView.getText().toString()).append('\n');
                            }
                        }
                    }
                }
                clipboardManager.setPrimaryClip(ClipData.newPlainText("ZA File Info", stringBuilder.toString()));
            }
        }
    }

    public void reShow(Context context) {
        if (this.mSave != null) {
            create(context, this.mSave);
        } else {
            create(context);
        }
        if (this.mDlg != null) {
            show();
        }
    }

    public void show() {
        if (this.mDlg != null) {
            this.mDlg.show();
        }
    }
}
