package ru.zdevs.zarchiver.dialog;

import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface.OnShowListener;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import ru.zdevs.zarchiver.C0136e;
import ru.zdevs.zarchiver.R;
import ru.zdevs.zarchiver.settings.Settings;

public class ZRootWarningDialog extends ZDialog implements OnClickListener {
    private CheckBox mCbDontShow = null;
    private Context mContext;
    private Dialog mDlg;

    /* renamed from: ru.zdevs.zarchiver.dialog.ZRootWarningDialog$1 */
    class C01321 implements OnShowListener {
        /* renamed from: a */
        final /* synthetic */ ZRootWarningDialog f340a;

        C01321(ZRootWarningDialog zRootWarningDialog) {
            this.f340a = zRootWarningDialog;
        }

        public void onShow(DialogInterface dialogInterface) {
            this.f340a.fixHoloTitle(this.f340a.mDlg);
        }
    }

    public ZRootWarningDialog(C0136e c0136e, Context context) {
        this.mCS = c0136e;
        create(context);
        addDialog();
    }

    private void create(Context context) {
        this.mContext = context;
        Builder builder = new Builder(context);
        builder.setTitle(R.string.RTW_TTL_WARNING);
        View inflate = LayoutInflater.from(context).inflate(R.layout.dlg_root_wrn, new LinearLayout(context));
        builder.setPositiveButton(R.string.BTN_OK, this);
        builder.setNegativeButton(R.string.BTN_CANCEL, this);
        this.mCbDontShow = (CheckBox) inflate.findViewById(R.id.cbDontShow);
        builder.setView(inflate);
        builder.setCancelable(false);
        this.mDlg = builder.create();
        this.mDlg.setCanceledOnTouchOutside(false);
        this.mDlg.setOnShowListener(new C01321(this));
    }

    public void close() {
        hide();
        delDialog();
    }

    public int getType() {
        return 15;
    }

    public void hide() {
        if (this.mDlg != null) {
            this.mDlg.dismiss();
            this.mDlg = null;
        }
        this.mContext = null;
    }

    public void onClick(DialogInterface dialogInterface, int i) {
        if (i == -1 && this.mOnOkListener != null) {
            this.mOnOkListener.onOk(this);
        }
        if (i == -2 && this.mOnCancelListener != null) {
            this.mOnCancelListener.onCancel(this);
        }
        if (this.mCbDontShow != null && this.mCbDontShow.isChecked()) {
            Settings.setShowRootWarning(this.mContext, false);
        }
        close();
    }

    public void reShow(Context context) {
        create(context);
        if (this.mDlg != null) {
            show();
        }
    }

    public void show() {
        if (this.mDlg != null) {
            this.mDlg.show();
        }
    }
}
