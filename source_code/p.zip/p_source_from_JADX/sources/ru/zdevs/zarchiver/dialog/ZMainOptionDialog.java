package ru.zdevs.zarchiver.dialog;

import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface.OnShowListener;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Spinner;
import ru.zdevs.zarchiver.C0136e;
import ru.zdevs.zarchiver.R;

public class ZMainOptionDialog extends ZDialog implements OnCancelListener, OnClickListener {
    private Dialog mDlg;
    private int mIconTheme;
    private int mLanguage;
    private CharSequence[] mLanguageList;
    private int mOEMCP;
    private CharSequence[] mOEMCPList;
    private Spinner mSpnIconTheme;
    private Spinner mSpnLanguage;
    private Spinner mSpnOEMCP;
    private Spinner mSpnTheme;
    private int mTheme;

    /* renamed from: ru.zdevs.zarchiver.dialog.ZMainOptionDialog$1 */
    class C01231 implements OnShowListener {
        /* renamed from: a */
        final /* synthetic */ ZMainOptionDialog f328a;

        C01231(ZMainOptionDialog zMainOptionDialog) {
            this.f328a = zMainOptionDialog;
        }

        public void onShow(DialogInterface dialogInterface) {
            this.f328a.fixHoloTitle(this.f328a.mDlg);
        }
    }

    public ZMainOptionDialog(C0136e c0136e, Context context) {
        this.mCS = c0136e;
        this.mLanguageList = context.getResources().getTextArray(R.array.OPT_LIST_LANGUAGE_VALUE);
        this.mOEMCPList = context.getResources().getTextArray(R.array.OPT_LIST_OEMCP_VALUE);
        create(context);
        addDialog();
    }

    private void create(Context context) {
        Builder builder = new Builder(context);
        builder.setTitle(R.string.SMO_TTL_OPTIONS);
        View inflate = LayoutInflater.from(context).inflate(R.layout.dlg_options_main, new LinearLayout(context));
        this.mSpnTheme = (Spinner) inflate.findViewById(R.id.spn_theme);
        this.mSpnTheme.setEnabled(false);
        this.mSpnIconTheme = (Spinner) inflate.findViewById(R.id.spn_icon_theme);
        this.mSpnLanguage = (Spinner) inflate.findViewById(R.id.spn_language);
        this.mSpnOEMCP = (Spinner) inflate.findViewById(R.id.spn_oem_cp);
        this.mSpnTheme.setSelection(this.mTheme);
        this.mSpnIconTheme.setSelection(this.mIconTheme);
        this.mSpnLanguage.setSelection(this.mLanguage);
        this.mSpnOEMCP.setSelection(this.mOEMCP);
        builder.setView(inflate);
        builder.setPositiveButton(R.string.BTN_OK, this);
        builder.setOnCancelListener(this);
        this.mDlg = builder.create();
        this.mDlg.setCanceledOnTouchOutside(false);
        this.mDlg.setOnShowListener(new C01231(this));
    }

    public void close() {
        hide();
        delDialog();
    }

    public String getIconTheme() {
        return "" + this.mIconTheme;
    }

    public String getLanguage() {
        return this.mLanguageList[this.mLanguage].toString();
    }

    public String getOEMCP() {
        return this.mOEMCPList[this.mOEMCP].toString();
    }

    public String getTheme() {
        return "" + this.mTheme;
    }

    public int getType() {
        return 8;
    }

    public void hide() {
        if (this.mDlg != null) {
            this.mTheme = this.mSpnTheme.getSelectedItemPosition();
            this.mIconTheme = this.mSpnIconTheme.getSelectedItemPosition();
            this.mLanguage = this.mSpnLanguage.getSelectedItemPosition();
            this.mOEMCP = this.mSpnOEMCP.getSelectedItemPosition();
            this.mDlg.dismiss();
            this.mDlg = null;
        }
    }

    public void onCancel(DialogInterface dialogInterface) {
        if (this.mOnCancelListener != null) {
            this.mOnCancelListener.onCancel(this);
        }
        close();
    }

    public void onClick(DialogInterface dialogInterface, int i) {
        if (this.mDlg != null) {
            this.mTheme = this.mSpnTheme.getSelectedItemPosition();
            this.mIconTheme = this.mSpnIconTheme.getSelectedItemPosition();
            this.mLanguage = this.mSpnLanguage.getSelectedItemPosition();
            this.mOEMCP = this.mSpnOEMCP.getSelectedItemPosition();
        }
        if (i == -1 && this.mOnOkListener != null) {
            this.mOnOkListener.onOk(this);
        }
        if (i == -2 && this.mOnCancelListener != null) {
            this.mOnCancelListener.onCancel(this);
        }
        close();
    }

    public void reShow(Context context) {
        create(context);
        if (this.mDlg != null) {
            show();
        }
    }

    public void setIconTheme(int i) {
        this.mIconTheme = i;
        if (this.mDlg != null && this.mSpnIconTheme != null) {
            this.mSpnIconTheme.setSelection(this.mIconTheme);
        }
    }

    public void setLanguage(String str) {
        for (int i = 0; i < this.mLanguageList.length; i++) {
            if (this.mLanguageList[i].equals(str)) {
                this.mLanguage = i;
                break;
            }
        }
        if (this.mDlg != null && this.mSpnLanguage != null) {
            this.mSpnLanguage.setSelection(this.mLanguage);
        }
    }

    public void setOEMCP(int i) {
        String str = "" + i;
        for (int i2 = 0; i2 < this.mOEMCPList.length; i2++) {
            if (this.mOEMCPList[i2].equals(str)) {
                this.mOEMCP = i2;
                break;
            }
        }
        if (this.mDlg != null && this.mSpnOEMCP != null) {
            this.mSpnOEMCP.setSelection(this.mOEMCP);
        }
    }

    public void setTheme(int i) {
        this.mTheme = i;
        if (this.mDlg != null && this.mSpnTheme != null) {
            this.mSpnTheme.setSelection(this.mTheme);
        }
    }

    public void show() {
        if (this.mDlg != null) {
            this.mDlg.show();
        }
    }
}
