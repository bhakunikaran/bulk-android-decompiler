package ru.zdevs.zarchiver.io;

import android.annotation.TargetApi;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore.Files;
import android.provider.MediaStore.Images.Media;
import java.io.File;
import java.io.OutputStream;
import java.util.List;
import ru.zdevs.zarchiver.tool.C0166c;
import ru.zdevs.zarchiver.tool.C0199n;
import ru.zdevs.zarchiver.tool.C0199n.C0198a;

@TargetApi(12)
public class KitKatExtSD {
    /* renamed from: a */
    private static Context f375a = null;
    /* renamed from: b */
    private static ContentResolver f376b;
    /* renamed from: c */
    private static Uri f377c;
    /* renamed from: d */
    private static String[] f378d;
    /* renamed from: e */
    private static String f379e = null;
    /* renamed from: f */
    private static int f380f = 0;

    /* renamed from: a */
    private static Uri m421a(File file) {
        Uri uri = null;
        if (!(file.exists() && file.isDirectory())) {
            try {
                String str = "_data=?";
                f376b.delete(f377c, "_data=?", new String[]{file.getAbsolutePath()});
                ContentValues contentValues = new ContentValues();
                contentValues.put("_data", file.getAbsolutePath());
                contentValues.put("_size", Integer.valueOf(1));
                uri = f376b.insert(f377c, contentValues);
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
        }
        return uri;
    }

    /* renamed from: a */
    private static Uri m422a(String str) {
        File file = new File(str);
        if (file.exists() && file.isDirectory()) {
            return null;
        }
        Cursor query;
        Uri contentUri;
        try {
            String str2 = "_data=?";
            query = f376b.query(f377c, f378d, "_data=?", new String[]{file.getAbsolutePath()}, "_id");
            if (query == null) {
                return null;
            }
            if (query.getCount() == 1) {
                int columnIndex = query.getColumnIndex("_id");
                query.moveToFirst();
                contentUri = Files.getContentUri("external", query.getLong(columnIndex));
            } else {
                contentUri = null;
            }
            query.close();
            return contentUri;
        } catch (Throwable th) {
            C0166c.m556a(th);
            contentUri = null;
        }
    }

    public static int close(int i) {
        return 0;
    }

    @TargetApi(19)
    public static String getExtSDPath(Context context) {
        if (VERSION.SDK_INT < 19) {
            return null;
        }
        File[] externalFilesDirs = context.getExternalFilesDirs(null);
        if (externalFilesDirs == null) {
            return null;
        }
        for (File file : externalFilesDirs) {
            if (file != null) {
                String absolutePath = file.getAbsolutePath();
                if (absolutePath.contains("/Android")) {
                    absolutePath = absolutePath.substring(0, absolutePath.indexOf("/Android"));
                }
                if (new File(absolutePath + "/Android").exists()) {
                    f379e = absolutePath;
                    return absolutePath;
                }
            }
        }
        return null;
    }

    public static boolean isExternalRW(String str) {
        return (f379e == null || str == null) ? false : str.startsWith(f379e);
    }

    public static boolean isUse(String str) {
        return isExternalRW(str);
    }

    public static boolean isWritePermission(Context context) {
        List<C0198a> b = C0199n.m695b(context, 12);
        if (b == null || b.size() <= 0) {
            return true;
        }
        if (f380f == 0) {
            f380f = 1;
            for (C0198a c0198a : b) {
                if (!c0198a.m684a() && !C0143a.m434d(c0198a.f542b)) {
                    f380f = 2;
                    break;
                }
            }
        }
        return f380f == 1;
    }

    public static int mkdir(String str) {
        if (f375a == null || f376b == null) {
            return -1;
        }
        File file = new File(str);
        if (file.exists()) {
            return -1;
        }
        OutputStream openOutStream = openOutStream(file.getAbsoluteFile() + "/.za_tmp.txt");
        if (openOutStream == null) {
            return -1;
        }
        try {
            openOutStream.close();
        } catch (Throwable e) {
            C0166c.m556a(e);
        }
        return 0;
    }

    public static boolean mkdir(File file) {
        if (f375a == null || f376b == null || file.exists()) {
            return false;
        }
        OutputStream openOutStream = openOutStream(file.getAbsoluteFile() + "/.za_tmp.txt");
        if (openOutStream == null) {
            return false;
        }
        try {
            openOutStream.close();
        } catch (Throwable e) {
            C0166c.m556a(e);
        }
        return true;
    }

    public static int open(String str, int i) {
        if (f375a == null || f376b == null) {
            return -1;
        }
        Uri a;
        Uri uri = null;
        if ((i & 257) != 0) {
            if ((i & 1026) != 0) {
                try {
                    uri = m422a(str);
                } catch (Throwable e) {
                    C0166c.m556a(e);
                    return -4;
                }
            }
            a = uri == null ? m421a(new File(str)) : uri;
        } else {
            a = m422a(str);
        }
        if (a == null) {
            return -2;
        }
        String str2 = "";
        if ((i & 3) != 0) {
            str2 = str2 + "w";
        }
        if ((i & 2) != 0) {
            str2 = str2 + "r";
        }
        if ((i & 1024) == 1024) {
            str2 = str2 + "a";
        }
        if ((i & 2048) == 2048) {
            str2 = str2 + "t";
        }
        ParcelFileDescriptor openFileDescriptor = f376b.openFileDescriptor(a, str2);
        if (openFileDescriptor == null) {
            return -3;
        }
        int detachFd = openFileDescriptor.detachFd();
        C0166c.m557b("KitKatExtSD", "Open file with FD: " + detachFd);
        return detachFd;
    }

    public static OutputStream openOutStream(String str) {
        OutputStream outputStream = null;
        if (!(f375a == null || f376b == null)) {
            try {
                Uri a = m421a(new File(str));
                if (a != null) {
                    outputStream = f376b.openOutputStream(a);
                }
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
        }
        return outputStream;
    }

    public static int remove(String str) {
        if (f375a == null || f376b == null) {
            return -1;
        }
        File file = new File(str);
        return (!file.exists() || remove(file)) ? 0 : -1;
    }

    public static boolean remove(File file) {
        boolean z = true;
        if (f375a == null || f376b == null || !isUse(file.getAbsolutePath())) {
            return false;
        }
        String[] list;
        if (file.isDirectory()) {
            list = file.list();
            if (list != null && list.length > 0) {
                return false;
            }
        }
        String str = "_data=?";
        list = new String[]{file.getAbsolutePath()};
        f376b.delete(f377c, "_data=?", list);
        if (file.exists()) {
            ContentValues contentValues = new ContentValues();
            contentValues.put("_data", file.getAbsolutePath());
            f376b.insert(Media.EXTERNAL_CONTENT_URI, contentValues);
            f376b.delete(f377c, "_data=?", list);
        }
        if (file.exists()) {
            z = false;
        }
        return z;
    }

    public static int rename(String str, String str2) {
        return -1;
    }

    public static void setContext(Context context) {
        if (VERSION.SDK_INT < 19) {
            f375a = null;
        } else if (f375a == context) {
        } else {
            if (context == null || isWritePermission(context)) {
                f376b = null;
                f377c = null;
                f378d = null;
                f379e = null;
                return;
            }
            f375a = context;
            f376b = context.getContentResolver();
            f377c = Files.getContentUri("external");
            f378d = new String[]{"_id"};
            f379e = getExtSDPath(context);
            f380f = 0;
        }
    }
}
