package ru.zdevs.zarchiver.io;

import android.content.Context;
import android.os.Build.VERSION;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;

/* renamed from: ru.zdevs.zarchiver.io.a */
public class C0143a {
    /* renamed from: a */
    private static boolean f396a = (VERSION.SDK_INT < 21);

    /* renamed from: a */
    public static OutputStream m426a(String str) {
        return f396a ? KitKatExtSD.openOutStream(str) : LollipopExtSD.openOutStream(str);
    }

    /* renamed from: a */
    public static void m427a(Context context) {
        ZAIO.m425a(context);
        if (f396a) {
            KitKatExtSD.setContext(context);
        } else {
            LollipopExtSD.setContext(context);
        }
    }

    /* renamed from: a */
    public static boolean m428a(File file) {
        return f396a ? KitKatExtSD.remove(file) : LollipopExtSD.remove(file);
    }

    /* renamed from: a */
    public static boolean m429a(String str, String str2, String str3) {
        return !f396a ? LollipopExtSD.renameTo(str, str2, str3) : false;
    }

    /* renamed from: b */
    public static boolean m430b(Context context) {
        return f396a ? KitKatExtSD.isWritePermission(context) : LollipopExtSD.isWritePermission(context);
    }

    /* renamed from: b */
    public static boolean m431b(File file) {
        return f396a ? KitKatExtSD.mkdir(file) : LollipopExtSD.mkdir(file);
    }

    /* renamed from: b */
    public static boolean m432b(String str) {
        return f396a ? KitKatExtSD.isExternalRW(str) : LollipopExtSD.isExternalRW(str);
    }

    /* renamed from: c */
    public static boolean m433c(String str) {
        return f396a ? KitKatExtSD.isUse(str) : LollipopExtSD.isUse(str);
    }

    /* renamed from: d */
    public static boolean m434d(String str) {
        boolean z;
        File file = new File(str + "/Android");
        if (!file.exists()) {
            file = new File(str);
        }
        File file2 = new File(file, ".za_sd_check");
        if (file2.exists()) {
            z = true;
        } else {
            try {
                z = file2.createNewFile();
            } catch (IOException e) {
                z = false;
            }
        }
        return (z && file2.exists()) ? file2.delete() : z;
    }
}
