package ru.zdevs.zarchiver;

import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.app.Activity;
import android.app.WallpaperManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.view.ActionMode;
import android.view.ActionMode.Callback;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewConfiguration;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListPopupWindow;
import android.widget.ListView;
import android.widget.PopupWindow.OnDismissListener;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import ru.zdevs.zarchiver.C0136e.C0135a;
import ru.zdevs.zarchiver.activity.AboutDlg;
import ru.zdevs.zarchiver.activity.SettingsDlg;
import ru.zdevs.zarchiver.fs.FSLocal;
import ru.zdevs.zarchiver.fs.MyUri;
import ru.zdevs.zarchiver.fs.ZFileInfo;
import ru.zdevs.zarchiver.fs.ZViewFS;
import ru.zdevs.zarchiver.fs.ZViewFS.FSFileInfo;
import ru.zdevs.zarchiver.p003a.C0043b;
import ru.zdevs.zarchiver.p003a.C0044c;
import ru.zdevs.zarchiver.p003a.C0046h;
import ru.zdevs.zarchiver.p003a.C0047d;
import ru.zdevs.zarchiver.p003a.C0049e;
import ru.zdevs.zarchiver.p003a.C0051f;
import ru.zdevs.zarchiver.settings.Favorites;
import ru.zdevs.zarchiver.settings.Settings;
import ru.zdevs.zarchiver.tool.C0166c;
import ru.zdevs.zarchiver.tool.C0169f;
import ru.zdevs.zarchiver.tool.C0178g;
import ru.zdevs.zarchiver.tool.C0202q;
import ru.zdevs.zarchiver.widget.ExtendRelativeLayout;
import ru.zdevs.zarchiver.widget.SwipeView;

public class ZSelectFile extends Activity implements OnItemClickListener {
    /* renamed from: a */
    public C0178g f78a = null;
    /* renamed from: b */
    public List<C0049e> f79b = new ArrayList();
    /* renamed from: c */
    public MyUri f80c = new MyUri(Settings.sHomeDir);
    /* renamed from: d */
    private Menu f81d = null;
    /* renamed from: e */
    private TextView f82e = null;
    /* renamed from: f */
    private TextView f83f = null;
    /* renamed from: g */
    private View f84g = null;
    /* renamed from: h */
    private ListPopupWindow f85h = null;
    /* renamed from: i */
    private TextView f86i = null;
    /* renamed from: j */
    private AbsListView f87j = null;
    /* renamed from: k */
    private View f88k = null;
    /* renamed from: l */
    private View f89l = null;
    /* renamed from: m */
    private TextView f90m = null;
    /* renamed from: n */
    private TextView f91n = null;
    /* renamed from: o */
    private TextView f92o = null;
    /* renamed from: p */
    private TextView f93p = null;
    /* renamed from: q */
    private ProgressBar f94q = null;
    /* renamed from: r */
    private AsyncTask<?, ?, ?> f95r = null;
    /* renamed from: s */
    private FSLocal f96s;
    /* renamed from: t */
    private List<C0135a> f97t = new ArrayList();
    /* renamed from: u */
    private int f98u;

    /* renamed from: ru.zdevs.zarchiver.ZSelectFile$2 */
    class C00372 implements OnItemClickListener {
        /* renamed from: a */
        final /* synthetic */ ZSelectFile f74a;

        C00372(ZSelectFile zSelectFile) {
            this.f74a = zSelectFile;
        }

        public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
            if (adapterView != null) {
                this.f74a.m57a(new MyUri(((C0044c) adapterView.getItemAtPosition(i)).f114c));
            }
        }
    }

    /* renamed from: ru.zdevs.zarchiver.ZSelectFile$a */
    private final class C0038a implements Callback {
        /* renamed from: a */
        final /* synthetic */ ZSelectFile f75a;

        private C0038a(ZSelectFile zSelectFile) {
            this.f75a = zSelectFile;
        }

        public boolean onActionItemClicked(ActionMode actionMode, MenuItem menuItem) {
            return true;
        }

        public boolean onCreateActionMode(ActionMode actionMode, Menu menu) {
            this.f75a.getActionBar().setCustomView(null);
            actionMode.setCustomView(this.f75a.f84g);
            this.f75a.f81d = menu;
            (VERSION.SDK_INT < 16 ? new MenuInflater(this.f75a) : this.f75a.getMenuInflater()).inflate(R.menu.menu_main, menu);
            MenuItem findItem = menu.findItem(R.id.bMenuNew);
            if (findItem != null) {
                findItem.setVisible(false);
            }
            findItem = menu.findItem(R.id.bMenuAdd);
            if (findItem != null) {
                findItem.setVisible(false);
            }
            findItem = menu.findItem(R.id.bSettings);
            if (findItem != null) {
                findItem.setVisible(false);
            }
            findItem = menu.findItem(R.id.bAbout);
            if (findItem != null) {
                findItem.setVisible(false);
            }
            this.f75a.m43a(Settings.sFMSortType, Settings.sFMSortDesc);
            return true;
        }

        public void onDestroyActionMode(ActionMode actionMode) {
            this.f75a.setResult(0, null);
            this.f75a.finish();
        }

        public boolean onPrepareActionMode(ActionMode actionMode, Menu menu) {
            return false;
        }
    }

    /* renamed from: ru.zdevs.zarchiver.ZSelectFile$b */
    private class C0039b extends AsyncTask<Void, Void, Long> {
        /* renamed from: a */
        final /* synthetic */ ZSelectFile f76a;
        /* renamed from: b */
        private MyUri f77b = null;

        C0039b(ZSelectFile zSelectFile, MyUri myUri) {
            this.f76a = zSelectFile;
            this.f77b = myUri;
        }

        /* renamed from: a */
        protected Long m37a(Void... voidArr) {
            FSFileInfo fileInfo = this.f76a.f96s.getFileInfo(this.f77b, this);
            return fileInfo != null ? Long.valueOf(fileInfo.mSize) : Long.valueOf(-1);
        }

        /* renamed from: a */
        protected void m38a(Long l) {
            this.f76a.f95r = null;
            if (!isCancelled()) {
                try {
                    if (this.f76a.f93p == null) {
                        return;
                    }
                    if (l.longValue() != -1) {
                        this.f76a.f93p.setText(this.f76a.getString(R.string.FINFO_SIZE) + " " + C0202q.m736b(l.longValue()));
                    } else {
                        this.f76a.f93p.setText(this.f76a.getString(R.string.FINFO_SIZE) + " ---");
                    }
                } catch (Throwable e) {
                    C0166c.m556a(e);
                }
            }
        }

        protected /* synthetic */ Object doInBackground(Object[] objArr) {
            return m37a((Void[]) objArr);
        }

        protected /* synthetic */ void onPostExecute(Object obj) {
            m38a((Long) obj);
        }
    }

    /* renamed from: a */
    private void m43a(byte b, boolean z) {
        Settings.sFMSortType = b;
        Settings.sFMSortDesc = z;
        ZViewFS.setSort(Settings.sFMSortType, Settings.sFMSortDesc);
        m44a(this.f81d);
    }

    /* renamed from: a */
    private void m44a(Menu menu) {
        if (menu != null) {
            MenuItem menuItem = null;
            switch (Settings.sFMSortType) {
                case (byte) 0:
                    menuItem = menu.findItem(R.id.bSortByName);
                    break;
                case (byte) 1:
                    menuItem = menu.findItem(R.id.bSortByType);
                    break;
                case (byte) 2:
                    menuItem = menu.findItem(R.id.bSortBySize);
                    break;
                case (byte) 3:
                    menuItem = menu.findItem(R.id.bSortByDate);
                    break;
            }
            if (menuItem != null) {
                menuItem.setChecked(true);
            }
            menuItem = menu.findItem(R.id.bSortDesс);
            if (menuItem != null) {
                menuItem.setChecked(Settings.sFMSortDesc);
            }
        }
    }

    @SuppressLint({"InlinedApi"})
    /* renamed from: h */
    private void m49h() {
        if (VERSION.SDK_INT >= 19) {
            if ((getResources().getConfiguration().screenLayout & 15) != 3 && ((Settings.sTheme == (byte) 0 && !Settings.sGUIWideBar) || ((Settings.sActionbarColor != 0 && Settings.sGUIWideBar) || VERSION.SDK_INT >= 21))) {
                getWindow().setFlags(134217728, 134217728);
            }
            if (Settings.sActionbarColor != 0 && VERSION.SDK_INT == 19) {
                getWindow().setFlags(67108864, 67108864);
            }
        }
        setTheme(Settings.sThemeResource);
        ActionBar actionBar = getActionBar();
        if (actionBar != null) {
            actionBar.getThemedContext().setTheme(Settings.sThemeResource);
            actionBar.show();
        }
    }

    /* renamed from: i */
    private void m50i() {
        String path = this.f80c.getPath();
        if (path.startsWith(C0202q.m727a((Context) this))) {
            path = path.replace(C0202q.m727a((Context) this), "~");
        }
        String str = "";
        int lastIndexOf = path.lastIndexOf(47);
        if (lastIndexOf >= 0) {
            Object substring = path.substring(lastIndexOf + 1);
            CharSequence substring2 = path.substring(0, lastIndexOf);
        } else {
            String str2 = str;
            str = path;
            Object obj = str2;
        }
        if (substring2.length() <= 1) {
            substring2 = substring2 + "/";
        }
        if (this.f83f != null) {
            try {
                this.f83f.setText(substring2);
            } catch (Throwable e) {
                C0166c.m556a(e);
                this.f83f.setEllipsize(null);
                this.f83f.setGravity(8388613);
                this.f83f.setText(substring2);
            }
        }
        if (this.f82e != null) {
            this.f82e.setText(substring);
        }
        if (this.f88k != null) {
            if (this.f95r != null) {
                this.f95r.cancel(true);
            }
            this.f88k.setVisibility(0);
            if (this.f89l != null) {
                try {
                    this.f89l.setVisibility(0);
                    File canonicalFile = this.f80c.toFile().getCanonicalFile();
                    if (this.f94q != null) {
                        this.f94q.setMax((int) canonicalFile.getTotalSpace());
                        this.f94q.setProgress((int) canonicalFile.getFreeSpace());
                    }
                    this.f90m.setText(getString(R.string.FINFO_TYPE) + " " + getString(R.string.FINFO_TYPE_FOLDER));
                    this.f91n.setText(getString(R.string.FINFO_FREE_SPACE) + " " + C0202q.m736b(canonicalFile.getFreeSpace()) + "/\n" + C0202q.m736b(canonicalFile.getTotalSpace()));
                } catch (Throwable e2) {
                    if (this.f94q != null) {
                        this.f94q.setMax(1);
                        this.f94q.setProgress(0);
                    }
                    this.f89l.setVisibility(8);
                    C0166c.m556a(e2);
                }
            }
            if (this.f92o != null) {
                this.f92o.setText(getString(R.string.FINFO_TYPE_FOLDER) + ": " + substring);
            }
            if (this.f93p != null) {
                this.f93p.setText(getString(R.string.FINFO_SIZE) + " ...");
                this.f95r = new C0039b(this, this.f80c).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Void[0]);
            }
        }
    }

    /* renamed from: j */
    private void m51j() {
        C0135a g = m65g();
        while (g != null && g.f345a.compareTo(this.f80c) == 0) {
            g = m65g();
        }
        if (g == null) {
            this.f80c.del();
            m58a(false);
            return;
        }
        this.f80c = g.f345a;
        m58a(false);
        if (m61c() != null && g.f347c >= 0) {
            m61c().setSelection(g.f347c);
        }
    }

    /* renamed from: k */
    private void m52k() {
        View findViewById = findViewById(Resources.getSystem().getIdentifier("action_mode_close_button", "id", "android"));
        if (findViewById != null) {
            try {
                if (findViewById instanceof ImageView) {
                    ((ImageView) findViewById).setImageDrawable(C0202q.m725a((Context) this, (int) R.attr.menuIconCancel));
                    return;
                }
                LinearLayout linearLayout = (LinearLayout) findViewById;
                if (linearLayout.getChildCount() > 0 && linearLayout.getChildAt(0) != null) {
                    ((ImageView) linearLayout.getChildAt(0)).setImageDrawable(C0202q.m725a((Context) this, (int) R.attr.menuIconCancel));
                    if (linearLayout.getChildCount() > 1 && linearLayout.getChildAt(1) != null) {
                        ((TextView) linearLayout.getChildAt(1)).setText(17039360);
                    }
                }
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
        }
    }

    /* renamed from: a */
    public void m53a() {
        if (Settings.sGUIGridView) {
            setContentView(R.layout.dlg_main_grid);
        } else {
            setContentView(R.layout.dlg_main_list);
        }
        this.f87j = (AbsListView) findViewById(16908298);
        getActionBar().setCustomView(R.layout.ctm_navigate);
        this.f84g = getActionBar().getCustomView();
        this.f82e = (TextView) this.f84g.findViewById(R.id.nTitle);
        this.f83f = (TextView) this.f84g.findViewById(R.id.nSubtitle);
        SearchView searchView = (SearchView) this.f84g.findViewById(R.id.svSearch);
        if (searchView != null) {
            searchView.setVisibility(8);
        }
        this.f86i = (TextView) findViewById(R.id.tvFSMessage);
        this.f88k = findViewById(R.id.llFolderInfo);
        if (this.f88k == null) {
            SwipeView swipeView = (SwipeView) findViewById(R.id.svSwipe);
            ExtendRelativeLayout extendRelativeLayout = (ExtendRelativeLayout) LayoutInflater.from(this).inflate(R.layout.extend_info, new ExtendRelativeLayout(this));
            extendRelativeLayout.setBackgroundColor(C0202q.m735b((Context) this, 16842801));
            swipeView.setExtendView(extendRelativeLayout);
            swipeView.setEnabled(true);
            this.f88k = swipeView;
        }
        this.f89l = this.f88k.findViewById(R.id.llStorage);
        this.f90m = (TextView) this.f88k.findViewById(R.id.tvStorage);
        this.f91n = (TextView) this.f88k.findViewById(R.id.tvStorageSpace);
        this.f92o = (TextView) this.f88k.findViewById(R.id.tvFolder);
        this.f93p = (TextView) this.f88k.findViewById(R.id.tvFolderSize);
        this.f94q = (ProgressBar) this.f88k.findViewById(R.id.pbFree);
        ImageButton imageButton = (ImageButton) findViewById(R.id.ibAction);
        if (imageButton != null) {
            imageButton.setVisibility(8);
        }
    }

    /* renamed from: a */
    public void m54a(int i) {
        m55a(i, null);
    }

    /* renamed from: a */
    public void m55a(int i, Animation animation) {
        int i2 = 1;
        this.f98u = i;
        C0046h e = m63e();
        if (this.f86i != null && e != null) {
            int i3 = i > 0 ? 1 : 0;
            if (i3 != 0 && (e instanceof C0051f) && e.getCount() > 0) {
                i3 = 0;
            }
            if (i3 != 0) {
                int count = e.getCount();
                if (!ZViewFS.sAddFolderUp) {
                    i2 = 0;
                }
                if (count > i2) {
                    i3 = 0;
                }
            }
            if (i3 != 0) {
                if (animation != null) {
                    this.f86i.startAnimation(animation);
                }
                this.f86i.setVisibility(0);
                this.f86i.setText(i);
                return;
            }
            this.f86i.setVisibility(8);
        }
    }

    /* renamed from: a */
    public void m56a(ListAdapter listAdapter) {
        if (this.f87j != null) {
            this.f87j.setAdapter(listAdapter);
        }
    }

    /* renamed from: a */
    public void m57a(MyUri myUri) {
        ListAdapter c0047d;
        m60b(m62d());
        int message = this.f96s.list(this, myUri, this.f79b, 0) ? this.f96s.getMessage() : 0;
        this.f80c = myUri;
        Animation animation = null;
        Animation animation2;
        if (!Settings.sGUIAnimation || m61c() == null) {
            animation2 = animation;
        } else {
            try {
                animation = AnimationUtils.loadAnimation(this, R.anim.file_list_in);
                if (animation != null) {
                    m61c().setAnimation(animation);
                    animation2 = animation;
                } else {
                    animation2 = animation;
                }
            } catch (Throwable th) {
                if (animation != null) {
                    m61c().setAnimation(animation);
                }
            }
        }
        C0046h e = m63e();
        if (e == null || !(e instanceof C0047d)) {
            c0047d = new C0047d(this);
            c0047d.mo15a(false);
        } else {
            C0047d c0047d2 = (C0047d) e;
        }
        if (!(!Settings.sGUIAnimation || m61c() == null || r3 == null)) {
            m61c().startLayoutAnimation();
        }
        c0047d.m89a(this.f79b, this.f80c);
        m56a(c0047d);
        m54a(message);
        m50i();
    }

    /* renamed from: a */
    public void m58a(boolean z) {
        ListAdapter c0047d;
        int firstVisiblePosition = (!z || m61c() == null) ? 0 : m61c().getFirstVisiblePosition();
        int message = this.f96s.list(this, this.f80c, this.f79b, z ? 1 : 0) ? this.f96s.getMessage() : 0;
        C0046h e = m63e();
        if (e == null || !(e instanceof C0047d)) {
            c0047d = new C0047d(this);
            c0047d.mo15a(false);
        } else {
            C0047d c0047d2 = (C0047d) e;
        }
        c0047d.m89a(this.f79b, this.f80c);
        m56a(c0047d);
        if (z && firstVisiblePosition > 0) {
            m61c().setSelection(firstVisiblePosition);
        }
        m54a(message);
        m50i();
    }

    /* renamed from: b */
    public void m59b() {
        ActionBar actionBar = getActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setDisplayShowCustomEnabled(true);
            actionBar.setDisplayShowTitleEnabled(false);
        }
        RelativeLayout relativeLayout = (RelativeLayout) this.f84g.findViewById(R.id.rlNavigation);
        getActionBar().setCustomView(this.f84g);
        final Resources resources = getResources();
        this.f84g.setMinimumWidth(resources.getDisplayMetrics().widthPixels);
        relativeLayout.setOnClickListener(new OnClickListener(this) {
            /* renamed from: b */
            final /* synthetic */ ZSelectFile f73b;

            /* renamed from: ru.zdevs.zarchiver.ZSelectFile$1$1 */
            class C00341 implements OnItemClickListener {
                /* renamed from: a */
                final /* synthetic */ C00361 f70a;

                C00341(C00361 c00361) {
                    this.f70a = c00361;
                }

                public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                    if (adapterView != null) {
                        this.f70a.f73b.m57a(new MyUri(((C0044c) adapterView.getItemAtPosition(i)).f114c));
                        if (this.f70a.f73b.f85h != null) {
                            this.f70a.f73b.f85h.dismiss();
                            this.f70a.f73b.f85h = null;
                        }
                    }
                }
            }

            /* renamed from: ru.zdevs.zarchiver.ZSelectFile$1$2 */
            class C00352 implements OnDismissListener {
                /* renamed from: a */
                final /* synthetic */ C00361 f71a;

                C00352(C00361 c00361) {
                    this.f71a = c00361;
                }

                public void onDismiss() {
                    this.f71a.f73b.f85h = null;
                }
            }

            public void onClick(View view) {
                this.f73b.f85h = new ListPopupWindow(this.f73b);
                this.f73b.f85h.setAnchorView(this.f73b.f84g);
                ListAdapter c0043b = new C0043b(this.f73b, true);
                c0043b.m69a(Favorites.getFavorites(this.f73b));
                this.f73b.f85h.setAdapter(c0043b);
                int identifier = resources.getIdentifier("config_prefDialogWidth", "dimen", "android");
                int i = resources.getDisplayMetrics().widthPixels;
                if (identifier != 0) {
                    i = Math.max(i, resources.getDimensionPixelSize(identifier));
                }
                this.f73b.f85h.setContentWidth(i);
                this.f73b.f85h.setOnItemClickListener(new C00341(this));
                this.f73b.f85h.setOnDismissListener(new C00352(this));
                this.f73b.f85h.setModal(true);
                this.f73b.f85h.show();
            }
        });
        m50i();
        m54a(this.f98u);
        ImageView imageView = (ImageView) findViewById(R.id.ivParent);
        Drawable drawable = null;
        switch (Settings.sGUIBackground) {
            case (byte) 1:
                drawable = WallpaperManager.getInstance(this).getDrawable();
                break;
            case (byte) 2:
                drawable = C0202q.m725a((Context) this, (int) R.attr.backgroundColorFileList);
                break;
            case (byte) 3:
                if (Settings.sActionbarColor != 0 && VERSION.SDK_INT < 21) {
                    drawable = C0202q.m725a((Context) this, (int) R.attr.backgroundColorFileList);
                    break;
                }
            case (byte) 4:
                try {
                    if (Settings.sBGCustomPath != null) {
                        drawable = Drawable.createFromPath(Settings.sBGCustomPath);
                        break;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(this, "Error on the loading the background image", 0).show();
                    break;
                }
                break;
        }
        if (drawable == null || !(drawable instanceof BitmapDrawable)) {
            imageView.setImageDrawable(drawable);
            m61c().setDrawingCacheEnabled(true);
        } else {
            imageView.setImageBitmap(((BitmapDrawable) drawable).getBitmap());
            imageView.setScaleType(ScaleType.CENTER_CROP);
            m61c().setCacheColorHint(0);
            AbsListView c = m61c();
            boolean z = Settings.sGUIBackground == (byte) 2 || Settings.sGUIBackground == (byte) 3;
            c.setDrawingCacheEnabled(z);
        }
        m61c().setFastScrollEnabled(Settings.sGUIFastScroll);
        m61c().setOnItemClickListener(this);
        relativeLayout = (RelativeLayout) findViewById(R.id.rlFavoBar);
        if (relativeLayout != null) {
            relativeLayout.setVisibility(Settings.sFavoriteBar ? 0 : 8);
        }
        ListView listView = (ListView) findViewById(R.id.lvFavorite);
        if (listView != null && Settings.sFavoriteBar) {
            ListAdapter c0043b = new C0043b(this);
            c0043b.m69a(Favorites.getFavorites(this));
            listView.setAdapter(c0043b);
            listView.setCacheColorHint(0);
            listView.setOnItemClickListener(new C00372(this));
        }
    }

    /* renamed from: b */
    public void m60b(int i) {
        C0135a c0135a = new C0135a(this.f80c, '\u0000', i, false, this.f98u);
        C0135a c0135a2 = null;
        if (this.f97t.size() > 0) {
            c0135a2 = (C0135a) this.f97t.get(this.f97t.size() - 1);
        }
        if (c0135a.m396a(c0135a2) != 0) {
            this.f97t.add(c0135a);
        }
    }

    /* renamed from: c */
    public AbsListView m61c() {
        return this.f87j;
    }

    /* renamed from: d */
    public int m62d() {
        return m61c() != null ? m61c().getFirstVisiblePosition() : -1;
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        if (keyEvent.getKeyCode() != 4 || keyEvent.getAction() != 1) {
            return super.dispatchKeyEvent(keyEvent);
        }
        if (this.f97t == null || this.f97t.size() <= 0) {
            setResult(0, null);
            finish();
            return true;
        }
        m51j();
        return true;
    }

    /* renamed from: e */
    public C0046h m63e() {
        return this.f87j != null ? (C0046h) this.f87j.getAdapter() : null;
    }

    /* renamed from: f */
    public void m64f() {
        if (this.f97t.size() > 0) {
            C0135a c0135a = (C0135a) this.f97t.get(this.f97t.size() - 1);
            while (c0135a != null && c0135a.f345a.compareTo(this.f80c) != 0) {
                this.f97t.remove(this.f97t.size() - 1);
                C0166c.m559d("ZSelectFile", "History delete. Size: " + this.f97t.size());
                if (this.f97t.size() > 0) {
                    c0135a = (C0135a) this.f97t.get(this.f97t.size() - 1);
                } else {
                    return;
                }
            }
        }
    }

    /* renamed from: g */
    public C0135a m65g() {
        if (this.f97t.size() <= 0) {
            return null;
        }
        C0135a c0135a = (C0135a) this.f97t.get(this.f97t.size() - 1);
        this.f97t.remove(this.f97t.size() - 1);
        return c0135a;
    }

    public void onCreate(Bundle bundle) {
        Settings.LoadSettings(this, false);
        ZViewFS.setSort(Settings.sFMSortType, Settings.sFMSortDesc);
        try {
            ViewConfiguration viewConfiguration = ViewConfiguration.get(this);
            Field declaredField = ViewConfiguration.class.getDeclaredField("sHasPermanentMenuKey");
            if (declaredField != null) {
                declaredField.setAccessible(true);
                declaredField.setBoolean(viewConfiguration, false);
            }
        } catch (Throwable e) {
            C0166c.m556a(e);
        }
        m49h();
        ZArchiver.setLanguage(this);
        super.onCreate(bundle);
        m53a();
        C0202q.m741c((Context) this);
        C0169f.m577a((Context) this);
        ZFileInfo.loadFileType(getResources());
        this.f96s = new FSLocal();
        this.f78a = null;
        this.f79b = new ArrayList();
        this.f98u = 0;
        this.f80c = new MyUri(Settings.sHomeDir);
        this.f97t = new ArrayList();
        Intent intent = getIntent();
        if (intent == null || intent.getAction() == null || !intent.getAction().equals("android.intent.action.GET_CONTENT")) {
            setResult(0, null);
            finish();
        }
        m53a();
        m59b();
        m58a(false);
        startActionMode(new C0038a());
        m52k();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }

    public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
        C0049e c0049e = null;
        if (i >= 0 && i < this.f79b.size()) {
            c0049e = (C0049e) this.f79b.get(i);
        }
        if (c0049e != null) {
            MyUri myUri;
            if (c0049e.m107b()) {
                myUri = new MyUri(this.f80c);
                if (c0049e.m108c()) {
                    if (myUri.del()) {
                        m57a(myUri);
                        m64f();
                        return;
                    }
                    return;
                } else if (myUri.add(c0049e.mo28e())) {
                    m57a(myUri);
                    return;
                } else {
                    return;
                }
            }
            myUri = new MyUri(this.f80c);
            if (myUri.add(c0049e.mo28e())) {
                Intent intent = new Intent();
                intent.setData(Uri.fromFile(new File(myUri.getPath())));
                setResult(-1, intent);
                finish();
            }
        }
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        return i == 82 ? true : super.onKeyDown(i, keyEvent);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 16908332) {
            return super.onOptionsItemSelected(menuItem);
        }
        m51j();
        return true;
    }

    protected void onStart() {
        super.onStart();
        if (Settings.sFMShowThumbnails || Settings.sFMShowApkIcon) {
            if (this.f78a == null) {
                this.f78a = new C0178g(this);
            }
            this.f78a.m616a((Context) this);
            this.f78a.m618b();
            C0047d.m84a(this.f78a);
            C0051f.m117a(this.f78a);
        }
    }

    protected void onStop() {
        super.onStop();
        if (this.f95r != null) {
            this.f95r.cancel(true);
        }
        this.f95r = null;
        if (this.f78a != null) {
            this.f78a.m615a();
            this.f78a = null;
            C0047d.m84a(null);
            C0051f.m117a(null);
        }
    }

    public void onToolbarItemClick(MenuItem menuItem) {
        boolean z = true;
        if (menuItem != null) {
            switch (menuItem.getItemId()) {
                case R.id.bAbout:
                    startActivity(new Intent(this, AboutDlg.class));
                    return;
                case R.id.bExit:
                    setResult(0, null);
                    finish();
                    return;
                case R.id.bSettings:
                    startActivity(new Intent(this, SettingsDlg.class));
                    return;
                case R.id.bSortByDate:
                    m43a((byte) 3, Settings.sFMSortDesc);
                    m58a(false);
                    return;
                case R.id.bSortByName:
                    m43a((byte) 0, Settings.sFMSortDesc);
                    m58a(false);
                    return;
                case R.id.bSortBySize:
                    m43a((byte) 2, Settings.sFMSortDesc);
                    m58a(false);
                    return;
                case R.id.bSortByType:
                    m43a((byte) 1, Settings.sFMSortDesc);
                    m58a(false);
                    return;
                case R.id.bSortDesс:
                    byte b = Settings.sFMSortType;
                    if (Settings.sFMSortDesc) {
                        z = false;
                    }
                    m43a(b, z);
                    m58a(false);
                    return;
                default:
                    return;
            }
        }
    }
}
