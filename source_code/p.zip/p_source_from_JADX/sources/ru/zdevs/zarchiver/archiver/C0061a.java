package ru.zdevs.zarchiver.archiver;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Build.VERSION;
import java.util.List;
import java.util.Locale;
import ru.zdevs.zarchiver.ZArchiverExtInterface;
import ru.zdevs.zarchiver.fs.ZViewFS.FSFileInfo;
import ru.zdevs.zarchiver.p003a.C0049e;
import ru.zdevs.zarchiver.tool.C0202q;

/* renamed from: ru.zdevs.zarchiver.archiver.a */
public class C0061a {
    /* renamed from: b */
    private static C0061a f210b;
    /* renamed from: a */
    public C0059f f211a;

    public C0061a() {
        f210b = this;
    }

    /* renamed from: a */
    public static List<C0066d> m201a(String str, String str2, boolean z, Thread thread) {
        return (f210b == null || f210b.f211a == null) ? null : f210b.f211a.mo30a(str, str2, z, thread);
    }

    /* renamed from: a */
    public static FSFileInfo m202a(String str, AsyncTask<?, ?, ?> asyncTask) {
        return (f210b == null || f210b.f211a == null) ? null : f210b.f211a.mo31a(str, (AsyncTask) asyncTask);
    }

    /* renamed from: a */
    public static FSFileInfo m203a(List<String> list, AsyncTask<?, ?, ?> asyncTask) {
        return (f210b == null || f210b.f211a == null) ? null : f210b.f211a.mo32a((List) list, (AsyncTask) asyncTask);
    }

    /* renamed from: a */
    public static void m204a(String str, List<C0049e> list, AsyncTask<?, ?, ?> asyncTask) {
        if (f210b != null && f210b.f211a != null) {
            f210b.f211a.mo38a(str, (List) list, (AsyncTask) asyncTask);
        }
    }

    /* renamed from: a */
    public static boolean m205a(Context context, String str) {
        if (str == null || str.startsWith(C0202q.m727a(context)) || str.startsWith("/uri/")) {
            return false;
        }
        String d = C0202q.m743d(str);
        return d.equals("apk") || d.equals(ZArchiverExtInterface.ARCHIVE_TYPE_ZIP) || d.equals(ZArchiverExtInterface.ARCHIVE_TYPE_7Z) || d.equals(ZArchiverExtInterface.ARCHIVE_TYPE_TAR) || d.equals("jar") || d.equals("wim");
    }

    /* renamed from: a */
    public static boolean m206a(String str) {
        return f210b != null && f210b.f211a != null && f210b.f211a.mo39a(str) && f210b.f211a.mo46g();
    }

    /* renamed from: a */
    public static boolean m207a(String str, boolean z) {
        if (str == null) {
            return false;
        }
        String d = C0061a.m215d(str);
        return d.equals(ZArchiverExtInterface.ARCHIVE_TYPE_ZIP) || d.equals("apk") || d.equals("mtz") || d.equals(ZArchiverExtInterface.ARCHIVE_TYPE_7Z) || d.equals("bz") || d.equals("bz2") || (d.equals("xz") && z);
    }

    /* renamed from: b */
    public static C0059f m208b() {
        return f210b.f211a;
    }

    /* renamed from: b */
    public static C0059f m209b(boolean z) {
        return f210b.m225a(z);
    }

    /* renamed from: b */
    public static void m210b(String str) {
        if (f210b != null && f210b.f211a != null && f210b.f211a.mo39a(str) && f210b.f211a.mo43d() != 2) {
            f210b.f211a.mo33a();
        }
    }

    /* renamed from: b */
    public static boolean m211b(Context context, String str) {
        if (str == null || str.startsWith(C0202q.m727a(context))) {
            return false;
        }
        String d = C0202q.m743d(str);
        return d.equals("apk") || d.equals(ZArchiverExtInterface.ARCHIVE_TYPE_ZIP) || d.equals("mtz") || d.equals(ZArchiverExtInterface.ARCHIVE_TYPE_TAR) || d.equals(ZArchiverExtInterface.ARCHIVE_TYPE_7Z) || d.equals("jar");
    }

    /* renamed from: c */
    public static String m212c() {
        return (f210b == null || f210b.f211a == null) ? null : f210b.f211a.mo45f();
    }

    /* renamed from: c */
    public static boolean m213c(String str) {
        return (f210b == null || f210b.f211a == null) ? false : f210b.f211a.mo39a(str);
    }

    /* renamed from: d */
    public static String m214d() {
        return (f210b == null || f210b.f211a == null) ? null : f210b.f211a.mo40b();
    }

    /* renamed from: d */
    public static String m215d(String str) {
        return f210b != null ? f210b.m224j(str) : C0202q.m743d(str);
    }

    /* renamed from: e */
    public static void m216e() {
        if (f210b != null && f210b.f211a != null) {
            f210b.f211a.mo33a();
        }
    }

    /* renamed from: e */
    public static boolean m217e(String str) {
        return C0061a.m215d(str).equals(ZArchiverExtInterface.ARCHIVE_TYPE_7Z);
    }

    /* renamed from: f */
    public static int m218f() {
        return (f210b == null || f210b.f211a == null) ? 0 : f210b.f211a.mo43d();
    }

    /* renamed from: f */
    public static boolean m219f(String str) {
        return C0061a.m215d(str).equals(ZArchiverExtInterface.ARCHIVE_TYPE_ZIP);
    }

    /* renamed from: g */
    public static float m220g() {
        return (f210b == null || f210b.f211a == null) ? 1.0f : f210b.f211a.mo48i();
    }

    /* renamed from: g */
    public static boolean m221g(String str) {
        String d = C0061a.m215d(str);
        return d.equals("rar") || d.equals("rar5");
    }

    /* renamed from: h */
    public static boolean m222h(String str) {
        String d = C0202q.m743d(str);
        return d.equals("xz") || d.equals("txz");
    }

    /* renamed from: i */
    public static boolean m223i(String str) {
        String d = C0202q.m743d(str);
        return d.equals(ZArchiverExtInterface.ARCHIVE_TYPE_ZIP) || d.equals(ZArchiverExtInterface.ARCHIVE_TYPE_7Z);
    }

    /* renamed from: j */
    private String m224j(String str) {
        String str2 = null;
        if (!(this.f211a == null || str == null || !this.f211a.mo39a(str))) {
            str2 = this.f211a.mo47h();
        }
        return str2 != null ? str2.contains("/") ? str2.substring(1, str2.indexOf(47) - 1).trim().toLowerCase(Locale.ENGLISH) : str2.toLowerCase(Locale.ENGLISH) : C0202q.m743d(str);
    }

    /* renamed from: a */
    public C0059f m225a(boolean z) {
        if (z == (this.f211a instanceof ArchiveContentStoreNative)) {
            this.f211a.mo33a();
        } else if (z) {
            this.f211a = new ArchiveContentStoreNative();
        } else if (VERSION.SDK_INT < 17 || Runtime.getRuntime().availableProcessors() < 2) {
            this.f211a = new C0065c();
        } else {
            this.f211a = new C0062b();
        }
        return this.f211a;
    }

    /* renamed from: a */
    public void m226a() {
        C0061a.m216e();
        f210b = null;
    }
}
