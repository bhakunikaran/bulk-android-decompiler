package ru.zdevs.zarchiver.archiver;

import android.os.AsyncTask;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import ru.zdevs.zarchiver.fs.ZViewFS.FSFileInfo;
import ru.zdevs.zarchiver.p003a.C0049e;
import ru.zdevs.zarchiver.tool.C0166c;
import ru.zdevs.zarchiver.tool.C0202q;

/* renamed from: ru.zdevs.zarchiver.archiver.b */
public class C0062b implements C0059f {
    /* renamed from: a */
    private String f212a;
    /* renamed from: b */
    private long f213b;
    /* renamed from: c */
    private C0066d f214c = new C0066d(null, 0, 0, 1);
    /* renamed from: d */
    private long f215d;
    /* renamed from: e */
    private int f216e;
    /* renamed from: f */
    private String f217f;
    /* renamed from: g */
    private String f218g;
    /* renamed from: h */
    private int f219h;
    /* renamed from: i */
    private C0066d f220i;
    /* renamed from: j */
    private String f221j;
    /* renamed from: k */
    private int f222k;

    public C0062b() {
        mo33a();
    }

    /* renamed from: a */
    private long m227a(C0066d c0066d, AsyncTask<?, ?, ?> asyncTask) {
        if (c0066d == null) {
            return 0;
        }
        long j = 0;
        for (C0066d c0066d2 : c0066d.m282i()) {
            if (asyncTask != null && asyncTask.isCancelled()) {
                return 0;
            }
            j = c0066d2.m280g() ? m227a(c0066d2, (AsyncTask) asyncTask) + j : c0066d2.m278e() + j;
        }
        return j;
    }

    /* renamed from: a */
    private C0066d m228a(String str, int i) {
        if (str == null) {
            return null;
        }
        C0066d c0066d;
        String substring;
        C0066d c0066d2;
        int i2;
        int i3 = (this.f221j == null || !str.startsWith(this.f221j)) ? 0 : 1;
        if (i3 != 0) {
            c0066d = this.f220i;
            substring = str.substring(this.f221j.length());
        } else {
            c0066d = this.f214c;
            substring = str;
        }
        String[] e = C0202q.m744e(substring);
        if (e.length <= 0 || e[0].length() != 0) {
            c0066d2 = c0066d;
            i2 = 0;
        } else {
            c0066d2 = c0066d;
            i2 = 1;
        }
        while (i2 < e.length) {
            C0066d a = c0066d2.m270a(e[i2]);
            if (a == null) {
                break;
            }
            i2++;
            c0066d2 = a;
        }
        if (i2 == e.length) {
            return c0066d2;
        }
        int i4 = i2;
        C0066d c0066d3 = c0066d2;
        while (i4 < e.length) {
            if (i4 + 1 != e.length) {
                c0066d2 = new C0066d(e[i4], 0, 0, i | 1);
            } else {
                if (i3 == 0 || this.f222k != i4) {
                    try {
                        this.f220i = c0066d3;
                        this.f222k = i4;
                        this.f221j = str.substring(0, str.lastIndexOf(47) + 1);
                    } catch (Throwable e2) {
                        this.f221j = null;
                        C0166c.m556a(e2);
                    }
                }
                c0066d2 = new C0066d(e[i4], 0, 0, i);
            }
            c0066d3.m274a(c0066d2);
            i4++;
            c0066d3 = c0066d2;
        }
        return c0066d3;
    }

    /* renamed from: a */
    private void m229a(String str, C0066d c0066d, List<C0066d> list, boolean z, Thread thread) {
        for (C0066d c0066d2 : c0066d.m282i()) {
            if (thread == null || !thread.isInterrupted()) {
                if (z || !c0066d2.m280g()) {
                    String c = c0066d2.m276c();
                    try {
                        c = c.toLowerCase(Locale.getDefault());
                    } catch (Throwable e) {
                        C0166c.m556a(e);
                    }
                    if (c.matches(str)) {
                        list.add(c0066d2);
                    }
                }
                if (c0066d2.m280g()) {
                    m229a(str, c0066d2, list, z, thread);
                }
            } else {
                return;
            }
        }
    }

    /* renamed from: c */
    private C0066d m230c(String str) {
        int i = 0;
        if (str == null) {
            return null;
        }
        C0066d c0066d = this.f214c;
        String[] e = C0202q.m744e(str);
        if (e.length > 0 && e[0].length() == 0) {
            i = 1;
        }
        while (i < e.length) {
            C0066d a = c0066d.m270a(e[i]);
            if (a == null) {
                break;
            }
            i++;
            c0066d = a;
        }
        return i != e.length ? null : c0066d;
    }

    /* renamed from: a */
    public List<C0066d> mo30a(String str, String str2, boolean z, Thread thread) {
        List arrayList = new ArrayList();
        if (str2 != null) {
            C0066d c = m230c(str);
            if (c != null && c.m280g()) {
                m229a(str2, c, arrayList, z, thread);
            }
        }
        return arrayList;
    }

    /* renamed from: a */
    public FSFileInfo mo31a(String str, AsyncTask<?, ?, ?> asyncTask) {
        C0066d c = m230c(str);
        if (c == null) {
            return new FSFileInfo();
        }
        FSFileInfo fSFileInfo = new FSFileInfo();
        fSFileInfo.mIsFile = !c.m280g();
        fSFileInfo.mLastMod = (long) c.m277d();
        if (c.m280g()) {
            fSFileInfo.mSize = 0;
            for (C0066d c0066d : c.m282i()) {
                if (asyncTask != null && asyncTask.isCancelled()) {
                    return null;
                }
                if (c0066d.m280g()) {
                    fSFileInfo.mSize += m227a(c0066d, (AsyncTask) asyncTask);
                } else {
                    fSFileInfo.mSize += c0066d.m278e();
                }
            }
        } else {
            fSFileInfo.mSize = c.m278e();
        }
        return fSFileInfo;
    }

    /* renamed from: a */
    public FSFileInfo mo32a(List<String> list, AsyncTask<?, ?, ?> asyncTask) {
        FSFileInfo fSFileInfo = new FSFileInfo();
        for (String str : list) {
            if (asyncTask != null && asyncTask.isCancelled()) {
                return null;
            }
            FSFileInfo a = mo31a(str, (AsyncTask) asyncTask);
            if (a != null) {
                fSFileInfo.mSize += a.mSize;
            }
        }
        return fSFileInfo;
    }

    /* renamed from: a */
    public void mo33a() {
        this.f212a = "";
        this.f213b = 0;
        this.f214c = new C0066d(null, 0, 0, 1);
        this.f215d = 0;
        this.f216e = 0;
        this.f217f = "";
        this.f218g = null;
        this.f219h = 0;
        this.f220i = null;
        this.f221j = null;
        this.f222k = 0;
    }

    /* renamed from: a */
    public void mo34a(int i) {
        this.f219h = i;
    }

    /* renamed from: a */
    public void mo35a(File file) {
        mo33a();
        this.f212a = file.getAbsolutePath();
        this.f213b = file.length();
        C0166c.m557b("ArchiveContentStore", "Start list: " + this.f212a);
    }

    /* renamed from: a */
    public void mo36a(String str, int i, long j) {
        this.f218g = str;
        this.f215d = j;
        this.f216e = i;
    }

    /* renamed from: a */
    public void mo37a(String str, long j, int i, int i2) {
        if (str != null) {
            C0066d a = m228a(str, i2);
            if (a != null) {
                a.m272a(i);
                a.m273a(j);
                if ((i2 & 1) == 0) {
                    this.f215d = a.m278e() + this.f215d;
                    this.f216e++;
                }
            }
        }
    }

    /* renamed from: a */
    public void mo38a(String str, List<C0049e> list, AsyncTask<?, ?, ?> asyncTask) {
        C0066d c = m230c(str);
        if (c != null && c.m280g()) {
            for (C0066d c0066d : c.m282i()) {
                list.add(new C0049e(c0066d.m276c(), c0066d.m280g() ? (byte) 2 : (byte) 0, c0066d.m279f() ? (byte) 30 : (byte) 0, (long) c0066d.m277d(), c0066d.m278e()));
            }
        }
    }

    /* renamed from: a */
    public boolean mo39a(String str) {
        if (this.f212a == null || str == null) {
            return false;
        }
        C0166c.m557b("ArchiveContentStore", "Compare: " + this.f212a + " and " + str);
        return this.f212a.endsWith(str);
    }

    /* renamed from: b */
    public String mo40b() {
        return this.f212a;
    }

    /* renamed from: b */
    public void mo41b(String str) {
        this.f217f = str;
    }

    /* renamed from: c */
    public void mo42c() {
        C0166c.m557b("ArchiveContentStore", "Stop list: " + this.f212a);
    }

    /* renamed from: d */
    public int mo43d() {
        return this.f219h;
    }

    /* renamed from: e */
    public int mo44e() {
        return this.f216e;
    }

    /* renamed from: f */
    public String mo45f() {
        return this.f217f == null ? "" : this.f217f;
    }

    /* renamed from: g */
    public boolean mo46g() {
        return this.f217f != null && this.f217f.length() > 0;
    }

    /* renamed from: h */
    public String mo47h() {
        return this.f218g;
    }

    /* renamed from: i */
    public float mo48i() {
        return (this.f212a == null || this.f212a.length() <= 0) ? -1.0f : this.f215d == 0 ? 1.0f : ((float) this.f213b) / ((float) this.f215d);
    }
}
