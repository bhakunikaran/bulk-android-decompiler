package ru.zdevs.zarchiver.archiver;

import android.os.AsyncTask;
import java.io.File;
import java.util.List;
import ru.zdevs.zarchiver.fs.ZViewFS.FSFileInfo;
import ru.zdevs.zarchiver.p003a.C0049e;
import ru.zdevs.zarchiver.tool.C0166c;

public class ArchiveContentStoreNative implements C0059f {
    /* renamed from: c */
    private static List<C0049e> f181c;
    /* renamed from: d */
    private static FSFileInfo f182d;
    /* renamed from: a */
    private String f183a;
    /* renamed from: b */
    private long f184b;
    /* renamed from: e */
    private long f185e;
    /* renamed from: f */
    private int f186f;
    /* renamed from: g */
    private String f187g;
    /* renamed from: h */
    private String f188h;
    /* renamed from: i */
    private int f189i;

    public ArchiveContentStoreNative() {
        mo33a();
    }

    public static native void cClear();

    public static native void cGetFileInfo(String str);

    public static native void cGetFileList(String str);

    public static native boolean cIsArchive(String str);

    public static native void cStartList(String str);

    public static void jAdd(String str, long j, int i, int i2) {
        byte b = (byte) 0;
        List list = f181c;
        byte b2 = (i2 & 1) != 0 ? (byte) 2 : (byte) 0;
        if ((i2 & 2) != 0) {
            b = (byte) 30;
        }
        list.add(new C0049e(str, b2, b, (long) (i * 1000), (i2 & 4) != 0 ? -2 : j));
    }

    public static void jSetFileInfo(long j, int i, int i2, int i3) {
        boolean z = true;
        if (f182d != null) {
            f182d.mSize = j;
            f182d.mFileCount = i;
            f182d.mLastMod = ((long) i2) * 1000;
            f182d.mIsFile = (i3 & 1) == 0;
            FSFileInfo fSFileInfo = f182d;
            if ((i3 & 4) == 0) {
                z = false;
            }
            fSFileInfo.mIsLink = z;
        }
    }

    /* renamed from: a */
    public List<C0066d> mo30a(String str, String str2, boolean z, Thread thread) {
        return null;
    }

    /* renamed from: a */
    public FSFileInfo mo31a(String str, AsyncTask<?, ?, ?> asyncTask) {
        FSFileInfo fSFileInfo = new FSFileInfo();
        f182d = fSFileInfo;
        cGetFileInfo(str);
        f182d = null;
        return fSFileInfo;
    }

    /* renamed from: a */
    public FSFileInfo mo32a(List<String> list, AsyncTask<?, ?, ?> asyncTask) {
        FSFileInfo fSFileInfo = new FSFileInfo();
        for (String str : list) {
            if (asyncTask != null && asyncTask.isCancelled()) {
                return null;
            }
            FSFileInfo a = mo31a(str, (AsyncTask) asyncTask);
            if (a != null) {
                fSFileInfo.mSize += a.mSize;
            }
        }
        return fSFileInfo;
    }

    /* renamed from: a */
    public void mo33a() {
        this.f183a = "";
        this.f184b = 0;
        f181c = null;
        this.f185e = 0;
        this.f186f = 0;
        this.f187g = "";
        this.f188h = null;
        this.f189i = 0;
        cClear();
    }

    /* renamed from: a */
    public void mo34a(int i) {
        this.f189i = i;
    }

    /* renamed from: a */
    public void mo35a(File file) {
        mo33a();
        this.f183a = file.getAbsolutePath();
        this.f184b = file.length();
        cStartList(this.f183a);
        C0166c.m557b("ArchiveContentStore", "Start list: " + this.f183a);
    }

    /* renamed from: a */
    public void mo36a(String str, int i, long j) {
        this.f188h = str;
        this.f186f = i;
        this.f185e = j;
    }

    /* renamed from: a */
    public void mo37a(String str, long j, int i, int i2) {
    }

    /* renamed from: a */
    public void mo38a(String str, List<C0049e> list, AsyncTask<?, ?, ?> asyncTask) {
        f181c = list;
        cGetFileList(str);
        f181c = null;
    }

    /* renamed from: a */
    public boolean mo39a(String str) {
        if (this.f183a == null || str == null) {
            return false;
        }
        C0166c.m557b("ArchiveContentStore", "Compare: " + this.f183a + " and " + str);
        return this.f183a.endsWith(str) && cIsArchive(this.f183a);
    }

    /* renamed from: b */
    public String mo40b() {
        return this.f183a;
    }

    /* renamed from: b */
    public void mo41b(String str) {
        this.f187g = str;
    }

    /* renamed from: c */
    public void mo42c() {
        C0166c.m557b("ArchiveContentStore", "Stop list: " + this.f183a);
    }

    /* renamed from: d */
    public int mo43d() {
        return this.f189i;
    }

    /* renamed from: e */
    public int mo44e() {
        return this.f186f;
    }

    /* renamed from: f */
    public String mo45f() {
        return this.f187g == null ? "" : this.f187g;
    }

    /* renamed from: g */
    public boolean mo46g() {
        return this.f187g != null && this.f187g.length() > 0;
    }

    /* renamed from: h */
    public String mo47h() {
        return this.f188h;
    }

    /* renamed from: i */
    public float mo48i() {
        return (this.f183a == null || this.f183a.length() <= 0) ? -1.0f : this.f185e == 0 ? 1.0f : ((float) this.f184b) / ((float) this.f185e);
    }
}
