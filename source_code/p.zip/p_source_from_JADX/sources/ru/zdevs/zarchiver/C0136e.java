package ru.zdevs.zarchiver;

import android.content.Context;
import java.util.ArrayList;
import java.util.List;
import ru.zdevs.zarchiver.dialog.ZDialog;
import ru.zdevs.zarchiver.fs.FileArchive;
import ru.zdevs.zarchiver.fs.FileLocal;
import ru.zdevs.zarchiver.fs.FileStorage;
import ru.zdevs.zarchiver.fs.MyUri;
import ru.zdevs.zarchiver.fs.ZOpenFile;
import ru.zdevs.zarchiver.p003a.C0049e;
import ru.zdevs.zarchiver.p003a.C0052g;
import ru.zdevs.zarchiver.settings.Settings;
import ru.zdevs.zarchiver.tool.C0166c;
import ru.zdevs.zarchiver.tool.C0199n;
import ru.zdevs.zarchiver.tool.C0200o;

/* renamed from: ru.zdevs.zarchiver.e */
public class C0136e {
    /* renamed from: a */
    public Actions f350a = new Actions(this);
    /* renamed from: b */
    public List<C0049e> f351b = new ArrayList();
    /* renamed from: c */
    public int f352c = 0;
    /* renamed from: d */
    public byte f353d = (byte) 0;
    /* renamed from: e */
    public final List<C0052g> f354e = new ArrayList();
    /* renamed from: f */
    public String f355f = "";
    /* renamed from: g */
    public boolean f356g = false;
    /* renamed from: h */
    public final List<ZOpenFile> f357h = new ArrayList();
    /* renamed from: i */
    public final List<ZDialog> f358i;
    /* renamed from: j */
    private char f359j = '\u0000';
    /* renamed from: k */
    private MyUri f360k = new MyUri(Settings.sHomeDir);
    /* renamed from: l */
    private MyUri f361l = null;
    /* renamed from: m */
    private final List<C0135a> f362m;

    /* renamed from: ru.zdevs.zarchiver.e$a */
    public static class C0135a implements Comparable<C0135a> {
        /* renamed from: a */
        public MyUri f345a;
        /* renamed from: b */
        public char f346b;
        /* renamed from: c */
        public int f347c;
        /* renamed from: d */
        public boolean f348d;
        /* renamed from: e */
        public int f349e;

        public C0135a(MyUri myUri, char c, int i, boolean z, int i2) {
            this.f345a = myUri;
            this.f346b = c;
            this.f347c = i;
            this.f348d = z;
            this.f349e = i2;
        }

        /* renamed from: a */
        public int m396a(C0135a c0135a) {
            int i = -1;
            if (c0135a == null) {
                return 1;
            }
            if (this.f348d || c0135a.f348d) {
                return this.f348d == c0135a.f348d ? 0 : !this.f348d ? -1 : 1;
            } else {
                if (this.f346b == c0135a.f346b) {
                    return this.f345a.compareTo(c0135a.f345a);
                }
                int compareTo = this.f345a.compareTo(c0135a.f345a);
                if (compareTo != 0) {
                    return compareTo;
                }
                if (this.f346b <= c0135a.f346b) {
                    i = 1;
                }
                return i;
            }
        }

        public /* synthetic */ int compareTo(Object obj) {
            return m396a((C0135a) obj);
        }

        public String toString() {
            return "Path: " + this.f345a.toString() + " Pos: " + this.f347c + " Action: " + String.format("0x%x", new Object[]{Integer.valueOf(this.f346b)});
        }
    }

    public C0136e() {
        this.f357h.add(new FileLocal(this));
        this.f357h.add(new FileStorage(this));
        this.f357h.add(new FileArchive(this));
        this.f358i = new ArrayList();
        this.f362m = new ArrayList();
        this.f362m.clear();
    }

    /* renamed from: a */
    public byte m397a(Context context) {
        if (this.f353d == (byte) 0) {
            this.f353d = C0200o.m709a(context, this.f360k);
        }
        return this.f353d;
    }

    /* renamed from: a */
    public ZDialog m398a(int i, int i2) {
        return m405b(i, i2, -1);
    }

    /* renamed from: a */
    public void m399a(char c) {
        this.f359j = c;
    }

    /* renamed from: a */
    public void m400a(char c, int i) {
        if (Settings.sBackType != (byte) 1) {
            C0135a c0135a = new C0135a(this.f360k, c, i, this.f356g, this.f352c);
            C0135a c0135a2 = null;
            if (this.f362m.size() > 0) {
                c0135a2 = (C0135a) this.f362m.get(this.f362m.size() - 1);
            }
            if (c0135a.m396a(c0135a2) != 0) {
                this.f362m.add(c0135a);
            }
        }
    }

    /* renamed from: a */
    public void m401a(int i) {
        if (Settings.sBackType != (byte) 1) {
            m400a(this.f359j, i);
        }
    }

    /* renamed from: a */
    public void m402a(int i, int i2, int i3) {
        if (this.f358i != null) {
            List<ZDialog> arrayList = new ArrayList();
            synchronized (this.f358i) {
                arrayList.addAll(this.f358i);
            }
            for (ZDialog zDialog : arrayList) {
                if ((i == -1 || zDialog.getTaskID() == i) && ((i2 == -1 || zDialog.getType() == i2) && (i3 == -1 || zDialog.getSubType() == i3))) {
                    try {
                        zDialog.close();
                    } catch (Throwable e) {
                        C0166c.m556a(e);
                    }
                }
            }
        }
    }

    /* renamed from: a */
    public void m403a(MyUri myUri) {
        this.f360k = myUri;
        this.f352c = 0;
        this.f353d = (byte) 0;
    }

    /* renamed from: a */
    public boolean m404a() {
        return this.f360k.isLocalFS();
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    /* renamed from: b */
    public ru.zdevs.zarchiver.dialog.ZDialog m405b(int r7, int r8, int r9) {
        /*
        r6 = this;
        r1 = 0;
        r5 = -1;
        r0 = r6.f358i;
        if (r0 != 0) goto L_0x0008;
    L_0x0006:
        r0 = r1;
    L_0x0007:
        return r0;
    L_0x0008:
        r2 = r6.f358i;
        monitor-enter(r2);
        r0 = r6.f358i;	 Catch:{ all -> 0x0037 }
        r3 = r0.iterator();	 Catch:{ all -> 0x0037 }
    L_0x0011:
        r0 = r3.hasNext();	 Catch:{ all -> 0x0037 }
        if (r0 == 0) goto L_0x003a;
    L_0x0017:
        r0 = r3.next();	 Catch:{ all -> 0x0037 }
        r0 = (ru.zdevs.zarchiver.dialog.ZDialog) r0;	 Catch:{ all -> 0x0037 }
        if (r7 == r5) goto L_0x0025;
    L_0x001f:
        r4 = r0.getTaskID();	 Catch:{ all -> 0x0037 }
        if (r4 != r7) goto L_0x0011;
    L_0x0025:
        if (r8 == r5) goto L_0x002d;
    L_0x0027:
        r4 = r0.getType();	 Catch:{ all -> 0x0037 }
        if (r4 != r8) goto L_0x0011;
    L_0x002d:
        if (r9 == r5) goto L_0x0035;
    L_0x002f:
        r4 = r0.getSubType();	 Catch:{ all -> 0x0037 }
        if (r4 != r9) goto L_0x0011;
    L_0x0035:
        monitor-exit(r2);	 Catch:{ all -> 0x0037 }
        goto L_0x0007;
    L_0x0037:
        r0 = move-exception;
        monitor-exit(r2);	 Catch:{ all -> 0x0037 }
        throw r0;
    L_0x003a:
        monitor-exit(r2);	 Catch:{ all -> 0x0037 }
        r0 = r1;
        goto L_0x0007;
        */
        throw new UnsupportedOperationException("Method not decompiled: ru.zdevs.zarchiver.e.b(int, int, int):ru.zdevs.zarchiver.dialog.ZDialog");
    }

    /* renamed from: b */
    public boolean m406b() {
        return this.f360k.isStorage();
    }

    /* renamed from: c */
    public boolean m407c() {
        return this.f360k.isRoot();
    }

    /* renamed from: d */
    public boolean m408d() {
        return this.f360k.isArchive();
    }

    /* renamed from: e */
    public boolean m409e() {
        return this.f360k.isExternal();
    }

    /* renamed from: f */
    public byte m410f() {
        return C0200o.m711a(this.f360k.toLocalPath());
    }

    /* renamed from: g */
    public final MyUri m411g() {
        return this.f360k;
    }

    /* renamed from: h */
    public final String m412h() {
        return this.f360k.toLocalPath();
    }

    /* renamed from: i */
    public void m413i() {
        this.f353d = (byte) 0;
    }

    /* renamed from: j */
    public char m414j() {
        return this.f359j;
    }

    /* renamed from: k */
    public char m415k() {
        return (char) (this.f359j & 7);
    }

    /* renamed from: l */
    public boolean m416l() {
        if (Settings.sBackType != (byte) 1) {
            return this.f362m == null || this.f362m.size() <= 0;
        } else {
            if (this.f360k == null || this.f360k.isArchive()) {
                return false;
            }
            if (this.f361l != null && this.f361l.equals(this.f360k)) {
                return true;
            }
            String path = this.f360k.getPath();
            return path != null ? (path.equals("/") && this.f360k.isLocalFS()) ? true : C0199n.m690a(path) != null : false;
        }
    }

    /* renamed from: m */
    public void m417m() {
        if (Settings.sBackType == (byte) 1) {
            this.f361l = new MyUri(this.f360k);
        } else {
            this.f362m.clear();
        }
    }

    /* renamed from: n */
    public void m418n() {
        if (this.f362m.size() > 0) {
            C0135a c0135a = (C0135a) this.f362m.get(this.f362m.size() - 1);
            while (c0135a != null && c0135a.f345a.compareTo(this.f360k) != 0 && c0135a.f348d == this.f356g && c0135a.f346b == this.f359j) {
                this.f362m.remove(this.f362m.size() - 1);
                C0166c.m559d("Session", "History clearing... Size: " + this.f362m.size());
                if (this.f362m.size() <= 0) {
                    break;
                }
                c0135a = (C0135a) this.f362m.get(this.f362m.size() - 1);
            }
            if (c0135a != null) {
                char c;
                if (!c0135a.f348d || this.f356g) {
                    c = '\u0000';
                } else {
                    this.f362m.clear();
                    c = '\u0001';
                }
                if (c0135a.f346b != '\u0000' && this.f359j == '\u0000') {
                    this.f362m.clear();
                    c = '\u0001';
                }
                if (c != '\u0000') {
                    MyUri myUri = new MyUri(Settings.sHomeDir);
                    MyUri myUri2 = new MyUri(this.f360k);
                    while (myUri2.toString().startsWith(myUri.toString())) {
                        this.f362m.add(0, new C0135a(new MyUri(myUri2), '\u0000', 0, false, 0));
                        if (!myUri2.del()) {
                            return;
                        }
                    }
                }
            }
        }
    }

    /* renamed from: o */
    public C0135a m419o() {
        if (this.f362m.size() <= 0) {
            return null;
        }
        C0135a c0135a = (C0135a) this.f362m.get(this.f362m.size() - 1);
        this.f362m.remove(this.f362m.size() - 1);
        return c0135a;
    }

    /* renamed from: p */
    public void m420p() {
        if (this.f358i != null) {
            List<ZDialog> arrayList = new ArrayList();
            synchronized (this.f358i) {
                arrayList.addAll(this.f358i);
            }
            for (ZDialog close : arrayList) {
                try {
                    close.close();
                } catch (Throwable e) {
                    C0166c.m556a(e);
                }
            }
        }
    }
}
