package ru.zdevs.zarchiver.p004b;

/* renamed from: ru.zdevs.zarchiver.b.g */
public class C0079g {
    /* renamed from: a */
    public static boolean m337a(C0073a c0073a, boolean z, String str, String str2) {
        if (str == null || str2 == null) {
            return false;
        }
        StringBuilder stringBuilder = new StringBuilder();
        if (z) {
            stringBuilder.append("mv -f '");
        } else {
            stringBuilder.append("cp -f '");
        }
        stringBuilder.append(str);
        stringBuilder.append("' '");
        stringBuilder.append(str2);
        stringBuilder.append("'");
        if (!c0073a.m309a(stringBuilder.toString())) {
            return false;
        }
        c0073a.mo50a(false);
        return c0073a.mo49a() == 0;
    }
}
