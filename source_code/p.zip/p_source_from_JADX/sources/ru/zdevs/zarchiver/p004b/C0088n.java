package ru.zdevs.zarchiver.p004b;

/* renamed from: ru.zdevs.zarchiver.b.n */
public class C0088n extends C0078f {
    /* renamed from: a */
    public static boolean m354a(C0073a c0073a, String str, boolean z) {
        if (str == null) {
            return false;
        }
        if (!C0078f.m336b()) {
            return C0087m.m353a(c0073a, str, z);
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(C0078f.m334a());
        stringBuilder.append(" rm ");
        if (z) {
            stringBuilder.append("-r ");
        }
        stringBuilder.append("-f '");
        stringBuilder.append(str);
        stringBuilder.append('\'');
        if (!c0073a.m309a(stringBuilder.toString())) {
            return false;
        }
        c0073a.mo50a(false);
        return c0073a.mo49a() == 0;
    }
}
