package ru.zdevs.zarchiver.p004b;

/* renamed from: ru.zdevs.zarchiver.b.e */
public class C0077e {
    /* renamed from: a */
    public static boolean m332a(C0073a c0073a, String str, String str2, String str3) {
        if (str == null) {
            return false;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("chown ");
        stringBuilder.append(str2);
        if (str3 != null) {
            stringBuilder.append(".");
            stringBuilder.append(str3);
        }
        stringBuilder.append(" '");
        stringBuilder.append(str);
        stringBuilder.append('\'');
        if (!c0073a.m309a(stringBuilder.toString())) {
            return false;
        }
        c0073a.mo50a(false);
        return c0073a.mo49a() == 0;
    }
}
