package ru.zdevs.zarchiver.p004b;

import android.os.Build.VERSION;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;
import ru.zdevs.zarchiver.tool.C0166c;
import ru.zdevs.zarchiver.tool.C0202q;

/* renamed from: ru.zdevs.zarchiver.b.i */
public class C0082i {

    /* renamed from: ru.zdevs.zarchiver.b.i$a */
    public static class C0081a {
        /* renamed from: a */
        public String f271a;
        /* renamed from: b */
        public long f272b;
        /* renamed from: c */
        public long f273c;
        /* renamed from: d */
        public int f274d;
        /* renamed from: e */
        public String f275e;
        /* renamed from: f */
        public String f276f;
        /* renamed from: g */
        public boolean f277g;
        /* renamed from: h */
        public boolean f278h;
        /* renamed from: i */
        public String f279i;
    }

    /* renamed from: a */
    static int m340a(String str) {
        int i = 4;
        try {
            int i2 = str.charAt(1) == 'r' ? 4 : 0;
            if (str.charAt(2) == 'w') {
                i2 += 2;
            }
            if (str.charAt(3) == 'x') {
                i2++;
            }
            int i3 = 0 + (i2 * 100);
            i2 = str.charAt(4) == 'r' ? 4 : 0;
            if (str.charAt(5) == 'w') {
                i2 += 2;
            }
            if (str.charAt(6) == 'x') {
                i2++;
            }
            i2 = (i2 * 10) + i3;
            if (str.charAt(7) != 'r') {
                i = 0;
            }
            if (str.charAt(8) == 'w') {
                i += 2;
            }
            if (str.charAt(9) == 'x') {
                i++;
            }
            return i + i2;
        } catch (Throwable e) {
            C0166c.m556a(e);
            return -1;
        }
    }

    /* renamed from: a */
    public static boolean m341a(C0073a c0073a, List<C0081a> list, String str, boolean z, boolean z2) {
        if (list == null || str == null) {
            return false;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("ls -l");
        if (z2) {
            stringBuilder.append(" -d");
        }
        if (z) {
            stringBuilder.append(" -a");
        }
        stringBuilder.append(" '");
        stringBuilder.append(str);
        stringBuilder.append("'");
        if (!c0073a.m309a(stringBuilder.toString())) {
            return false;
        }
        int i;
        Object obj;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);
        if (VERSION.SDK_INT < 24) {
            i = 1;
            obj = null;
        } else {
            i = 2;
            obj = 1;
        }
        while (true) {
            String a = c0073a.mo50a(true);
            if (a == null) {
                break;
            }
            try {
                String[] a2 = C0202q.m734a(a, ' ');
                if (a2.length >= 6 && a2[0] != null && a2[0].length() >= 10) {
                    C0081a c0081a = new C0081a();
                    c0081a.f277g = a2[0].charAt(0) == 'd';
                    c0081a.f278h = a2[0].charAt(0) == 'l';
                    c0081a.f274d = C0082i.m340a(a2[0]);
                    int i2 = i + 1;
                    c0081a.f275e = a2[i];
                    int i3 = i2 + 1;
                    c0081a.f276f = a2[i2];
                    if (c0081a.f277g || c0081a.f278h) {
                        c0081a.f272b = 0;
                        if (obj != null) {
                            i3++;
                        }
                    } else {
                        i2 = i3 + 1;
                        c0081a.f272b = C0078f.m335b(a2[i3]);
                        i3 = i2;
                    }
                    c0081a.f273c = 0;
                    try {
                        c0081a.f273c = simpleDateFormat.parse(a2[i3] + " " + a2[i3 + 1]).getTime();
                    } catch (Throwable e) {
                        C0166c.m556a(e);
                    }
                    i2 = i3 + 2;
                    c0081a.f271a = null;
                    c0081a.f279i = null;
                    while (i2 < a2.length) {
                        if (c0081a.f278h) {
                            if (c0081a.f279i != null) {
                                c0081a.f279i += " " + a2[i2];
                            } else if (a2[i2].equals("->")) {
                                c0081a.f279i = a2[i2 + 1];
                                i2++;
                            }
                            i2++;
                        }
                        if (c0081a.f271a != null) {
                            c0081a.f271a += " " + a2[i2];
                        } else {
                            c0081a.f271a = a2[i2];
                        }
                        i2++;
                    }
                    if (c0081a.f271a != null) {
                        if (c0081a.f278h && c0081a.f279i != null) {
                            c0081a.f277g = new File(c0081a.f279i).isDirectory();
                        }
                        list.add(c0081a);
                    }
                }
            } catch (Throwable e2) {
                C0166c.m556a(e2);
            }
        }
        return c0073a.mo49a() == 0;
    }
}
