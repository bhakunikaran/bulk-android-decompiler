package ru.zdevs.zarchiver.tool;

import android.os.Process;
import android.text.TextUtils;
import java.io.File;

/* renamed from: ru.zdevs.zarchiver.tool.e */
public class C0168e {
    /* renamed from: a */
    private static final String f461a = System.getenv("EMULATED_STORAGE_SOURCE");
    /* renamed from: b */
    private static final String f462b = System.getenv("EMULATED_STORAGE_TARGET");
    /* renamed from: c */
    private static final String f463c = System.getenv("EXTERNAL_STORAGE");
    /* renamed from: d */
    private static String f464d = null;

    /* renamed from: a */
    public static File m570a(File file) {
        return new File(C0168e.m572b(file.getAbsolutePath()));
    }

    /* renamed from: a */
    public static String m571a(String str) {
        if (TextUtils.isEmpty(f461a) || TextUtils.isEmpty(f462b) || TextUtils.isEmpty(f463c)) {
            return str;
        }
        if (str.startsWith(f461a)) {
            str = str.replace(f461a, f462b);
        }
        if (!str.startsWith(f463c)) {
            return str;
        }
        return str.replace(f463c, new File(f462b, String.valueOf(Process.myUid() / 100000)).getAbsolutePath());
    }

    /* renamed from: b */
    public static String m572b(String str) {
        if (TextUtils.isEmpty(f461a) || TextUtils.isEmpty(f462b) || TextUtils.isEmpty(f463c)) {
            return str;
        }
        if (str.startsWith(f461a)) {
            str = str.replace(f461a, f462b);
        }
        if (f464d == null) {
            f464d = new File(f462b, String.valueOf(Process.myUid() / 100000)).getAbsolutePath();
        }
        return str.startsWith(f464d) ? str.replace(f464d, f463c) : str;
    }

    /* renamed from: c */
    public static String m573c(String str) {
        if (TextUtils.isEmpty(f461a) || TextUtils.isEmpty(f462b) || TextUtils.isEmpty(f463c)) {
            return str;
        }
        if (str.startsWith(f462b)) {
            str = str.replace(f462b, f461a);
        }
        if (f464d == null) {
            f464d = new File(f462b, String.valueOf(Process.myUid() / 100000)).getAbsolutePath();
        }
        return str.startsWith(f464d) ? str.replace(f464d, f461a) : str;
    }
}
