package ru.zdevs.zarchiver.tool;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;

/* renamed from: ru.zdevs.zarchiver.tool.r */
public class C0203r {
    /* renamed from: a */
    public static int m745a(Context context) {
        int identifier = Resources.getSystem().getIdentifier("max_action_buttons", "integer", "android");
        if (identifier != 0) {
            return context.getResources().getInteger(identifier);
        }
        Configuration configuration = context.getResources().getConfiguration();
        int i = configuration.screenWidthDp;
        int i2 = configuration.screenHeightDp;
        return (configuration.smallestScreenWidthDp > 600 || ((i > 960 && i2 > 720) || (i > 720 && i2 > 960))) ? 5 : (i >= 500 || ((i > 640 && i2 > 480) || (i > 480 && i2 > 640))) ? 4 : i >= 360 ? 3 : 2;
    }
}
