package ru.zdevs.zarchiver.tool;

import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.media.MediaScannerConnection;
import android.media.MediaScannerConnection.MediaScannerConnectionClient;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore.Files;
import java.util.ArrayList;
import java.util.List;

/* renamed from: ru.zdevs.zarchiver.tool.i */
public class C0182i {
    /* renamed from: a */
    public static C0180a f513a = null;
    /* renamed from: b */
    private static ContentResolver f514b = null;

    /* renamed from: ru.zdevs.zarchiver.tool.i$a */
    static class C0180a implements MediaScannerConnectionClient {
        /* renamed from: a */
        C0181b f507a = null;
        /* renamed from: b */
        Context f508b;
        /* renamed from: c */
        MediaScannerConnection f509c = null;
        /* renamed from: d */
        private final List<String> f510d = new ArrayList();
        /* renamed from: e */
        private boolean f511e = false;
        /* renamed from: f */
        private boolean f512f = false;

        C0180a(Context context, String str, boolean z) {
            this.f508b = context;
            if (str != null) {
                this.f510d.add(str);
            }
            this.f511e = z;
        }

        /* JADX WARNING: inconsistent code. */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        /* renamed from: a */
        void m626a() {
            /*
            r4 = this;
            r2 = 1;
            r1 = r4.f510d;
            monitor-enter(r1);
            r0 = r4.f509c;	 Catch:{ all -> 0x001b }
            if (r0 != 0) goto L_0x000a;
        L_0x0008:
            monitor-exit(r1);	 Catch:{ all -> 0x001b }
        L_0x0009:
            return;
        L_0x000a:
            r0 = r4.f510d;	 Catch:{ all -> 0x001b }
            r0 = r0.size();	 Catch:{ all -> 0x001b }
            if (r0 >= r2) goto L_0x004b;
        L_0x0012:
            r0 = r4.f511e;	 Catch:{ all -> 0x001b }
            if (r0 == 0) goto L_0x001e;
        L_0x0016:
            r0 = 1;
            r4.f512f = r0;	 Catch:{ all -> 0x001b }
        L_0x0019:
            monitor-exit(r1);	 Catch:{ all -> 0x001b }
            goto L_0x0009;
        L_0x001b:
            r0 = move-exception;
            monitor-exit(r1);	 Catch:{ all -> 0x001b }
            throw r0;
        L_0x001e:
            r0 = r4.f507a;	 Catch:{ all -> 0x001b }
            if (r0 == 0) goto L_0x0027;
        L_0x0022:
            r0 = r4.f507a;	 Catch:{ all -> 0x001b }
            r0.m629a();	 Catch:{ all -> 0x001b }
        L_0x0027:
            r0 = r4.f509c;	 Catch:{ all -> 0x001b }
            r0.disconnect();	 Catch:{ all -> 0x001b }
            r0 = 0;
            r4.f509c = r0;	 Catch:{ all -> 0x001b }
            r0 = r4.f508b;	 Catch:{ all -> 0x001b }
            if (r0 == 0) goto L_0x0040;
        L_0x0033:
            r0 = r4.f508b;	 Catch:{ all -> 0x001b }
            r0 = r0 instanceof ru.zdevs.zarchiver.service.ZArchiverService;	 Catch:{ all -> 0x001b }
            if (r0 == 0) goto L_0x0040;
        L_0x0039:
            r0 = r4.f508b;	 Catch:{ all -> 0x001b }
            r0 = (ru.zdevs.zarchiver.service.ZArchiverService) r0;	 Catch:{ all -> 0x001b }
            r0.m452a();	 Catch:{ all -> 0x001b }
        L_0x0040:
            r0 = 0;
            r4.f508b = r0;	 Catch:{ all -> 0x001b }
            r0 = ru.zdevs.zarchiver.tool.C0182i.f513a;	 Catch:{ all -> 0x001b }
            if (r0 != r4) goto L_0x0019;
        L_0x0047:
            r0 = 0;
            ru.zdevs.zarchiver.tool.C0182i.f513a = r0;	 Catch:{ all -> 0x001b }
            goto L_0x0019;
        L_0x004b:
            r2 = r4.f509c;	 Catch:{ all -> 0x001b }
            r0 = r4.f510d;	 Catch:{ all -> 0x001b }
            r3 = 0;
            r0 = r0.get(r3);	 Catch:{ all -> 0x001b }
            r0 = (java.lang.String) r0;	 Catch:{ all -> 0x001b }
            r0 = ru.zdevs.zarchiver.tool.C0168e.m571a(r0);	 Catch:{ all -> 0x001b }
            r3 = 0;
            r2.scanFile(r0, r3);	 Catch:{ all -> 0x001b }
            r0 = r4.f510d;	 Catch:{ all -> 0x001b }
            r2 = 0;
            r0.remove(r2);	 Catch:{ all -> 0x001b }
            monitor-exit(r1);	 Catch:{ all -> 0x001b }
            goto L_0x0009;
            */
            throw new UnsupportedOperationException("Method not decompiled: ru.zdevs.zarchiver.tool.i.a.a():void");
        }

        /* JADX WARNING: inconsistent code. */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        /* renamed from: a */
        boolean m627a(java.lang.String r5) {
            /*
            r4 = this;
            r1 = 1;
            r0 = 0;
            if (r5 != 0) goto L_0x0005;
        L_0x0004:
            return r0;
        L_0x0005:
            r2 = r4.f510d;
            monitor-enter(r2);
            r3 = r4.f510d;	 Catch:{ all -> 0x0016 }
            r3 = r3.size();	 Catch:{ all -> 0x0016 }
            if (r3 >= r1) goto L_0x0019;
        L_0x0010:
            r3 = r4.f512f;	 Catch:{ all -> 0x0016 }
            if (r3 != 0) goto L_0x0019;
        L_0x0014:
            monitor-exit(r2);	 Catch:{ all -> 0x0016 }
            goto L_0x0004;
        L_0x0016:
            r0 = move-exception;
            monitor-exit(r2);	 Catch:{ all -> 0x0016 }
            throw r0;
        L_0x0019:
            r3 = r4.f510d;	 Catch:{ all -> 0x0016 }
            r3.add(r5);	 Catch:{ all -> 0x0016 }
            monitor-exit(r2);	 Catch:{ all -> 0x0016 }
            r2 = r4.f512f;
            if (r2 == 0) goto L_0x0028;
        L_0x0023:
            r4.f512f = r0;
            r4.m626a();
        L_0x0028:
            r0 = r1;
            goto L_0x0004;
            */
            throw new UnsupportedOperationException("Method not decompiled: ru.zdevs.zarchiver.tool.i.a.a(java.lang.String):boolean");
        }

        /* renamed from: b */
        public void m628b() {
            synchronized (this.f510d) {
                this.f508b = null;
                if (!this.f511e || (this.f512f && this.f510d.size() < 1)) {
                    this.f510d.clear();
                    if (this.f509c != null) {
                        this.f509c.disconnect();
                        this.f509c = null;
                    }
                }
                this.f511e = false;
                this.f512f = false;
            }
        }

        public void onMediaScannerConnected() {
            m626a();
        }

        public void onScanCompleted(String str, Uri uri) {
            m626a();
        }
    }

    /* renamed from: ru.zdevs.zarchiver.tool.i$b */
    public interface C0181b {
        /* renamed from: a */
        void m629a();
    }

    /* renamed from: a */
    public static void m630a() {
        if (f513a != null) {
            f513a.m628b();
            f513a = null;
        }
        f514b = null;
    }

    /* renamed from: a */
    public static void m631a(Context context) {
        if (VERSION.SDK_INT < 19) {
            try {
                context.sendBroadcast(new Intent("android.intent.action.MEDIA_MOUNTED", Uri.parse("file://" + Environment.getExternalStorageDirectory())));
                return;
            } catch (Throwable e) {
                C0166c.m556a(e);
                return;
            }
        }
        Bundle bundle = new Bundle();
        bundle.putString("volume", "external");
        Intent putExtras = new Intent("android.media.IMediaScannerService").putExtras(bundle);
        putExtras.setClassName("com.android.providers.media", "com.android.providers.media.MediaScannerService");
        try {
            context.startService(putExtras);
        } catch (Throwable e2) {
            C0166c.m556a(e2);
        }
    }

    /* renamed from: a */
    public static void m632a(Context context, String str) {
        if ((f513a == null || !f513a.m627a(str)) && context != null) {
            C0180a c0180a = new C0180a(null, str, false);
            c0180a.f509c = new MediaScannerConnection(context, c0180a);
            c0180a.f509c.connect();
        }
    }

    /* renamed from: b */
    public static void m633b(Context context, String str) {
        ContentResolver contentResolver = f514b;
        if (contentResolver == null) {
            if (context != null) {
                contentResolver = context.getContentResolver();
            } else {
                return;
            }
        }
        String a = C0168e.m571a(str);
        try {
            contentResolver.delete(Files.getContentUri("external"), "_data=?", new String[]{a});
        } catch (Throwable e) {
            C0166c.m556a(e);
        }
    }

    /* renamed from: b */
    public static boolean m634b() {
        return (f513a == null || f513a.f508b == null || f513a.f510d == null || f513a.f510d.size() <= 0) ? false : true;
    }

    /* renamed from: c */
    public static void m635c(Context context, String str) {
        ContentResolver contentResolver = f514b;
        if (contentResolver == null) {
            if (context != null) {
                contentResolver = context.getContentResolver();
            } else {
                return;
            }
        }
        String str2 = "_data=? OR _data LIKE '" + C0168e.m571a(str) + "/%'";
        try {
            contentResolver.delete(Files.getContentUri("external"), str2, new String[]{r1});
        } catch (Throwable e) {
            C0166c.m556a(e);
        }
    }
}
