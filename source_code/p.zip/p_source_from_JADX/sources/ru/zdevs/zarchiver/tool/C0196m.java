package ru.zdevs.zarchiver.tool;

import java.util.Comparator;
import java.util.Locale;
import ru.zdevs.zarchiver.p003a.C0049e;

/* renamed from: ru.zdevs.zarchiver.tool.m */
public class C0196m {

    /* renamed from: ru.zdevs.zarchiver.tool.m$a */
    public static class C0188a implements Comparator<C0049e> {
        /* renamed from: a */
        final int f533a;

        public C0188a(boolean z) {
            this.f533a = z ? -1 : 1;
        }

        /* renamed from: a */
        public int m673a(C0049e c0049e, C0049e c0049e2) {
            return c0049e.m107b() ? c0049e2.m107b() ? c0049e.m116k() == c0049e2.m116k() ? C0164a.m548a(c0049e.mo28e(), c0049e2.mo28e()) : c0049e.m116k() > c0049e2.m116k() ? this.f533a : -this.f533a : -1 : !c0049e2.m107b() ? c0049e.m116k() == c0049e2.m116k() ? C0164a.m548a(c0049e.mo28e(), c0049e2.mo28e()) : c0049e.m116k() > c0049e2.m116k() ? this.f533a : -this.f533a : 1;
        }

        public /* synthetic */ int compare(Object obj, Object obj2) {
            return m673a((C0049e) obj, (C0049e) obj2);
        }
    }

    /* renamed from: ru.zdevs.zarchiver.tool.m$b */
    public static class C0189b implements Comparator<C0049e> {
        /* renamed from: a */
        final int f534a;

        public C0189b(boolean z) {
            this.f534a = z ? -1 : 1;
        }

        /* renamed from: a */
        public int m674a(C0049e c0049e, C0049e c0049e2) {
            return c0049e.m107b() ? c0049e2.m107b() ? c0049e.m116k() == c0049e2.m116k() ? c0049e.mo28e().compareToIgnoreCase(c0049e2.mo28e()) : c0049e.m116k() > c0049e2.m116k() ? this.f534a : -this.f534a : -1 : !c0049e2.m107b() ? c0049e.m116k() == c0049e2.m116k() ? c0049e.mo28e().compareToIgnoreCase(c0049e2.mo28e()) : c0049e.m116k() > c0049e2.m116k() ? this.f534a : -this.f534a : 1;
        }

        public /* synthetic */ int compare(Object obj, Object obj2) {
            return m674a((C0049e) obj, (C0049e) obj2);
        }
    }

    /* renamed from: ru.zdevs.zarchiver.tool.m$c */
    public static class C0190c implements Comparator<C0049e> {
        /* renamed from: a */
        final int f535a;

        public C0190c(boolean z) {
            this.f535a = z ? -1 : 1;
        }

        /* renamed from: a */
        public int m675a(C0049e c0049e, C0049e c0049e2) {
            return c0049e.m107b() ? c0049e2.m107b() ? this.f535a * C0164a.m548a(c0049e.mo28e(), c0049e2.mo28e()) : -1 : !c0049e2.m107b() ? this.f535a * C0164a.m548a(c0049e.mo28e(), c0049e2.mo28e()) : 1;
        }

        public /* synthetic */ int compare(Object obj, Object obj2) {
            return m675a((C0049e) obj, (C0049e) obj2);
        }
    }

    /* renamed from: ru.zdevs.zarchiver.tool.m$d */
    public static class C0191d implements Comparator<C0049e> {
        /* renamed from: a */
        final int f536a;

        public C0191d(boolean z) {
            this.f536a = z ? -1 : 1;
        }

        /* renamed from: a */
        public int m676a(C0049e c0049e, C0049e c0049e2) {
            return c0049e.m107b() ? c0049e2.m107b() ? this.f536a * c0049e.mo28e().compareToIgnoreCase(c0049e2.mo28e()) : -1 : !c0049e2.m107b() ? this.f536a * c0049e.mo28e().compareToIgnoreCase(c0049e2.mo28e()) : 1;
        }

        public /* synthetic */ int compare(Object obj, Object obj2) {
            return m676a((C0049e) obj, (C0049e) obj2);
        }
    }

    /* renamed from: ru.zdevs.zarchiver.tool.m$e */
    public static class C0192e implements Comparator<C0049e> {
        /* renamed from: a */
        final int f537a;

        public C0192e(boolean z) {
            this.f537a = z ? -1 : 1;
        }

        /* renamed from: a */
        public int m677a(C0049e c0049e, C0049e c0049e2) {
            return c0049e.m107b() ? c0049e2.m107b() ? C0164a.m548a(c0049e.mo28e(), c0049e2.mo28e()) : -1 : !c0049e2.m107b() ? c0049e.m115j() == c0049e2.m115j() ? C0164a.m548a(c0049e.mo28e(), c0049e2.mo28e()) : c0049e.m115j() > c0049e2.m115j() ? this.f537a : -this.f537a : 1;
        }

        public /* synthetic */ int compare(Object obj, Object obj2) {
            return m677a((C0049e) obj, (C0049e) obj2);
        }
    }

    /* renamed from: ru.zdevs.zarchiver.tool.m$f */
    public static class C0193f implements Comparator<C0049e> {
        /* renamed from: a */
        final int f538a;

        public C0193f(boolean z) {
            this.f538a = z ? -1 : 1;
        }

        /* renamed from: a */
        public int m678a(C0049e c0049e, C0049e c0049e2) {
            return c0049e.m107b() ? c0049e2.m107b() ? c0049e.mo28e().compareToIgnoreCase(c0049e2.mo28e()) : -1 : !c0049e2.m107b() ? c0049e.m115j() == c0049e2.m115j() ? c0049e.mo28e().compareToIgnoreCase(c0049e2.mo28e()) : c0049e.m115j() > c0049e2.m115j() ? this.f538a : -this.f538a : 1;
        }

        public /* synthetic */ int compare(Object obj, Object obj2) {
            return m678a((C0049e) obj, (C0049e) obj2);
        }
    }

    /* renamed from: ru.zdevs.zarchiver.tool.m$g */
    public static class C0194g implements Comparator<C0049e> {
        /* renamed from: a */
        final int f539a;

        public C0194g(boolean z) {
            this.f539a = z ? -1 : 1;
        }

        /* renamed from: a */
        public int m679a(C0049e c0049e, C0049e c0049e2) {
            return c0049e.m107b() ? c0049e2.m107b() ? C0164a.m548a(c0049e.mo28e(), c0049e2.mo28e()) : -1 : !c0049e2.m107b() ? this.f539a * C0196m.m681a(c0049e.mo28e()).compareToIgnoreCase(C0196m.m681a(c0049e2.mo28e())) : 1;
        }

        public /* synthetic */ int compare(Object obj, Object obj2) {
            return m679a((C0049e) obj, (C0049e) obj2);
        }
    }

    /* renamed from: ru.zdevs.zarchiver.tool.m$h */
    public static class C0195h implements Comparator<C0049e> {
        /* renamed from: a */
        final int f540a;

        public C0195h(boolean z) {
            this.f540a = z ? -1 : 1;
        }

        /* renamed from: a */
        public int m680a(C0049e c0049e, C0049e c0049e2) {
            return c0049e.m107b() ? c0049e2.m107b() ? c0049e.mo28e().compareToIgnoreCase(c0049e2.mo28e()) : -1 : !c0049e2.m107b() ? this.f540a * C0196m.m681a(c0049e.mo28e()).compareToIgnoreCase(C0196m.m681a(c0049e2.mo28e())) : 1;
        }

        public /* synthetic */ int compare(Object obj, Object obj2) {
            return m680a((C0049e) obj, (C0049e) obj2);
        }
    }

    /* renamed from: a */
    public static String m681a(String str) {
        int lastIndexOf = str.lastIndexOf(46);
        return lastIndexOf > 0 ? str.substring(lastIndexOf + 1, str.length()).toLowerCase(Locale.US) : "";
    }
}
