package ru.zdevs.zarchiver.tool;

public class MimeTool {
    /* renamed from: a */
    public static int m546a(String str) {
        try {
            return cGetType(str);
        } catch (Error e) {
            C0166c.m554a(e);
            return 0;
        }
    }

    public static native int cGetType(String str);
}
