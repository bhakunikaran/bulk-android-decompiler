package ru.zdevs.zarchiver.tool;

import android.annotation.SuppressLint;
import android.content.ContentUris;
import android.content.Context;
import android.content.CursorLoader;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore.Audio;
import android.provider.MediaStore.Images.Media;
import android.provider.MediaStore.Video;
import java.io.File;
import java.net.URLDecoder;
import ru.zdevs.zarchiver.tool.C0199n.C0198a;

/* renamed from: ru.zdevs.zarchiver.tool.k */
public class C0185k {
    @SuppressLint({"SdCardPath"})
    /* renamed from: a */
    private static final String[] f526a = new String[]{"/storage/emulated/", "/sdcard/"};

    /* renamed from: a */
    public static File m653a(Context context, Uri uri) {
        if ("file".equals(uri.getScheme())) {
            return new File(uri.getPath());
        }
        C0166c.m559d("RealPathUtil", "uriToFile: " + uri.toString());
        String uri2 = uri.toString();
        if (uri2 == null) {
            return null;
        }
        File file;
        String b = C0185k.m656b(context, uri);
        if (b != null) {
            C0166c.m559d("RealPathUtil", "uriToFile real: " + b);
            file = new File(b);
            if (file.exists()) {
                return file;
            }
        }
        b = uri.getQuery();
        if (b != null && b.contains("file://")) {
            file = new File(URLDecoder.decode(b.substring(b.indexOf("file://") + 7)));
            if (file.exists()) {
                return file;
            }
        }
        if (uri2.contains("primary%3A")) {
            file = new File(Environment.getExternalStorageDirectory(), URLDecoder.decode(uri2.substring(uri2.indexOf("%3A") + 3)));
            if (file.exists()) {
                return file;
            }
        }
        for (String indexOf : f526a) {
            int indexOf2 = uri2.indexOf(indexOf);
            if (indexOf2 >= 0) {
                int indexOf3 = uri2.indexOf("?", indexOf2);
                if (indexOf3 < 0) {
                    indexOf3 = uri2.length();
                }
                file = new File(URLDecoder.decode(uri2.substring(indexOf2, indexOf3)));
                if (file.exists()) {
                    return file;
                }
            }
        }
        return null;
    }

    /* renamed from: a */
    private static String m654a(Context context, Uri uri, String str, String[] strArr) {
        Cursor query;
        Throwable e;
        String str2 = "_data";
        try {
            query = context.getContentResolver().query(uri, new String[]{"_data"}, str, strArr, null);
            if (query != null) {
                try {
                    if (query.moveToFirst()) {
                        str2 = query.getString(query.getColumnIndexOrThrow("_data"));
                        if (query == null) {
                            return str2;
                        }
                        query.close();
                        return str2;
                    }
                } catch (Exception e2) {
                    e = e2;
                    try {
                        C0166c.m556a(e);
                        if (query != null) {
                            query.close();
                        }
                        return null;
                    } catch (Throwable th) {
                        e = th;
                        if (query != null) {
                            query.close();
                        }
                        throw e;
                    }
                }
            }
            if (query != null) {
                query.close();
            }
            return null;
        } catch (Exception e3) {
            e = e3;
            query = null;
            C0166c.m556a(e);
            if (query != null) {
                query.close();
            }
            return null;
        } catch (Throwable th2) {
            e = th2;
            query = null;
            if (query != null) {
                query.close();
            }
            throw e;
        }
    }

    /* renamed from: a */
    private static boolean m655a(Uri uri) {
        return "com.android.externalstorage.documents".equals(uri.getAuthority());
    }

    /* renamed from: b */
    private static String m656b(Context context, Uri uri) {
        try {
            return VERSION.SDK_INT < 19 ? C0185k.m658c(context, uri) : C0185k.m660d(context, uri);
        } catch (Throwable e) {
            C0166c.m556a(e);
            return null;
        }
    }

    /* renamed from: b */
    private static boolean m657b(Uri uri) {
        return "com.android.providers.downloads.documents".equals(uri.getAuthority());
    }

    /* renamed from: c */
    private static String m658c(Context context, Uri uri) {
        Cursor loadInBackground;
        Throwable e;
        try {
            loadInBackground = new CursorLoader(context, uri, new String[]{"_data"}, null, null, null).loadInBackground();
            if (loadInBackground != null) {
                try {
                    if (loadInBackground.moveToFirst()) {
                        String string = loadInBackground.getString(loadInBackground.getColumnIndexOrThrow("_data"));
                        if (loadInBackground == null) {
                            return string;
                        }
                        loadInBackground.close();
                        return string;
                    }
                } catch (Exception e2) {
                    e = e2;
                    try {
                        C0166c.m556a(e);
                        if (loadInBackground != null) {
                            loadInBackground.close();
                        }
                        return null;
                    } catch (Throwable th) {
                        e = th;
                        if (loadInBackground != null) {
                            loadInBackground.close();
                        }
                        throw e;
                    }
                }
            }
            if (loadInBackground != null) {
                loadInBackground.close();
            }
            return null;
        } catch (Exception e3) {
            e = e3;
            loadInBackground = null;
            C0166c.m556a(e);
            if (loadInBackground != null) {
                loadInBackground.close();
            }
            return null;
        } catch (Throwable th2) {
            e = th2;
            loadInBackground = null;
            if (loadInBackground != null) {
                loadInBackground.close();
            }
            throw e;
        }
    }

    /* renamed from: c */
    private static boolean m659c(Uri uri) {
        return "com.android.providers.media.documents".equals(uri.getAuthority());
    }

    @SuppressLint({"NewApi"})
    /* renamed from: d */
    private static String m660d(Context context, Uri uri) {
        Uri uri2 = null;
        if ((VERSION.SDK_INT >= 19 ? 1 : 0) == 0 || !DocumentsContract.isDocumentUri(context, uri)) {
            return "content".equalsIgnoreCase(uri.getScheme()) ? C0185k.m661d(uri) ? uri.getLastPathSegment() : C0185k.m654a(context, uri, null, null) : null;
        } else {
            String[] split;
            if (C0185k.m655a(uri)) {
                split = DocumentsContract.getDocumentId(uri).split(":");
                String str = split[0];
                if ("primary".equalsIgnoreCase(str)) {
                    return Environment.getExternalStorageDirectory() + "/" + split[1];
                }
                if ("home".equalsIgnoreCase(str)) {
                    return Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS) + "/" + split[1];
                }
                C0198a b = C0199n.m696b(str);
                return b != null ? b.f542b + "/" + split[1] : null;
            } else if (C0185k.m657b(uri)) {
                return C0185k.m654a(context, ContentUris.withAppendedId(Uri.parse("content://downloads/public_downloads"), Long.valueOf(DocumentsContract.getDocumentId(uri)).longValue()), null, null);
            } else if (!C0185k.m659c(uri)) {
                return null;
            } else {
                Object obj = DocumentsContract.getDocumentId(uri).split(":")[0];
                if ("image".equals(obj)) {
                    uri2 = Media.EXTERNAL_CONTENT_URI;
                } else if ("video".equals(obj)) {
                    uri2 = Video.Media.EXTERNAL_CONTENT_URI;
                } else if ("audio".equals(obj)) {
                    uri2 = Audio.Media.EXTERNAL_CONTENT_URI;
                }
                String str2 = "_id=?";
                return C0185k.m654a(context, uri2, "_id=?", new String[]{split[1]});
            }
        }
    }

    /* renamed from: d */
    private static boolean m661d(Uri uri) {
        return "com.google.android.apps.photos.content".equals(uri.getAuthority());
    }
}
