package ru.zdevs.zarchiver.settings;

import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.preference.DialogPreference;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import ru.zdevs.zarchiver.p003a.C0041a;

public class ColorPreference extends DialogPreference {
    private int mValue;

    /* renamed from: ru.zdevs.zarchiver.settings.ColorPreference$1 */
    class C01631 implements OnClickListener {
        /* renamed from: a */
        final /* synthetic */ ColorPreference f458a;

        C01631(ColorPreference colorPreference) {
            this.f458a = colorPreference;
        }

        public void onClick(DialogInterface dialogInterface, int i) {
            this.f458a.mValue = i;
            this.f458a.onClick(dialogInterface, -1);
            dialogInterface.dismiss();
        }
    }

    public ColorPreference(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    private void getCurrentValue() {
        this.mValue = getPersistedInt(0);
    }

    protected View onCreateView(ViewGroup viewGroup) {
        getCurrentValue();
        setSummary(C0041a.m66a(this.mValue));
        return super.onCreateView(viewGroup);
    }

    protected void onDialogClosed(boolean z) {
        super.onDialogClosed(z);
        persistInt(this.mValue);
        notifyChanged();
    }

    protected void onPrepareDialogBuilder(Builder builder) {
        super.onPrepareDialogBuilder(builder);
        ListAdapter c0041a = new C0041a(getContext());
        getCurrentValue();
        builder.setSingleChoiceItems(c0041a, this.mValue, new C01631(this));
        builder.setPositiveButton(null, null);
    }
}
