package ru.zdevs.zarchiver.settings;

import android.content.Context;
import android.content.res.Resources;
import android.preference.DialogPreference;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import ru.zdevs.zarchiver.R;

public class SeekBarPreference extends DialogPreference implements OnSeekBarChangeListener {
    private static final String ANDROID_NS = "http://schemas.android.com/apk/res/android";
    private static final String ATTR_DEFAULT_VALUE = "defaultValue";
    private static final String ATTR_MAX_VALUE = "maxValue";
    private static final String ATTR_MIN_VALUE = "minValue";
    private static final String PREFERENCE_NS = "http://schemas.android.com/apk/res/ru.zdevs.zarchiver";
    private int mCurrentValue;
    private int mDefaultValue;
    private int mMaxValue;
    private int mMinValue;
    private TextView mValueText;

    public SeekBarPreference(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        Resources resources = context.getResources();
        this.mMinValue = getIntegerValue(resources, attributeSet, PREFERENCE_NS, ATTR_MIN_VALUE, 0);
        this.mMaxValue = getIntegerValue(resources, attributeSet, PREFERENCE_NS, ATTR_MAX_VALUE, 100);
        this.mDefaultValue = getIntegerValue(resources, attributeSet, ANDROID_NS, ATTR_DEFAULT_VALUE, 0);
    }

    private int getIntegerValue(Resources resources, AttributeSet attributeSet, String str, String str2, int i) {
        int attributeIntValue = attributeSet.getAttributeIntValue(str, str2, Integer.MIN_VALUE);
        if (attributeIntValue != Integer.MIN_VALUE) {
            return attributeIntValue;
        }
        attributeIntValue = attributeSet.getAttributeResourceValue(str, str2, Integer.MIN_VALUE);
        return attributeIntValue != Integer.MIN_VALUE ? resources.getDimensionPixelSize(attributeIntValue) : i;
    }

    protected View onCreateDialogView() {
        this.mCurrentValue = getPersistedInt(this.mDefaultValue);
        View inflate = ((LayoutInflater) getContext().getSystemService("layout_inflater")).inflate(R.layout.dialog_slider, null);
        ((TextView) inflate.findViewById(R.id.min_value)).setText(Integer.toString(this.mMinValue));
        ((TextView) inflate.findViewById(R.id.max_value)).setText(Integer.toString(this.mMaxValue));
        SeekBar seekBar = (SeekBar) inflate.findViewById(R.id.seek_bar);
        seekBar.setMax(this.mMaxValue - this.mMinValue);
        seekBar.setProgress(this.mCurrentValue - this.mMinValue);
        seekBar.setOnSeekBarChangeListener(this);
        this.mValueText = (TextView) inflate.findViewById(R.id.current_value);
        this.mValueText.setText(Integer.toString(this.mCurrentValue));
        return inflate;
    }

    protected void onDialogClosed(boolean z) {
        super.onDialogClosed(z);
        if (z) {
            if (shouldPersist()) {
                persistInt(this.mCurrentValue);
            }
            notifyChanged();
        }
    }

    public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
        this.mCurrentValue = this.mMinValue + i;
        this.mValueText.setText(Integer.toString(this.mCurrentValue));
    }

    public void onStartTrackingTouch(SeekBar seekBar) {
    }

    public void onStopTrackingTouch(SeekBar seekBar) {
    }
}
