package ru.zdevs.zarchiver.settings;

import android.annotation.SuppressLint;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.preference.ListPreference;
import android.util.AttributeSet;
import android.widget.ListAdapter;
import ru.zdevs.zarchiver.archiver.C0071e;
import ru.zdevs.zarchiver.p003a.C0055k;

public class Compression7zLevelPreference extends ListPreference {
    public Compression7zLevelPreference(Context context) {
        super(context);
    }

    public Compression7zLevelPreference(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    @SuppressLint({"NewApi"})
    public Compression7zLevelPreference(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    @SuppressLint({"NewApi"})
    public Compression7zLevelPreference(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
    }

    protected void onPrepareDialogBuilder(Builder builder) {
        int a;
        ListAdapter c0055k = new C0055k(builder.getContext());
        c0055k.m137a();
        for (CharSequence charSequence : getEntries()) {
            c0055k.m139a(charSequence.toString());
        }
        if (!Settings.sExtIgnoreRAMLimit.booleanValue()) {
            a = C0071e.m285a();
            if (a < 9) {
                c0055k.m138a(5, false);
            }
            if (a < 7) {
                c0055k.m138a(4, false);
            }
            if (a < 5) {
                c0055k.m138a(3, false);
            }
            if (a < 3) {
                c0055k.m138a(2, false);
            }
        }
        builder.setAdapter(c0055k, null);
        super.onPrepareDialogBuilder(builder);
    }
}
