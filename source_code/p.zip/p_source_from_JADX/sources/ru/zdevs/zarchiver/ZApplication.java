package ru.zdevs.zarchiver;

import android.app.Application;
import ru.zdevs.zarchiver.archiver.C0061a;
import ru.zdevs.zarchiver.archiver.C0072g;

public class ZApplication extends Application {
    /* renamed from: a */
    private C0072g f29a;
    /* renamed from: b */
    private C0061a f30b;

    /* renamed from: a */
    public void m24a() {
        if (this.f29a == null) {
            this.f29a = new C0072g();
        }
        if (this.f30b == null) {
            this.f30b = new C0061a();
        }
    }

    public void onCreate() {
        super.onCreate();
        this.f29a = null;
        this.f30b = null;
    }

    public void onTerminate() {
        super.onTerminate();
        if (this.f29a != null) {
            this.f29a.m303a();
            this.f29a = null;
        }
        if (this.f30b != null) {
            this.f30b.m226a();
            this.f30b = null;
        }
    }

    public void onTrimMemory(int i) {
        if (i >= 40) {
            C0061a.m216e();
        }
        super.onTrimMemory(i);
    }
}
