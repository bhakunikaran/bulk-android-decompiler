package ru.zdevs.zarchiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import ru.zdevs.zarchiver.dialog.ZDialog;
import ru.zdevs.zarchiver.dialog.ZEnterPwdDialogExt;
import ru.zdevs.zarchiver.dialog.ZMessageDialog;
import ru.zdevs.zarchiver.dialog.ZProgDialogExt;
import ru.zdevs.zarchiver.fs.MyUri;
import ru.zdevs.zarchiver.settings.Settings;
import ru.zdevs.zarchiver.tool.C0166c;
import ru.zdevs.zarchiver.widget.bottomsheet.ViewDragHelper;

public class ActionsExt extends Actions {
    private static final String TAG = "ActionsExt";
    public List<ZDialog> Dialogs = new ArrayList();
    public final BroadcastReceiver mMesageReceiver = new C00081(this);

    /* renamed from: ru.zdevs.zarchiver.ActionsExt$1 */
    class C00081 extends BroadcastReceiver {
        /* renamed from: a */
        final /* synthetic */ ActionsExt f27a;

        C00081(ActionsExt actionsExt) {
            this.f27a = actionsExt;
        }

        public void onReceive(Context context, Intent intent) {
            boolean z = true;
            if (ZArchiverExt.sContext != null && intent.getExtras() != null) {
                Bundle extras = intent.getExtras();
                int i = extras.getInt("iTaskIDExt", -1);
                if (i > 0) {
                    int i2 = extras.getInt("iTaskID");
                    int i3 = extras.getInt("iTaskType");
                    int i4 = extras.getInt("iAction");
                    ZProgDialogExt zProgDialogExt;
                    switch (i4) {
                        case 1:
                            C0166c.m558c(ActionsExt.TAG, "CMD_SHOW_PROGRESS");
                            if (this.f27a.FindDialog(i2, 2) == null) {
                                int i5;
                                switch (i3) {
                                    case -127:
                                    case 1:
                                    case 5:
                                        i5 = R.string.MES_DECOMPRESS_FILE_PROCESS;
                                        break;
                                    case -117:
                                    case 11:
                                        i5 = R.string.MES_TEST_FILE_PROCESS;
                                        break;
                                    case 4:
                                        i5 = R.string.MES_COPY_FILE;
                                        break;
                                    case Actions.CHECK_ACTION_RENAME /*6*/:
                                        i5 = R.string.MES_REMOVE_FILE;
                                        break;
                                    case ZArchiverExtInterface.COMPRESSION_LAVEL_MAX /*7*/:
                                        i5 = R.string.MES_ADD_TO_ARCHIVE;
                                        break;
                                    case ViewDragHelper.EDGE_BOTTOM /*8*/:
                                        i5 = R.string.MES_DEL_FROM_ARCHIVE;
                                        break;
                                    case 10:
                                        i5 = R.string.MES_MOVE_FILE;
                                        break;
                                    default:
                                        i5 = R.string.MES_COMPRESS_FILE_PROCESS;
                                        break;
                                }
                                ZDialog zProgDialogExt2 = new ZProgDialogExt(this.f27a, ZArchiverExt.sContext, i5);
                                zProgDialogExt2.setTaskID(i2);
                                zProgDialogExt2.setOnCancelListener(this.f27a);
                                zProgDialogExt2.show();
                                return;
                            }
                            return;
                        case 2:
                            C0166c.m558c(ActionsExt.TAG, "CMD_CLOSE_PROGRESS");
                            ZDialog access$000 = this.f27a.FindDialog(i2, 2);
                            if (access$000 != null) {
                                access$000.close();
                                return;
                            }
                            return;
                        case 3:
                            C0166c.m558c(ActionsExt.TAG, "CMD_SET_PROGRESS");
                            zProgDialogExt = (ZProgDialogExt) this.f27a.FindDialog(i2, 2);
                            if (zProgDialogExt != null) {
                                zProgDialogExt.setText(extras.getString("sText"));
                                return;
                            }
                            return;
                        case 4:
                            C0166c.m558c(ActionsExt.TAG, "CMD_SET_PROGRESS");
                            zProgDialogExt = (ZProgDialogExt) this.f27a.FindDialog(i2, 2);
                            if (zProgDialogExt != null) {
                                zProgDialogExt.setProgress(extras.getInt("iProgress", 0));
                                return;
                            }
                            return;
                        case 5:
                            C0166c.m558c(ActionsExt.TAG, "CMD_SHOW_PASSWORD_DLG");
                            if (((ZEnterPwdDialogExt) this.f27a.FindDialog(i2, 3)) == null) {
                                ZEnterPwdDialogExt zEnterPwdDialogExt = new ZEnterPwdDialogExt(this.f27a, ZArchiverExt.sContext);
                                zEnterPwdDialogExt.setTaskID(i2);
                                zEnterPwdDialogExt.setOnOkListener(this.f27a);
                                zEnterPwdDialogExt.setOnCancelListener(this.f27a);
                                zEnterPwdDialogExt.show();
                                return;
                            }
                            return;
                        case ViewDragHelper.EDGE_ALL /*15*/:
                            C0166c.m558c(ActionsExt.TAG, "CMD_CHANGE_ARCHIVE_NAME");
                            if (i3 == -127) {
                                zProgDialogExt = (ZProgDialogExt) this.f27a.FindDialog(i2, 2);
                                if (zProgDialogExt != null) {
                                    zProgDialogExt.setCaption(extras.getString("sText"));
                                    return;
                                }
                                return;
                            }
                            return;
                        case 16:
                        case 17:
                            C0166c.m558c(ActionsExt.TAG, "CMD_COMPLETE_(UN)SUCESSFUL");
                            Context context2 = ZArchiverExt.sContext;
                            boolean z2 = i3 == 3;
                            if (i4 != 16) {
                                z = false;
                            }
                            C0091b.m357a(context2, i, z2, z);
                            return;
                        default:
                            return;
                    }
                }
            }
        }
    }

    /* renamed from: ru.zdevs.zarchiver.ActionsExt$a */
    private class C0009a extends AsyncTask<Intent, Void, Void> {
        /* renamed from: a */
        final /* synthetic */ ActionsExt f28a;

        private C0009a(ActionsExt actionsExt) {
            this.f28a = actionsExt;
        }

        /* renamed from: a */
        protected Void m23a(Intent... intentArr) {
            this.f28a.onReceive(null, intentArr[0]);
            return null;
        }

        protected /* synthetic */ Object doInBackground(Object[] objArr) {
            return m23a((Intent[]) objArr);
        }
    }

    public ActionsExt() {
        super(null);
        this.Dialogs.clear();
    }

    private ActionsExt(C0136e c0136e) {
        super(c0136e);
    }

    private ZDialog FindDialog(int i, int i2) {
        for (ZDialog zDialog : this.Dialogs) {
            if (zDialog.getTaskID() == i && zDialog.getType() == i2) {
                return zDialog;
            }
        }
        return null;
    }

    public void checkOnExite(boolean z) {
        boolean z2 = false;
        boolean z3 = true;
        if (this.Dialogs.size() > 0) {
            z3 = false;
        }
        if (bWaitService == null) {
            z2 = z3;
        }
        C0166c.m558c(TAG, "Check on exite: close = " + z2);
        if (z2 && ZArchiverExt.sContext != null) {
            ZArchiverExt.sContext.finish();
        }
    }

    public void onCancel(ZDialog zDialog) {
        switch (zDialog.getType()) {
            case 1:
            case 2:
                if (!Settings.sConfirmCancel) {
                    try {
                        this.mService.SetStatusTask(zDialog.getTaskID(), 15);
                        return;
                    } catch (Throwable e) {
                        C0166c.m556a(e);
                        return;
                    }
                } else if (ZArchiverExt.sContext != null) {
                    ZMessageDialog zMessageDialog = new ZMessageDialog(null, ZArchiverExt.sContext, (byte) 1, ZArchiverExt.sContext.getString(R.string.MES_CONFIRM_CANCEL));
                    zMessageDialog.setSubType(9);
                    zMessageDialog.setTaskID(zDialog.getTaskID());
                    zMessageDialog.setOnOkListener(this);
                    zMessageDialog.setOnCancelListener(this);
                    zMessageDialog.showWithoutCancel();
                    return;
                }
                break;
        }
        super.onCancel(zDialog);
    }

    public void onDlgClose() {
        checkOnExite(false);
    }

    public void onOk(ZDialog zDialog) {
        super.onOk(zDialog);
    }

    public void onProcessIntent(Intent intent) {
        new C0009a().execute(new Intent[]{intent});
    }

    public void onReceive(Context context, Intent intent) {
        Throwable e;
        int i = 0;
        if (ZArchiverExt.sContext != null) {
            int i2;
            if (C0091b.m358a(intent)) {
                C0166c.m558c(TAG, "onReceive intent from ExternalInterface");
                if (C0091b.m359b(intent)) {
                    if (C0091b.m360c(intent)) {
                        try {
                            if (ZArchiverExt.sContext.iService == null) {
                                serviceWait();
                            }
                            if (ZArchiverExt.sContext.iService == null) {
                                checkOnExite(true);
                                return;
                            }
                            String g = C0091b.m364g(intent);
                            i2 = C0091b.m366i(intent);
                            String j = C0091b.m367j(intent);
                            String str = "\\-mx=" + i2;
                            this.mFileListAction = C0091b.m369l(intent);
                            this.mFileListActionPath = C0091b.m368k(intent);
                            if (!g.startsWith("/")) {
                                g = this.mFileListAction + "/" + g;
                            }
                            archiveNew(C0091b.m363f(intent), j, str, g, i, (byte) 1, i);
                            return;
                        } catch (Exception e2) {
                            checkOnExite(true);
                            return;
                        }
                    }
                    checkOnExite(true);
                } else if (!C0091b.m361d(intent)) {
                } else {
                    if (C0091b.m362e(intent)) {
                        File file = new File(C0091b.m364g(intent));
                        if (file.exists()) {
                            try {
                                if (ZArchiverExt.sContext.iService == null) {
                                    serviceWait();
                                }
                                if (ZArchiverExt.sContext.iService == null) {
                                    checkOnExite(true);
                                    return;
                                }
                                this.mFileListAction = new String[1];
                                this.mFileListAction[i] = file.getName();
                                this.mFileListActionPath = new MyUri(file.getParent());
                                archiveExtract(C0091b.m363f(intent), C0091b.m365h(intent), i, i);
                                return;
                            } catch (Exception e3) {
                                checkOnExite(true);
                                return;
                            }
                        }
                        checkOnExite(true);
                        return;
                    }
                    checkOnExite(true);
                }
            } else if (C0092c.m371a(intent)) {
                i2 = intent.getIntExtra("ZArchiver.iCMD", i);
                int i3 = intent.getExtras().getInt("iTaskID");
                if (intent.getExtras().getInt("iTaskIDExt", -1) > 0) {
                    switch (i2) {
                        case 21:
                            String GetProgText;
                            C0166c.m558c(TAG, "SHow PROG DLG!!!");
                            Intent intent2 = new Intent("ZArchiver.iMES");
                            intent2.putExtra("iTaskID", i3);
                            intent2.putExtra("iTaskType", intent.getExtras().getInt("iTaskType"));
                            intent2.putExtra("iAction", 1);
                            this.mMesageReceiver.onReceive(context, intent2);
                            String str2 = "";
                            try {
                                serviceWait();
                                GetProgText = this.mService.GetProgText(i3);
                                try {
                                    i = this.mService.GetProgPercent(i3);
                                } catch (Exception e4) {
                                    e = e4;
                                    C0166c.m556a(e);
                                    intent2.putExtra("iProgress", i);
                                    intent2.putExtra("sText", GetProgText);
                                    intent2.putExtra("iAction", 4);
                                    this.mMesageReceiver.onReceive(context, intent2);
                                    intent2.putExtra("iAction", 3);
                                    this.mMesageReceiver.onReceive(context, intent2);
                                    return;
                                }
                            } catch (Throwable e5) {
                                Throwable th = e5;
                                GetProgText = str2;
                                e = th;
                                C0166c.m556a(e);
                                intent2.putExtra("iProgress", i);
                                intent2.putExtra("sText", GetProgText);
                                intent2.putExtra("iAction", 4);
                                this.mMesageReceiver.onReceive(context, intent2);
                                intent2.putExtra("iAction", 3);
                                this.mMesageReceiver.onReceive(context, intent2);
                                return;
                            }
                            intent2.putExtra("iProgress", i);
                            intent2.putExtra("sText", GetProgText);
                            intent2.putExtra("iAction", 4);
                            this.mMesageReceiver.onReceive(context, intent2);
                            intent2.putExtra("iAction", 3);
                            this.mMesageReceiver.onReceive(context, intent2);
                            return;
                        case 22:
                            C0166c.m558c(TAG, "SHow PWD DLG!!!");
                            Intent intent3 = new Intent("ZArchiver.iMES");
                            intent3.putExtra("iTaskID", i3);
                            intent3.putExtra("iAction", 5);
                            this.mMesageReceiver.onReceive(context, intent3);
                            return;
                        default:
                            return;
                    }
                }
            } else {
                checkOnExite(true);
            }
        }
    }
}
