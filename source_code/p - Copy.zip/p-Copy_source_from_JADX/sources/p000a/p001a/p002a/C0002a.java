package p000a.p001a.p002a;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.os.Build.VERSION;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager.LayoutParams;
import android.widget.FrameLayout;
import java.lang.reflect.Method;

/* renamed from: a.a.a.a */
public class C0002a {
    /* renamed from: a */
    private static String f9a;
    /* renamed from: b */
    private final C0001a f10b;
    /* renamed from: c */
    private boolean f11c;
    /* renamed from: d */
    private boolean f12d;
    /* renamed from: e */
    private boolean f13e;
    /* renamed from: f */
    private boolean f14f;
    /* renamed from: g */
    private View f15g;
    /* renamed from: h */
    private View f16h;

    /* renamed from: a.a.a.a$a */
    public static class C0001a {
        /* renamed from: a */
        private final boolean f0a;
        /* renamed from: b */
        private final boolean f1b;
        /* renamed from: c */
        private final int f2c;
        /* renamed from: d */
        private final int f3d;
        /* renamed from: e */
        private final boolean f4e;
        /* renamed from: f */
        private final int f5f;
        /* renamed from: g */
        private final int f6g;
        /* renamed from: h */
        private final boolean f7h;
        /* renamed from: i */
        private final float f8i;

        private C0001a(Activity activity, boolean z, boolean z2) {
            boolean z3 = true;
            Resources resources = activity.getResources();
            this.f7h = resources.getConfiguration().orientation == 1;
            this.f8i = m0a(activity);
            this.f2c = m2a(resources, "status_bar_height");
            this.f3d = m1a((Context) activity);
            this.f5f = m3b(activity);
            this.f6g = m4c(activity);
            if (this.f5f <= 0) {
                z3 = false;
            }
            this.f4e = z3;
            this.f0a = z;
            this.f1b = z2;
        }

        @SuppressLint({"NewApi"})
        /* renamed from: a */
        private float m0a(Activity activity) {
            DisplayMetrics displayMetrics = new DisplayMetrics();
            if (VERSION.SDK_INT >= 16) {
                activity.getWindowManager().getDefaultDisplay().getRealMetrics(displayMetrics);
            } else {
                activity.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
            }
            return Math.min(((float) displayMetrics.widthPixels) / displayMetrics.density, ((float) displayMetrics.heightPixels) / displayMetrics.density);
        }

        @TargetApi(14)
        /* renamed from: a */
        private int m1a(Context context) {
            if (VERSION.SDK_INT < 14) {
                return 0;
            }
            TypedValue typedValue = new TypedValue();
            context.getTheme().resolveAttribute(16843499, typedValue, true);
            return TypedValue.complexToDimensionPixelSize(typedValue.data, context.getResources().getDisplayMetrics());
        }

        /* renamed from: a */
        private int m2a(Resources resources, String str) {
            int identifier = resources.getIdentifier(str, "dimen", "android");
            return identifier > 0 ? resources.getDimensionPixelSize(identifier) : 0;
        }

        @TargetApi(14)
        /* renamed from: b */
        private int m3b(Context context) {
            Resources resources = context.getResources();
            if (VERSION.SDK_INT < 14 || !m5d(context)) {
                return 0;
            }
            return m2a(resources, this.f7h ? "navigation_bar_height" : "navigation_bar_height_landscape");
        }

        @TargetApi(14)
        /* renamed from: c */
        private int m4c(Context context) {
            return (VERSION.SDK_INT < 14 || !m5d(context)) ? 0 : m2a(context.getResources(), "navigation_bar_width");
        }

        @TargetApi(14)
        /* renamed from: d */
        private boolean m5d(Context context) {
            boolean z = true;
            Resources resources = context.getResources();
            int identifier = resources.getIdentifier("config_showNavigationBar", "bool", "android");
            if (identifier != 0) {
                return "1".equals(C0002a.f9a) ? false : "0".equals(C0002a.f9a) ? true : resources.getBoolean(identifier);
            } else {
                if (ViewConfiguration.get(context).hasPermanentMenuKey()) {
                    z = false;
                }
                return z;
            }
        }

        /* renamed from: a */
        public boolean m6a() {
            return this.f8i >= 600.0f || this.f7h;
        }

        /* renamed from: b */
        public int m7b() {
            return this.f2c;
        }

        /* renamed from: c */
        public boolean m8c() {
            return this.f4e;
        }

        /* renamed from: d */
        public int m9d() {
            return this.f5f;
        }

        /* renamed from: e */
        public int m10e() {
            return this.f6g;
        }
    }

    static {
        if (VERSION.SDK_INT >= 19) {
            try {
                Method declaredMethod = Class.forName("android.os.SystemProperties").getDeclaredMethod("get", new Class[]{String.class});
                declaredMethod.setAccessible(true);
                f9a = (String) declaredMethod.invoke(null, new Object[]{"qemu.hw.mainkeys"});
            } catch (Throwable th) {
                f9a = null;
            }
        }
    }

    @TargetApi(19)
    public C0002a(Activity activity) {
        Window window = activity.getWindow();
        ViewGroup viewGroup = (ViewGroup) window.getDecorView();
        if (VERSION.SDK_INT >= 19) {
            TypedArray obtainStyledAttributes = activity.obtainStyledAttributes(new int[]{16843759, 16843760});
            try {
                this.f11c = obtainStyledAttributes.getBoolean(0, false);
                this.f12d = obtainStyledAttributes.getBoolean(1, false);
                LayoutParams attributes = window.getAttributes();
                if ((67108864 & attributes.flags) != 0) {
                    this.f11c = true;
                }
                if ((attributes.flags & 134217728) != 0) {
                    this.f12d = true;
                }
            } finally {
                obtainStyledAttributes.recycle();
            }
        }
        this.f10b = new C0001a(activity, this.f11c, this.f12d);
        if (!this.f10b.m8c()) {
            this.f12d = false;
        }
        if (this.f11c) {
            m12a(activity, viewGroup);
        }
        if (this.f12d) {
            m13b(activity, viewGroup);
        }
    }

    /* renamed from: a */
    private void m12a(Context context, ViewGroup viewGroup) {
        this.f15g = new View(context);
        ViewGroup.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, this.f10b.m7b());
        layoutParams.gravity = 48;
        if (this.f12d && !this.f10b.m6a()) {
            layoutParams.rightMargin = this.f10b.m10e();
        }
        this.f15g.setLayoutParams(layoutParams);
        this.f15g.setBackgroundColor(-1728053248);
        this.f15g.setVisibility(8);
        viewGroup.addView(this.f15g);
    }

    /* renamed from: b */
    private void m13b(Context context, ViewGroup viewGroup) {
        ViewGroup.LayoutParams layoutParams;
        this.f16h = new View(context);
        if (this.f10b.m6a()) {
            layoutParams = new FrameLayout.LayoutParams(-1, this.f10b.m9d());
            layoutParams.gravity = 80;
        } else {
            layoutParams = new FrameLayout.LayoutParams(this.f10b.m10e(), -1);
            layoutParams.gravity = 5;
        }
        this.f16h.setLayoutParams(layoutParams);
        this.f16h.setBackgroundColor(-1728053248);
        this.f16h.setVisibility(8);
        viewGroup.addView(this.f16h);
    }

    /* renamed from: a */
    public void m14a(int i) {
        m16b(i);
        m18c(i);
    }

    /* renamed from: a */
    public void m15a(boolean z) {
        this.f13e = z;
        if (this.f11c) {
            this.f15g.setVisibility(z ? 0 : 8);
        }
    }

    /* renamed from: b */
    public void m16b(int i) {
        if (this.f11c) {
            this.f15g.setBackgroundColor(i);
        }
    }

    /* renamed from: b */
    public void m17b(boolean z) {
        this.f14f = z;
        if (this.f12d) {
            this.f16h.setVisibility(z ? 0 : 8);
        }
    }

    /* renamed from: c */
    public void m18c(int i) {
        if (this.f12d) {
            this.f16h.setBackgroundColor(i);
        }
    }
}
