package ru.zdevs.zarchiver.p004b;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import ru.zdevs.zarchiver.tool.C0166c;

/* renamed from: ru.zdevs.zarchiver.b.b */
public class C0074b extends C0073a {
    /* renamed from: c */
    private static Process f255c;
    /* renamed from: d */
    private static DataOutputStream f256d;
    /* renamed from: e */
    private static DataInputStream f257e;
    /* renamed from: b */
    private final String f258b = getClass().getName();
    /* renamed from: f */
    private int f259f = 0;
    /* renamed from: g */
    private boolean f260g;

    public C0074b() {
        String str = null;
        try {
            f255c = new ProcessBuilder(new String[0]).command(new String[]{"sh"}).redirectErrorStream(true).start();
            f256d = new DataOutputStream(f255c.getOutputStream());
            f257e = new DataInputStream(f255c.getInputStream());
            if (m309a("id")) {
                str = mo50a(false);
            }
            if (str == null || str.length() <= 0 || this.f259f != 0) {
                C0166c.m557b(this.f258b, "Can't get root access or denied by user");
                f255c = null;
                f256d = null;
                f257e = null;
                return;
            }
            C0166c.m558c(this.f258b, "ID: " + str);
        } catch (Throwable e) {
            C0166c.m556a(e);
        }
    }

    /* renamed from: a */
    public int mo49a() {
        return this.f259f;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    /* renamed from: a */
    public java.lang.String mo50a(boolean r7) {
        /*
        r6 = this;
        r1 = 0;
        if (r7 != 0) goto L_0x0027;
    L_0x0003:
        r0 = new java.lang.StringBuilder;
        r0.<init>();
        r2 = r0;
        r0 = r1;
    L_0x000a:
        r1 = r6.f260g;	 Catch:{ Exception -> 0x0020 }
        if (r1 != 0) goto L_0x0024;
    L_0x000e:
        if (r7 == 0) goto L_0x0012;
    L_0x0010:
        if (r0 != 0) goto L_0x0024;
    L_0x0012:
        r1 = f257e;	 Catch:{ Exception -> 0x0020 }
        r1 = r1.available();	 Catch:{ Exception -> 0x0020 }
        if (r1 > 0) goto L_0x002a;
    L_0x001a:
        r4 = 100;
        java.lang.Thread.sleep(r4);	 Catch:{ Exception -> 0x0020 }
        goto L_0x000a;
    L_0x0020:
        r1 = move-exception;
        ru.zdevs.zarchiver.tool.C0166c.m556a(r1);
    L_0x0024:
        if (r7 == 0) goto L_0x00a2;
    L_0x0026:
        return r0;
    L_0x0027:
        r2 = r1;
        r0 = r1;
        goto L_0x000a;
    L_0x002a:
        r1 = f257e;	 Catch:{ Exception -> 0x0020 }
        r1 = r6.m306a(r1);	 Catch:{ Exception -> 0x0020 }
        r3 = r6.f260g;	 Catch:{ Exception -> 0x0020 }
        if (r3 != 0) goto L_0x0024;
    L_0x0034:
        if (r1 == 0) goto L_0x000a;
    L_0x0036:
        r3 = r6.f258b;	 Catch:{ Exception -> 0x0020 }
        r4 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x0020 }
        r4.<init>();	 Catch:{ Exception -> 0x0020 }
        r5 = "LINE: ";
        r4 = r4.append(r5);	 Catch:{ Exception -> 0x0020 }
        r4 = r4.append(r1);	 Catch:{ Exception -> 0x0020 }
        r4 = r4.toString();	 Catch:{ Exception -> 0x0020 }
        ru.zdevs.zarchiver.tool.C0166c.m555a(r3, r4);	 Catch:{ Exception -> 0x0020 }
        r3 = "#@#[";
        r3 = r1.startsWith(r3);	 Catch:{ Exception -> 0x0020 }
        if (r3 == 0) goto L_0x0093;
    L_0x0056:
        r3 = "]#@#";
        r3 = r1.endsWith(r3);	 Catch:{ Exception -> 0x0020 }
        if (r3 == 0) goto L_0x0093;
    L_0x005e:
        r3 = 1;
        r6.f260g = r3;	 Catch:{ Exception -> 0x0020 }
        r3 = 4;
        r4 = r1.length();	 Catch:{ Exception -> 0x008e }
        r4 = r4 + -4;
        r1 = r1.substring(r3, r4);	 Catch:{ Exception -> 0x008e }
        r1 = java.lang.Integer.parseInt(r1);	 Catch:{ Exception -> 0x008e }
        r6.f259f = r1;	 Catch:{ Exception -> 0x008e }
    L_0x0072:
        r1 = r6.f258b;	 Catch:{ Exception -> 0x0020 }
        r3 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x0020 }
        r3.<init>();	 Catch:{ Exception -> 0x0020 }
        r4 = "result: ";
        r3 = r3.append(r4);	 Catch:{ Exception -> 0x0020 }
        r4 = r6.f259f;	 Catch:{ Exception -> 0x0020 }
        r3 = r3.append(r4);	 Catch:{ Exception -> 0x0020 }
        r3 = r3.toString();	 Catch:{ Exception -> 0x0020 }
        ru.zdevs.zarchiver.tool.C0166c.m555a(r1, r3);	 Catch:{ Exception -> 0x0020 }
        goto L_0x000a;
    L_0x008e:
        r1 = move-exception;
        r1 = -1;
        r6.f259f = r1;	 Catch:{ Exception -> 0x0020 }
        goto L_0x0072;
    L_0x0093:
        if (r7 == 0) goto L_0x0098;
    L_0x0095:
        r0 = r1;
        goto L_0x000a;
    L_0x0098:
        r2.append(r1);	 Catch:{ Exception -> 0x0020 }
        r1 = 10;
        r2.append(r1);	 Catch:{ Exception -> 0x0020 }
        goto L_0x000a;
    L_0x00a2:
        r0 = r2.toString();
        goto L_0x0026;
        */
        throw new UnsupportedOperationException("Method not decompiled: ru.zdevs.zarchiver.b.b.a(boolean):java.lang.String");
    }

    /* renamed from: a */
    public boolean mo51a(String str, int i) {
        this.f260g = false;
        this.f259f = -1;
        while (f257e.available() > 0) {
            try {
                f257e.skip((long) f257e.available());
            } catch (Throwable e) {
                C0166c.m556a(e);
                this.f260g = true;
                return false;
            }
        }
        String str2 = str + " ; echo -e \"\\n#@#[$?]#@#\\n\" \r\n";
        C0166c.m558c(this.f258b, ">" + str2);
        f256d.write(str2.getBytes("UTF-8"));
        f256d.flush();
        C0166c.m555a(this.f258b, "Wait...");
        int i2 = i * 100;
        while (f257e.available() < 2) {
            Thread.sleep(10);
            i2--;
            if (i2 <= 0) {
                break;
            }
        }
        C0166c.m555a(this.f258b, "Wait end!");
        return i2 > 0;
    }

    /* renamed from: b */
    public boolean mo52b() {
        return (f255c == null || f256d == null || f257e == null) ? false : true;
    }

    /* renamed from: b */
    public boolean mo53b(String str) {
        if (this.f260g) {
            return false;
        }
        try {
            String str2 = str + "\r\n";
            C0166c.m558c(this.f258b, ">" + str2);
            f256d.write(str2.getBytes("UTF-8"));
            f256d.flush();
            return true;
        } catch (Throwable e) {
            C0166c.m556a(e);
            return false;
        }
    }

    /* renamed from: c */
    public void mo54c() {
        if (this.f260g) {
            this.f260g = false;
        }
        try {
            if (f256d != null) {
                f256d.close();
                f256d = null;
            }
            if (f257e != null) {
                f257e.close();
                f257e = null;
            }
            if (f255c != null) {
                f255c.destroy();
                f255c = null;
            }
        } catch (Throwable e) {
            C0166c.m556a(e);
        }
    }
}
