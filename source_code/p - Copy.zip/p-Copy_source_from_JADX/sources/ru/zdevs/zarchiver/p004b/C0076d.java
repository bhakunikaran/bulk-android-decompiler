package ru.zdevs.zarchiver.p004b;

/* renamed from: ru.zdevs.zarchiver.b.d */
public class C0076d {
    /* renamed from: a */
    public static boolean m331a(C0073a c0073a, String str, int i) {
        if (str == null) {
            return false;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("chmod ");
        stringBuilder.append(i);
        stringBuilder.append(" '");
        stringBuilder.append(str);
        stringBuilder.append('\'');
        if (!c0073a.m309a(stringBuilder.toString())) {
            return false;
        }
        c0073a.mo50a(false);
        return c0073a.mo49a() == 0;
    }
}
