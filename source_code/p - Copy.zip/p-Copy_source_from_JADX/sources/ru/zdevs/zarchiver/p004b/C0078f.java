package ru.zdevs.zarchiver.p004b;

import android.annotation.SuppressLint;
import android.util.Log;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import ru.zdevs.zarchiver.tool.C0166c;

/* renamed from: ru.zdevs.zarchiver.b.f */
public class C0078f {
    @SuppressLint({"SdCardPath"})
    /* renamed from: a */
    private static final String[] f267a = new String[]{"/data/data/ru.zdevs.zarchiver/lib/libcoreutils.so", "/system/lib/ru.zdevs.zarchiver/libcoreutils.so", "/system/lib/libcoreutils.so"};
    /* renamed from: b */
    private static String f268b = null;
    /* renamed from: c */
    private static boolean f269c = false;
    /* renamed from: d */
    private static boolean f270d = false;

    /* renamed from: a */
    static int m333a(String str) {
        try {
            return Integer.parseInt(str);
        } catch (Throwable e) {
            C0166c.m556a(e);
            return 0;
        }
    }

    /* renamed from: a */
    static String m334a() {
        if (f268b == null) {
            int read;
            File file = null;
            for (String str : f267a) {
                f268b = str;
                file = new File(str);
                if (file.exists()) {
                    break;
                }
            }
            if (!(file == null || file.canExecute())) {
                f268b = "/data/data/ru.zdevs.zarchiver/bin/coreutils";
                File file2 = new File("/data/data/ru.zdevs.zarchiver/bin/coreutils");
                if (!(file2.exists() && file2.length() == file.length())) {
                    file2.getParentFile().mkdirs();
                    byte[] bArr = new byte[1024];
                    try {
                        InputStream fileInputStream = new FileInputStream(file);
                        OutputStream fileOutputStream = new FileOutputStream(file2);
                        while (true) {
                            read = fileInputStream.read(bArr);
                            if (read <= 0) {
                                break;
                            }
                            fileOutputStream.write(bArr, 0, read);
                        }
                        fileInputStream.close();
                        fileOutputStream.close();
                    } catch (Throwable e) {
                        C0166c.m556a(e);
                    }
                    C0074b c0074b = new C0074b();
                    c0074b.m309a("chmod 755 '/data/data/ru.zdevs.zarchiver/bin/coreutils'");
                    c0074b.mo54c();
                }
            }
        }
        return f268b;
    }

    /* renamed from: b */
    static long m335b(String str) {
        try {
            return Long.parseLong(str);
        } catch (Throwable e) {
            C0166c.m556a(e);
            return 0;
        }
    }

    /* renamed from: b */
    static boolean m336b() {
        if (!f270d) {
            File file = new File(C0078f.m334a());
            if (file.exists() && file.canExecute()) {
                f269c = true;
            }
            f270d = true;
            if (!f269c) {
                Log.w("cpInternal", "Internal operation don't supported!");
            }
        }
        return f269c;
    }
}
