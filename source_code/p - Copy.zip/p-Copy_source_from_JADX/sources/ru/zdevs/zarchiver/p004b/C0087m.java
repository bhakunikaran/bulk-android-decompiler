package ru.zdevs.zarchiver.p004b;

/* renamed from: ru.zdevs.zarchiver.b.m */
public class C0087m {
    /* renamed from: a */
    public static boolean m353a(C0073a c0073a, String str, boolean z) {
        if (str == null) {
            return false;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("rm ");
        if (z) {
            stringBuilder.append("-r");
        }
        stringBuilder.append(" '");
        stringBuilder.append(str);
        stringBuilder.append('\'');
        if (!c0073a.m309a(stringBuilder.toString())) {
            return false;
        }
        c0073a.mo50a(false);
        return c0073a.mo49a() == 0;
    }
}
