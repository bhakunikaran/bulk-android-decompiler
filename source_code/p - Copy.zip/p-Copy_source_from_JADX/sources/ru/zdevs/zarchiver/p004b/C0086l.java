package ru.zdevs.zarchiver.p004b;

import android.annotation.SuppressLint;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import ru.zdevs.zarchiver.tool.C0166c;

/* renamed from: ru.zdevs.zarchiver.b.l */
public class C0086l {
    @SuppressLint({"SdCardPath"})
    /* renamed from: a */
    private static final String[] f284a = new String[]{"/data/data/ru.zdevs.zarchiver/lib/libp7zbin.so", "/system/lib/ru.zdevs.zarchiver/libp7zbin.so", "/system/lib/libp7zbin.so"};
    /* renamed from: b */
    private static String f285b = null;

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    /* renamed from: a */
    private static byte m345a(ru.zdevs.zarchiver.p004b.C0073a r12) {
        /*
        r9 = 0;
    L_0x0001:
        r0 = 1;
        r0 = r12.mo50a(r0);	 Catch:{ Exception -> 0x01fe }
        if (r0 == 0) goto L_0x0186;
    L_0x0008:
        r1 = "p7zip";
        r2 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x01fe }
        r2.<init>();	 Catch:{ Exception -> 0x01fe }
        r3 = "Get line: ";
        r2 = r2.append(r3);	 Catch:{ Exception -> 0x01fe }
        r2 = r2.append(r0);	 Catch:{ Exception -> 0x01fe }
        r2 = r2.toString();	 Catch:{ Exception -> 0x01fe }
        ru.zdevs.zarchiver.tool.C0166c.m555a(r1, r2);	 Catch:{ Exception -> 0x01fe }
        r1 = r0.length();	 Catch:{ Exception -> 0x01fe }
        if (r1 <= 0) goto L_0x0001;
    L_0x0026:
        r1 = 0;
        r1 = r0.charAt(r1);	 Catch:{ Exception -> 0x01fe }
        r2 = 126; // 0x7e float:1.77E-43 double:6.23E-322;
        if (r1 != r2) goto L_0x0001;
    L_0x002f:
        r1 = 9;
        r8 = ru.zdevs.zarchiver.tool.C0202q.m734a(r0, r1);	 Catch:{ Exception -> 0x01fe }
        r0 = r8.length;	 Catch:{ Exception -> 0x01fe }
        r1 = 2;
        if (r0 < r1) goto L_0x0001;
    L_0x0039:
        r0 = 1;
        r0 = r8[r0];	 Catch:{ Exception -> 0x01fe }
        if (r0 == 0) goto L_0x0001;
    L_0x003e:
        r0 = 1;
        r1 = r8[r0];	 Catch:{ Exception -> 0x01fe }
        r0 = -1;
        r2 = r1.hashCode();	 Catch:{ Exception -> 0x01fe }
        switch(r2) {
            case 77: goto L_0x0077;
            case 2085: goto L_0x0081;
            case 2094: goto L_0x0063;
            case 2281: goto L_0x008b;
            case 2560: goto L_0x0059;
            case 2564: goto L_0x004f;
            case 2671: goto L_0x006d;
            default: goto L_0x0049;
        };	 Catch:{ Exception -> 0x01fe }
    L_0x0049:
        switch(r0) {
            case 0: goto L_0x0095;
            case 1: goto L_0x00a1;
            case 2: goto L_0x00b1;
            case 3: goto L_0x0165;
            case 4: goto L_0x0189;
            case 5: goto L_0x01b3;
            case 6: goto L_0x01d5;
            default: goto L_0x004c;
        };	 Catch:{ Exception -> 0x01fe }
    L_0x004c:
        r0 = r9;
    L_0x004d:
        r9 = r0;
        goto L_0x0001;
    L_0x004f:
        r2 = "PT";
        r1 = r1.equals(r2);	 Catch:{ Exception -> 0x01fe }
        if (r1 == 0) goto L_0x0049;
    L_0x0057:
        r0 = 0;
        goto L_0x0049;
    L_0x0059:
        r2 = "PP";
        r1 = r1.equals(r2);	 Catch:{ Exception -> 0x01fe }
        if (r1 == 0) goto L_0x0049;
    L_0x0061:
        r0 = 1;
        goto L_0x0049;
    L_0x0063:
        r2 = "AO";
        r1 = r1.equals(r2);	 Catch:{ Exception -> 0x01fe }
        if (r1 == 0) goto L_0x0049;
    L_0x006b:
        r0 = 2;
        goto L_0x0049;
    L_0x006d:
        r2 = "TC";
        r1 = r1.equals(r2);	 Catch:{ Exception -> 0x01fe }
        if (r1 == 0) goto L_0x0049;
    L_0x0075:
        r0 = 3;
        goto L_0x0049;
    L_0x0077:
        r2 = "M";
        r1 = r1.equals(r2);	 Catch:{ Exception -> 0x01fe }
        if (r1 == 0) goto L_0x0049;
    L_0x007f:
        r0 = 4;
        goto L_0x0049;
    L_0x0081:
        r2 = "AF";
        r1 = r1.equals(r2);	 Catch:{ Exception -> 0x01fe }
        if (r1 == 0) goto L_0x0049;
    L_0x0089:
        r0 = 5;
        goto L_0x0049;
    L_0x008b:
        r2 = "GP";
        r1 = r1.equals(r2);	 Catch:{ Exception -> 0x01fe }
        if (r1 == 0) goto L_0x0049;
    L_0x0093:
        r0 = 6;
        goto L_0x0049;
    L_0x0095:
        r0 = r12.m315d();	 Catch:{ Exception -> 0x01fe }
        r1 = 2;
        r1 = r8[r1];	 Catch:{ Exception -> 0x01fe }
        ru.zdevs.zarchiver.archiver.C2JBridge.jSetProcessText(r0, r1);	 Catch:{ Exception -> 0x01fe }
        r0 = r9;
        goto L_0x004d;
    L_0x00a1:
        r0 = r12.m315d();	 Catch:{ Exception -> 0x01fe }
        r1 = 2;
        r1 = r8[r1];	 Catch:{ Exception -> 0x01fe }
        r1 = ru.zdevs.zarchiver.p004b.C0078f.m333a(r1);	 Catch:{ Exception -> 0x01fe }
        ru.zdevs.zarchiver.archiver.C2JBridge.jSetProcessPercent(r0, r1);	 Catch:{ Exception -> 0x01fe }
        r0 = r9;
        goto L_0x004d;
    L_0x00b1:
        r0 = r8.length;	 Catch:{ Exception -> 0x01fe }
        r1 = 7;
        if (r0 >= r1) goto L_0x00b7;
    L_0x00b5:
        r0 = r9;
        goto L_0x004d;
    L_0x00b7:
        r10 = 8;
        r0 = r12.m315d();	 Catch:{ Exception -> 0x015f }
        r1 = 6;
        r1 = r8[r1];	 Catch:{ Exception -> 0x015f }
        r2 = 2;
        r2 = r8[r2];	 Catch:{ Exception -> 0x015f }
        r2 = ru.zdevs.zarchiver.p004b.C0078f.m335b(r2);	 Catch:{ Exception -> 0x015f }
        r4 = 3;
        r4 = r8[r4];	 Catch:{ Exception -> 0x015f }
        r4 = ru.zdevs.zarchiver.p004b.C0078f.m333a(r4);	 Catch:{ Exception -> 0x015f }
        r5 = 6;
        r5 = r8[r5];	 Catch:{ Exception -> 0x015f }
        r6 = 4;
        r6 = r8[r6];	 Catch:{ Exception -> 0x015f }
        r6 = ru.zdevs.zarchiver.p004b.C0078f.m335b(r6);	 Catch:{ Exception -> 0x015f }
        r11 = 5;
        r8 = r8[r11];	 Catch:{ Exception -> 0x015f }
        r8 = ru.zdevs.zarchiver.p004b.C0078f.m333a(r8);	 Catch:{ Exception -> 0x015f }
        r0 = ru.zdevs.zarchiver.archiver.C2JBridge.jAskOverwrite(r0, r1, r2, r4, r5, r6, r8);	 Catch:{ Exception -> 0x015f }
        r1 = r0;
    L_0x00e4:
        r0 = "$";
        r2 = r1 & 1;
        if (r2 == 0) goto L_0x00fd;
    L_0x00ea:
        r2 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x01fe }
        r2.<init>();	 Catch:{ Exception -> 0x01fe }
        r0 = r2.append(r0);	 Catch:{ Exception -> 0x01fe }
        r2 = 89;
        r0 = r0.append(r2);	 Catch:{ Exception -> 0x01fe }
        r0 = r0.toString();	 Catch:{ Exception -> 0x01fe }
    L_0x00fd:
        r2 = r1 & 2;
        if (r2 == 0) goto L_0x0114;
    L_0x0101:
        r2 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x01fe }
        r2.<init>();	 Catch:{ Exception -> 0x01fe }
        r0 = r2.append(r0);	 Catch:{ Exception -> 0x01fe }
        r2 = 78;
        r0 = r0.append(r2);	 Catch:{ Exception -> 0x01fe }
        r0 = r0.toString();	 Catch:{ Exception -> 0x01fe }
    L_0x0114:
        r2 = r1 & 8;
        if (r2 == 0) goto L_0x012b;
    L_0x0118:
        r2 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x01fe }
        r2.<init>();	 Catch:{ Exception -> 0x01fe }
        r0 = r2.append(r0);	 Catch:{ Exception -> 0x01fe }
        r2 = 67;
        r0 = r0.append(r2);	 Catch:{ Exception -> 0x01fe }
        r0 = r0.toString();	 Catch:{ Exception -> 0x01fe }
    L_0x012b:
        r2 = r1 & 4;
        if (r2 == 0) goto L_0x0142;
    L_0x012f:
        r2 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x01fe }
        r2.<init>();	 Catch:{ Exception -> 0x01fe }
        r0 = r2.append(r0);	 Catch:{ Exception -> 0x01fe }
        r2 = 82;
        r0 = r0.append(r2);	 Catch:{ Exception -> 0x01fe }
        r0 = r0.toString();	 Catch:{ Exception -> 0x01fe }
    L_0x0142:
        r1 = r1 & 16;
        if (r1 == 0) goto L_0x0159;
    L_0x0146:
        r1 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x01fe }
        r1.<init>();	 Catch:{ Exception -> 0x01fe }
        r0 = r1.append(r0);	 Catch:{ Exception -> 0x01fe }
        r1 = 65;
        r0 = r0.append(r1);	 Catch:{ Exception -> 0x01fe }
        r0 = r0.toString();	 Catch:{ Exception -> 0x01fe }
    L_0x0159:
        r12.mo53b(r0);	 Catch:{ Exception -> 0x01fe }
        r0 = r9;
        goto L_0x004d;
    L_0x015f:
        r0 = move-exception;
        ru.zdevs.zarchiver.tool.C0166c.m556a(r0);	 Catch:{ Exception -> 0x01fe }
        r1 = r10;
        goto L_0x00e4;
    L_0x0165:
        r0 = 2;
        r0 = r8[r0];	 Catch:{ Exception -> 0x01fe }
        r0 = ru.zdevs.zarchiver.p004b.C0078f.m333a(r0);	 Catch:{ Exception -> 0x01fe }
        r0 = r0 + 1;
        r0 = (byte) r0;
        r1 = 1;
        if (r0 == r1) goto L_0x0173;
    L_0x0172:
        r0 = 2;
    L_0x0173:
        r2 = r12.m315d();	 Catch:{ Exception -> 0x0180 }
        r1 = 2;
        if (r0 != r1) goto L_0x0187;
    L_0x017a:
        r1 = 1;
    L_0x017b:
        ru.zdevs.zarchiver.archiver.C2JBridge.jSetTaskCompleted(r2, r1);	 Catch:{ Exception -> 0x0180 }
        goto L_0x004d;
    L_0x0180:
        r1 = move-exception;
        r9 = r0;
        r0 = r1;
    L_0x0183:
        ru.zdevs.zarchiver.tool.C0166c.m556a(r0);
    L_0x0186:
        return r9;
    L_0x0187:
        r1 = 0;
        goto L_0x017b;
    L_0x0189:
        r2 = r12.m315d();	 Catch:{ Exception -> 0x01fe }
        r0 = 2;
        r0 = r8[r0];	 Catch:{ Exception -> 0x01fe }
        r3 = ru.zdevs.zarchiver.p004b.C0078f.m333a(r0);	 Catch:{ Exception -> 0x01fe }
        r0 = r8.length;	 Catch:{ Exception -> 0x01fe }
        r1 = 4;
        if (r0 <= r1) goto L_0x01ad;
    L_0x0198:
        r0 = 4;
        r0 = r8[r0];	 Catch:{ Exception -> 0x01fe }
        r1 = r0;
    L_0x019c:
        r0 = 3;
        r0 = r8[r0];	 Catch:{ Exception -> 0x01fe }
        r0 = ru.zdevs.zarchiver.p004b.C0078f.m333a(r0);	 Catch:{ Exception -> 0x01fe }
        r4 = 1;
        if (r0 != r4) goto L_0x01b1;
    L_0x01a6:
        r0 = 1;
    L_0x01a7:
        ru.zdevs.zarchiver.archiver.C2JBridge.jShowMessage(r2, r3, r1, r0);	 Catch:{ Exception -> 0x01fe }
        r0 = r9;
        goto L_0x004d;
    L_0x01ad:
        r0 = "";
        r1 = r0;
        goto L_0x019c;
    L_0x01b1:
        r0 = 0;
        goto L_0x01a7;
    L_0x01b3:
        r0 = r12.m315d();	 Catch:{ Exception -> 0x01fe }
        r1 = 5;
        r1 = r8[r1];	 Catch:{ Exception -> 0x01fe }
        r2 = 2;
        r2 = r8[r2];	 Catch:{ Exception -> 0x01fe }
        r2 = ru.zdevs.zarchiver.p004b.C0078f.m335b(r2);	 Catch:{ Exception -> 0x01fe }
        r4 = 3;
        r4 = r8[r4];	 Catch:{ Exception -> 0x01fe }
        r4 = ru.zdevs.zarchiver.p004b.C0078f.m333a(r4);	 Catch:{ Exception -> 0x01fe }
        r5 = 4;
        r5 = r8[r5];	 Catch:{ Exception -> 0x01fe }
        r5 = ru.zdevs.zarchiver.p004b.C0078f.m333a(r5);	 Catch:{ Exception -> 0x01fe }
        ru.zdevs.zarchiver.archiver.C2JBridge.jAddFileToList(r0, r1, r2, r4, r5);	 Catch:{ Exception -> 0x01fe }
        r0 = r9;
        goto L_0x004d;
    L_0x01d5:
        r1 = "";
        r0 = r12.m315d();	 Catch:{ Exception -> 0x01f8 }
        r0 = ru.zdevs.zarchiver.archiver.C2JBridge.jGetPassword(r0);	 Catch:{ Exception -> 0x01f8 }
    L_0x01df:
        r1 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x01fe }
        r1.<init>();	 Catch:{ Exception -> 0x01fe }
        r2 = "#";
        r1 = r1.append(r2);	 Catch:{ Exception -> 0x01fe }
        r0 = r1.append(r0);	 Catch:{ Exception -> 0x01fe }
        r0 = r0.toString();	 Catch:{ Exception -> 0x01fe }
        r12.mo53b(r0);	 Catch:{ Exception -> 0x01fe }
        r0 = r9;
        goto L_0x004d;
    L_0x01f8:
        r0 = move-exception;
        ru.zdevs.zarchiver.tool.C0166c.m556a(r0);	 Catch:{ Exception -> 0x01fe }
        r0 = r1;
        goto L_0x01df;
    L_0x01fe:
        r0 = move-exception;
        goto L_0x0183;
        */
        throw new UnsupportedOperationException("Method not decompiled: ru.zdevs.zarchiver.b.l.a(ru.zdevs.zarchiver.b.a):byte");
    }

    /* renamed from: a */
    private static String m346a() {
        if (f285b == null) {
            int read;
            File file = null;
            for (String str : f284a) {
                f285b = str;
                file = new File(str);
                if (file.exists()) {
                    break;
                }
            }
            if (!(file == null || file.canExecute())) {
                f285b = "/data/data/ru.zdevs.zarchiver/bin/p7zbin";
                File file2 = new File("/data/data/ru.zdevs.zarchiver/bin/p7zbin");
                if (!(file2.exists() && file2.length() == file.length())) {
                    file2.getParentFile().mkdirs();
                    try {
                        InputStream fileInputStream = new FileInputStream(file);
                        OutputStream fileOutputStream = new FileOutputStream(file2);
                        byte[] bArr = new byte[1024];
                        while (true) {
                            read = fileInputStream.read(bArr);
                            if (read <= 0) {
                                break;
                            }
                            fileOutputStream.write(bArr, 0, read);
                        }
                        fileInputStream.close();
                        fileOutputStream.close();
                    } catch (Throwable e) {
                        C0166c.m556a(e);
                    }
                    C0074b c0074b = new C0074b();
                    c0074b.m309a("chmod 755 '/data/data/ru.zdevs.zarchiver/bin/p7zbin'");
                    c0074b.mo54c();
                }
            }
        }
        return f285b;
    }

    /* renamed from: a */
    public static boolean m347a(C0073a c0073a, String str, String str2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(C0086l.m346a());
        stringBuilder.append(" t '");
        stringBuilder.append(str);
        stringBuilder.append("' ");
        stringBuilder.append(str2);
        return c0073a.m309a(stringBuilder.toString()) && C0086l.m345a(c0073a) == (byte) 2;
    }

    /* renamed from: a */
    public static boolean m348a(C0073a c0073a, String str, String str2, String str3, String str4) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(C0086l.m346a());
        stringBuilder.append(" a '");
        stringBuilder.append(str);
        stringBuilder.append("' ");
        stringBuilder.append(str2);
        stringBuilder.append(" -- ");
        stringBuilder.append(str3);
        if (!c0073a.m309a("cd " + str4)) {
            return false;
        }
        c0073a.mo50a(false);
        return c0073a.m309a(stringBuilder.toString()) && C0086l.m345a(c0073a) == (byte) 2;
    }

    /* renamed from: a */
    public static boolean m349a(C0073a c0073a, String str, String str2, String str3, String str4, boolean z) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(C0086l.m346a());
        stringBuilder.append(z ? " xp '" : " x '");
        stringBuilder.append(str);
        stringBuilder.append("' ");
        stringBuilder.append(str2);
        stringBuilder.append(" '-o");
        stringBuilder.append(str4);
        stringBuilder.append("' -- ");
        stringBuilder.append(str3);
        if (!c0073a.m309a("cd " + str4)) {
            return false;
        }
        c0073a.mo50a(false);
        if (!c0073a.m309a(stringBuilder.toString())) {
            return false;
        }
        return C0086l.m345a(c0073a) == (byte) 2;
    }

    /* renamed from: a */
    public static boolean m350a(C0073a c0073a, String str, String str2, boolean z) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(C0086l.m346a());
        stringBuilder.append(z ? " lp '" : " l '");
        stringBuilder.append(str);
        stringBuilder.append("' ");
        stringBuilder.append(str2);
        if (!c0073a.m309a(stringBuilder.toString())) {
            return false;
        }
        return C0086l.m345a(c0073a) == (byte) 2;
    }

    /* renamed from: a */
    public static boolean m351a(C0073a c0073a, boolean z, String str, String str2, String str3, String str4) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(C0086l.m346a());
        stringBuilder.append(z ? " a '" : " d '");
        stringBuilder.append(str);
        stringBuilder.append("' ");
        stringBuilder.append(str2);
        stringBuilder.append(" -- ");
        stringBuilder.append(str3);
        if (!c0073a.m309a("cd " + str4)) {
            return false;
        }
        c0073a.mo50a(false);
        if (!c0073a.m309a(stringBuilder.toString())) {
            return false;
        }
        return C0086l.m345a(c0073a) == (byte) 2;
    }

    /* renamed from: b */
    public static boolean m352b(C0073a c0073a, String str, String str2, String str3, String str4) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(C0086l.m346a());
        stringBuilder.append(" t '");
        stringBuilder.append(str);
        stringBuilder.append("' ");
        stringBuilder.append(str2);
        stringBuilder.append(" -- ");
        stringBuilder.append(str3);
        stringBuilder.append(str4);
        return c0073a.m309a(stringBuilder.toString()) && C0086l.m345a(c0073a) == (byte) 2;
    }
}
