package ru.zdevs.zarchiver.p004b;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import ru.zdevs.zarchiver.tool.C0166c;

/* renamed from: ru.zdevs.zarchiver.b.c */
public class C0075c extends C0073a {
    /* renamed from: c */
    private static Process f261c;
    /* renamed from: d */
    private static DataOutputStream f262d;
    /* renamed from: e */
    private static DataInputStream f263e;
    /* renamed from: b */
    private final String f264b;
    /* renamed from: f */
    private int f265f;
    /* renamed from: g */
    private boolean f266g;

    public C0075c() {
        this(false);
    }

    public C0075c(boolean z) {
        String str = null;
        this.f264b = getClass().getName();
        this.f265f = 0;
        String str2 = "su";
        try {
            f261c = new ProcessBuilder(new String[0]).command(new String[]{str2}).redirectErrorStream(true).start();
            f262d = new DataOutputStream(f261c.getOutputStream());
            f263e = new DataInputStream(f261c.getInputStream());
            if (m327a("id", 600, true)) {
                str = m325a(false, true);
            }
            if (str == null || str.length() <= 0 || this.f265f != 0) {
                C0166c.m557b(this.f264b, "Can't get root access or denied by user");
                f261c = null;
                f262d = null;
                f263e = null;
                return;
            }
            C0166c.m558c(this.f264b, "ID: " + str);
        } catch (Throwable e) {
            C0166c.m556a(e);
        }
    }

    /* renamed from: a */
    public int mo49a() {
        return this.f265f;
    }

    /* renamed from: a */
    public String mo50a(boolean z) {
        return m325a(z, false);
    }

    /* renamed from: a */
    public String m325a(boolean z, boolean z2) {
        String str;
        int i;
        StringBuilder stringBuilder;
        if (z) {
            str = null;
            i = 0;
            stringBuilder = null;
        } else {
            i = 0;
            stringBuilder = new StringBuilder();
            str = null;
        }
        while (!this.f266g && (!z || str == null)) {
            if (f263e.available() > 0) {
                String a = m306a(f263e);
                if (this.f266g) {
                    break;
                } else if (a != null) {
                    C0166c.m555a(this.f264b, "LINE: " + a);
                    if (a.startsWith("#@#[") && a.endsWith("]#@#")) {
                        this.f266g = true;
                        try {
                            this.f265f = Integer.parseInt(a.substring(4, a.length() - 4));
                        } catch (Exception e) {
                            this.f265f = -1;
                        }
                        try {
                            C0166c.m555a(this.f264b, "result: " + this.f265f);
                        } catch (Throwable e2) {
                            C0166c.m556a(e2);
                        }
                    } else if (z) {
                        str = a;
                    } else {
                        stringBuilder.append(a);
                        stringBuilder.append('\n');
                    }
                } else {
                    continue;
                }
            } else {
                Thread.sleep(100);
                int i2 = i + 1;
                if (z2 && i2 > 2) {
                    C0166c.m557b(this.f264b, "Timeout error!");
                    this.f265f = -1;
                    break;
                }
                i = i2;
            }
        }
        return z ? str : stringBuilder.toString();
    }

    /* renamed from: a */
    public boolean mo51a(String str, int i) {
        return m327a(str, i, false);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    /* renamed from: a */
    public boolean m327a(java.lang.String r7, int r8, boolean r9) {
        /*
        r6 = this;
        r0 = 1;
        r1 = 0;
        r6.f266g = r1;
        r2 = -1;
        r6.f265f = r2;
    L_0x0007:
        r2 = f263e;	 Catch:{ Exception -> 0x001c }
        r2 = r2.available();	 Catch:{ Exception -> 0x001c }
        if (r2 <= 0) goto L_0x0025;
    L_0x000f:
        r2 = f263e;	 Catch:{ Exception -> 0x001c }
        r3 = f263e;	 Catch:{ Exception -> 0x001c }
        r3 = r3.available();	 Catch:{ Exception -> 0x001c }
        r4 = (long) r3;	 Catch:{ Exception -> 0x001c }
        r2.skip(r4);	 Catch:{ Exception -> 0x001c }
        goto L_0x0007;
    L_0x001c:
        r2 = move-exception;
        if (r9 != 0) goto L_0x0022;
    L_0x001f:
        ru.zdevs.zarchiver.tool.C0166c.m556a(r2);
    L_0x0022:
        r6.f266g = r0;
    L_0x0024:
        return r1;
    L_0x0025:
        r2 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x001c }
        r2.<init>();	 Catch:{ Exception -> 0x001c }
        r2 = r2.append(r7);	 Catch:{ Exception -> 0x001c }
        r3 = " ; echo -e \"\\n#@#[$?]#@#\\n\" \r\n";
        r2 = r2.append(r3);	 Catch:{ Exception -> 0x001c }
        r2 = r2.toString();	 Catch:{ Exception -> 0x001c }
        r3 = r6.f264b;	 Catch:{ Exception -> 0x001c }
        r4 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x001c }
        r4.<init>();	 Catch:{ Exception -> 0x001c }
        r5 = ">";
        r4 = r4.append(r5);	 Catch:{ Exception -> 0x001c }
        r4 = r4.append(r2);	 Catch:{ Exception -> 0x001c }
        r4 = r4.toString();	 Catch:{ Exception -> 0x001c }
        ru.zdevs.zarchiver.tool.C0166c.m558c(r3, r4);	 Catch:{ Exception -> 0x001c }
        r3 = f262d;	 Catch:{ Exception -> 0x001c }
        r4 = "UTF-8";
        r2 = r2.getBytes(r4);	 Catch:{ Exception -> 0x001c }
        r3.write(r2);	 Catch:{ Exception -> 0x001c }
        r2 = f262d;	 Catch:{ Exception -> 0x001c }
        r2.flush();	 Catch:{ Exception -> 0x001c }
        r2 = r6.f264b;	 Catch:{ Exception -> 0x001c }
        r3 = "Wait...";
        ru.zdevs.zarchiver.tool.C0166c.m555a(r2, r3);	 Catch:{ Exception -> 0x001c }
        r2 = r8 * 100;
    L_0x0069:
        r4 = 10;
        java.lang.Thread.sleep(r4);	 Catch:{ Exception -> 0x001c }
        r3 = f263e;	 Catch:{ Exception -> 0x001c }
        r3 = r3.available();	 Catch:{ Exception -> 0x001c }
        r4 = 2;
        if (r3 >= r4) goto L_0x007b;
    L_0x0077:
        r2 = r2 + -1;
        if (r2 > 0) goto L_0x0097;
    L_0x007b:
        r3 = r6.f264b;	 Catch:{ Exception -> 0x001c }
        r4 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x001c }
        r4.<init>();	 Catch:{ Exception -> 0x001c }
        r5 = "Wait end! Timeout: ";
        r4 = r4.append(r5);	 Catch:{ Exception -> 0x001c }
        r4 = r4.append(r2);	 Catch:{ Exception -> 0x001c }
        r4 = r4.toString();	 Catch:{ Exception -> 0x001c }
        ru.zdevs.zarchiver.tool.C0166c.m555a(r3, r4);	 Catch:{ Exception -> 0x001c }
        if (r2 <= 0) goto L_0x00a2;
    L_0x0095:
        r1 = r0;
        goto L_0x0024;
    L_0x0097:
        r3 = f261c;	 Catch:{ IllegalThreadStateException -> 0x00a0 }
        r3.exitValue();	 Catch:{ IllegalThreadStateException -> 0x00a0 }
        r3 = 1;
        r6.f266g = r3;	 Catch:{ IllegalThreadStateException -> 0x00a0 }
        goto L_0x0024;
    L_0x00a0:
        r3 = move-exception;
        goto L_0x0069;
    L_0x00a2:
        r0 = r1;
        goto L_0x0095;
        */
        throw new UnsupportedOperationException("Method not decompiled: ru.zdevs.zarchiver.b.c.a(java.lang.String, int, boolean):boolean");
    }

    /* renamed from: b */
    public boolean mo52b() {
        return (f261c == null || f262d == null || f263e == null) ? false : true;
    }

    /* renamed from: b */
    public boolean mo53b(String str) {
        if (this.f266g) {
            return false;
        }
        try {
            String str2 = str + "\r\n";
            C0166c.m558c(this.f264b, ">" + str2);
            f262d.write(str2.getBytes("UTF-8"));
            f262d.flush();
            return true;
        } catch (Throwable e) {
            C0166c.m556a(e);
            return false;
        }
    }

    /* renamed from: c */
    public void mo54c() {
        if (this.f266g) {
            this.f266g = false;
        }
        try {
            if (f262d != null) {
                f262d.close();
                f262d = null;
            }
            if (f263e != null) {
                f263e.close();
                f263e = null;
            }
            if (f261c != null) {
                f261c.destroy();
                f261c = null;
            }
        } catch (Throwable e) {
            C0166c.m556a(e);
        }
    }
}
