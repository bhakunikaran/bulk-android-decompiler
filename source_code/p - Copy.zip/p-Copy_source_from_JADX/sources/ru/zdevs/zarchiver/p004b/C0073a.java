package ru.zdevs.zarchiver.p004b;

import java.io.DataInputStream;
import ru.zdevs.zarchiver.widget.bottomsheet.ViewDragHelper;

/* renamed from: ru.zdevs.zarchiver.b.a */
public class C0073a {
    /* renamed from: a */
    protected static byte f251a = (byte) 0;
    /* renamed from: d */
    private static final String[] f252d = new String[]{"/system/xbin/busybox", "/system/bin/busybox", "/system/sbin/busybox", "/sbin/busybox", "/bin/busybox", "/xsbin/busybox"};
    /* renamed from: b */
    private int f253b = 0;
    /* renamed from: c */
    private String f254c = null;

    protected C0073a() {
    }

    /* renamed from: f */
    public static boolean m304f() {
        if (f251a != (byte) 0) {
            return f251a >= (byte) 2;
        } else {
            f251a = (byte) 1;
            C0074b c0074b = new C0074b();
            if (c0074b.mo52b() && c0074b.mo51a("su -v", 5)) {
                String a = c0074b.mo50a(false);
                if (c0074b.mo49a() == 0) {
                    if (a.contains("SUPERSU")) {
                        f251a = (byte) 3;
                    } else {
                        f251a = (byte) 2;
                    }
                }
            }
            c0074b.mo54c();
            return f251a >= (byte) 2;
        }
    }

    /* renamed from: a */
    public int mo49a() {
        return 0;
    }

    /* renamed from: a */
    public final String m306a(DataInputStream dataInputStream) {
        byte[] bArr = new byte[1024];
        int i = 0;
        while (true) {
            int read = dataInputStream.read();
            switch (read) {
                case ViewDragHelper.INVALID_POINTER /*-1*/:
                    return i == 0 ? null : new String(bArr, 0, i, "UTF-8");
                case 10:
                    return new String(bArr, 0, i, "UTF-8");
                case 13:
                    break;
                default:
                    int i2 = i + 1;
                    bArr[i] = (byte) read;
                    i = i2;
                    break;
            }
        }
    }

    /* renamed from: a */
    public String mo50a(boolean z) {
        return "";
    }

    /* renamed from: a */
    public void m308a(int i) {
        this.f253b = i;
    }

    /* renamed from: a */
    public boolean m309a(String str) {
        return mo51a(str, 600);
    }

    /* renamed from: a */
    public boolean mo51a(String str, int i) {
        return false;
    }

    /* renamed from: b */
    public boolean mo52b() {
        return false;
    }

    /* renamed from: b */
    public boolean mo53b(String str) {
        return false;
    }

    /* renamed from: c */
    public void mo54c() {
    }

    /* renamed from: c */
    public void m314c(String str) {
        this.f254c = str;
    }

    /* renamed from: d */
    public int m315d() {
        return this.f253b;
    }

    /* renamed from: e */
    public String m316e() {
        return this.f254c;
    }
}
