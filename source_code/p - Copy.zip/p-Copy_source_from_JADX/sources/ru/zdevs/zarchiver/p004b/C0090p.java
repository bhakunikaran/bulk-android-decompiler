package ru.zdevs.zarchiver.p004b;

/* renamed from: ru.zdevs.zarchiver.b.p */
public class C0090p extends C0078f {
    /* renamed from: a */
    public static boolean m356a(C0073a c0073a, String str, long j) {
        if (str == null) {
            return false;
        }
        if (!C0078f.m336b()) {
            return C0089o.m355a(c0073a, str, j);
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(C0078f.m334a());
        stringBuilder.append(" touch -c -t ");
        stringBuilder.append((int) (j / 1000));
        stringBuilder.append(" '");
        stringBuilder.append(str);
        stringBuilder.append('\'');
        if (!c0073a.m309a(stringBuilder.toString())) {
            return false;
        }
        c0073a.mo50a(false);
        return c0073a.mo49a() == 0;
    }
}
