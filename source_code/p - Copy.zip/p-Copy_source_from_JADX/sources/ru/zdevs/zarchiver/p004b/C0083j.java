package ru.zdevs.zarchiver.p004b;

import java.io.File;
import java.util.List;
import ru.zdevs.zarchiver.p004b.C0082i.C0081a;
import ru.zdevs.zarchiver.tool.C0166c;
import ru.zdevs.zarchiver.tool.C0202q;

/* renamed from: ru.zdevs.zarchiver.b.j */
public class C0083j extends C0078f {
    /* renamed from: a */
    public static boolean m342a(C0073a c0073a, List<C0081a> list, String str, boolean z, boolean z2) {
        boolean z3 = true;
        if (list == null || str == null) {
            return false;
        }
        if (!C0078f.m336b()) {
            return C0082i.m341a(c0073a, list, str, z, z2);
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(C0078f.m334a());
        stringBuilder.append(" ls -l");
        if (z2) {
            stringBuilder.append(" -d");
        } else {
            stringBuilder.append(" -L");
        }
        if (z) {
            stringBuilder.append(" -A");
        }
        stringBuilder.append(" '");
        stringBuilder.append(str);
        stringBuilder.append("'");
        if (!c0073a.m309a(stringBuilder.toString())) {
            return false;
        }
        while (true) {
            String a = c0073a.mo50a(true);
            if (a == null) {
                break;
            }
            try {
                String[] a2 = C0202q.m734a(a, '\t');
                if (a2.length >= 6 && a2[0] != null && a2[0].length() >= 10 && a2[5] != null) {
                    C0081a c0081a = new C0081a();
                    c0081a.f277g = a2[0].charAt(0) == 'd';
                    c0081a.f278h = a2[0].charAt(0) == 'l';
                    c0081a.f274d = C0082i.m340a(a2[0]);
                    c0081a.f275e = a2[1];
                    c0081a.f276f = a2[2];
                    if (c0081a.f277g || c0081a.f278h) {
                        c0081a.f272b = 0;
                    } else {
                        c0081a.f272b = C0078f.m335b(a2[3]);
                    }
                    c0081a.f273c = C0078f.m335b(a2[4]) * 1000;
                    c0081a.f271a = a2[5];
                    if (!c0081a.f278h || a2.length <= 6) {
                        c0081a.f279i = null;
                    } else {
                        c0081a.f279i = a2[6].substring(2);
                    }
                    if (c0081a.f278h && c0081a.f279i != null) {
                        c0081a.f277g = new File(c0081a.f279i).isDirectory();
                    }
                    list.add(c0081a);
                }
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
        }
        if (c0073a.mo49a() != 0) {
            z3 = false;
        }
        return z3;
    }
}
