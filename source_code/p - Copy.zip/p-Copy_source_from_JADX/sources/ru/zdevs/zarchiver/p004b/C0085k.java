package ru.zdevs.zarchiver.p004b;

import java.util.List;
import ru.zdevs.zarchiver.tool.C0166c;
import ru.zdevs.zarchiver.tool.C0202q;

/* renamed from: ru.zdevs.zarchiver.b.k */
public class C0085k {

    /* renamed from: ru.zdevs.zarchiver.b.k$a */
    public static class C0084a {
        /* renamed from: a */
        public String f280a;
        /* renamed from: b */
        public String f281b;
        /* renamed from: c */
        public String f282c;
        /* renamed from: d */
        public boolean f283d;
    }

    /* renamed from: a */
    public static boolean m343a(C0073a c0073a, String str, boolean z) {
        if (str == null) {
            return false;
        }
        if (!c0073a.m309a("mount -o,remount," + (z ? "rw" : "ro") + " " + str)) {
            return false;
        }
        c0073a.mo50a(false);
        return c0073a.mo49a() == 0;
    }

    /* renamed from: a */
    public static boolean m344a(C0073a c0073a, List<C0084a> list) {
        boolean z = true;
        if (list == null) {
            return false;
        }
        String str = "cat /proc/mounts";
        if (!c0073a.m309a("cat /proc/mounts")) {
            return false;
        }
        while (true) {
            str = c0073a.mo50a(true);
            if (str == null) {
                break;
            }
            try {
                C0084a c0084a = new C0084a();
                String[] a = C0202q.m734a(str, ' ');
                if (a.length >= 6) {
                    c0084a.f280a = a[0];
                    c0084a.f281b = a[1];
                    c0084a.f282c = a[2];
                    boolean z2 = a[3] != null && a[3].contains("rw");
                    c0084a.f283d = z2;
                    list.add(c0084a);
                }
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
        }
        if (c0073a.mo49a() != 0) {
            z = false;
        }
        return z;
    }
}
