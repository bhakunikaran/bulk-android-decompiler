package ru.zdevs.zarchiver.p004b;

/* renamed from: ru.zdevs.zarchiver.b.h */
public class C0080h extends C0078f {
    /* renamed from: a */
    public static boolean m338a(C0073a c0073a, boolean z, boolean z2, boolean z3, boolean z4, String str, String str2) {
        return C0080h.m339a(c0073a, z, z2, false, z3, z4, str, str2);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    /* renamed from: a */
    public static boolean m339a(ru.zdevs.zarchiver.p004b.C0073a r13, boolean r14, boolean r15, boolean r16, boolean r17, boolean r18, java.lang.String r19, java.lang.String r20) {
        /*
        if (r19 == 0) goto L_0x0004;
    L_0x0002:
        if (r20 != 0) goto L_0x0006;
    L_0x0004:
        r2 = 0;
    L_0x0005:
        return r2;
    L_0x0006:
        r2 = ru.zdevs.zarchiver.p004b.C0078f.m336b();
        if (r2 != 0) goto L_0x0015;
    L_0x000c:
        r0 = r19;
        r1 = r20;
        r2 = ru.zdevs.zarchiver.p004b.C0079g.m337a(r13, r14, r0, r1);
        goto L_0x0005;
    L_0x0015:
        r3 = new java.lang.StringBuilder;
        r3.<init>();
        r2 = ru.zdevs.zarchiver.p004b.C0078f.m334a();
        r3.append(r2);
        if (r14 == 0) goto L_0x0060;
    L_0x0023:
        if (r15 == 0) goto L_0x005d;
    L_0x0025:
        r2 = " mv -f";
    L_0x0027:
        r3.append(r2);
    L_0x002a:
        if (r18 == 0) goto L_0x0031;
    L_0x002c:
        r2 = "d";
        r3.append(r2);
    L_0x0031:
        if (r17 == 0) goto L_0x0038;
    L_0x0033:
        r2 = "p";
        r3.append(r2);
    L_0x0038:
        r2 = " '";
        r3.append(r2);
        r0 = r19;
        r3.append(r0);
        r2 = "' '";
        r3.append(r2);
        r0 = r20;
        r3.append(r0);
        r2 = "'";
        r3.append(r2);
        r2 = r3.toString();
        r2 = r13.m309a(r2);
        if (r2 != 0) goto L_0x006b;
    L_0x005b:
        r2 = 0;
        goto L_0x0005;
    L_0x005d:
        r2 = " mv -i";
        goto L_0x0027;
    L_0x0060:
        if (r15 == 0) goto L_0x0068;
    L_0x0062:
        r2 = " cp -Rf";
    L_0x0064:
        r3.append(r2);
        goto L_0x002a;
    L_0x0068:
        r2 = " cp -Ri";
        goto L_0x0064;
    L_0x006b:
        r2 = 1;
        r2 = r13.mo50a(r2);	 Catch:{ Exception -> 0x00c2 }
        if (r2 == 0) goto L_0x00c6;
    L_0x0072:
        r3 = "cpInternal";
        r4 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x00c2 }
        r4.<init>();	 Catch:{ Exception -> 0x00c2 }
        r5 = "Get line: ";
        r4 = r4.append(r5);	 Catch:{ Exception -> 0x00c2 }
        r4 = r4.append(r2);	 Catch:{ Exception -> 0x00c2 }
        r4 = r4.toString();	 Catch:{ Exception -> 0x00c2 }
        ru.zdevs.zarchiver.tool.C0166c.m555a(r3, r4);	 Catch:{ Exception -> 0x00c2 }
        r3 = r2.length();	 Catch:{ Exception -> 0x00c2 }
        if (r3 <= 0) goto L_0x006b;
    L_0x0090:
        r3 = 0;
        r3 = r2.charAt(r3);	 Catch:{ Exception -> 0x00c2 }
        r4 = 126; // 0x7e float:1.77E-43 double:6.23E-322;
        if (r3 != r4) goto L_0x006b;
    L_0x0099:
        r3 = 9;
        r10 = ru.zdevs.zarchiver.tool.C0202q.m734a(r2, r3);	 Catch:{ Exception -> 0x00c2 }
        r2 = r10.length;	 Catch:{ Exception -> 0x00c2 }
        r3 = 2;
        if (r2 < r3) goto L_0x006b;
    L_0x00a3:
        r2 = 1;
        r2 = r10[r2];	 Catch:{ Exception -> 0x00c2 }
        if (r2 == 0) goto L_0x006b;
    L_0x00a8:
        r2 = 1;
        r3 = r10[r2];	 Catch:{ Exception -> 0x00c2 }
        r2 = -1;
        r4 = r3.hashCode();	 Catch:{ Exception -> 0x00c2 }
        switch(r4) {
            case 2094: goto L_0x00e3;
            case 2560: goto L_0x00d9;
            case 2564: goto L_0x00cf;
            default: goto L_0x00b3;
        };	 Catch:{ Exception -> 0x00c2 }
    L_0x00b3:
        switch(r2) {
            case 0: goto L_0x00b7;
            case 1: goto L_0x00ed;
            case 2: goto L_0x00fd;
            default: goto L_0x00b6;
        };	 Catch:{ Exception -> 0x00c2 }
    L_0x00b6:
        goto L_0x006b;
    L_0x00b7:
        r2 = r13.m315d();	 Catch:{ Exception -> 0x00c2 }
        r3 = 2;
        r3 = r10[r3];	 Catch:{ Exception -> 0x00c2 }
        ru.zdevs.zarchiver.archiver.C2JBridge.jSetProcessText(r2, r3);	 Catch:{ Exception -> 0x00c2 }
        goto L_0x006b;
    L_0x00c2:
        r2 = move-exception;
        ru.zdevs.zarchiver.tool.C0166c.m556a(r2);
    L_0x00c6:
        r2 = r13.mo49a();
        if (r2 != 0) goto L_0x01b4;
    L_0x00cc:
        r2 = 1;
        goto L_0x0005;
    L_0x00cf:
        r4 = "PT";
        r3 = r3.equals(r4);	 Catch:{ Exception -> 0x00c2 }
        if (r3 == 0) goto L_0x00b3;
    L_0x00d7:
        r2 = 0;
        goto L_0x00b3;
    L_0x00d9:
        r4 = "PP";
        r3 = r3.equals(r4);	 Catch:{ Exception -> 0x00c2 }
        if (r3 == 0) goto L_0x00b3;
    L_0x00e1:
        r2 = 1;
        goto L_0x00b3;
    L_0x00e3:
        r4 = "AO";
        r3 = r3.equals(r4);	 Catch:{ Exception -> 0x00c2 }
        if (r3 == 0) goto L_0x00b3;
    L_0x00eb:
        r2 = 2;
        goto L_0x00b3;
    L_0x00ed:
        r2 = r13.m315d();	 Catch:{ Exception -> 0x00c2 }
        r3 = 2;
        r3 = r10[r3];	 Catch:{ Exception -> 0x00c2 }
        r3 = ru.zdevs.zarchiver.p004b.C0078f.m333a(r3);	 Catch:{ Exception -> 0x00c2 }
        ru.zdevs.zarchiver.archiver.C2JBridge.jSetProcessPercent(r2, r3);	 Catch:{ Exception -> 0x00c2 }
        goto L_0x006b;
    L_0x00fd:
        r2 = r10.length;	 Catch:{ Exception -> 0x00c2 }
        r3 = 7;
        if (r2 < r3) goto L_0x006b;
    L_0x0101:
        r11 = 8;
        if (r16 == 0) goto L_0x0181;
    L_0x0105:
        r2 = 2;
    L_0x0106:
        r3 = r2;
    L_0x0107:
        r2 = "$";
        r4 = r3 & 1;
        if (r4 == 0) goto L_0x0120;
    L_0x010d:
        r4 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x00c2 }
        r4.<init>();	 Catch:{ Exception -> 0x00c2 }
        r2 = r4.append(r2);	 Catch:{ Exception -> 0x00c2 }
        r4 = 89;
        r2 = r2.append(r4);	 Catch:{ Exception -> 0x00c2 }
        r2 = r2.toString();	 Catch:{ Exception -> 0x00c2 }
    L_0x0120:
        r4 = r3 & 2;
        if (r4 == 0) goto L_0x0137;
    L_0x0124:
        r4 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x00c2 }
        r4.<init>();	 Catch:{ Exception -> 0x00c2 }
        r2 = r4.append(r2);	 Catch:{ Exception -> 0x00c2 }
        r4 = 78;
        r2 = r2.append(r4);	 Catch:{ Exception -> 0x00c2 }
        r2 = r2.toString();	 Catch:{ Exception -> 0x00c2 }
    L_0x0137:
        r4 = r3 & 8;
        if (r4 == 0) goto L_0x014e;
    L_0x013b:
        r4 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x00c2 }
        r4.<init>();	 Catch:{ Exception -> 0x00c2 }
        r2 = r4.append(r2);	 Catch:{ Exception -> 0x00c2 }
        r4 = 67;
        r2 = r2.append(r4);	 Catch:{ Exception -> 0x00c2 }
        r2 = r2.toString();	 Catch:{ Exception -> 0x00c2 }
    L_0x014e:
        r4 = r3 & 4;
        if (r4 == 0) goto L_0x0165;
    L_0x0152:
        r4 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x00c2 }
        r4.<init>();	 Catch:{ Exception -> 0x00c2 }
        r2 = r4.append(r2);	 Catch:{ Exception -> 0x00c2 }
        r4 = 82;
        r2 = r2.append(r4);	 Catch:{ Exception -> 0x00c2 }
        r2 = r2.toString();	 Catch:{ Exception -> 0x00c2 }
    L_0x0165:
        r3 = r3 & 16;
        if (r3 == 0) goto L_0x017c;
    L_0x0169:
        r3 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x00c2 }
        r3.<init>();	 Catch:{ Exception -> 0x00c2 }
        r2 = r3.append(r2);	 Catch:{ Exception -> 0x00c2 }
        r3 = 65;
        r2 = r2.append(r3);	 Catch:{ Exception -> 0x00c2 }
        r2 = r2.toString();	 Catch:{ Exception -> 0x00c2 }
    L_0x017c:
        r13.mo53b(r2);	 Catch:{ Exception -> 0x00c2 }
        goto L_0x006b;
    L_0x0181:
        r2 = r13.m315d();	 Catch:{ Exception -> 0x01ad }
        r3 = 6;
        r3 = r10[r3];	 Catch:{ Exception -> 0x01ad }
        r4 = 2;
        r4 = r10[r4];	 Catch:{ Exception -> 0x01ad }
        r4 = ru.zdevs.zarchiver.p004b.C0078f.m335b(r4);	 Catch:{ Exception -> 0x01ad }
        r6 = 3;
        r6 = r10[r6];	 Catch:{ Exception -> 0x01ad }
        r6 = ru.zdevs.zarchiver.p004b.C0078f.m333a(r6);	 Catch:{ Exception -> 0x01ad }
        r7 = 6;
        r7 = r10[r7];	 Catch:{ Exception -> 0x01ad }
        r8 = 4;
        r8 = r10[r8];	 Catch:{ Exception -> 0x01ad }
        r8 = ru.zdevs.zarchiver.p004b.C0078f.m335b(r8);	 Catch:{ Exception -> 0x01ad }
        r12 = 5;
        r10 = r10[r12];	 Catch:{ Exception -> 0x01ad }
        r10 = ru.zdevs.zarchiver.p004b.C0078f.m333a(r10);	 Catch:{ Exception -> 0x01ad }
        r2 = ru.zdevs.zarchiver.archiver.C2JBridge.jAskOverwrite(r2, r3, r4, r6, r7, r8, r10);	 Catch:{ Exception -> 0x01ad }
        goto L_0x0106;
    L_0x01ad:
        r2 = move-exception;
        ru.zdevs.zarchiver.tool.C0166c.m556a(r2);	 Catch:{ Exception -> 0x00c2 }
        r3 = r11;
        goto L_0x0107;
    L_0x01b4:
        r2 = 0;
        goto L_0x0005;
        */
        throw new UnsupportedOperationException("Method not decompiled: ru.zdevs.zarchiver.b.h.a(ru.zdevs.zarchiver.b.a, boolean, boolean, boolean, boolean, boolean, java.lang.String, java.lang.String):boolean");
    }
}
