package ru.zdevs.zarchiver.p004b;

import android.text.format.DateFormat;

/* renamed from: ru.zdevs.zarchiver.b.o */
public class C0089o {
    /* renamed from: a */
    public static boolean m355a(C0073a c0073a, String str, long j) {
        if (str == null) {
            return false;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("touch -t ");
        stringBuilder.append(DateFormat.format("yyyyMMddhhmm.ss", j));
        stringBuilder.append(" '");
        stringBuilder.append(str);
        stringBuilder.append('\'');
        if (!c0073a.m309a(stringBuilder.toString())) {
            return false;
        }
        c0073a.mo50a(false);
        return c0073a.mo49a() == 0;
    }
}
