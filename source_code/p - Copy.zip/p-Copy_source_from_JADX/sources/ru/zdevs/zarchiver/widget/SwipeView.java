package ru.zdevs.zarchiver.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Build.VERSION;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Transformation;
import android.widget.AbsListView;
import ru.zdevs.zarchiver.Actions;
import ru.zdevs.zarchiver.tool.C0166c;

public class SwipeView extends ViewGroup {
    private static final int ANIMATE_TO_START_DURATION = 200;
    private static final float DECELERATE_INTERPOLATION_FACTOR = 2.0f;
    private static final float DRAG_RATE = 0.5f;
    private static final int INVALID_POINTER = -1;
    private static final int SCALE_DOWN_DURATION = 150;
    private static final String TAG = "SwipeView";
    private int mActivePointerId;
    private final Animation mAnimateToStartPosition;
    private ExtendRelativeLayout mCircleView;
    private int mCircleViewIndex;
    private int mCurrentTargetOffsetTop;
    private final DecelerateInterpolator mDecelerateInterpolator;
    protected int mFrom;
    private float mInitialDownY;
    private float mInitialMotionY;
    private boolean mIsBeingDragged;
    private OnRefreshListener mListener;
    private boolean mNotify;
    private boolean mOriginalOffsetCalculated;
    protected int mOriginalOffsetTop;
    private boolean mReturningToStart;
    private OnShowListener mShowListener;
    private float mSpinnerFinalOffset;
    private View mTarget;
    private float mTotalDragDistance;
    private int mTouchSlop;

    public interface OnRefreshListener {
        void onRefresh();
    }

    public interface OnShowListener {
        void onShow();
    }

    /* renamed from: ru.zdevs.zarchiver.widget.SwipeView$1 */
    class C02051 extends Animation {
        /* renamed from: a */
        final /* synthetic */ SwipeView f561a;

        C02051(SwipeView swipeView) {
            this.f561a = swipeView;
        }

        public void applyTransformation(float f, Transformation transformation) {
        }
    }

    /* renamed from: ru.zdevs.zarchiver.widget.SwipeView$2 */
    class C02062 implements AnimationListener {
        /* renamed from: a */
        final /* synthetic */ SwipeView f562a;

        C02062(SwipeView swipeView) {
            this.f562a = swipeView;
        }

        public void onAnimationEnd(Animation animation) {
            if (this.f562a.mNotify) {
                if (this.f562a.mListener != null) {
                    this.f562a.mListener.onRefresh();
                }
                this.f562a.mNotify = false;
            }
            this.f562a.startScaleDownAnimation(null);
        }

        public void onAnimationRepeat(Animation animation) {
        }

        public void onAnimationStart(Animation animation) {
        }
    }

    /* renamed from: ru.zdevs.zarchiver.widget.SwipeView$3 */
    class C02073 extends Animation {
        /* renamed from: a */
        final /* synthetic */ SwipeView f563a;

        C02073(SwipeView swipeView) {
            this.f563a = swipeView;
        }

        public void applyTransformation(float f, Transformation transformation) {
            this.f563a.moveToStart(f);
        }
    }

    public SwipeView(Context context) {
        this(context, null);
    }

    public SwipeView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.mTotalDragDistance = -1.0f;
        this.mActivePointerId = -1;
        this.mCircleViewIndex = -1;
        this.mAnimateToStartPosition = new C02073(this);
        this.mTouchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
        setWillNotDraw(false);
        this.mDecelerateInterpolator = new DecelerateInterpolator(DECELERATE_INTERPOLATION_FACTOR);
        setChildrenDrawingOrderEnabled(true);
    }

    private void animateOffsetToStartPosition(int i, AnimationListener animationListener) {
        this.mFrom = i;
        this.mAnimateToStartPosition.reset();
        this.mAnimateToStartPosition.setDuration(200);
        this.mAnimateToStartPosition.setInterpolator(this.mDecelerateInterpolator);
        if (animationListener != null) {
            this.mCircleView.setAnimationListener(animationListener);
        }
        this.mCircleView.clearAnimation();
        this.mCircleView.startAnimation(this.mAnimateToStartPosition);
    }

    private void ensureTarget() {
        if (this.mTarget == null) {
            int i = 0;
            while (i < getChildCount()) {
                View childAt = getChildAt(i);
                if (childAt.equals(this.mCircleView)) {
                    i++;
                } else {
                    this.mTarget = childAt;
                    return;
                }
            }
        }
    }

    private float getMotionEventY(MotionEvent motionEvent, int i) {
        int findPointerIndex = motionEvent.findPointerIndex(i);
        return findPointerIndex < 0 ? -1.0f : motionEvent.getY(findPointerIndex);
    }

    private void moveToStart(float f) {
        setTargetOffsetTopAndBottom((this.mFrom + ((int) (((float) (this.mOriginalOffsetTop - this.mFrom)) * f))) - this.mCircleView.getTop(), false);
    }

    private void onSecondaryPointerUp(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.mActivePointerId) {
            this.mActivePointerId = motionEvent.getPointerId(actionIndex == 0 ? 1 : 0);
        }
    }

    private void setTargetOffsetTopAndBottom(int i, boolean z) {
        this.mCircleView.bringToFront();
        this.mCircleView.offsetTopAndBottom(i);
        this.mCurrentTargetOffsetTop = this.mCircleView.getTop();
        if (z) {
            invalidate();
        }
    }

    private void startScaleDownAnimation(AnimationListener animationListener) {
        Animation c02051 = new C02051(this);
        c02051.setDuration(150);
        this.mCircleView.setAnimationListener(animationListener);
        this.mCircleView.clearAnimation();
        this.mCircleView.startAnimation(c02051);
    }

    public boolean canChildScrollUp() {
        boolean z = false;
        if (this.mTarget instanceof AbsListView) {
            AbsListView absListView = (AbsListView) this.mTarget;
            return absListView.getChildCount() > 0 && (absListView.getFirstVisiblePosition() > 0 || absListView.getChildAt(0).getTop() < absListView.getPaddingTop());
        } else {
            if (this.mTarget.canScrollVertically(-1) || this.mTarget.getScrollY() > 0) {
                z = true;
            }
            return z;
        }
    }

    protected int getChildDrawingOrder(int i, int i2) {
        return this.mCircleViewIndex < 0 ? i2 : i2 == i + -1 ? this.mCircleViewIndex : i2 >= this.mCircleViewIndex ? i2 + 1 : i2;
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        ensureTarget();
        int actionMasked = motionEvent.getActionMasked();
        if (this.mReturningToStart && actionMasked == 0) {
            this.mReturningToStart = false;
        }
        if (!isEnabled() || this.mReturningToStart || canChildScrollUp()) {
            return false;
        }
        float motionEventY;
        switch (actionMasked) {
            case 0:
                setTargetOffsetTopAndBottom(this.mOriginalOffsetTop - this.mCircleView.getTop(), true);
                this.mActivePointerId = motionEvent.getPointerId(0);
                this.mIsBeingDragged = false;
                motionEventY = getMotionEventY(motionEvent, this.mActivePointerId);
                if (motionEventY != -1.0f) {
                    this.mInitialDownY = motionEventY;
                    break;
                }
                return false;
            case 1:
            case 3:
                this.mIsBeingDragged = false;
                this.mActivePointerId = -1;
                break;
            case 2:
                if (this.mActivePointerId == -1) {
                    C0166c.m557b(TAG, "Got ACTION_MOVE event but don't have an active pointer id.");
                    return false;
                }
                motionEventY = getMotionEventY(motionEvent, this.mActivePointerId);
                if (motionEventY != -1.0f) {
                    if (motionEventY - this.mInitialDownY > ((float) this.mTouchSlop) && !this.mIsBeingDragged) {
                        this.mInitialMotionY = this.mInitialDownY + ((float) this.mTouchSlop);
                        this.mIsBeingDragged = true;
                        if (this.mShowListener != null) {
                            this.mShowListener.onShow();
                            break;
                        }
                    }
                }
                return false;
                break;
            case Actions.CHECK_ACTION_RENAME /*6*/:
                onSecondaryPointerUp(motionEvent);
                break;
        }
        return this.mIsBeingDragged;
    }

    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int measuredWidth = getMeasuredWidth();
        int measuredHeight = getMeasuredHeight();
        if (getChildCount() != 0) {
            if (this.mTarget == null) {
                ensureTarget();
            }
            if (this.mTarget != null) {
                View view = this.mTarget;
                int paddingLeft = getPaddingLeft();
                int paddingTop = getPaddingTop();
                view.layout(paddingLeft, paddingTop, ((measuredWidth - getPaddingLeft()) - getPaddingRight()) + paddingLeft, ((measuredHeight - getPaddingTop()) - getPaddingBottom()) + paddingTop);
                this.mCircleView.layout((measuredWidth / 2) - (this.mCircleView.getMeasuredWidth() / 2), this.mCurrentTargetOffsetTop, (measuredWidth / 2) + (this.mCircleView.getMeasuredWidth() / 2), this.mCurrentTargetOffsetTop + this.mCircleView.getMeasuredHeight());
            }
        }
    }

    @SuppressLint({"NewApi"})
    public void onMeasure(int i, int i2) {
        int i3 = 0;
        super.onMeasure(i, i2);
        if (this.mTarget == null) {
            ensureTarget();
        }
        if (this.mTarget != null) {
            this.mTarget.measure(MeasureSpec.makeMeasureSpec((getMeasuredWidth() - getPaddingLeft()) - getPaddingRight(), 1073741824), MeasureSpec.makeMeasureSpec((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom(), 1073741824));
            this.mCircleView.measure(MeasureSpec.makeMeasureSpec((getMeasuredWidth() - getPaddingLeft()) - getPaddingRight(), 1073741824), MeasureSpec.makeMeasureSpec((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom(), 0));
            if (!this.mOriginalOffsetCalculated) {
                this.mOriginalOffsetCalculated = true;
                int i4;
                if (VERSION.SDK_INT < 16 || !this.mTarget.getFitsSystemWindows()) {
                    i4 = -this.mCircleView.getMeasuredHeight();
                    this.mOriginalOffsetTop = i4;
                    this.mCurrentTargetOffsetTop = i4;
                } else {
                    i4 = (-this.mCircleView.getMeasuredHeight()) + this.mTarget.getPaddingTop();
                    this.mOriginalOffsetTop = i4;
                    this.mCurrentTargetOffsetTop = i4;
                }
                float measuredHeight = (float) this.mCircleView.getMeasuredHeight();
                this.mSpinnerFinalOffset = measuredHeight;
                this.mTotalDragDistance = measuredHeight;
            }
            this.mCircleViewIndex = -1;
            while (i3 < getChildCount()) {
                if (getChildAt(i3) == this.mCircleView) {
                    this.mCircleViewIndex = i3;
                    return;
                }
                i3++;
            }
        }
    }

    @SuppressLint({"ClickableViewAccessibility"})
    public boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (this.mReturningToStart && actionMasked == 0) {
            this.mReturningToStart = false;
        }
        if (!isEnabled() || this.mReturningToStart || canChildScrollUp()) {
            return false;
        }
        float y;
        switch (actionMasked) {
            case 0:
                this.mActivePointerId = motionEvent.getPointerId(0);
                this.mIsBeingDragged = false;
                break;
            case 1:
            case 3:
                if (this.mActivePointerId != -1) {
                    actionMasked = motionEvent.findPointerIndex(this.mActivePointerId);
                    if (actionMasked < 0) {
                        C0166c.m557b(TAG, "Got ACTION_CANCEL event but have an invalid active pointer id.");
                        return false;
                    }
                    y = (motionEvent.getY(actionMasked) - this.mInitialMotionY) * DRAG_RATE;
                    this.mIsBeingDragged = false;
                    if (this.mListener != null && ((double) y) > ((double) this.mTotalDragDistance) * 1.5d) {
                        this.mNotify = true;
                    }
                    animateOffsetToStartPosition(this.mCurrentTargetOffsetTop, new C02062(this));
                    this.mActivePointerId = -1;
                    return false;
                } else if (actionMasked != 1) {
                    return false;
                } else {
                    C0166c.m557b(TAG, "Got ACTION_UP event but don't have an active pointer id.");
                    return false;
                }
            case 2:
                actionMasked = motionEvent.findPointerIndex(this.mActivePointerId);
                if (actionMasked < 0) {
                    C0166c.m557b(TAG, "Got ACTION_MOVE event but have an invalid active pointer id.");
                    return false;
                }
                y = (motionEvent.getY(actionMasked) - this.mInitialMotionY) * DRAG_RATE;
                if (this.mIsBeingDragged) {
                    y /= this.mTotalDragDistance;
                    if (y >= 0.0f) {
                        y = Math.min(1.0f, Math.abs(y));
                        actionMasked = ((int) (y * this.mSpinnerFinalOffset)) + this.mOriginalOffsetTop;
                        if (this.mCircleView.getVisibility() != 0) {
                            this.mCircleView.setVisibility(0);
                        }
                        this.mCircleView.setScaleX(1.0f);
                        this.mCircleView.setScaleY(1.0f);
                        setTargetOffsetTopAndBottom(actionMasked - this.mCurrentTargetOffsetTop, true);
                        break;
                    }
                    return false;
                }
                break;
            case 5:
                this.mActivePointerId = motionEvent.getPointerId(motionEvent.getActionIndex());
                break;
            case Actions.CHECK_ACTION_RENAME /*6*/:
                onSecondaryPointerUp(motionEvent);
                break;
        }
        return true;
    }

    public boolean performClick() {
        return super.performClick();
    }

    public void requestDisallowInterceptTouchEvent(boolean z) {
    }

    public void setExtendView(ExtendRelativeLayout extendRelativeLayout) {
        this.mCircleView = extendRelativeLayout;
        this.mCircleView.setVisibility(8);
        addView(this.mCircleView);
    }

    public void setOnRefreshListener(OnRefreshListener onRefreshListener) {
        this.mListener = onRefreshListener;
    }

    public void setOnShowListener(OnShowListener onShowListener) {
        this.mShowListener = onShowListener;
    }
}
