package ru.zdevs.zarchiver.widget.bottomsheet;

import android.content.Context;
import android.os.Build.VERSION;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import ru.zdevs.zarchiver.widget.bottomsheet.ViewDragHelper.Callback;

public class CollapsingView extends FrameLayout {
    public static final int COLLAPSE_BY_CLICK = 1;
    public static final int COLLAPSE_BY_SWIPE = 0;
    private ViewDragHelper mDragHelper;
    private boolean mEnableDrag = true;
    private int mExtendHeight;
    private int mHeight;
    private C0211a mListener;
    private int mMinCollapseHeight;
    private int mMinExtendHeight;

    /* renamed from: ru.zdevs.zarchiver.widget.bottomsheet.CollapsingView$a */
    interface C0211a {
        void onCollapse(int i);

        void onExtend();
    }

    /* renamed from: ru.zdevs.zarchiver.widget.bottomsheet.CollapsingView$b */
    private class C0213b extends Callback {
        /* renamed from: a */
        final /* synthetic */ CollapsingView f567a;

        private C0213b(CollapsingView collapsingView) {
            this.f567a = collapsingView;
        }

        public int clampViewPositionVertical(View view, int i, int i2) {
            return i < 0 ? i < this.f567a.mExtendHeight ? this.f567a.mExtendHeight : i : i <= 0 ? 0 : i;
        }

        public int getViewVerticalDragRange(View view) {
            return this.f567a.getMeasuredHeight();
        }

        public void onViewPositionChanged(View view, int i, int i2, int i3, int i4) {
            super.onViewPositionChanged(view, i, i2, i3, i4);
            if (i2 >= this.f567a.mHeight && this.f567a.mListener != null) {
                this.f567a.mListener.onCollapse(0);
            }
            if (i2 <= this.f567a.mExtendHeight) {
                this.f567a.mMinExtendHeight = 0;
                if (this.f567a.mListener != null) {
                    this.f567a.mListener.onExtend();
                }
            }
        }

        public void onViewReleased(View view, float f, float f2) {
            super.onViewReleased(view, f, f2);
            if (f2 >= 800.0f || view.getTop() >= this.f567a.mMinCollapseHeight + this.f567a.mMinExtendHeight) {
                this.f567a.mDragHelper.settleCapturedViewAt(view.getLeft(), this.f567a.mHeight);
            } else if (f2 <= -800.0f || view.getTop() <= this.f567a.mMinExtendHeight) {
                this.f567a.mDragHelper.settleCapturedViewAt(view.getLeft(), this.f567a.mExtendHeight);
            } else {
                this.f567a.mDragHelper.settleCapturedViewAt(view.getLeft(), 0);
            }
            this.f567a.invalidate();
        }

        public boolean tryCaptureView(View view, int i) {
            return this.f567a.mEnableDrag;
        }
    }

    public CollapsingView(Context context) {
        super(context);
    }

    public CollapsingView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public CollapsingView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    public void computeScroll() {
        super.computeScroll();
        if (!this.mDragHelper.continueSettling(true)) {
            return;
        }
        if (VERSION.SDK_INT < 16) {
            postInvalidate();
        } else {
            postInvalidateOnAnimation();
        }
    }

    public void enableDrag(boolean z) {
        this.mEnableDrag = z;
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.mDragHelper = ViewDragHelper.create(this, 0.8f, new C0213b());
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        return this.mDragHelper.shouldInterceptTouchEvent(motionEvent) || super.onInterceptTouchEvent(motionEvent);
    }

    protected void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        this.mHeight = i2;
        this.mMinCollapseHeight = i2 / 2;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() != 0 || motionEvent.getY() >= ((float) (-this.mExtendHeight))) {
            this.mDragHelper.processTouchEvent(motionEvent);
        } else if (this.mListener != null) {
            this.mListener.onCollapse(1);
        }
        return true;
    }

    public void setCollapseListener(C0211a c0211a) {
        this.mListener = c0211a;
    }

    public void setExtendHeight(int i) {
        this.mExtendHeight = -i;
        this.mMinExtendHeight = (-i) / 2;
    }
}
