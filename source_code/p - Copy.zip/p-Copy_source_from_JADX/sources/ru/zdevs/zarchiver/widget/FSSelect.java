package ru.zdevs.zarchiver.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ListAdapter;
import android.widget.ListView;
import java.util.ArrayList;
import java.util.List;
import ru.zdevs.zarchiver.C0093d;
import ru.zdevs.zarchiver.R;
import ru.zdevs.zarchiver.dialog.ZDialog;
import ru.zdevs.zarchiver.dialog.ZDialog.OnOkListener;
import ru.zdevs.zarchiver.dialog.ZMenuDialog;
import ru.zdevs.zarchiver.fs.FSLocal;
import ru.zdevs.zarchiver.fs.FSRoot;
import ru.zdevs.zarchiver.fs.MyUri;
import ru.zdevs.zarchiver.p003a.C0047d;
import ru.zdevs.zarchiver.p003a.C0049e;
import ru.zdevs.zarchiver.settings.Settings;
import ru.zdevs.zarchiver.widget.bottomsheet.ViewDragHelper;

public class FSSelect extends ListView implements OnItemClickListener, OnItemLongClickListener, OnOkListener {
    private Context mContext;
    public MyUri mCurrentPath;
    private List<C0049e> mDirectoryEntries;
    private FSLocal mFSLocal;
    private FSRoot mFSRoot;
    private boolean mMultiSelect;
    private OnFileMarkListener mOnFileMarkListener;
    private OnFileSelectListener mOnFileSelectListener;
    private OnPathChangeListener mOnPathChangeListener;

    public interface OnFileMarkListener {
        void onFileMark(int i);
    }

    public interface OnFileSelectListener {
        void onFileSelect(String str, String str2);
    }

    public interface OnPathChangeListener {
        void onPathChange(String str);
    }

    public FSSelect(Context context) {
        this(context, null);
    }

    public FSSelect(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init(context);
    }

    private void init(Context context) {
        this.mContext = context;
        this.mFSLocal = new FSLocal();
        this.mCurrentPath = new MyUri(Settings.sHomeDir);
        this.mDirectoryEntries = new ArrayList();
        setCurrentPath(new MyUri(this.mCurrentPath));
        setCacheColorHint(0);
        setDrawingCacheEnabled(false);
        setOnItemClickListener(this);
    }

    public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
        C0049e c0049e = (C0049e) this.mDirectoryEntries.get(i);
        if (c0049e != null) {
            if (c0049e.m107b()) {
                this.mCurrentPath.add(c0049e.mo28e());
                setCurrentPath(new MyUri(this.mCurrentPath));
            } else if (this.mMultiSelect) {
                ((C0047d) getAdapter()).mo20c(i);
                if (this.mOnFileMarkListener != null) {
                    this.mOnFileMarkListener.onFileMark(((C0047d) getAdapter()).mo16b());
                }
            } else if (this.mOnFileSelectListener != null) {
                this.mOnFileSelectListener.onFileSelect(this.mCurrentPath.toLocalPath(), c0049e.mo28e());
            }
        }
    }

    public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long j) {
        List arrayList = new ArrayList();
        C0093d c0093d = new C0093d(this.mContext);
        c0093d.m374a(arrayList, 14);
        c0093d.m374a(arrayList, 16);
        c0093d.m374a(arrayList, 15);
        ZMenuDialog zMenuDialog = new ZMenuDialog(null, this.mContext, arrayList, this.mContext.getString(R.string.MENU_SELECT), 1);
        zMenuDialog.setOnOkListener(this);
        zMenuDialog.show();
        return false;
    }

    public void onOk(ZDialog zDialog) {
        switch (((ZMenuDialog) zDialog).getSelectMenuItemID()) {
            case 14:
                ((C0047d) getAdapter()).mo21d();
                break;
            case ViewDragHelper.EDGE_ALL /*15*/:
                ((C0047d) getAdapter()).mo19c();
                break;
            case 16:
                ((C0047d) getAdapter()).mo22e();
                break;
        }
        if (this.mOnFileMarkListener != null) {
            this.mOnFileMarkListener.onFileMark(((C0047d) getAdapter()).mo16b());
        }
    }

    public void setCurrentPath(MyUri myUri) {
        if (myUri.isStorage()) {
            myUri.setPath(myUri.getPath().replace("/SAF", "/mnt/media_rw"));
            myUri.setScheme(FSRoot.SCHEME);
        }
        if (!(this.mFSLocal.list(this.mContext, myUri, this.mDirectoryEntries, 4) || this.mFSRoot == null)) {
            this.mFSRoot.list(this.mContext, myUri, this.mDirectoryEntries, 4);
        }
        if (Settings.sGUIAnimation) {
            setAnimation(myUri.toString().length() < this.mCurrentPath.toString().length() ? AnimationUtils.loadAnimation(this.mContext, R.anim.file_list_in) : AnimationUtils.makeInAnimation(this.mContext, true));
        }
        ListAdapter listAdapter = (C0047d) getAdapter();
        if (listAdapter == null) {
            listAdapter = new C0047d(this.mContext, false);
            listAdapter.mo15a(false);
        }
        if (Settings.sGUIAnimation) {
            startLayoutAnimation();
        }
        listAdapter.m89a(this.mDirectoryEntries, myUri);
        setAdapter(listAdapter);
        if (this.mOnFileMarkListener != null) {
            this.mOnFileMarkListener.onFileMark(((C0047d) getAdapter()).mo16b());
        }
        if (this.mOnPathChangeListener != null) {
            this.mOnPathChangeListener.onPathChange(myUri.toLocalPath());
        }
        this.mCurrentPath = myUri;
    }

    public void setMultiSelect(boolean z) {
        this.mMultiSelect = z;
        setSelectionByIcon(z);
        if (z) {
            setOnItemLongClickListener(this);
        } else {
            setOnItemLongClickListener(null);
        }
    }

    public void setOnFileMarkListener(OnFileMarkListener onFileMarkListener) {
        this.mOnFileMarkListener = onFileMarkListener;
    }

    public void setOnFileSelectListener(OnFileSelectListener onFileSelectListener) {
        this.mOnFileSelectListener = onFileSelectListener;
    }

    public void setOnPathChangeListener(OnPathChangeListener onPathChangeListener) {
        this.mOnPathChangeListener = onPathChangeListener;
    }

    public void setRootSupport(boolean z) {
        if (z) {
            this.mFSRoot = new FSRoot();
        } else {
            this.mFSRoot = null;
        }
    }

    public void setSelectionByIcon(boolean z) {
        C0047d c0047d = (C0047d) getAdapter();
        if (c0047d == null) {
            ListAdapter c0047d2 = new C0047d(this.mContext);
            c0047d2.mo15a(z);
            setAdapter(c0047d2);
            return;
        }
        c0047d.mo15a(z);
    }
}
