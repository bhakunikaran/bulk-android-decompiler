package ru.zdevs.zarchiver.widget.bottomsheet;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnShowListener;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout.LayoutParams;
import ru.zdevs.zarchiver.R;
import ru.zdevs.zarchiver.widget.bottomsheet.CollapsingView.C0211a;

public class BottomSheet extends Dialog implements OnCancelListener, C0211a {
    private static final String TAG = "BottomSheet";
    private final Runnable dismissRunnable;
    private Builder mBuilder;
    private int mCollapseWhich;
    private CollapsingView mCollapsingView;
    private BottomSheetListener mListener;

    /* renamed from: ru.zdevs.zarchiver.widget.bottomsheet.BottomSheet$1 */
    class C02081 implements Runnable {
        /* renamed from: a */
        final /* synthetic */ BottomSheet f564a;

        C02081(BottomSheet bottomSheet) {
            this.f564a = bottomSheet;
        }

        public void run() {
            this.f564a.mCollapseWhich = -4;
            this.f564a.dismiss();
        }
    }

    /* renamed from: ru.zdevs.zarchiver.widget.bottomsheet.BottomSheet$2 */
    class C02102 implements OnShowListener {
        /* renamed from: a */
        final /* synthetic */ BottomSheet f566a;

        /* renamed from: ru.zdevs.zarchiver.widget.bottomsheet.BottomSheet$2$1 */
        class C02091 implements OnClickListener {
            /* renamed from: a */
            final /* synthetic */ C02102 f565a;

            C02091(C02102 c02102) {
                this.f565a = c02102;
            }

            public void onClick(View view) {
                this.f565a.f566a.onExtend();
            }
        }

        C02102(BottomSheet bottomSheet) {
            this.f566a = bottomSheet;
        }

        public void onShow(DialogInterface dialogInterface) {
            if (this.f566a.mBuilder.mMaxPeekHeight > 0 && this.f566a.mBuilder.mView.getHeight() > this.f566a.mBuilder.mMaxPeekHeight) {
                View findViewById = this.f566a.mBuilder.mView.findViewById(R.id.ivExpand);
                if (findViewById != null) {
                    findViewById.setVisibility(0);
                    findViewById.setClickable(true);
                    findViewById.setOnClickListener(new C02091(this));
                }
                int height = this.f566a.mBuilder.mView.getHeight() - this.f566a.mBuilder.mMaxPeekHeight;
                this.f566a.mBuilder.mView.setY((float) height);
                this.f566a.mCollapsingView.setExtendHeight(height);
            }
        }
    }

    public static class Builder {
        boolean mCancelable = true;
        Context mContext;
        int mGravity = 0;
        BottomSheetListener mListener;
        int mMaxPeekHeight = 0;
        View mView;
        int mWidth = 0;

        public Builder(Context context) {
            this.mContext = context;
        }

        public BottomSheet create() {
            TypedValue typedValue = new TypedValue();
            this.mContext.getTheme().resolveAttribute(R.attr.bottomSheetStyle, typedValue, true);
            return new BottomSheet(this.mContext, typedValue.resourceId, this);
        }

        public Builder setCancelable(boolean z) {
            this.mCancelable = z;
            return this;
        }

        public Builder setListener(BottomSheetListener bottomSheetListener) {
            this.mListener = bottomSheetListener;
            return this;
        }

        public Builder setMaxPeekHeight(int i) {
            this.mMaxPeekHeight = i;
            return this;
        }

        public Builder setView(int i) {
            return setView(LayoutInflater.from(this.mContext).inflate(i, null));
        }

        public Builder setView(View view) {
            this.mView = view;
            return this;
        }

        public Builder setWidthGravity(int i, int i2) {
            this.mWidth = i;
            this.mGravity = i2;
            return this;
        }

        public void show() {
            create().show();
        }
    }

    private BottomSheet(Context context, int i, Builder builder) {
        super(context, i);
        this.mCollapseWhich = -6;
        this.dismissRunnable = new C02081(this);
        this.mBuilder = builder;
        this.mListener = builder.mListener;
    }

    private void initViewLayout() {
        this.mCollapsingView = new CollapsingView(getContext());
        this.mCollapsingView.setLayoutParams(new LayoutParams(-1, -1));
        this.mCollapsingView.setCollapseListener(this);
        this.mCollapsingView.enableDrag(this.mBuilder.mCancelable);
        TypedValue typedValue = new TypedValue();
        getContext().getTheme().resolveAttribute(16842801, typedValue, true);
        if (typedValue.type < 28 || typedValue.type > 31) {
            this.mBuilder.mView.setBackgroundColor(-1);
        } else {
            this.mBuilder.mView.setBackgroundColor(typedValue.data);
        }
        this.mCollapsingView.addView(this.mBuilder.mView);
        setOnShowListener(new C02102(this));
        setContentView(this.mCollapsingView);
    }

    public void dismiss() {
        if (this.mListener != null) {
            this.mListener.onSheetDismissed(this, this.mCollapseWhich);
        }
        super.dismiss();
    }

    public View getLayout() {
        return this.mCollapsingView;
    }

    public void onCancel(DialogInterface dialogInterface) {
        this.mCollapseWhich = -5;
    }

    public void onCollapse(int i) {
        if (getWindow() == null || getWindow().getDecorView() == null) {
            this.mCollapseWhich = i == 0 ? -4 : -5;
            dismiss();
            return;
        }
        getWindow().getDecorView().post(this.dismissRunnable);
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (this.mBuilder == null || this.mBuilder.mView == null) {
            throw new IllegalStateException("Unable to create BottomSheet, missing params");
        }
        setCancelable(this.mBuilder.mCancelable);
        Window window = getWindow();
        if (window != null) {
            if (this.mBuilder.mWidth <= 0) {
                Display defaultDisplay = ((WindowManager) getContext().getSystemService("window")).getDefaultDisplay();
                int width = defaultDisplay.getWidth();
                int height = defaultDisplay.getHeight();
                if (width < height) {
                    height = -1;
                }
                window.setLayout(height, -2);
            } else {
                window.setLayout(this.mBuilder.mWidth, -2);
            }
            window.setGravity(this.mBuilder.mGravity | 80);
        } else {
            Log.e(TAG, "Window came back as null, unable to set defaults");
        }
        if (this.mBuilder.mView != null) {
            initViewLayout();
        }
        if (this.mListener != null) {
            this.mListener.onSheetShown(this);
        }
        setOnCancelListener(this);
    }

    public void onExtend() {
        this.mBuilder.mView.setY(0.0f);
        this.mCollapsingView.setExtendHeight(0);
        View findViewById = this.mBuilder.mView.findViewById(R.id.ivExpand);
        if (findViewById != null) {
            findViewById.setVisibility(8);
        }
    }
}
