package ru.zdevs.zarchiver.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewConfiguration;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.ListAdapter;
import android.widget.ListView;
import ru.zdevs.zarchiver.p003a.C0046h;
import ru.zdevs.zarchiver.widget.IListView.OnListMeasure;

public class ExListView extends ListView implements OnTouchListener, OnScrollListener, IListView {
    private int mClickX;
    private int mClickY;
    private int mDownMouseButton;
    private OnListMeasure mOnListMeasure;

    public ExListView(Context context) {
        super(context);
        init(context);
    }

    public ExListView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init(context);
    }

    public ExListView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        init(context);
    }

    private void init(Context context) {
        setOnScrollListener(this);
        setOnTouchListener(this);
        this.mDownMouseButton = 0;
        this.mClickY = 0;
        this.mClickX = 0;
    }

    public int getClickRawX() {
        return this.mClickX;
    }

    public int getClickRawY() {
        return this.mClickY;
    }

    public int getFirsItemPosition() {
        int firstVisiblePosition = getFirstVisiblePosition();
        int paddingTop = getPaddingTop();
        if (paddingTop == 0) {
            return firstVisiblePosition;
        }
        for (int i = 0; i < 5; i++) {
            View childAt = getChildAt(i);
            if (childAt == null) {
                return firstVisiblePosition;
            }
            if ((childAt.getHeight() / 2) + childAt.getTop() >= paddingTop) {
                return firstVisiblePosition + i;
            }
        }
        return firstVisiblePosition;
    }

    protected void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        if (this.mOnListMeasure != null) {
            this.mOnListMeasure.onListMeasure(i, i2);
        }
    }

    public void onScroll(AbsListView absListView, int i, int i2, int i3) {
    }

    public void onScrollStateChanged(AbsListView absListView, int i) {
        boolean z;
        switch (i) {
            case 1:
            case 2:
                z = true;
                break;
            default:
                z = false;
                break;
        }
        C0046h c0046h = (C0046h) getAdapter();
        c0046h.mo18b(z);
        if (!z) {
            c0046h.mo24g();
        }
    }

    public boolean onTouch(View view, MotionEvent motionEvent) {
        this.mClickX = (int) motionEvent.getRawX();
        this.mClickY = (int) motionEvent.getRawY();
        if (motionEvent.getAction() == 0) {
            this.mDownMouseButton = motionEvent.getButtonState();
        }
        int pointToPosition;
        if (this.mDownMouseButton == 2 && motionEvent.getAction() == 1 && motionEvent.getEventTime() - motionEvent.getDownTime() < ((long) ViewConfiguration.getLongPressTimeout())) {
            pointToPosition = pointToPosition((int) motionEvent.getX(), (int) motionEvent.getY());
            view.performClick();
            if (pointToPosition >= 0 && getOnItemLongClickListener() != null) {
                getOnItemLongClickListener().onItemLongClick(null, null, pointToPosition, 0);
            }
            this.mDownMouseButton = 0;
            return true;
        } else if (this.mDownMouseButton != 4 || motionEvent.getAction() != 1) {
            return motionEvent.getButtonState() == 4 ? true : (motionEvent.getButtonState() != this.mDownMouseButton || this.mDownMouseButton == 0 || this.mDownMouseButton == 1) ? false : true;
        } else {
            pointToPosition = pointToPosition((int) motionEvent.getX(), (int) motionEvent.getY());
            view.performClick();
            if (pointToPosition >= 0 && getOnItemClickListener() != null) {
                getOnItemClickListener().onItemClick(null, null, pointToPosition, -8);
            }
            this.mDownMouseButton = 0;
            return true;
        }
    }

    public boolean performClick() {
        return super.performClick();
    }

    public void setAdapter(ListAdapter listAdapter) {
        super.setAdapter(listAdapter);
    }

    public void setOnListMeasure(OnListMeasure onListMeasure) {
        this.mOnListMeasure = onListMeasure;
    }
}
