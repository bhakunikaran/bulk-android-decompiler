package ru.zdevs.zarchiver.dialog;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface.OnShowListener;
import android.text.InputFilter;
import android.text.InputFilter.LengthFilter;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.Toast;
import java.util.Locale;
import ru.zdevs.zarchiver.C0136e;
import ru.zdevs.zarchiver.R;
import ru.zdevs.zarchiver.ZArchiverExtInterface;
import ru.zdevs.zarchiver.archiver.C0071e;
import ru.zdevs.zarchiver.dialog.ZDialog.OnOkListener;
import ru.zdevs.zarchiver.p003a.C0057m;
import ru.zdevs.zarchiver.p004b.C0073a;
import ru.zdevs.zarchiver.settings.Settings;
import ru.zdevs.zarchiver.tool.C0166c;
import ru.zdevs.zarchiver.tool.C0202q;
import ru.zdevs.zarchiver.widget.EditPassword;

public class ZCompressDialog extends ZDialog implements OnCancelListener, OnClickListener, View.OnClickListener, OnOkListener {
    private C0057m mAdpLevel;
    private C0057m mAdpSplit;
    private String mAppendFile;
    private String mArcFormat;
    private String mArcParam;
    private Button mBtnSelectPwd;
    private CheckBox mCbDeleteFile;
    private CheckBox mCbSeparate;
    private Context mContext;
    private boolean mDeleteFile;
    private Dialog mDlg;
    private int mEnc;
    private EditPassword mEtPassword;
    private EditText mEtTName;
    private int mFormat;
    private int mLevel;
    private String mName;
    private boolean mOneFile;
    private String mOriginalName;
    private String mPassword;
    private boolean mRoot;
    private boolean mSeparate;
    private int mSplit;
    private int mSplitAddCustomValue;
    private String mSplitValue;
    private Spinner mSpnEnc;
    private Spinner mSpnFormat;
    private Spinner mSpnLevel;
    private Spinner mSpnSplit;
    private int mType;

    /* renamed from: ru.zdevs.zarchiver.dialog.ZCompressDialog$1 */
    class C00971 implements OnItemSelectedListener {
        /* renamed from: a */
        final /* synthetic */ ZCompressDialog f290a;

        C00971(ZCompressDialog zCompressDialog) {
            this.f290a = zCompressDialog;
        }

        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
            if (i == this.f290a.mSplitAddCustomValue) {
                this.f290a.showPartSizeDlg(this.f290a.mContext);
            }
        }

        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    /* renamed from: ru.zdevs.zarchiver.dialog.ZCompressDialog$2 */
    class C00982 implements OnItemSelectedListener {
        /* renamed from: a */
        final /* synthetic */ ZCompressDialog f291a;

        C00982(ZCompressDialog zCompressDialog) {
            this.f291a = zCompressDialog;
        }

        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
            this.f291a.setArchiveType(i);
        }

        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    /* renamed from: ru.zdevs.zarchiver.dialog.ZCompressDialog$3 */
    class C00993 implements OnCheckedChangeListener {
        /* renamed from: a */
        final /* synthetic */ ZCompressDialog f292a;

        C00993(ZCompressDialog zCompressDialog) {
            this.f292a = zCompressDialog;
        }

        public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
            if (z) {
                String str = "";
                int lastIndexOf = this.f292a.mOriginalName.lastIndexOf(47);
                if (lastIndexOf >= 0) {
                    str = this.f292a.mOriginalName.substring(0, lastIndexOf);
                }
                this.f292a.mEtTName.setText(str + "<name>");
                this.f292a.mSpnSplit.setEnabled(false);
                this.f292a.mSpnSplit.setSelection(0);
                this.f292a.mAdpSplit.m143a(false);
            } else {
                this.f292a.mEtTName.setText(this.f292a.mOriginalName);
                this.f292a.mSpnSplit.setEnabled(true);
                this.f292a.mAdpSplit.m143a(true);
            }
            this.f292a.setArchiveType(this.f292a.mSpnFormat.getSelectedItemPosition());
        }
    }

    /* renamed from: ru.zdevs.zarchiver.dialog.ZCompressDialog$4 */
    class C01004 implements OnShowListener {
        /* renamed from: a */
        final /* synthetic */ ZCompressDialog f293a;

        C01004(ZCompressDialog zCompressDialog) {
            this.f293a = zCompressDialog;
        }

        public void onShow(DialogInterface dialogInterface) {
            this.f293a.fixHoloTitle(this.f293a.mDlg);
        }
    }

    public ZCompressDialog(C0136e c0136e, Context context, String str, boolean z, boolean z2, boolean z3) {
        this.mCS = c0136e;
        boolean z4 = z && !z2;
        this.mOneFile = z4;
        this.mRoot = z3;
        this.mAppendFile = null;
        this.mType = -1;
        this.mName = "";
        this.mOriginalName = str;
        if (z2) {
            this.mOriginalName += ".ext";
        }
        if (this.mRoot && !this.mOriginalName.startsWith("/") && Settings.sArchiveDir == null) {
            this.mOriginalName = Settings.sHomeDir + "/" + this.mOriginalName;
        }
        this.mFormat = 0;
        this.mSplit = 0;
        this.mEnc = 0;
        this.mLevel = 0;
        this.mPassword = "";
        this.mSplitValue = "";
        this.mSplitAddCustomValue = 0;
        this.mSeparate = false;
        create(context, this.mOriginalName);
        this.mDeleteFile = Settings.sCompressRemoveFile;
        String str2 = "";
        this.mArcFormat = str2;
        this.mArcParam = str2;
        addDialog();
    }

    private void addSplitValue(Context context, String str) {
        this.mAdpSplit.m140a();
        this.mAdpSplit.m142a(context.getResources().getString(R.string.CMP_SPLIT_NO));
        this.mAdpSplit.m142a("5" + C0202q.f554b);
        this.mAdpSplit.m142a("10" + C0202q.f554b);
        this.mAdpSplit.m142a("24" + C0202q.f554b);
        this.mAdpSplit.m142a("50" + C0202q.f554b);
        this.mAdpSplit.m142a("100" + C0202q.f554b);
        this.mSplitAddCustomValue = this.mAdpSplit.getCount();
        this.mAdpSplit.m142a(context.getResources().getString(R.string.CMP_SPLIT_OVER_SIZE));
        if (str != null) {
            this.mAdpSplit.m142a(str);
        }
        this.mSpnSplit.setAdapter(this.mAdpSplit);
        if (str != null) {
            this.mSpnSplit.setSelection(this.mAdpSplit.getCount() - 1);
        } else {
            this.mSpnSplit.setSelection(0);
        }
    }

    private void build7ZCommand() {
        int i = 1;
        String type = getType(this.mSpnFormat.getSelectedItem().toString());
        this.mArcFormat = type;
        StringBuilder stringBuilder = new StringBuilder();
        String obj = this.mEtPassword.getText().toString();
        if (this.mEtPassword.isEnabled() && obj.length() > 0) {
            stringBuilder.append("\\-p").append(obj.replace("\\", "\\\\"));
            if (this.mSpnFormat.getSelectedItemId() != 0) {
                if (this.mSpnFormat.getSelectedItemId() == 1) {
                    switch (this.mSpnEnc.getSelectedItemPosition()) {
                        case 1:
                            stringBuilder.append("\\-mem=AES128");
                            break;
                        case 2:
                            stringBuilder.append("\\-mem=AES192");
                            break;
                        case 3:
                            stringBuilder.append("\\-mem=AES256");
                            break;
                        default:
                            break;
                    }
                }
            } else if (this.mSpnEnc.getSelectedItemPosition() == 1) {
                stringBuilder.append("\\-mhe");
            }
        }
        int selectedItemPosition = this.mSpnLevel.getSelectedItemPosition();
        if (selectedItemPosition > 0) {
            selectedItemPosition = (selectedItemPosition * 2) - 1;
        }
        if (selectedItemPosition > 0 || !type.equalsIgnoreCase("lz4")) {
            i = selectedItemPosition;
        }
        if (this.mSpnFormat.getSelectedItemId() != 2) {
            stringBuilder.append("\\-mx=").append(i);
        }
        if (this.mSpnFormat.getSelectedItemId() == 0) {
            if (i > 0 && (Settings.s7zOptions & 1) == 0) {
                stringBuilder.append("\\-m0=LZMA");
            }
            if ((Settings.s7zOptions & 2) != 0) {
                stringBuilder.append("\\-ms=").append(C0071e.m286a(i)).append('m');
            } else {
                stringBuilder.append("\\-ms=off");
            }
            stringBuilder.append("\\-mf=off");
            i = C0071e.m287a(i, false);
            if (i > 0) {
                stringBuilder.append("\\-md=").append(i).append("m");
            }
        }
        if (this.mSpnSplit.isEnabled() && this.mSpnSplit.getSelectedItemId() > 0) {
            String obj2 = this.mSpnSplit.getSelectedItem().toString();
            if (obj2 != null && obj2.length() > 0) {
                obj = obj2.trim();
                obj2 = obj.endsWith(C0202q.f554b) ? "m" : obj.endsWith(C0202q.f555c) ? "k" : obj.endsWith(C0202q.f553a) ? "g" : "b";
                obj = obj.replaceAll("[\\D]", "");
                if (obj != null && obj.length() > 0) {
                    selectedItemPosition = Integer.parseInt(obj);
                    if (selectedItemPosition > 0) {
                        stringBuilder.append("\\-v").append(selectedItemPosition).append(obj2);
                    }
                }
            }
        }
        this.mArcParam = stringBuilder.toString();
    }

    private void buildCommand() {
        String str = "";
        this.mArcParam = str;
        this.mArcFormat = str;
        str = this.mEtTName.getText().toString();
        if (str.length() > 0) {
            build7ZCommand();
            if (!(this.mAppendFile == null || str.equals(this.mAppendFile))) {
                this.mAppendFile = null;
            }
            Settings.setLateCompressOpt(this.mContext, this.mSpnFormat.getSelectedItem().toString(), this.mSpnLevel.getSelectedItemPosition(), this.mSpnEnc.getSelectedItemPosition(), this.mCbDeleteFile.isChecked());
        }
    }

    private void create(Context context, String str) {
        this.mContext = context;
        Builder builder = new Builder(this.mContext);
        builder.setTitle(R.string.CMP_TTL_COMPRESS);
        View inflate = LayoutInflater.from(context).inflate(R.layout.dlg_compress, new LinearLayout(context));
        this.mEtTName = (EditText) inflate.findViewById(R.id.edt_name);
        this.mEtTName.setInputType(262145);
        this.mEtTName.setText(str);
        Button button = (Button) inflate.findViewById(R.id.btn_path);
        if (button != null) {
            button.setOnClickListener(this);
        }
        this.mCbDeleteFile = (CheckBox) inflate.findViewById(R.id.cb_deletefile);
        if (this.mRoot) {
            this.mCbDeleteFile.setEnabled(false);
            this.mCbDeleteFile.setChecked(false);
        } else {
            this.mCbDeleteFile.setChecked(this.mDeleteFile);
        }
        this.mCbSeparate = (CheckBox) inflate.findViewById(R.id.cb_separate);
        if (this.mOneFile) {
            this.mCbSeparate.setEnabled(false);
        }
        this.mSpnLevel = (Spinner) inflate.findViewById(R.id.spn_level);
        this.mAdpLevel = new C0057m(this.mContext);
        this.mAdpLevel.m144a(this.mContext.getResources().getStringArray(R.array.CMP_LIST_LEVELS));
        this.mSpnLevel.setAdapter(this.mAdpLevel);
        this.mSpnEnc = (Spinner) inflate.findViewById(R.id.spn_encrypt);
        this.mSpnSplit = (Spinner) inflate.findViewById(R.id.spn_split);
        this.mAdpSplit = new C0057m(this.mContext);
        addSplitValue(context, null);
        this.mEtPassword = (EditPassword) inflate.findViewById(R.id.edt_password);
        this.mEtPassword.setHint(R.string.CMP_ENTER_PASSWORD);
        this.mEtPassword.setFilters(new InputFilter[]{new LengthFilter(256)});
        this.mSpnFormat = (Spinner) inflate.findViewById(R.id.spn_format);
        SpinnerAdapter createFromResource;
        if (!this.mOneFile) {
            createFromResource = ArrayAdapter.createFromResource(this.mContext, R.array.CMP_LIST_FORMATS_ANY, 17367048);
            createFromResource.setDropDownViewResource(17367049);
            this.mSpnFormat.setAdapter(createFromResource);
        } else if (this.mOriginalName.toLowerCase(Locale.getDefault()).endsWith(".tar")) {
            createFromResource = ArrayAdapter.createFromResource(this.mContext, R.array.CMP_LIST_FORMATS_TAR, 17367048);
            createFromResource.setDropDownViewResource(17367049);
            this.mSpnFormat.setAdapter(createFromResource);
        }
        this.mSpnSplit.setOnItemSelectedListener(new C00971(this));
        this.mSpnFormat.setOnItemSelectedListener(new C00982(this));
        this.mCbSeparate.setOnCheckedChangeListener(new C00993(this));
        if (Settings.sCompressDefLevel < this.mSpnLevel.getCount() && Settings.sCompressDefLevel >= 0) {
            this.mSpnLevel.setSelection(Settings.sCompressDefLevel);
        }
        if (Settings.sCompressDefEncrypt < this.mSpnEnc.getCount() && Settings.sCompressDefEncrypt >= 0) {
            this.mSpnEnc.setSelection(Settings.sCompressDefEncrypt);
        }
        int i = 0;
        while (i < this.mSpnFormat.getCount()) {
            if (this.mSpnFormat.getItemAtPosition(i) != null && Settings.sCompressDefType.equalsIgnoreCase(this.mSpnFormat.getItemAtPosition(i).toString())) {
                this.mSpnFormat.setSelection(i);
                break;
            }
            i++;
        }
        builder.setView(inflate);
        builder.setPositiveButton(R.string.BTN_OK, this);
        builder.setNegativeButton(R.string.BTN_CANCEL, this);
        builder.setOnCancelListener(this);
        this.mDlg = builder.create();
        this.mDlg.setOnShowListener(new C01004(this));
    }

    private String getExtension(String str) {
        return str.equalsIgnoreCase("bzip2") ? ".bz2" : str.equalsIgnoreCase("gzip") ? ".gz" : "." + str.toLowerCase(Locale.US);
    }

    private String getType(String str) {
        return str.equalsIgnoreCase("tar.bz2") ? "tbz" : str.equalsIgnoreCase("tar.gz") ? "tgz" : str.equalsIgnoreCase("tar.xz") ? "txz" : str.equalsIgnoreCase("tar.lz4") ? "tlz4" : str.toLowerCase(Locale.US);
    }

    private boolean isSaveName(String str) {
        return (str.equalsIgnoreCase("xz") || str.equalsIgnoreCase("bzip2") || str.equalsIgnoreCase("gzip") || str.equalsIgnoreCase("lz4")) ? false : true;
    }

    private boolean isValidPwd() {
        if (this.mEtPassword == null || !this.mEtPassword.isEnabled()) {
            return true;
        }
        if (this.mSpnFormat == null || this.mSpnFormat.getSelectedItemId() != 1) {
            return true;
        }
        if (this.mSpnEnc == null || this.mSpnEnc.getSelectedItemId() != 0) {
            return true;
        }
        String obj = this.mEtPassword.getText().toString();
        if (obj.length() <= 0) {
            return true;
        }
        for (int i = 0; i < obj.length(); i++) {
            char charAt = obj.charAt(i);
            if (charAt < ' ' || charAt > '') {
                return false;
            }
        }
        return true;
    }

    private void setArchiveType(int i) {
        String obj;
        String extension;
        boolean z = false;
        if (this.mType >= 0) {
            obj = this.mEtTName.getText().toString();
            extension = getExtension(this.mSpnFormat.getItemAtPosition(this.mType).toString());
            obj = obj.endsWith(extension) ? obj.substring(0, obj.length() - extension.length()) : C0202q.m728a(this.mEtTName.getText().toString());
            if (obj.equals(this.mOriginalName)) {
                obj = C0202q.m728a(obj);
            }
        } else {
            obj = C0202q.m728a(this.mEtTName.getText().toString());
            if (obj.equals(this.mOriginalName)) {
                obj = C0202q.m728a(obj);
            }
        }
        extension = this.mSpnFormat.getItemAtPosition(i).toString();
        String extension2 = getExtension(extension);
        r0 = !isSaveName(extension) ? C0202q.m728a(this.mOriginalName).equals(obj) ? this.mOriginalName + extension2 : obj + extension2 : obj + extension2;
        this.mEtTName.setText(r0);
        this.mSpnEnc.setEnabled(i <= 1);
        if (i <= 1) {
            SpinnerAdapter createFromResource = ArrayAdapter.createFromResource(this.mContext, i == 0 ? R.array.CMP_LIST_ENCRYPT_7Z : R.array.CMP_LIST_ENCRYPT_ZIP, 17367048);
            createFromResource.setDropDownViewResource(17367049);
            this.mSpnEnc.setAdapter(createFromResource);
        }
        this.mEtPassword.setEnabled(i <= 1);
        if (this.mBtnSelectPwd != null) {
            this.mBtnSelectPwd.setEnabled(i <= 1);
        }
        this.mSpnSplit.setEnabled(i <= 1);
        Spinner spinner = this.mSpnLevel;
        if (i != 2) {
            z = true;
        }
        spinner.setEnabled(z);
        setLevelEnabled(extension);
        int i2 = 3;
        if (i == 0) {
            try {
                i2 = Integer.parseInt(Settings.sLevel7z);
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
        } else if (i == 1) {
            i2 = Integer.parseInt(Settings.sLevelZip);
        }
        if (i2 > 0) {
            i2 = (i2 + 1) >> 1;
        }
        if (i2 >= 0) {
            this.mSpnLevel.setSelection(i2);
        }
        if (Settings.sCompressDefType.equalsIgnoreCase(extension)) {
            if (Settings.sCompressDefLevel < this.mSpnLevel.getCount() && Settings.sCompressDefLevel >= 0) {
                this.mSpnLevel.setSelection(Settings.sCompressDefLevel);
            }
            if (Settings.sCompressDefEncrypt < this.mSpnEnc.getCount() && Settings.sCompressDefEncrypt >= 0) {
                this.mSpnEnc.setSelection(Settings.sCompressDefEncrypt);
            }
        }
        this.mType = i;
    }

    private void setLevelEnabled(String str) {
        if (this.mSpnLevel != null && this.mAdpLevel != null) {
            this.mAdpLevel.m143a(true);
            if (str.equalsIgnoreCase("lz4")) {
                this.mAdpLevel.m141a(0, false);
            }
            if ((str.equalsIgnoreCase(ZArchiverExtInterface.ARCHIVE_TYPE_7Z) || str.equalsIgnoreCase("xz") || str.equalsIgnoreCase("lz4")) && !Settings.sExtIgnoreRAMLimit.booleanValue()) {
                int a = C0071e.m285a();
                if (a < 9) {
                    this.mAdpLevel.m141a(5, false);
                }
                if (a < 7) {
                    this.mAdpLevel.m141a(4, false);
                }
                if (a < 5) {
                    this.mAdpLevel.m141a(3, false);
                }
                if (a < 3) {
                    this.mAdpLevel.m141a(2, false);
                }
            }
        }
    }

    private void showPartSizeDlg(final Context context) {
        Builder builder = new Builder(context);
        builder.setTitle(R.string.app_name);
        View inflate = LayoutInflater.from(context).inflate(R.layout.dlg_split_size, new LinearLayout(context));
        final EditText editText = (EditText) inflate.findViewById(R.id.etSplitSize);
        final Spinner spinner = (Spinner) inflate.findViewById(R.id.spSplitSize);
        spinner.setSelection(2);
        builder.setView(inflate);
        builder.setPositiveButton(R.string.BTN_OK, new OnClickListener(this) {
            /* renamed from: d */
            final /* synthetic */ ZCompressDialog f297d;

            public void onClick(DialogInterface dialogInterface, int i) {
                try {
                    int parseInt = Integer.parseInt(editText.getText().toString());
                    Spinner spinner = (Spinner) this.f297d.mDlg.findViewById(R.id.spn_split);
                    if (parseInt > 0 && spinner != null) {
                        this.f297d.addSplitValue(context, String.valueOf(parseInt) + spinner.getSelectedItem().toString());
                    }
                } catch (Throwable e) {
                    C0166c.m556a(e);
                }
            }
        });
        AlertDialog create = builder.create();
        create.show();
        create.setCanceledOnTouchOutside(false);
    }

    public void close() {
        if (this.mDlg != null) {
            this.mDlg.dismiss();
            this.mDlg = null;
        }
        delDialog();
    }

    public String getArcName() {
        return this.mName;
    }

    public boolean getDeleteFile() {
        return this.mDeleteFile && !this.mRoot;
    }

    public String getFormat() {
        return this.mArcFormat;
    }

    public String getParam() {
        return this.mArcParam;
    }

    public boolean getSeparated() {
        return this.mSeparate;
    }

    public int getType() {
        return 5;
    }

    public void hide() {
        if (this.mDlg != null) {
            this.mName = this.mEtTName.getText().toString();
            this.mLevel = this.mSpnLevel.getSelectedItemPosition();
            this.mEnc = this.mSpnEnc.getSelectedItemPosition();
            this.mSplit = this.mSpnSplit.getSelectedItemPosition();
            if (this.mSplit >= 5) {
                this.mSplitValue = this.mSpnSplit.getSelectedItem().toString();
            }
            this.mPassword = this.mEtPassword.getText().toString();
            this.mFormat = this.mSpnFormat.getSelectedItemPosition();
            this.mDeleteFile = this.mCbDeleteFile.isChecked();
            this.mSeparate = this.mCbSeparate.isChecked();
            this.mDlg.dismiss();
            this.mDlg = null;
        }
    }

    public boolean isAppendArchive() {
        return this.mAppendFile != null;
    }

    public void onCancel(DialogInterface dialogInterface) {
        if (this.mOnCancelListener != null) {
            this.mOnCancelListener.onCancel(this);
        }
        this.mDlg = null;
    }

    public void onClick(DialogInterface dialogInterface, int i) {
        if (i == -1 && this.mOnOkListener != null) {
            if (isValidPwd()) {
                buildCommand();
                this.mName = this.mEtTName.getText().toString();
                this.mDeleteFile = this.mCbDeleteFile.isChecked();
                this.mSeparate = this.mCbSeparate.isChecked();
                this.mOnOkListener.onOk(this);
            } else {
                Toast.makeText(this.mContext, this.mContext.getResources().getString(R.string.MES_SUPPORT_ONLY_ASCII_PWD), 0).show();
                return;
            }
        }
        if (i == -2 && this.mOnCancelListener != null) {
            this.mOnCancelListener.onCancel(this);
        }
        close();
    }

    public void onClick(View view) {
        if (this.mDlg != null && view != null) {
            switch (view.getId()) {
                case R.id.btn_path:
                    ZFileSelect zFileSelect = new ZFileSelect(this.mCS, this.mContext, R.string.CMP_TTL_COMPRESS, (byte) 11);
                    boolean z = Settings.sRoot && C0073a.m304f();
                    zFileSelect.setRootSupport(z);
                    zFileSelect.setTaskID(getTaskID());
                    zFileSelect.setOnOkListener(this);
                    zFileSelect.show();
                    return;
                default:
                    return;
            }
        }
    }

    public void onOk(ZDialog zDialog) {
        if (this.mDlg != null && zDialog != null && zDialog.getType() == 7) {
            ZFileSelect zFileSelect = (ZFileSelect) zDialog;
            String fileName = zFileSelect.getFileName();
            if (fileName == null) {
                fileName = this.mEtTName.getText().toString();
                int lastIndexOf = fileName.lastIndexOf(47);
                Object obj = lastIndexOf >= 0 ? zFileSelect.getPath() + fileName.substring(lastIndexOf) : zFileSelect.getPath() + "/" + fileName;
                this.mEtTName.setText(obj);
                this.mEtTName.setSelection(obj.length());
                return;
            }
            this.mAppendFile = zFileSelect.getPath() + "/" + fileName;
            this.mEtTName.setText(this.mAppendFile);
            String d = C0202q.m743d(fileName);
            int i = 0;
            while (i < this.mSpnFormat.getCount()) {
                if (this.mSpnFormat.getItemAtPosition(i) == null || !d.equalsIgnoreCase(this.mSpnFormat.getItemAtPosition(i).toString())) {
                    i++;
                } else {
                    this.mSpnFormat.setSelection(i);
                    return;
                }
            }
        }
    }

    public void reShow(Context context) {
        create(context, this.mName);
        if (this.mDlg != null) {
            show();
            this.mSpnFormat.setSelection(this.mFormat);
            this.mSpnLevel.setSelection(this.mLevel);
            this.mSpnEnc.setSelection(this.mEnc);
            if (this.mSplit <= 5) {
                this.mSpnSplit.setSelection(this.mSplit);
            } else {
                addSplitValue(context, this.mSplitValue);
            }
            this.mEtPassword.setText(this.mPassword);
            this.mCbDeleteFile.setChecked(this.mDeleteFile);
            this.mCbSeparate.setChecked(this.mSeparate);
        }
    }

    public void setPassword(String str) {
        this.mPassword = str;
        if (this.mDlg != null) {
            this.mEtPassword.setText(str);
        }
    }

    public void show() {
        if (this.mDlg != null) {
            this.mDlg.show();
        }
    }
}
