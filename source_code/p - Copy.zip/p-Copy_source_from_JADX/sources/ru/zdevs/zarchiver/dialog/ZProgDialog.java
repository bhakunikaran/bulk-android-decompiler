package ru.zdevs.zarchiver.dialog;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import ru.zdevs.zarchiver.C0136e;
import ru.zdevs.zarchiver.R;
import ru.zdevs.zarchiver.tool.C0166c;

public class ZProgDialog extends ZDialog implements OnCancelListener, OnClickListener, View.OnClickListener {
    private CheckBox mCbKeepScreenOn;
    private AlertDialog mDlg;
    private boolean mKeepScreenOn;
    private int mOperation;
    private ProgressBar mPbProgress;
    private int mProgress;
    protected boolean mShowTitle = false;
    private String mStatus;
    private TextView mTvProgressCaption;
    private TextView mTvProgressName;
    private TextView mTvProgressPercent;

    /* renamed from: ru.zdevs.zarchiver.dialog.ZProgDialog$1 */
    class C01311 implements View.OnClickListener {
        /* renamed from: a */
        final /* synthetic */ ZProgDialog f339a;

        C01311(ZProgDialog zProgDialog) {
            this.f339a = zProgDialog;
        }

        public void onClick(View view) {
            if (this.f339a.mDlg != null && this.f339a.mDlg.getWindow() != null) {
                if (this.f339a.mCbKeepScreenOn.isChecked()) {
                    this.f339a.mDlg.getWindow().addFlags(128);
                } else {
                    this.f339a.mDlg.getWindow().clearFlags(128);
                }
            }
        }
    }

    public ZProgDialog(C0136e c0136e, Context context, int i) {
        this.mCS = c0136e;
        this.mOperation = i;
        create(context);
        addDialog();
    }

    private void create(Context context) {
        Builder builder = new Builder(context);
        if (this.mShowTitle) {
            builder.setTitle(R.string.app_name);
        }
        View inflate = LayoutInflater.from(context).inflate(R.layout.dlg_progress, new LinearLayout(context));
        TextView textView = (TextView) inflate.findViewById(R.id.tvProgress);
        if (textView != null) {
            textView.setText(context.getResources().getString(this.mOperation));
        }
        this.mPbProgress = (ProgressBar) inflate.findViewById(R.id.pbProgress);
        this.mTvProgressPercent = (TextView) inflate.findViewById(R.id.tvProgressPercent);
        this.mTvProgressName = (TextView) inflate.findViewById(R.id.tvProgressName);
        this.mTvProgressCaption = (TextView) inflate.findViewById(R.id.tvProgressCaption);
        this.mTvProgressCaption.setVisibility(8);
        this.mCbKeepScreenOn = (CheckBox) inflate.findViewById(R.id.cbKeepScreenOn);
        builder.setView(inflate);
        builder.setPositiveButton(R.string.BTN_HIDE, this);
        builder.setNegativeButton(R.string.BTN_CANCEL, this);
        builder.setOnCancelListener(this);
        this.mDlg = builder.create();
        this.mDlg.setCanceledOnTouchOutside(false);
        this.mPbProgress.setIndeterminate(true);
        this.mCbKeepScreenOn.setOnClickListener(new C01311(this));
    }

    public void close() {
        if (this.mDlg != null) {
            try {
                this.mDlg.dismiss();
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
            this.mDlg = null;
        }
        this.mPbProgress = null;
        this.mTvProgressPercent = null;
        this.mTvProgressName = null;
        this.mTvProgressCaption = null;
        this.mCbKeepScreenOn = null;
        delDialog();
    }

    public int getType() {
        return 2;
    }

    public void hide() {
        if (this.mDlg != null) {
            this.mProgress = this.mPbProgress.getProgress();
            this.mStatus = this.mTvProgressName.getText().toString();
            this.mKeepScreenOn = this.mCbKeepScreenOn.isChecked();
            this.mDlg.dismiss();
            this.mDlg = null;
        }
        this.mPbProgress = null;
        this.mTvProgressPercent = null;
        this.mTvProgressName = null;
        this.mTvProgressCaption = null;
        this.mCbKeepScreenOn = null;
    }

    public void onCancel(DialogInterface dialogInterface) {
        if (this.mOnCancelListener != null) {
            this.mOnCancelListener.onCancel(this);
        }
    }

    public void onClick(DialogInterface dialogInterface, int i) {
        if (i == -1 && this.mOnOkListener != null) {
            this.mOnOkListener.onOk(this);
        }
        if (i == -2 && this.mOnCancelListener != null) {
            this.mOnCancelListener.onCancel(this);
        }
        close();
    }

    public void onClick(View view) {
        if (view.getTag() != null && ((Integer) view.getTag()).intValue() == -2 && this.mOnCancelListener != null) {
            this.mOnCancelListener.onCancel(this);
        }
    }

    public void reShow(Context context) {
        create(context);
        show();
        setProgress(this.mProgress);
        setText(this.mStatus);
        this.mCbKeepScreenOn.setChecked(this.mKeepScreenOn);
        if (this.mKeepScreenOn && this.mDlg.getWindow() != null) {
            this.mDlg.getWindow().addFlags(128);
        }
    }

    public void setCaption(String str) {
        if (this.mDlg != null) {
            if (this.mTvProgressCaption.getVisibility() == 8) {
                this.mTvProgressCaption.setVisibility(0);
            }
            this.mTvProgressCaption.setText(str);
        }
    }

    public void setProgress(int i) {
        if (this.mDlg != null) {
            this.mPbProgress.setProgress(i);
            if (i > 0) {
                this.mPbProgress.setIndeterminate(false);
            }
            this.mTvProgressPercent.setText(i + "%");
            this.mPbProgress.postInvalidate();
            this.mTvProgressPercent.postInvalidate();
        }
    }

    public void setText(String str) {
        if (this.mDlg != null) {
            this.mTvProgressName.setText(str);
        }
    }

    public void show() {
        if (this.mDlg != null) {
            this.mDlg.show();
            Button button = this.mDlg.getButton(-2);
            button.setTag(Integer.valueOf(-2));
            button.setOnClickListener(this);
        }
    }
}
