package ru.zdevs.zarchiver.dialog;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnKeyListener;
import android.content.DialogInterface.OnShowListener;
import android.view.KeyEvent;
import ru.zdevs.zarchiver.C0136e;
import ru.zdevs.zarchiver.R;
import ru.zdevs.zarchiver.tool.C0166c;

public class ZProcDialog extends ZDialog implements OnCancelListener, OnKeyListener {
    private ProgressDialog mDlg;
    private int mTitleID;

    /* renamed from: ru.zdevs.zarchiver.dialog.ZProcDialog$1 */
    class C01301 implements OnShowListener {
        /* renamed from: a */
        final /* synthetic */ ZProcDialog f338a;

        C01301(ZProcDialog zProcDialog) {
            this.f338a = zProcDialog;
        }

        public void onShow(DialogInterface dialogInterface) {
            this.f338a.fixHoloTitle(this.f338a.mDlg);
        }
    }

    public ZProcDialog(C0136e c0136e, Context context, int i) {
        this.mCS = c0136e;
        this.mTitleID = i;
        create(context);
        addDialog();
    }

    private void create(Context context) {
        if (context != null) {
            this.mDlg = new ProgressDialog(context);
            this.mDlg.setProgressStyle(0);
            this.mDlg.setTitle(R.string.app_name);
            this.mDlg.setMessage(context.getResources().getString(this.mTitleID));
            this.mDlg.setCancelable(false);
            this.mDlg.setOnKeyListener(this);
            this.mDlg.setCanceledOnTouchOutside(false);
            this.mDlg.setOnShowListener(new C01301(this));
        }
    }

    public void close() {
        hide();
        delDialog();
    }

    public int getType() {
        return 1;
    }

    public void hide() {
        if (this.mDlg != null) {
            try {
                this.mDlg.dismiss();
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
            this.mDlg = null;
        }
    }

    public void onCancel(DialogInterface dialogInterface) {
        if (this.mOnCancelListener != null) {
            this.mOnCancelListener.onCancel(this);
        }
    }

    public boolean onKey(DialogInterface dialogInterface, int i, KeyEvent keyEvent) {
        if (keyEvent.getKeyCode() == 4 && keyEvent.getAction() == 1) {
            onCancel(dialogInterface);
        }
        return false;
    }

    public void reShow(Context context) {
        create(context);
        show();
    }

    public void show() {
        if (this.mDlg != null) {
            this.mDlg.show();
        }
    }
}
