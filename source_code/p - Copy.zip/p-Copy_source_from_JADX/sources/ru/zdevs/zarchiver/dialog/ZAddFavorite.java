package ru.zdevs.zarchiver.dialog;

import android.annotation.SuppressLint;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface.OnShowListener;
import android.content.res.Resources;
import android.os.Build.VERSION;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import ru.zdevs.zarchiver.C0136e;
import ru.zdevs.zarchiver.R;
import ru.zdevs.zarchiver.fs.MyUri;
import ru.zdevs.zarchiver.p003a.C0054j;
import ru.zdevs.zarchiver.p003a.C0056l;
import ru.zdevs.zarchiver.tool.C0169f;

public class ZAddFavorite extends ZDialog implements OnCancelListener, OnClickListener {
    private static final int ICON_MAX = 10;
    private static final int ICON_MIN = -2;
    private Dialog mDlg;
    private EditText mEtText;
    private String mFavoriteName;
    private int mIconNum;
    private MyUri mPath;
    private Spinner mSpnIcon;
    private String mTitle;

    /* renamed from: ru.zdevs.zarchiver.dialog.ZAddFavorite$1 */
    class C00941 implements OnShowListener {
        /* renamed from: a */
        final /* synthetic */ ZAddFavorite f287a;

        C00941(ZAddFavorite zAddFavorite) {
            this.f287a = zAddFavorite;
        }

        public void onShow(DialogInterface dialogInterface) {
            this.f287a.fixHoloTitle(this.f287a.mDlg);
        }
    }

    public ZAddFavorite(C0136e c0136e, Context context, int i, String str, String str2) {
        this(c0136e, context, i, str, new MyUri(str2));
    }

    public ZAddFavorite(C0136e c0136e, Context context, int i, String str, MyUri myUri) {
        this.mCS = c0136e;
        this.mTitle = str;
        if (this.mTitle == null || this.mTitle.length() <= 0) {
            this.mTitle = context.getString(R.string.ADDF_TTL_ADD_FAVORITE);
        }
        this.mFavoriteName = str;
        this.mPath = myUri;
        this.mIconNum = i;
        create(context);
        addDialog();
    }

    public ZAddFavorite(C0136e c0136e, Context context, String str, String str2) {
        this(c0136e, context, 1000, str, str2);
    }

    @SuppressLint({"NewApi"})
    private void buildIconList(Context context, C0054j c0054j) {
        int i = ICON_MIN;
        if (VERSION.SDK_INT < 21) {
            Resources resources = context.getResources();
            while (i <= ICON_MAX) {
                c0054j.m136a(new C0056l("", "", resources.getDrawable(C0169f.m574a(i))));
                i++;
            }
            return;
        }
        while (i <= ICON_MAX) {
            c0054j.m136a(new C0056l("", "", context.getDrawable(C0169f.m574a(i))));
            i++;
        }
    }

    private void create(Context context) {
        Builder builder = new Builder(context);
        builder.setTitle(this.mTitle);
        View inflate = LayoutInflater.from(context).inflate(R.layout.dlg_add_to_favotite, new LinearLayout(context));
        SpinnerAdapter c0054j = new C0054j(context);
        buildIconList(context, c0054j);
        if (this.mIconNum + 2 < 0 || this.mIconNum + 2 > ICON_MAX) {
            this.mIconNum = ICON_MAX;
        }
        TextView textView = (TextView) inflate.findViewById(R.id.tvText);
        textView.setText(textView.getText().toString().replace("%1", this.mPath.toViewString()));
        this.mEtText = (EditText) inflate.findViewById(R.id.edt_text);
        this.mEtText.setText(this.mFavoriteName);
        this.mSpnIcon = (Spinner) inflate.findViewById(R.id.spn_icon);
        this.mSpnIcon.setAdapter(c0054j);
        this.mSpnIcon.setSelection(this.mIconNum + 2);
        builder.setView(inflate);
        builder.setPositiveButton(R.string.BTN_OK, this);
        builder.setNegativeButton(R.string.BTN_CANCEL, this);
        builder.setOnCancelListener(this);
        this.mDlg = builder.create();
        this.mDlg.setOnShowListener(new C00941(this));
    }

    public void close() {
        hide();
        delDialog();
    }

    public int getIcon() {
        return this.mIconNum;
    }

    public String getText() {
        return this.mFavoriteName.replace('|', '!').replace(']', ')').replace('[', '(');
    }

    public int getType() {
        return 11;
    }

    public void hide() {
        if (this.mDlg != null) {
            this.mFavoriteName = this.mEtText.getText().toString();
            this.mIconNum = this.mSpnIcon.getSelectedItemPosition() + ICON_MIN;
            this.mDlg.dismiss();
            this.mDlg = null;
        }
    }

    public void onCancel(DialogInterface dialogInterface) {
        if (this.mOnCancelListener != null) {
            this.mOnCancelListener.onCancel(this);
        }
        close();
    }

    public void onClick(DialogInterface dialogInterface, int i) {
        if (this.mDlg != null) {
            this.mFavoriteName = this.mEtText.getText().toString();
            this.mIconNum = this.mSpnIcon.getSelectedItemPosition() + ICON_MIN;
        }
        if (i == -1 && this.mOnOkListener != null) {
            this.mOnOkListener.onOk(this);
        }
        if (i == ICON_MIN && this.mOnCancelListener != null) {
            this.mOnCancelListener.onCancel(this);
        }
        close();
    }

    public void reShow(Context context) {
        create(context);
        if (this.mDlg != null) {
            show();
        }
    }

    public void setText(String str) {
        if (this.mDlg != null && this.mEtText != null) {
            this.mEtText.setText(str);
        }
    }

    public void show() {
        if (this.mDlg != null) {
            this.mDlg.show();
        }
    }
}
