package ru.zdevs.zarchiver.dialog;

import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface.OnShowListener;
import ru.zdevs.zarchiver.C0136e;
import ru.zdevs.zarchiver.R;

public class ZMessageDialog extends ZDialog implements OnCancelListener, OnClickListener {
    public static final byte BTN_CANCEL_CONTINUE = (byte) 5;
    public static final byte BTN_OK = (byte) 4;
    public static final byte BTN_OK_CANCEL = (byte) 2;
    public static final byte BTN_YES_CANCEL = (byte) 3;
    public static final byte BTN_YES_NO = (byte) 1;
    private byte mButton;
    private Dialog mDlg;
    private String mText;

    /* renamed from: ru.zdevs.zarchiver.dialog.ZMessageDialog$1 */
    class C01271 implements OnShowListener {
        /* renamed from: a */
        final /* synthetic */ ZMessageDialog f335a;

        C01271(ZMessageDialog zMessageDialog) {
            this.f335a = zMessageDialog;
        }

        public void onShow(DialogInterface dialogInterface) {
            this.f335a.fixHoloTitle(this.f335a.mDlg);
        }
    }

    public ZMessageDialog(C0136e c0136e, Context context, byte b, String str) {
        this.mCS = c0136e;
        this.mButton = b;
        this.mText = str;
        create(context);
        addDialog();
    }

    private void create(Context context) {
        Builder builder = new Builder(context);
        builder.setTitle(R.string.app_name);
        builder.setMessage(this.mText);
        switch (this.mButton) {
            case (byte) 1:
                builder.setPositiveButton(R.string.BTN_YES, this);
                builder.setNegativeButton(R.string.BTN_NO, this);
                break;
            case (byte) 2:
                builder.setPositiveButton(R.string.BTN_OK, this);
                builder.setNegativeButton(R.string.BTN_CANCEL, this);
                break;
            case (byte) 3:
                builder.setPositiveButton(R.string.BTN_YES, this);
                builder.setNegativeButton(R.string.BTN_CANCEL, this);
                break;
            case (byte) 4:
                builder.setPositiveButton(R.string.BTN_OK, this);
                break;
            case (byte) 5:
                builder.setPositiveButton(R.string.BTN_CANCEL, this);
                break;
        }
        builder.setOnCancelListener(this);
        this.mDlg = builder.create();
        this.mDlg.setCanceledOnTouchOutside(false);
        this.mDlg.setOnShowListener(new C01271(this));
    }

    public void close() {
        hide();
        delDialog();
    }

    public int getType() {
        return 4;
    }

    public void hide() {
        if (this.mDlg != null) {
            this.mDlg.dismiss();
            this.mDlg = null;
        }
    }

    public void onCancel(DialogInterface dialogInterface) {
        if (this.mOnCancelListener != null) {
            this.mOnCancelListener.onCancel(this);
        }
        close();
    }

    public void onClick(DialogInterface dialogInterface, int i) {
        if (i == -1 && this.mOnOkListener != null) {
            this.mOnOkListener.onOk(this);
        }
        if (i == -2 && this.mOnCancelListener != null) {
            this.mOnCancelListener.onCancel(this);
        }
        close();
    }

    public void reShow(Context context) {
        create(context);
        if (this.mDlg != null) {
            show();
        }
    }

    public void show() {
        if (this.mDlg != null) {
            this.mDlg.show();
        }
    }

    public void showWithoutCancel() {
        if (this.mDlg != null) {
            this.mDlg.show();
            this.mDlg.setCancelable(false);
        }
    }
}
