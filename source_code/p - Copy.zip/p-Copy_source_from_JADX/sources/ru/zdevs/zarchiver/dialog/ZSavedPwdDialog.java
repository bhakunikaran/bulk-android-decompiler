package ru.zdevs.zarchiver.dialog;

import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface.OnShowListener;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import ru.zdevs.zarchiver.C0136e;
import ru.zdevs.zarchiver.R;
import ru.zdevs.zarchiver.p003a.C0056l;
import ru.zdevs.zarchiver.settings.Settings;
import ru.zdevs.zarchiver.tool.C0166c;

public class ZSavedPwdDialog extends ZDialog implements OnCancelListener, OnClickListener, OnItemClickListener, OnItemLongClickListener {
    private Context mContext;
    private Dialog mDlg;
    private List<C0056l> mItems;
    private ListView mPopupList;

    /* renamed from: ru.zdevs.zarchiver.dialog.ZSavedPwdDialog$1 */
    class C01331 implements OnShowListener {
        /* renamed from: a */
        final /* synthetic */ ZSavedPwdDialog f341a;

        C01331(ZSavedPwdDialog zSavedPwdDialog) {
            this.f341a = zSavedPwdDialog;
        }

        public void onShow(DialogInterface dialogInterface) {
            this.f341a.fixHoloTitle(this.f341a.mDlg);
        }
    }

    /* renamed from: ru.zdevs.zarchiver.dialog.ZSavedPwdDialog$a */
    private static class C0134a extends BaseAdapter {
        /* renamed from: a */
        private Context f342a;
        /* renamed from: b */
        private List<C0056l> f343b;
        /* renamed from: c */
        private LayoutInflater f344c = ((LayoutInflater) this.f342a.getSystemService("layout_inflater"));

        C0134a(Context context, List<C0056l> list) {
            this.f342a = context;
            this.f343b = list;
        }

        /* renamed from: b */
        private Drawable m394b(int i) {
            return VERSION.SDK_INT < 21 ? this.f342a.getResources().getDrawable(i) : this.f342a.getDrawable(i);
        }

        /* renamed from: a */
        public C0056l m395a(int i) {
            return (C0056l) this.f343b.get(i);
        }

        public int getCount() {
            return this.f343b.size();
        }

        public /* synthetic */ Object getItem(int i) {
            return m395a(i);
        }

        public long getItemId(int i) {
            return (long) ((C0056l) this.f343b.get(i)).f173d;
        }

        public View getView(int i, View view, ViewGroup viewGroup) {
            if (view == null) {
                view = this.f344c.inflate(R.layout.item_menu, viewGroup, false);
                ((ImageView) view.findViewById(R.id.ivIcon)).setImageDrawable(m394b(R.drawable.ic_menu_login));
            }
            ((TextView) view.findViewById(R.id.tvText)).setText(m395a(i).f170a);
            return view;
        }
    }

    public ZSavedPwdDialog(C0136e c0136e, Context context) {
        this.mCS = c0136e;
        create(context);
        addDialog();
    }

    private void create(Context context) {
        this.mContext = context;
        Builder builder = new Builder(context);
        builder.setTitle(R.string.PWD_TTL_SAVED_PASSWORD);
        View inflate = LayoutInflater.from(context).inflate(R.layout.dlg_menu, new LinearLayout(context));
        this.mPopupList = (ListView) inflate.findViewById(R.id.lvPopupList);
        this.mPopupList.setOnItemClickListener(this);
        this.mPopupList.setOnItemLongClickListener(this);
        updateList();
        builder.setNeutralButton(R.string.BTN_ADD, this);
        builder.setNegativeButton(R.string.BTN_CANCEL, this);
        builder.setView(inflate);
        builder.setOnCancelListener(this);
        this.mDlg = builder.create();
        this.mDlg.setCanceledOnTouchOutside(true);
        this.mDlg.setOnShowListener(new C01331(this));
    }

    public void close() {
        hide();
        delDialog();
    }

    public int getType() {
        return 13;
    }

    public void hide() {
        if (this.mDlg != null) {
            try {
                this.mDlg.dismiss();
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
            this.mDlg = null;
        }
        this.mContext = null;
        this.mPopupList = null;
    }

    public void onCancel(DialogInterface dialogInterface) {
        if (this.mOnCancelListener != null) {
            this.mOnCancelListener.onCancel(this);
        }
        close();
    }

    public void onClick(DialogInterface dialogInterface, int i) {
        if (i == -3 && this.mContext != null) {
            ZAddPasswordDialog zAddPasswordDialog = new ZAddPasswordDialog(this.mCS, this.mContext);
            zAddPasswordDialog.setTaskID(getTaskID());
            zAddPasswordDialog.show();
        }
        if (i == -2 && this.mOnCancelListener != null) {
            this.mOnCancelListener.onCancel(this);
        }
        close();
    }

    public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
        if (view != null) {
            if (i >= 0 && this.mItems != null && i < this.mItems.size()) {
                ZEnterPwdDialog zEnterPwdDialog = (ZEnterPwdDialog) this.mCS.m398a(getTaskID(), 12);
                if (zEnterPwdDialog != null) {
                    try {
                        zEnterPwdDialog.setPassword(Settings.getSavedPwdPassword(((C0056l) this.mItems.get(i)).f171b));
                    } catch (Throwable e) {
                        C0166c.m556a(e);
                    }
                } else {
                    ZCompressDialog zCompressDialog = (ZCompressDialog) this.mCS.m398a(getTaskID(), 5);
                    if (zCompressDialog != null) {
                        zCompressDialog.setPassword(Settings.getSavedPwdPassword(((C0056l) this.mItems.get(i)).f171b));
                    }
                }
            }
            close();
        }
    }

    public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long j) {
        if (view == null || i < 0 || this.mItems == null || i >= this.mItems.size()) {
            return false;
        }
        ZMessageDialog zMessageDialog = new ZMessageDialog(this.mCS, this.mContext, (byte) 1, this.mContext.getString(R.string.PWD_REMOVE_PASSWORD).replace("%1", ((C0056l) this.mItems.get(i)).f170a));
        zMessageDialog.setTaskID(getTaskID());
        zMessageDialog.setSubType(19);
        zMessageDialog.setStringData(1, "" + i);
        zMessageDialog.setOnOkListener(this.mCS.f350a);
        zMessageDialog.show();
        return true;
    }

    public void reShow(Context context) {
        create(context);
        if (this.mDlg != null) {
            show();
        }
    }

    public void show() {
        if (this.mDlg != null) {
            this.mDlg.show();
        }
    }

    public void updateList() {
        this.mItems = new ArrayList();
        for (String str : Settings.sSavedPassword) {
            this.mItems.add(new C0056l(Settings.getSavedPwdName(str), str));
        }
        if (this.mPopupList != null && this.mContext != null) {
            this.mPopupList.setAdapter(new C0134a(this.mContext, this.mItems));
        }
    }
}
