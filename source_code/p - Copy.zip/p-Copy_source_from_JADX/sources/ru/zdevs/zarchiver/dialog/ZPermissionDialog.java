package ru.zdevs.zarchiver.dialog;

import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface.OnShowListener;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.Locale;
import ru.zdevs.zarchiver.C0136e;
import ru.zdevs.zarchiver.R;
import ru.zdevs.zarchiver.fs.FSRoot;
import ru.zdevs.zarchiver.fs.MyUri;
import ru.zdevs.zarchiver.fs.ZViewFS.FSFileInfo;
import ru.zdevs.zarchiver.p004b.C0073a;
import ru.zdevs.zarchiver.p004b.C0075c;
import ru.zdevs.zarchiver.tool.C0166c;

public class ZPermissionDialog extends ZDialog implements OnClickListener, OnCheckedChangeListener {
    private static final int[] mGroupPerm = new int[]{R.id.cbGroupX, R.id.cbGroupW, R.id.cbGroupR};
    private static final int[] mOtherPerm = new int[]{R.id.cbOtherX, R.id.cbOtherW, R.id.cbOtherR};
    private static final int[][] mPerm = new int[][]{mUserPerm, mGroupPerm, mOtherPerm};
    private static final int[] mUserPerm = new int[]{R.id.cbUserX, R.id.cbUserW, R.id.cbUserR};
    private boolean mChangesHandle;
    private Dialog mDlg;
    private EditText mEtGID;
    private EditText mEtPermission;
    private TextView mEtPermissionsText;
    private EditText mEtUID;
    private int mGID;
    private int mGIDOld;
    private String[] mName;
    private MyUri[] mPath;
    private int mPermission;
    private int mPermissionOld;
    private int mUID;
    private int mUIDOld;

    /* renamed from: ru.zdevs.zarchiver.dialog.ZPermissionDialog$1 */
    class C01281 implements TextWatcher {
        /* renamed from: a */
        final /* synthetic */ ZPermissionDialog f336a;

        C01281(ZPermissionDialog zPermissionDialog) {
            this.f336a = zPermissionDialog;
        }

        public void afterTextChanged(Editable editable) {
        }

        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            this.f336a.onTextChange();
        }
    }

    /* renamed from: ru.zdevs.zarchiver.dialog.ZPermissionDialog$2 */
    class C01292 implements OnShowListener {
        /* renamed from: a */
        final /* synthetic */ ZPermissionDialog f337a;

        C01292(ZPermissionDialog zPermissionDialog) {
            this.f337a = zPermissionDialog;
        }

        public void onShow(DialogInterface dialogInterface) {
            this.f337a.fixHoloTitle(this.f337a.mDlg);
            this.f337a.mChangesHandle = true;
            this.f337a.onTextChange();
        }
    }

    public ZPermissionDialog(C0136e c0136e, Context context, MyUri myUri, String[] strArr) {
        this.mCS = c0136e;
        this.mPath = new MyUri[]{myUri};
        this.mName = (String[]) strArr.clone();
        initPermission(context);
        create(context);
        addDialog();
    }

    public ZPermissionDialog(C0136e c0136e, Context context, MyUri[] myUriArr, String[] strArr) {
        this.mCS = c0136e;
        this.mPath = (MyUri[]) myUriArr.clone();
        this.mName = (String[]) strArr.clone();
        initPermission(context);
        create(context);
        addDialog();
    }

    private void create(Context context) {
        Builder builder = new Builder(context);
        builder.setTitle(R.string.SPD_TTL_PERMISSIONS);
        View inflate = LayoutInflater.from(context).inflate(R.layout.dlg_permissions, new LinearLayout(context));
        for (int findViewById : mUserPerm) {
            ((CheckBox) inflate.findViewById(findViewById)).setOnCheckedChangeListener(this);
        }
        for (int findViewById2 : mGroupPerm) {
            ((CheckBox) inflate.findViewById(findViewById2)).setOnCheckedChangeListener(this);
        }
        for (int findViewById22 : mOtherPerm) {
            ((CheckBox) inflate.findViewById(findViewById22)).setOnCheckedChangeListener(this);
        }
        this.mEtPermission = (EditText) inflate.findViewById(R.id.etPermissions);
        this.mEtPermission.setText(String.format(Locale.getDefault(), "%1$03d", new Object[]{Integer.valueOf(this.mPermission)}));
        this.mEtPermission.addTextChangedListener(new C01281(this));
        this.mEtPermissionsText = (TextView) inflate.findViewById(R.id.etPermissionsText);
        setTextPermission();
        this.mEtUID = (EditText) inflate.findViewById(R.id.etUid);
        this.mEtUID.setText(String.format(Locale.getDefault(), "%1$d", new Object[]{Integer.valueOf(this.mUID)}));
        this.mEtGID = (EditText) inflate.findViewById(R.id.etGid);
        this.mEtGID.setText(String.format(Locale.getDefault(), "%1$d", new Object[]{Integer.valueOf(this.mGID)}));
        TextView textView = (TextView) inflate.findViewById(R.id.tvFileName);
        if (this.mName.length == 1) {
            textView.setText(this.mName[0]);
        } else {
            textView.setText(context.getString(R.string.FINFO_NAME_FILE_GROUP).replace("%1", "" + this.mName.length));
        }
        builder.setPositiveButton(R.string.BTN_OK, this);
        builder.setNegativeButton(R.string.BTN_CANCEL, this);
        builder.setView(inflate);
        builder.setCancelable(false);
        this.mDlg = builder.create();
        this.mDlg.setCanceledOnTouchOutside(false);
        this.mDlg.setOnShowListener(new C01292(this));
    }

    private void getData() {
        try {
            this.mPermission = Integer.parseInt(this.mEtPermission.getText().toString());
        } catch (Throwable e) {
            C0166c.m556a(e);
        }
        try {
            this.mUID = Integer.parseInt(this.mEtUID.getText().toString());
        } catch (Throwable e2) {
            C0166c.m556a(e2);
        }
        try {
            this.mGID = Integer.parseInt(this.mEtGID.getText().toString());
        } catch (Throwable e22) {
            C0166c.m556a(e22);
        }
    }

    private void initPermission(Context context) {
        this.mPermissionOld = 0;
        this.mPermission = 0;
        this.mUIDOld = -1;
        this.mUID = -1;
        this.mGIDOld = -1;
        this.mGID = -1;
        C0073a c0073a = null;
        for (int i = 0; i < this.mName.length; i++) {
            FSFileInfo fileInfo;
            MyUri myUri = this.mPath.length > 1 ? new MyUri(this.mPath[i]) : new MyUri(this.mPath[0]);
            myUri.add(this.mName[i]);
            FSFileInfo fileInfo2 = c0073a == null ? FSRoot.getFileInfo(myUri.toFile()) : FSRoot.getFileInfo(c0073a, myUri.toFile());
            if (fileInfo2 == null) {
                c0073a = new C0075c();
                fileInfo = FSRoot.getFileInfo(c0073a, myUri.toFile());
            } else {
                fileInfo = fileInfo2;
            }
            if (fileInfo != null) {
                try {
                    this.mUID = Integer.parseInt(fileInfo.mUID);
                } catch (Throwable e) {
                    C0166c.m556a(e);
                }
                if (this.mUIDOld == -1 || this.mUIDOld < this.mUID) {
                    this.mUIDOld = this.mUID;
                }
                try {
                    this.mGID = Integer.parseInt(fileInfo.mUID);
                } catch (Throwable e2) {
                    C0166c.m556a(e2);
                }
                if (this.mGIDOld == -1 || this.mGIDOld < this.mUID) {
                    this.mGIDOld = this.mGID;
                }
                int i2 = 10;
                int i3 = 1;
                for (int i4 = 0; i4 < 3; i4++) {
                    if ((this.mPermission % i2) / i3 < (fileInfo.mPermissions % i2) / i3) {
                        this.mPermission = (this.mPermission - (((this.mPermission % i2) / i3) * i3)) + (((fileInfo.mPermissions % i2) / i3) * i3);
                    }
                    i3 *= 10;
                    i2 *= 10;
                }
            }
        }
        this.mPermissionOld = this.mPermission;
        this.mGID = this.mGIDOld;
        this.mUID = this.mUIDOld;
        if (c0073a != null) {
            c0073a.mo54c();
        }
    }

    private void onTextChange() {
        if (this.mChangesHandle) {
            int selectionStart;
            int i;
            int parseInt;
            this.mChangesHandle = false;
            for (int parseInt2 : mUserPerm) {
                ((CheckBox) this.mDlg.findViewById(parseInt2)).setChecked(false);
            }
            for (int parseInt22 : mGroupPerm) {
                ((CheckBox) this.mDlg.findViewById(parseInt22)).setChecked(false);
            }
            for (int parseInt222 : mOtherPerm) {
                ((CheckBox) this.mDlg.findViewById(parseInt222)).setChecked(false);
            }
            String obj = this.mEtPermission.getText().toString();
            if (obj.contains("8") || obj.contains("9")) {
                selectionStart = this.mEtPermission.getSelectionStart();
                obj = obj.replace('8', '7').replace('9', '7');
                this.mEtPermission.setText(obj);
                this.mEtPermission.setSelection(selectionStart, selectionStart);
            }
            try {
                parseInt222 = Integer.parseInt(obj);
                i = 0;
                while (i < 3) {
                    int i2 = parseInt222 % 10;
                    int i3 = parseInt222 / 10;
                    int i4 = 0;
                    for (selectionStart = 1; selectionStart <= 4; selectionStart <<= 1) {
                        if ((i2 & selectionStart) == selectionStart) {
                            ((CheckBox) this.mDlg.findViewById(mPerm[2 - i][i4])).setChecked(true);
                        }
                        i4++;
                    }
                    i++;
                    parseInt222 = i3;
                }
                setTextPermission();
                this.mChangesHandle = true;
            } catch (Exception e) {
                this.mChangesHandle = true;
            }
        }
    }

    private void setTextPermission() {
        int parseInt;
        try {
            parseInt = Integer.parseInt(this.mEtPermission.getText().toString());
        } catch (Throwable e) {
            C0166c.m556a(e);
            parseInt = 0;
        }
        StringBuilder stringBuilder = new StringBuilder();
        int i = parseInt;
        for (parseInt = 0; parseInt < 3; parseInt++) {
            int i2 = i % 10;
            i /= 10;
            if ((i2 & 1) == 1) {
                stringBuilder.insert(0, 'x');
            } else {
                stringBuilder.insert(0, '-');
            }
            if ((i2 & 2) == 2) {
                stringBuilder.insert(0, 'w');
            } else {
                stringBuilder.insert(0, '-');
            }
            if ((i2 & 4) == 4) {
                stringBuilder.insert(0, 'r');
            } else {
                stringBuilder.insert(0, '-');
            }
            stringBuilder.insert(0, ' ');
        }
        this.mEtPermissionsText.setText(stringBuilder.toString());
    }

    public void close() {
        hide();
        delDialog();
    }

    public int getGID() {
        return this.mGID;
    }

    public String[] getNames() {
        return this.mName;
    }

    public MyUri[] getPath() {
        return this.mPath;
    }

    public int getPermission() {
        return this.mPermission;
    }

    public int getType() {
        return 16;
    }

    public int getUID() {
        return this.mUID;
    }

    public void hide() {
        getData();
        this.mEtPermission = null;
        this.mEtUID = null;
        this.mEtGID = null;
        if (this.mDlg != null) {
            this.mDlg.dismiss();
            this.mDlg = null;
        }
    }

    public boolean isPermissionChange() {
        return this.mPermission != this.mPermissionOld;
    }

    public boolean isUIDGIDChange() {
        return (this.mUID == this.mUIDOld && this.mGID == this.mGIDOld) ? false : true;
    }

    public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
        if (this.mChangesHandle) {
            this.mChangesHandle = false;
            int i = 0;
            for (int i2 = 0; i2 < 3; i2++) {
                int i3 = 1;
                int i4 = 0;
                while (i3 <= 4) {
                    int i5 = ((CheckBox) this.mDlg.findViewById(mPerm[i2][i4])).isChecked() ? i + i3 : i;
                    i4++;
                    i3 <<= 1;
                    i = i5;
                }
                if (i2 != 2) {
                    i *= 10;
                }
            }
            this.mEtPermission.setText(String.format(Locale.getDefault(), "%1$03d", new Object[]{Integer.valueOf(i)}));
            setTextPermission();
            this.mChangesHandle = true;
        }
    }

    public void onClick(DialogInterface dialogInterface, int i) {
        getData();
        if (i == -1 && this.mOnOkListener != null) {
            this.mOnOkListener.onOk(this);
        }
        if (i == -2 && this.mOnCancelListener != null) {
            this.mOnCancelListener.onCancel(this);
        }
        close();
    }

    public void reShow(Context context) {
        create(context);
        if (this.mDlg != null) {
            show();
        }
    }

    public void show() {
        if (this.mDlg != null) {
            this.mDlg.show();
        }
    }
}
