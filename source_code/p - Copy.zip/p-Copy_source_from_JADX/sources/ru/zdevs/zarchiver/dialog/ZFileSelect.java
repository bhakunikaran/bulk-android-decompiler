package ru.zdevs.zarchiver.dialog;

import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface.OnShowListener;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager.LayoutParams;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListPopupWindow;
import android.widget.PopupWindow.OnDismissListener;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import ru.zdevs.zarchiver.C0136e;
import ru.zdevs.zarchiver.R;
import ru.zdevs.zarchiver.ZArchiverExtInterface;
import ru.zdevs.zarchiver.archiver.C0071e;
import ru.zdevs.zarchiver.fs.MyUri;
import ru.zdevs.zarchiver.p003a.C0043b;
import ru.zdevs.zarchiver.p003a.C0044c;
import ru.zdevs.zarchiver.p003a.C0047d;
import ru.zdevs.zarchiver.p003a.C0057m;
import ru.zdevs.zarchiver.settings.Favorites;
import ru.zdevs.zarchiver.settings.Settings;
import ru.zdevs.zarchiver.tool.C0166c;
import ru.zdevs.zarchiver.tool.C0202q;
import ru.zdevs.zarchiver.widget.EditPassword;
import ru.zdevs.zarchiver.widget.FSSelect;
import ru.zdevs.zarchiver.widget.FSSelect.OnFileMarkListener;
import ru.zdevs.zarchiver.widget.FSSelect.OnFileSelectListener;
import ru.zdevs.zarchiver.widget.FSSelect.OnPathChangeListener;

public class ZFileSelect extends ZDialog implements OnCancelListener, OnClickListener, OnFileMarkListener, OnFileSelectListener, OnPathChangeListener {
    public static final byte ARCHIVE_TYPE_7ZIP = (byte) 1;
    public static final byte ARCHIVE_TYPE_UNKNOWN = (byte) 0;
    public static final byte ARCHIVE_TYPE_ZIP = (byte) 2;
    public static final byte SELECT_FILE = (byte) 1;
    public static final byte SELECT_FILES = (byte) 5;
    public static final byte SELECT_FILES_ARCHIVE = (byte) 8;
    public static final byte SELECT_FILE_OR_FOLDER = (byte) 3;
    public static final byte SELECT_FOLDER = (byte) 2;
    private static final byte SELECT_MULTIPLE = (byte) 4;
    private byte mArcType;
    private int mCaptionStrId;
    private CheckBox mCbEncryptType;
    private Context mContext;
    private MyUri mCurrentPath;
    private Dialog mDlg;
    private boolean mEncrypt;
    private int mEncryptType;
    private TextView mEtInfo;
    private EditPassword mEtPassword;
    private TextView mEtSubtitle;
    private TextView mEtTitle;
    private String mFileName;
    private FSSelect mFsFileList;
    private String mInfoString;
    private RelativeLayout mNavigation;
    private boolean mOkButton;
    private String mPassword;
    private ListPopupWindow mPopupNavigation;
    private byte mSelectType;
    private boolean mSetPass;
    private Spinner mSpnEncrypt;
    private Spinner mSpnLevel;
    private boolean mWideWindows;

    /* renamed from: ru.zdevs.zarchiver.dialog.ZFileSelect$1 */
    class C01181 implements View.OnClickListener {
        /* renamed from: a */
        final /* synthetic */ ZFileSelect f322a;

        /* renamed from: ru.zdevs.zarchiver.dialog.ZFileSelect$1$1 */
        class C01161 implements OnItemClickListener {
            /* renamed from: a */
            final /* synthetic */ C01181 f320a;

            C01161(C01181 c01181) {
                this.f320a = c01181;
            }

            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                if (adapterView != null) {
                    this.f320a.f322a.mFsFileList.setCurrentPath(new MyUri(((C0044c) adapterView.getItemAtPosition(i)).f114c));
                    this.f320a.f322a.onUpdatePath();
                    this.f320a.f322a.mPopupNavigation.dismiss();
                    this.f320a.f322a.mPopupNavigation = null;
                }
            }
        }

        /* renamed from: ru.zdevs.zarchiver.dialog.ZFileSelect$1$2 */
        class C01172 implements OnDismissListener {
            /* renamed from: a */
            final /* synthetic */ C01181 f321a;

            C01172(C01181 c01181) {
                this.f321a = c01181;
            }

            public void onDismiss() {
                this.f321a.f322a.mPopupNavigation = null;
            }
        }

        C01181(ZFileSelect zFileSelect) {
            this.f322a = zFileSelect;
        }

        public void onClick(View view) {
            this.f322a.mPopupNavigation = new ListPopupWindow(this.f322a.mContext);
            this.f322a.mPopupNavigation.setAnchorView(this.f322a.mNavigation);
            ListAdapter c0043b = new C0043b(this.f322a.mContext);
            c0043b.m69a(Favorites.getFavorites(this.f322a.mContext));
            this.f322a.mPopupNavigation.setAdapter(c0043b);
            this.f322a.mPopupNavigation.setContentWidth((this.f322a.mNavigation.getWidth() - this.f322a.mNavigation.getPaddingLeft()) - this.f322a.mNavigation.getPaddingRight());
            this.f322a.mPopupNavigation.setOnItemClickListener(new C01161(this));
            this.f322a.mPopupNavigation.setOnDismissListener(new C01172(this));
            this.f322a.mPopupNavigation.setModal(true);
            this.f322a.mPopupNavigation.show();
        }
    }

    /* renamed from: ru.zdevs.zarchiver.dialog.ZFileSelect$3 */
    class C01203 implements OnCheckedChangeListener {
        /* renamed from: a */
        final /* synthetic */ ZFileSelect f325a;

        C01203(ZFileSelect zFileSelect) {
            this.f325a = zFileSelect;
        }

        public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
            this.f325a.mSpnLevel.setVisibility(z ? 0 : 8);
        }
    }

    /* renamed from: ru.zdevs.zarchiver.dialog.ZFileSelect$4 */
    class C01214 implements OnShowListener {
        /* renamed from: a */
        final /* synthetic */ ZFileSelect f326a;

        C01214(ZFileSelect zFileSelect) {
            this.f326a = zFileSelect;
        }

        public void onShow(DialogInterface dialogInterface) {
            this.f326a.fixHoloTitle(this.f326a.mDlg);
        }
    }

    public ZFileSelect(C0136e c0136e, Context context, int i, byte b) {
        this.mCS = c0136e;
        this.mCaptionStrId = i;
        this.mSelectType = b;
        this.mInfoString = context.getString(R.string.ADD_SELECTED_FILES);
        this.mSetPass = false;
        this.mArcType = (byte) 0;
        this.mOkButton = true;
        this.mEncrypt = false;
        this.mEncryptType = 0;
        this.mPassword = "";
        create(context);
        addDialog();
    }

    public ZFileSelect(C0136e c0136e, Context context, int i, byte b, boolean z, byte b2) {
        this.mCS = c0136e;
        this.mCaptionStrId = i;
        this.mSelectType = b;
        this.mInfoString = context.getString(R.string.ADD_SELECTED_FILES);
        this.mSetPass = z;
        this.mArcType = b2;
        this.mOkButton = false;
        this.mEncrypt = false;
        this.mEncryptType = 0;
        this.mPassword = "";
        this.mFileName = null;
        create(context);
        addDialog();
    }

    private void create(Context context) {
        View findViewById;
        this.mContext = context;
        Builder builder = new Builder(context);
        builder.setTitle(this.mCaptionStrId);
        View inflate = LayoutInflater.from(context).inflate(R.layout.dlg_select_file, new LinearLayout(context));
        this.mEtTitle = (TextView) inflate.findViewById(R.id.nTitle);
        this.mEtSubtitle = (TextView) inflate.findViewById(R.id.nSubtitle);
        this.mFsFileList = (FSSelect) inflate.findViewById(R.id.fss_file_list);
        this.mFsFileList.setMultiSelect((this.mSelectType & 4) == 4);
        this.mFsFileList.setOnPathChangeListener(this);
        this.mFsFileList.setOnFileMarkListener(this);
        if ((this.mSelectType & 4) == 0 && (this.mSelectType & 1) == 1) {
            this.mFsFileList.setOnFileSelectListener(this);
        }
        this.mNavigation = (RelativeLayout) inflate.findViewById(R.id.rlNavigation);
        this.mNavigation.setOnClickListener(new C01181(this));
        this.mEtInfo = (TextView) inflate.findViewById(R.id.tv_info);
        if ((this.mSelectType & 4) == 0) {
            this.mEtInfo.setText(null);
            this.mEtInfo.setHeight(1);
            this.mEtInfo = null;
        }
        this.mWideWindows = false;
        if (this.mSetPass) {
            findViewById = inflate.findViewById(R.id.sv_bar);
            if (findViewById != null) {
                findViewById.setVisibility(0);
                this.mWideWindows = true;
            }
            this.mCbEncryptType = (CheckBox) inflate.findViewById(R.id.cb_encrypt);
            this.mCbEncryptType.setVisibility(0);
            final LinearLayout linearLayout = (LinearLayout) inflate.findViewById(R.id.ll_pass);
            this.mCbEncryptType.setOnCheckedChangeListener(new OnCheckedChangeListener(this) {
                /* renamed from: b */
                final /* synthetic */ ZFileSelect f324b;

                public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                    linearLayout.setVisibility(z ? 0 : 8);
                }
            });
            this.mSpnEncrypt = (Spinner) inflate.findViewById(R.id.spn_encrypt);
            this.mEtPassword = (EditPassword) inflate.findViewById(R.id.edt_password);
            if (this.mArcType == (byte) 1) {
                this.mSpnEncrypt.setVisibility(8);
                this.mSpnEncrypt = null;
                TextView textView = (TextView) inflate.findViewById(R.id.tv_enc);
                if (textView != null) {
                    textView.setVisibility(8);
                }
            }
        }
        if (this.mArcType == (byte) 2) {
            int a;
            findViewById = inflate.findViewById(R.id.sv_bar);
            if (findViewById != null) {
                findViewById.setVisibility(0);
                this.mWideWindows = true;
            }
            CheckBox checkBox = (CheckBox) inflate.findViewById(R.id.cb_level);
            checkBox.setVisibility(0);
            this.mSpnLevel = (Spinner) inflate.findViewById(R.id.spn_level);
            Object c0057m = new C0057m(this.mContext);
            c0057m.m144a(this.mContext.getResources().getStringArray(R.array.CMP_LIST_LEVELS));
            if (!Settings.sExtIgnoreRAMLimit.booleanValue()) {
                a = C0071e.m285a();
                if (a < 9) {
                    c0057m.m141a(5, false);
                }
                if (a < 7) {
                    c0057m.m141a(4, false);
                }
                if (a < 5) {
                    c0057m.m141a(3, false);
                }
                if (a < 3) {
                    c0057m.m141a(2, false);
                }
            }
            this.mSpnLevel.setAdapter(c0057m);
            a = (Integer.parseInt(Settings.sLevelZip) / 2) + 1;
            if (a < this.mSpnLevel.getCount() && c0057m.isEnabled(a)) {
                this.mSpnLevel.setSelection(a);
            }
            checkBox.setOnCheckedChangeListener(new C01203(this));
        }
        builder.setView(inflate);
        builder.setPositiveButton(this.mOkButton ? R.string.BTN_OK : R.string.BTN_ADD, this);
        builder.setNegativeButton(R.string.BTN_CANCEL, this);
        builder.setOnCancelListener(this);
        this.mDlg = builder.create();
        this.mDlg.setCanceledOnTouchOutside(false);
        this.mDlg.setOnShowListener(new C01214(this));
        onFileMark(0);
        onPathChange(this.mFsFileList.mCurrentPath.toLocalPath());
    }

    private void onUpdatePath() {
        String path = this.mFsFileList.mCurrentPath.isLocalFS() ? this.mFsFileList.mCurrentPath.getPath() : "";
        int lastIndexOf = path.lastIndexOf(47);
        if (lastIndexOf < 0 || path.length() <= lastIndexOf + 1) {
            Object obj = path;
            Object obj2 = "/";
        } else {
            CharSequence substring = path.substring(lastIndexOf + 1);
            CharSequence substring2 = lastIndexOf > 0 ? path.substring(0, lastIndexOf) : "/";
        }
        if (this.mEtSubtitle != null) {
            try {
                this.mEtSubtitle.setText(substring2);
            } catch (Throwable e) {
                C0166c.m556a(e);
                this.mEtSubtitle.setEllipsize(null);
                this.mEtSubtitle.setGravity(8388613);
                this.mEtSubtitle.setText(substring2);
            }
        }
        if (this.mEtTitle != null) {
            this.mEtTitle.setText(substring);
        }
    }

    public void close() {
        hide();
        delDialog();
    }

    public int getCompressionLevel() {
        if (this.mArcType != (byte) 2 || this.mSpnLevel == null || this.mSpnLevel.getVisibility() != 0) {
            return -1;
        }
        int selectedItemPosition = this.mSpnLevel.getSelectedItemPosition();
        return selectedItemPosition > 0 ? (selectedItemPosition * 2) - 1 : selectedItemPosition;
    }

    public int getEncType() {
        return (this.mArcType == (byte) 1 || this.mSpnEncrypt == null || this.mSpnEncrypt.getVisibility() != 0) ? -1 : this.mSpnEncrypt.getSelectedItemPosition();
    }

    public String getFileName() {
        return this.mFileName;
    }

    public String getPassword(boolean z) {
        return (this.mCbEncryptType == null || this.mEtPassword == null || !this.mCbEncryptType.isChecked()) ? "" : z ? this.mEtPassword.getText().toString().replace("\\", "\\\\") : this.mEtPassword.getText().toString();
    }

    public String getPath() {
        return (this.mDlg == null || this.mFsFileList == null) ? "" : this.mFsFileList.mCurrentPath.toLocalPath();
    }

    public final String getSelectedFiles(String str) {
        if (this.mDlg == null || this.mFsFileList == null) {
            return "";
        }
        C0047d c0047d = (C0047d) this.mFsFileList.getAdapter();
        return (c0047d == null || c0047d.mo16b() <= 0) ? "" : c0047d.m86a(str);
    }

    public int getType() {
        return 7;
    }

    public void hide() {
        if (this.mDlg != null) {
            if (this.mFsFileList != null) {
                this.mCurrentPath = this.mFsFileList.mCurrentPath;
            }
            if (this.mCbEncryptType != null) {
                this.mEncrypt = this.mCbEncryptType.isChecked();
            }
            if (this.mEtPassword != null) {
                this.mPassword = this.mEtPassword.getText().toString();
            }
            if (this.mSpnEncrypt != null) {
                this.mEncryptType = this.mSpnEncrypt.getSelectedItemPosition();
            }
            this.mDlg.dismiss();
            this.mDlg = null;
        }
        if (this.mPopupNavigation != null) {
            this.mPopupNavigation.dismiss();
            this.mPopupNavigation = null;
        }
        this.mNavigation = null;
        this.mEtSubtitle = null;
        this.mEtTitle = null;
        this.mEtInfo = null;
        this.mFsFileList = null;
        this.mCbEncryptType = null;
        this.mSpnEncrypt = null;
        this.mEtPassword = null;
        this.mContext = null;
    }

    public void onCancel(DialogInterface dialogInterface) {
        if (this.mOnCancelListener != null) {
            this.mOnCancelListener.onCancel(this);
        }
        close();
    }

    public void onClick(DialogInterface dialogInterface, int i) {
        if (i == -1 && this.mOnOkListener != null) {
            this.mOnOkListener.onOk(this);
        }
        if (i == -2 && this.mOnCancelListener != null) {
            this.mOnCancelListener.onCancel(this);
        }
        close();
    }

    public void onFileMark(int i) {
        if (this.mDlg != null && this.mEtInfo != null) {
            this.mEtInfo.setText(this.mInfoString.replace("%1", "" + i));
        }
    }

    public void onFileSelect(String str, String str2) {
        if ((this.mSelectType & 1) == 1) {
            if ((this.mSelectType & 8) == 8) {
                String d = C0202q.m743d(str2);
                if (!(d.equals("apk") || d.equals(ZArchiverExtInterface.ARCHIVE_TYPE_ZIP) || d.equals(ZArchiverExtInterface.ARCHIVE_TYPE_7Z) || d.equals("wim"))) {
                    return;
                }
            }
            this.mFileName = str2;
            if (this.mOnOkListener != null) {
                this.mOnOkListener.onOk(this);
            }
            close();
        }
    }

    public void onPathChange(String str) {
        if (this.mDlg != null && this.mEtTitle != null && this.mEtSubtitle != null) {
            onUpdatePath();
        }
    }

    public void reShow(Context context) {
        create(context);
        if (this.mDlg != null) {
            if (!(this.mFsFileList == null || this.mCurrentPath == null)) {
                this.mFsFileList.setCurrentPath(this.mCurrentPath);
            }
            if (this.mCbEncryptType != null) {
                this.mCbEncryptType.setChecked(this.mEncrypt);
            }
            if (this.mEtPassword != null) {
                this.mEtPassword.setText("");
                this.mEtPassword.setText(this.mPassword);
            }
            if (this.mSpnEncrypt != null) {
                this.mSpnEncrypt.setSelection(this.mEncryptType);
            }
            show();
        }
    }

    public void setRootSupport(boolean z) {
        if (this.mFsFileList != null) {
            this.mFsFileList.setRootSupport(z);
        }
    }

    public void show() {
        if (this.mDlg != null) {
            if (this.mWideWindows) {
                LayoutParams layoutParams;
                if (this.mDlg.getWindow() != null) {
                    layoutParams = new LayoutParams();
                    layoutParams.copyFrom(this.mDlg.getWindow().getAttributes());
                    layoutParams.width = -1;
                } else {
                    layoutParams = null;
                }
                this.mDlg.show();
                if (layoutParams != null) {
                    this.mDlg.getWindow().setAttributes(layoutParams);
                    return;
                }
                return;
            }
            this.mDlg.show();
        }
    }
}
