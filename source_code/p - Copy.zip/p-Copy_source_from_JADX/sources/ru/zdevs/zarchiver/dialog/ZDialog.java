package ru.zdevs.zarchiver.dialog;

import android.app.Dialog;
import android.content.Context;
import android.os.Build.VERSION;
import android.util.SparseArray;
import android.view.View;
import android.widget.TextView;
import ru.zdevs.zarchiver.C0136e;
import ru.zdevs.zarchiver.R;
import ru.zdevs.zarchiver.settings.Settings;
import ru.zdevs.zarchiver.tool.C0166c;
import ru.zdevs.zarchiver.tool.C0202q;

public class ZDialog {
    public static final char DLG_ADD_PASSWORD = '\u000e';
    public static final char DLG_ADD_TO_FAVORITE = '\u000b';
    public static final char DLG_ASK_OVERWRITE = '\t';
    public static final char DLG_ENTER_PASSWORD = '\f';
    public static final char DLG_ENTER_TEXT = '\u0003';
    public static final char DLG_FILE_INFO = '\u0006';
    public static final char DLG_FILE_SELECT = '\u0007';
    public static final char DLG_MAIN_OPTION = '\b';
    public static final char DLG_NONE = '\u0000';
    public static final char DLG_OPT_COMPRESS = '\u0005';
    public static final char DLG_POPUP_MENU = '\n';
    public static final char DLG_PROCESS = '\u0001';
    public static final char DLG_PROGRESS = '\u0002';
    public static final char DLG_ROOT_WARNING = '\u000f';
    public static final char DLG_SAVED_PASSWORD = '\r';
    public static final char DLG_SET_PERMISSION = '\u0010';
    public static final char DLG_SHOW_MES = '\u0004';
    protected C0136e mCS;
    private int mID = -1;
    protected OnCancelListener mOnCancelListener = null;
    protected OnOkListener mOnOkListener = null;
    private SparseArray<String> mStringData;
    private int mSubType = -1;

    public interface OnCancelListener {
        void onCancel(ZDialog zDialog);
    }

    public interface OnOkListener {
        void onOk(ZDialog zDialog);
    }

    public void addDialog() {
        if (this.mCS != null) {
            synchronized (this.mCS.f358i) {
                this.mCS.f358i.add(this);
            }
        }
    }

    public void close() {
    }

    public void delDialog() {
        if (this.mCS != null) {
            synchronized (this.mCS.f358i) {
                this.mCS.f358i.remove(this);
            }
        }
    }

    protected void fixHoloTitle(Dialog dialog) {
        if (dialog != null && Settings.sActionbarColor != 0 && VERSION.SDK_INT < 21) {
            Context context = dialog.getContext();
            try {
                TextView textView = (TextView) dialog.findViewById(context.getResources().getIdentifier("android:id/alertTitle", null, null));
                if (textView != null) {
                    textView.setTextColor(C0202q.m735b(context, (int) R.attr.defaultTextColorFileList));
                    textView.setTypeface(null, 1);
                }
                View findViewById = dialog.findViewById(context.getResources().getIdentifier("android:id/titleDivider", null, null));
                if (findViewById != null) {
                    findViewById.setBackgroundColor(context.getResources().getColor(17170445));
                }
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
        }
    }

    public String getStringData(int i) {
        return this.mStringData == null ? null : (String) this.mStringData.get(i);
    }

    public int getSubType() {
        return this.mSubType;
    }

    public int getTaskID() {
        return this.mID;
    }

    public int getType() {
        return 0;
    }

    public void hide() {
    }

    public void reShow(Context context) {
    }

    public void setOnCancelListener(OnCancelListener onCancelListener) {
        this.mOnCancelListener = onCancelListener;
    }

    public void setOnOkListener(OnOkListener onOkListener) {
        this.mOnOkListener = onOkListener;
    }

    public void setStringData(int i, String str) {
        if (this.mStringData == null) {
            this.mStringData = new SparseArray();
        }
        this.mStringData.append(i, str);
    }

    public void setSubType(int i) {
        this.mSubType = i;
    }

    public void setTaskID(int i) {
        this.mID = i;
    }

    public void show() {
    }
}
