package ru.zdevs.zarchiver.dialog;

import android.annotation.SuppressLint;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnShowListener;
import android.content.res.Configuration;
import android.os.Build.VERSION;
import android.util.DisplayMetrics;
import android.view.ContextThemeWrapper;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import ru.zdevs.zarchiver.C0136e;
import ru.zdevs.zarchiver.R;
import ru.zdevs.zarchiver.p003a.C0056l;
import ru.zdevs.zarchiver.settings.Settings;
import ru.zdevs.zarchiver.tool.C0166c;
import ru.zdevs.zarchiver.tool.C0202q;
import ru.zdevs.zarchiver.widget.bottomsheet.BottomSheet;
import ru.zdevs.zarchiver.widget.bottomsheet.BottomSheetListener;

public class ZMenuDialog extends ZDialog implements OnCancelListener, OnItemClickListener, BottomSheetListener {
    public static final int FLAG_DIALOG_MENU = 1;
    public static final int FLAG_NONE = 0;
    private static int sScreenPeak;
    private Dialog mDlg;
    private int mFlags;
    private int mItemID;
    private List<C0056l> mItems;
    private String mTitle;
    private int mX;
    private int mY;

    /* renamed from: ru.zdevs.zarchiver.dialog.ZMenuDialog$1 */
    class C01241 implements OnShowListener {
        /* renamed from: a */
        final /* synthetic */ ZMenuDialog f329a;

        C01241(ZMenuDialog zMenuDialog) {
            this.f329a = zMenuDialog;
        }

        public void onShow(DialogInterface dialogInterface) {
            this.f329a.fixHoloTitle(this.f329a.mDlg);
        }
    }

    /* renamed from: ru.zdevs.zarchiver.dialog.ZMenuDialog$a */
    private class C0126a extends BaseAdapter {
        /* renamed from: a */
        final /* synthetic */ ZMenuDialog f331a;
        /* renamed from: b */
        private Context f332b = null;
        /* renamed from: c */
        private List<C0056l> f333c = new ArrayList();
        /* renamed from: d */
        private LayoutInflater f334d = null;

        /* renamed from: ru.zdevs.zarchiver.dialog.ZMenuDialog$a$1 */
        class C01251 implements OnClickListener {
            /* renamed from: a */
            final /* synthetic */ C0126a f330a;

            C01251(C0126a c0126a) {
                this.f330a = c0126a;
            }

            public void onClick(View view) {
                this.f330a.f331a.onItemClick(null, view, 0, (long) ((Integer) view.getTag()).intValue());
            }
        }

        C0126a(ZMenuDialog zMenuDialog, Context context, List<C0056l> list) {
            this.f331a = zMenuDialog;
            this.f332b = context;
            this.f333c = list;
            if (VERSION.SDK_INT > 19 && Settings.sTheme == (byte) 2) {
                this.f332b = new ContextThemeWrapper(this.f332b, R.style.AppTheme.Light);
            }
            this.f334d = (LayoutInflater) this.f332b.getSystemService("layout_inflater");
        }

        /* renamed from: a */
        public C0056l m393a(int i) {
            return (C0056l) this.f333c.get(i);
        }

        public int getCount() {
            return this.f333c.size();
        }

        public /* synthetic */ Object getItem(int i) {
            return m393a(i);
        }

        public long getItemId(int i) {
            return (long) ((C0056l) this.f333c.get(i)).f173d;
        }

        public View getView(int i, View view, ViewGroup viewGroup) {
            if (view == null) {
                view = this.f334d.inflate(R.layout.item_bottom_menu, viewGroup, false);
            }
            C0056l a = m393a(i);
            ImageView imageView = (ImageView) view.findViewById(R.id.ivIcon);
            ImageView imageView2 = (ImageView) view.findViewById(R.id.ivMore);
            ((TextView) view.findViewById(R.id.tvText)).setText(a.f170a);
            imageView.setImageDrawable(a.f172c);
            if (a.f174e) {
                imageView2.setImageDrawable(C0202q.m725a(this.f332b, (int) R.attr.menuIconExtend));
                imageView2.setVisibility(0);
                imageView2.setTag(Integer.valueOf(a.f173d + 1));
                imageView2.setClickable(true);
                imageView2.setOnClickListener(new C01251(this));
            }
            return view;
        }
    }

    public ZMenuDialog(C0136e c0136e, Context context, List<C0056l> list, int i) {
        this(c0136e, context, (List) list, context.getString(i));
    }

    public ZMenuDialog(C0136e c0136e, Context context, List<C0056l> list, String str) {
        this.mCS = c0136e;
        this.mItems = list;
        this.mTitle = str;
        this.mItemID = -1;
        this.mY = 0;
        this.mX = 0;
        this.mFlags = 0;
        create(context);
        addDialog();
    }

    public ZMenuDialog(C0136e c0136e, Context context, List<C0056l> list, String str, int i) {
        this.mCS = c0136e;
        this.mItems = list;
        this.mTitle = str;
        this.mItemID = -1;
        this.mY = 0;
        this.mX = 0;
        this.mFlags = i;
        create(context);
        addDialog();
    }

    public ZMenuDialog(C0136e c0136e, Context context, List<C0056l> list, String str, int i, int i2) {
        this.mCS = c0136e;
        this.mItems = list;
        this.mTitle = str;
        this.mItemID = -1;
        this.mX = i;
        this.mY = i2;
        this.mFlags = 0;
        create(context);
        addDialog();
    }

    private void create(Context context) {
        if ((this.mFlags & 1) != 0 || VERSION.SDK_INT < 21) {
            create_holo(context);
        } else {
            create_material(context);
        }
    }

    private void create_holo(Context context) {
        Builder builder = new Builder(context);
        builder.setTitle(this.mTitle);
        View inflate = LayoutInflater.from(context).inflate(R.layout.dlg_menu_holo, new LinearLayout(context));
        ListView listView = (ListView) inflate.findViewById(R.id.lvPopupList);
        listView.setAdapter(new C0126a(this, context, this.mItems));
        listView.setOnItemClickListener(this);
        builder.setView(inflate);
        builder.setOnCancelListener(this);
        this.mDlg = builder.create();
        this.mDlg.setCanceledOnTouchOutside(true);
        this.mDlg.setOnShowListener(new C01241(this));
    }

    @SuppressLint({"RtlHardcoded"})
    private void create_material(Context context) {
        int width;
        int i;
        int i2 = 0;
        View inflate = LayoutInflater.from(context).inflate(R.layout.dlg_menu, new LinearLayout(context));
        ((TextView) inflate.findViewById(R.id.tvTitle)).setText(this.mTitle);
        ListView listView = (ListView) inflate.findViewById(R.id.lvPopupList);
        listView.setAdapter(new C0126a(this, context, this.mItems));
        listView.setOnItemClickListener(this);
        if (VERSION.SDK_INT > 23) {
            listView.setDividerHeight(0);
            listView.setDivider(null);
        }
        Display defaultDisplay = ((WindowManager) context.getSystemService("window")).getDefaultDisplay();
        Configuration configuration = context.getResources().getConfiguration();
        int i3;
        if (configuration.orientation == 1 || configuration.screenLayout < 3) {
            if (sScreenPeak <= 0) {
                DisplayMetrics displayMetrics = new DisplayMetrics();
                defaultDisplay.getMetrics(displayMetrics);
                sScreenPeak = (int) (2.3f * displayMetrics.ydpi);
                if (((float) displayMetrics.heightPixels) * 0.9f < ((float) sScreenPeak)) {
                    sScreenPeak = (int) (((float) displayMetrics.heightPixels) * 0.9f);
                }
            }
            i3 = sScreenPeak;
            width = (configuration.orientation == 2 || configuration.screenLayout >= 3) ? defaultDisplay.getWidth() / 2 : 0;
            i = i3;
        } else {
            i3 = defaultDisplay.getWidth();
            width = configuration.screenLayout > 3 ? i3 / 3 : i3 / 2;
            if (this.mX <= 0) {
                i = 0;
            } else if (this.mX < i3 / 4) {
                i = 0;
                i2 = 3;
            } else if (this.mX > (i3 * 3) / 4) {
                i = 0;
                i2 = 5;
            } else {
                i = 0;
            }
        }
        this.mDlg = new BottomSheet.Builder(context).setView(inflate).setMaxPeekHeight(i).setWidthGravity(width, i2).setListener(this).create();
    }

    public void close() {
        hide();
        delDialog();
    }

    public int getSelectMenuItemID() {
        return this.mItemID;
    }

    public int getType() {
        return 10;
    }

    public void hide() {
        if (this.mDlg != null) {
            try {
                this.mDlg.dismiss();
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
            this.mDlg = null;
        }
    }

    public void onCancel(DialogInterface dialogInterface) {
        if (this.mOnCancelListener != null) {
            this.mOnCancelListener.onCancel(this);
        }
        close();
    }

    public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
        if (view != null) {
            this.mItemID = (int) j;
            if (this.mOnOkListener != null) {
                this.mOnOkListener.onOk(this);
            }
            close();
        }
    }

    public void onSheetDismissed(BottomSheet bottomSheet, int i) {
        if (i != -6) {
            if (this.mOnCancelListener != null) {
                this.mOnCancelListener.onCancel(this);
            }
            delDialog();
        }
    }

    public void onSheetShown(BottomSheet bottomSheet) {
    }

    public void reShow(Context context) {
        create(context);
        if (this.mDlg != null) {
            show();
        }
    }

    public void show() {
        if (this.mDlg != null) {
            this.mDlg.show();
        }
    }
}
