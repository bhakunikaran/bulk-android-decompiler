package ru.zdevs.zarchiver.dialog;

import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface.OnShowListener;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;
import ru.zdevs.zarchiver.C0136e;
import ru.zdevs.zarchiver.R;
import ru.zdevs.zarchiver.archiver.AskOverwriteInfo;
import ru.zdevs.zarchiver.tool.C0166c;
import ru.zdevs.zarchiver.tool.C0202q;

public class ZAskOverwriteDialog extends ZDialog implements OnClickListener {
    private AskOverwriteInfo mAskOverwrite;
    private boolean mCancel = false;
    private CheckBox mCbToAll;
    private Dialog mDlg;
    private boolean mToAllFile = false;

    /* renamed from: ru.zdevs.zarchiver.dialog.ZAskOverwriteDialog$1 */
    class C00961 implements OnShowListener {
        /* renamed from: a */
        final /* synthetic */ ZAskOverwriteDialog f289a;

        C00961(ZAskOverwriteDialog zAskOverwriteDialog) {
            this.f289a = zAskOverwriteDialog;
        }

        public void onShow(DialogInterface dialogInterface) {
            this.f289a.fixHoloTitle(this.f289a.mDlg);
        }
    }

    public ZAskOverwriteDialog(C0136e c0136e, Context context, AskOverwriteInfo askOverwriteInfo) {
        this.mCS = c0136e;
        this.mAskOverwrite = askOverwriteInfo;
        create(context);
        addDialog();
    }

    private void create(Context context) {
        Builder builder = new Builder(context);
        builder.setTitle(context.getString(R.string.OVERW_TTL_ASK_OVERWRITE));
        View inflate = LayoutInflater.from(context).inflate(R.layout.dlg_ask_overwrite, new LinearLayout(context));
        ((TextView) inflate.findViewById(R.id.tvText)).setText(context.getString(R.string.OVERW_TEXT).replace("%1", this.mAskOverwrite.f193d));
        ((TextView) inflate.findViewById(R.id.tvScrFileDesc)).setText(context.getString(R.string.FINFO_SIZE) + " " + C0202q.m736b(this.mAskOverwrite.f191b) + "\n" + context.getString(R.string.FINFO_LAST_MOD) + " " + DateFormat.getDateFormat(context).format(Long.valueOf(((long) this.mAskOverwrite.f192c) * 1000)) + " " + DateFormat.getTimeFormat(context).format(Integer.valueOf(this.mAskOverwrite.f192c)));
        ((TextView) inflate.findViewById(R.id.tvDestFileDesc)).setText(context.getString(R.string.FINFO_SIZE) + " " + C0202q.m736b(this.mAskOverwrite.f194e) + "\n" + context.getString(R.string.FINFO_LAST_MOD) + " " + DateFormat.getDateFormat(context).format(Long.valueOf(((long) this.mAskOverwrite.f195f) * 1000)) + " " + DateFormat.getTimeFormat(context).format(Integer.valueOf(this.mAskOverwrite.f195f)));
        this.mCbToAll = (CheckBox) inflate.findViewById(R.id.cbToAllFile);
        this.mCbToAll.setChecked(this.mToAllFile);
        builder.setView(inflate);
        builder.setPositiveButton(R.string.BTN_REPLACE, this);
        builder.setNegativeButton(R.string.BTN_SKIP, this);
        builder.setNeutralButton(R.string.BTN_CANCEL, this);
        builder.setCancelable(false);
        this.mDlg = builder.create();
        this.mDlg.setCanceledOnTouchOutside(false);
        this.mDlg.setOnShowListener(new C00961(this));
    }

    public void close() {
        hide();
        delDialog();
    }

    public int getType() {
        return 9;
    }

    public void hide() {
        if (this.mDlg != null) {
            if (this.mCbToAll != null) {
                this.mToAllFile = this.mCbToAll.isChecked();
            }
            this.mCbToAll = null;
            try {
                this.mDlg.dismiss();
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
            this.mDlg = null;
        }
        this.mCbToAll = null;
    }

    public boolean isCancel() {
        return this.mCancel;
    }

    public boolean isToAll() {
        return this.mCbToAll == null ? this.mToAllFile : this.mCbToAll.isChecked();
    }

    public void onClick(DialogInterface dialogInterface, int i) {
        if (this.mCbToAll != null) {
            this.mToAllFile = this.mCbToAll.isChecked();
        }
        if (i == -1 && this.mOnOkListener != null) {
            this.mOnOkListener.onOk(this);
        }
        if (i == -2 && this.mOnCancelListener != null) {
            this.mOnCancelListener.onCancel(this);
        }
        if (i == -3 && this.mOnCancelListener != null) {
            this.mCancel = true;
            this.mOnCancelListener.onCancel(this);
        }
        close();
    }

    public void reShow(Context context) {
        create(context);
        if (this.mDlg != null) {
            show();
        }
    }

    public void show() {
        if (this.mDlg != null) {
            this.mDlg.show();
        }
    }
}
