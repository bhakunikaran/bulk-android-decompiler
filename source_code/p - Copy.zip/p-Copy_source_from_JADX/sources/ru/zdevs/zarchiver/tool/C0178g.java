package ru.zdevs.zarchiver.tool;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.pdf.PdfRenderer;
import android.graphics.pdf.PdfRenderer.Page;
import android.media.ExifInterface;
import android.media.ThumbnailUtils;
import android.os.Build.VERSION;
import android.os.ParcelFileDescriptor;
import android.util.Log;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.lang.Thread.State;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import ru.zdevs.zarchiver.Actions;
import ru.zdevs.zarchiver.ZArchiver;
import ru.zdevs.zarchiver.archiver.C0061a;
import ru.zdevs.zarchiver.archiver.C2JBridge;
import ru.zdevs.zarchiver.fs.MyUri;
import ru.zdevs.zarchiver.p003a.C0048i;
import ru.zdevs.zarchiver.p003a.C0049e;
import ru.zdevs.zarchiver.p003a.C0052g;
import ru.zdevs.zarchiver.settings.Settings;
import ru.zdevs.zarchiver.widget.bottomsheet.ViewDragHelper;

/* renamed from: ru.zdevs.zarchiver.tool.g */
public class C0178g {
    /* renamed from: a */
    private static C0178g f495a = null;
    /* renamed from: b */
    private static int f496b = 10;
    /* renamed from: c */
    private static int f497c = 0;
    /* renamed from: d */
    private static String f498d = null;
    /* renamed from: e */
    private Context f499e;
    /* renamed from: f */
    private final Map<Object, Bitmap> f500f = new HashMap();
    /* renamed from: g */
    private final List<String> f501g = new ArrayList();
    /* renamed from: h */
    private BaseAdapter f502h;
    /* renamed from: i */
    private C0172b f503i;
    /* renamed from: j */
    private C0171a f504j;

    /* renamed from: ru.zdevs.zarchiver.tool.g$a */
    class C0171a extends Thread {
        /* renamed from: a */
        final /* synthetic */ C0178g f472a;
        /* renamed from: b */
        private final List<C0173c> f473b = new ArrayList();
        /* renamed from: c */
        private boolean f474c = false;

        C0171a(C0178g c0178g) {
            this.f472a = c0178g;
        }

        /* renamed from: a */
        private void m582a() {
            if (this.f474c) {
                C2JBridge.cSetStatus(5, 15);
            }
            synchronized (this.f473b) {
                this.f473b.clear();
                this.f473b.notifyAll();
            }
        }

        /* renamed from: a */
        private void m585a(C0173c c0173c) {
            if (this.f474c) {
                C2JBridge.cSetStatus(5, 15);
            }
            synchronized (this.f473b) {
                this.f473b.add(c0173c);
                this.f473b.notifyAll();
            }
        }

        /* renamed from: a */
        private boolean m586a(int i) {
            synchronized (this.f473b) {
                for (C0173c c0173c : this.f473b) {
                    if (c0173c.f480d <= i && i < c0173c.f481e) {
                        return true;
                    }
                }
                return false;
            }
        }

        public void interrupt() {
            if (this.f474c) {
                C2JBridge.cSetStatus(5, 15);
            }
            super.interrupt();
        }

        public void run() {
            do {
                try {
                    if (this.f473b.size() == 0) {
                        synchronized (this.f473b) {
                            this.f473b.wait();
                            if (isInterrupted()) {
                                return;
                            }
                        }
                    }
                    if (this.f473b.size() != 0) {
                        C0173c c0173c;
                        synchronized (this.f473b) {
                            c0173c = (C0173c) this.f473b.get(0);
                        }
                        this.f474c = true;
                        C0178g.f497c = c0173c.f482f;
                        C0178g.f498d = c0173c.f479c;
                        C2JBridge.cExtract(5, c0173c.f477a, c0173c.f478b, c0173c.f479c, C0202q.m727a(this.f472a.f499e), 1);
                        this.f474c = false;
                        synchronized (this.f473b) {
                            if (this.f473b.size() != 0) {
                                this.f473b.remove(c0173c);
                            }
                        }
                    }
                } catch (Throwable e) {
                    if (!(e instanceof InterruptedException)) {
                        C0166c.m556a(e);
                        return;
                    }
                    return;
                }
            } while (!isInterrupted());
        }
    }

    /* renamed from: ru.zdevs.zarchiver.tool.g$b */
    private class C0172b extends Thread {
        /* renamed from: a */
        final /* synthetic */ C0178g f475a;
        /* renamed from: b */
        private final List<C0174d> f476b;

        private C0172b(C0178g c0178g) {
            this.f475a = c0178g;
            this.f476b = new ArrayList();
        }

        /* renamed from: a */
        private Bitmap m588a(String str) {
            if (str.startsWith("/SAF")) {
                return null;
            }
            try {
                PackageManager packageManager = this.f475a.f499e.getPackageManager();
                PackageInfo packageArchiveInfo = packageManager.getPackageArchiveInfo(str, 1);
                if (packageArchiveInfo == null) {
                    return null;
                }
                ApplicationInfo applicationInfo = packageArchiveInfo.applicationInfo;
                applicationInfo.sourceDir = str;
                applicationInfo.publicSourceDir = str;
                return ((BitmapDrawable) packageManager.getApplicationIcon(applicationInfo)).getBitmap();
            } catch (Throwable e) {
                C0166c.m556a(e);
                return null;
            }
        }

        /* renamed from: a */
        private Bitmap m589a(String str, String str2) {
            Bitmap bitmap = null;
            if (str2 != null) {
                try {
                    File file = new File(str2 + "/" + str + "/" + str + ".apk");
                    if (file.exists()) {
                        bitmap = m588a(file.getAbsolutePath());
                    }
                } catch (Throwable e) {
                    C0166c.m556a(e);
                    return C0169f.f465a[2];
                }
            }
            if (bitmap == null) {
                if (str.charAt(str.length() - 2) == '-') {
                    str = str.substring(0, str.length() - 2);
                }
                bitmap = ((BitmapDrawable) this.f475a.f499e.getPackageManager().getApplicationIcon(str)).getBitmap();
            }
            return C0169f.m576a(C0169f.f465a[2], bitmap);
        }

        /* renamed from: b */
        private Bitmap m590b(String str) {
            try {
                ExifInterface exifInterface = new ExifInterface(str);
                if (!exifInterface.hasThumbnail()) {
                    return null;
                }
                byte[] thumbnail = exifInterface.getThumbnail();
                Options options = new Options();
                options.inJustDecodeBounds = true;
                BitmapFactory.decodeByteArray(thumbnail, 0, thumbnail.length, options);
                if (options.outWidth == -1 || options.outHeight == -1) {
                    return null;
                }
                int i = options.outHeight > options.outWidth ? options.outHeight : options.outWidth;
                Options options2 = new Options();
                if (Settings.sGUIGridView) {
                    options2.inSampleSize = (int) (((float) i) / (((float) Settings.sFMItemSize) * 1.6f));
                } else {
                    options2.inSampleSize = i / Settings.sFMItemSize;
                }
                return BitmapFactory.decodeByteArray(thumbnail, 0, thumbnail.length, options2);
            } catch (Throwable e) {
                C0166c.m556a(e);
                return null;
            }
        }

        /* renamed from: c */
        private Bitmap m591c(String str) {
            Bitmap b;
            boolean startsWith = str.startsWith("/SAF");
            if (!startsWith && str.toLowerCase(Locale.ENGLISH).endsWith(".jpg")) {
                b = m590b(str);
                if (b != null) {
                    return b;
                }
            }
            Options options = new Options();
            options.inJustDecodeBounds = true;
            if (startsWith) {
                try {
                    InputStream d = C0187l.m671d(str);
                    if (d == null) {
                        return null;
                    }
                    BitmapFactory.decodeStream(d, null, options);
                    d.close();
                } catch (Throwable e) {
                    C0166c.m556a(e);
                    return null;
                }
            }
            BitmapFactory.decodeFile(str, options);
            if (options.outWidth == -1 || options.outHeight == -1) {
                return null;
            }
            int i = options.outHeight > options.outWidth ? options.outHeight : options.outWidth;
            Options options2 = new Options();
            if (Settings.sGUIGridView) {
                options2.inSampleSize = (int) (((float) i) / (((float) Settings.sFMItemSize) * 1.6f));
            } else {
                options2.inSampleSize = i / Settings.sFMItemSize;
            }
            if (!startsWith) {
                return BitmapFactory.decodeFile(str, options2);
            }
            try {
                InputStream d2 = C0187l.m671d(str);
                if (d2 == null) {
                    return null;
                }
                b = BitmapFactory.decodeStream(d2, null, options2);
                d2.close();
                return b;
            } catch (Throwable e2) {
                C0166c.m556a(e2);
                return null;
            }
        }

        /* renamed from: d */
        private Bitmap m592d(String str) {
            if (str.startsWith("/SAF")) {
                return null;
            }
            Bitmap createVideoThumbnail = ThumbnailUtils.createVideoThumbnail(str, 3);
            if (createVideoThumbnail == null || createVideoThumbnail.getWidth() == 0 || createVideoThumbnail.getHeight() == 0) {
                return null;
            }
            Bitmap createBitmap = Bitmap.createBitmap(createVideoThumbnail.getWidth(), createVideoThumbnail.getHeight(), createVideoThumbnail.getConfig());
            Canvas canvas = new Canvas(createBitmap);
            canvas.drawBitmap(createVideoThumbnail, 0.0f, 0.0f, null);
            canvas.drawBitmap(C0169f.f466b[0], null, new Rect(createVideoThumbnail.getWidth() / 3, createVideoThumbnail.getHeight() / 4, (createVideoThumbnail.getWidth() * 2) / 3, (createVideoThumbnail.getHeight() * 3) / 4), null);
            createVideoThumbnail.recycle();
            return createBitmap;
        }

        @TargetApi(21)
        /* renamed from: e */
        private Bitmap m593e(String str) {
            if (VERSION.SDK_INT < 21) {
                return null;
            }
            boolean startsWith = str.startsWith("/SAF");
            if (startsWith) {
                try {
                    InputStream d = C0187l.m671d(str);
                } catch (Throwable e) {
                    C0166c.m556a(e);
                    return null;
                }
            }
            d = new FileInputStream(new File(str));
            if (d == null) {
                return null;
            }
            try {
                byte[] bArr = new byte[8];
                bArr[0] = (byte) 0;
                if (d.read(bArr) < 4 || bArr[0] != (byte) 37 || bArr[1] != (byte) 80 || bArr[2] != (byte) 68 || bArr[3] != (byte) 70) {
                    return null;
                }
                d.skip((long) (d.available() - bArr.length));
                if (d.read(bArr) < 4) {
                    return null;
                }
                Object obj;
                int i = 0;
                while (i < bArr.length - 3) {
                    if (bArr[i + 0] != (byte) 69 || bArr[i + 1] != (byte) 79 || bArr[i + 2] != (byte) 70) {
                        obj = 1;
                        break;
                    }
                    i++;
                }
                obj = null;
                if (obj == null) {
                    return null;
                }
                ParcelFileDescriptor a;
                if (startsWith) {
                    try {
                        a = C0187l.m662a(str, "r");
                    } catch (Throwable e2) {
                        C0166c.m556a(e2);
                        return null;
                    }
                }
                a = ParcelFileDescriptor.open(new File(str), 268435456);
                try {
                    PdfRenderer pdfRenderer = new PdfRenderer(a);
                    if (pdfRenderer.getPageCount() <= 0) {
                        pdfRenderer.close();
                        a.close();
                        return null;
                    }
                    Page openPage = pdfRenderer.openPage(0);
                    if (openPage == null || openPage.getHeight() == 0 || openPage.getWidth() == 0) {
                        pdfRenderer.close();
                        a.close();
                        return null;
                    }
                    int i2 = Settings.sGUIGridView ? (int) (((float) Settings.sFMItemSize) * 1.6f) : Settings.sFMItemSize;
                    float max = Math.max(((float) i2) / ((float) openPage.getHeight()), ((float) i2) / ((float) openPage.getWidth()));
                    Matrix matrix = new Matrix();
                    matrix.setScale(max, max);
                    Bitmap createBitmap = Bitmap.createBitmap((int) (((float) openPage.getWidth()) * max), (int) (max * ((float) openPage.getHeight())), Config.ARGB_8888);
                    openPage.render(createBitmap, null, matrix, 1);
                    openPage.close();
                    pdfRenderer.close();
                    a.close();
                    Bitmap createBitmap2 = Bitmap.createBitmap(createBitmap.getWidth(), createBitmap.getHeight(), createBitmap.getConfig());
                    createBitmap2.eraseColor(-1);
                    new Canvas(createBitmap2).drawBitmap(createBitmap, 0.0f, 0.0f, null);
                    createBitmap.recycle();
                    return createBitmap2;
                } catch (Throwable e22) {
                    C0166c.m556a(e22);
                    return null;
                }
            } catch (Throwable e222) {
                C0166c.m556a(e222);
                return null;
            }
        }

        /* renamed from: a */
        void m594a() {
            synchronized (this.f476b) {
                if (this.f476b.size() > 0 && !((C0174d) this.f476b.get(0)).f489g) {
                    C0178g.m605b(0);
                }
                this.f476b.clear();
                this.f476b.notifyAll();
            }
        }

        /* renamed from: a */
        void m595a(C0174d c0174d) {
            synchronized (this.f476b) {
                this.f476b.add(c0174d);
                while (!c0174d.f489g && this.f476b.size() > C0178g.f496b) {
                    String str = ((C0174d) this.f476b.get(0)).f484b;
                    synchronized (this.f475a.f500f) {
                        this.f475a.f500f.remove(str);
                    }
                    synchronized (this.f475a.f500f) {
                        this.f475a.f501g.remove(str);
                    }
                    this.f476b.remove(0);
                }
                this.f476b.notifyAll();
            }
        }

        public void run() {
            try {
                File file = new File(C0202q.m727a(this.f475a.f499e));
                if (file.exists() && file.isFile()) {
                    file.delete();
                }
                if (!file.exists()) {
                    file.mkdirs();
                }
                do {
                    if (this.f476b.size() == 0) {
                        synchronized (this.f476b) {
                            this.f476b.wait();
                            if (isInterrupted()) {
                                return;
                            }
                        }
                    }
                    if (this.f476b.size() != 0) {
                        C0174d c0174d;
                        Bitmap a;
                        synchronized (this.f476b) {
                            c0174d = (C0174d) this.f476b.get(this.f476b.size() - 1);
                            this.f476b.remove(this.f476b.size() - 1);
                        }
                        switch (c0174d.f483a) {
                            case (byte) 2:
                                a = m589a(c0174d.f484b, c0174d.f485c);
                                break;
                            case Actions.CHECK_ACTION_RENAME /*6*/:
                                a = m588a(c0174d.f485c + "/" + c0174d.f484b);
                                break;
                            case (byte) 11:
                                a = m591c(c0174d.f485c + "/" + c0174d.f484b);
                                break;
                            case ViewDragHelper.EDGE_ALL /*15*/:
                                a = m593e(c0174d.f485c + "/" + c0174d.f484b);
                                break;
                            case (byte) 16:
                                a = m592d(c0174d.f485c + "/" + c0174d.f484b);
                                break;
                            default:
                                a = null;
                                break;
                        }
                        if (a != null) {
                            synchronized (this.f475a.f500f) {
                                this.f475a.f500f.put(c0174d.f484b, a);
                            }
                            synchronized (this.f475a.f501g) {
                                this.f475a.f501g.remove(c0174d.f484b);
                            }
                            if (!c0174d.f489g) {
                                try {
                                    if (c0174d.f487e != null && ((Integer) c0174d.f487e.getTag()).intValue() == c0174d.f486d) {
                                        ((Activity) c0174d.f487e.getContext()).runOnUiThread(new C0175e(a, c0174d.f487e));
                                    }
                                } catch (Throwable e) {
                                    C0166c.m556a(e);
                                }
                                if (this.f476b.size() == 0) {
                                    if (c0174d.f487e != null) {
                                        ((Activity) c0174d.f487e.getContext()).runOnUiThread(new C0176f(c0174d.f488f));
                                    }
                                    C0178g.m605b(0);
                                } else {
                                    C0178g.m605b(((C0178g.f496b - this.f476b.size()) * 100) / C0178g.f496b);
                                }
                                this.f475a.m611g();
                            } else if (this.f475a.f499e != null) {
                                ((Activity) this.f475a.f499e).runOnUiThread(new C0176f(c0174d.f488f));
                                new File(c0174d.f485c, c0174d.f484b).delete();
                            }
                        } else if (this.f476b.size() == 0) {
                            C0178g.m605b(0);
                        } else {
                            C0178g.m605b(((C0178g.f496b - this.f476b.size()) * 100) / C0178g.f496b);
                        }
                    }
                } while (!isInterrupted());
            } catch (Throwable e2) {
                if (!(e2 instanceof InterruptedException)) {
                    C0166c.m556a(e2);
                }
            }
        }
    }

    /* renamed from: ru.zdevs.zarchiver.tool.g$c */
    private static class C0173c {
        /* renamed from: a */
        final String f477a;
        /* renamed from: b */
        final String f478b;
        /* renamed from: c */
        final String f479c;
        /* renamed from: d */
        final int f480d;
        /* renamed from: e */
        final int f481e;
        /* renamed from: f */
        final int f482f;

        C0173c(String str, String str2, String str3, int i, int i2, int i3) {
            this.f477a = str;
            this.f478b = str2;
            this.f479c = str3;
            this.f480d = i;
            this.f481e = i2;
            this.f482f = i3;
        }
    }

    /* renamed from: ru.zdevs.zarchiver.tool.g$d */
    private static class C0174d {
        /* renamed from: a */
        final byte f483a;
        /* renamed from: b */
        final String f484b;
        /* renamed from: c */
        final String f485c;
        /* renamed from: d */
        final int f486d;
        /* renamed from: e */
        final ImageView f487e;
        /* renamed from: f */
        final BaseAdapter f488f;
        /* renamed from: g */
        final boolean f489g;

        C0174d(byte b, String str, String str2, BaseAdapter baseAdapter) {
            this.f483a = b;
            this.f484b = str;
            this.f485c = str2;
            this.f487e = null;
            this.f486d = 0;
            this.f488f = baseAdapter;
            this.f489g = true;
        }

        C0174d(byte b, String str, String str2, ImageView imageView, int i, BaseAdapter baseAdapter) {
            this.f483a = b;
            this.f484b = str;
            this.f485c = str2;
            this.f487e = imageView;
            this.f486d = i;
            this.f488f = baseAdapter;
            this.f489g = false;
        }
    }

    /* renamed from: ru.zdevs.zarchiver.tool.g$e */
    private static class C0175e implements Runnable {
        /* renamed from: a */
        private final Bitmap f490a;
        /* renamed from: b */
        private final ImageView f491b;

        C0175e(Bitmap bitmap, ImageView imageView) {
            this.f490a = bitmap;
            this.f491b = imageView;
        }

        public void run() {
            try {
                if (this.f490a != null) {
                    this.f491b.setImageBitmap(this.f490a);
                }
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
        }
    }

    /* renamed from: ru.zdevs.zarchiver.tool.g$f */
    private static class C0176f implements Runnable {
        /* renamed from: a */
        private final BaseAdapter f492a;

        C0176f(BaseAdapter baseAdapter) {
            this.f492a = baseAdapter;
        }

        public void run() {
            try {
                if (this.f492a != null) {
                    this.f492a.notifyDataSetChanged();
                }
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
        }
    }

    /* renamed from: ru.zdevs.zarchiver.tool.g$g */
    private static class C0177g implements Runnable {
        /* renamed from: a */
        private final ZArchiver f493a;
        /* renamed from: b */
        private final int f494b;

        C0177g(ZArchiver zArchiver, int i) {
            this.f493a = zArchiver;
            this.f494b = i;
        }

        public void run() {
            try {
                this.f493a.setImageLoadProgress(this.f494b);
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
        }
    }

    public C0178g(Context context) {
        this.f499e = context;
    }

    /* renamed from: a */
    private void m597a(byte b, String str, String str2, ImageView imageView, int i, BaseAdapter baseAdapter) {
        if (this.f503i != null) {
            if (this.f503i.getState() == State.NEW) {
                this.f503i.start();
            }
            synchronized (this.f501g) {
                this.f501g.add(str);
            }
            this.f503i.m595a(new C0174d(b, str, str2, imageView, i, baseAdapter));
        }
    }

    /* renamed from: a */
    public static void m598a(int i) {
        if (i < 6) {
            i = 6;
        }
        if (i > Settings.sImgCashSize) {
            i = Settings.sImgCashSize;
        }
        f496b = i;
    }

    /* renamed from: a */
    public static void m599a(String str) {
        if (f495a != null && f495a.f502h != null && f495a.f503i != null) {
            Object substring;
            if (str.contains("/") && str.lastIndexOf("/") + 1 < str.length()) {
                substring = str.substring(str.lastIndexOf("/") + 1);
            }
            if (f498d == null || f498d.contains(substring)) {
                if (f495a.f503i.getState() == State.NEW) {
                    f495a.f503i.start();
                }
                if (f495a.f501g.contains(substring)) {
                    Log.e("ImageLoader", "Overrun extract process!");
                }
                synchronized (f495a.f501g) {
                    f495a.f501g.add(substring);
                }
                f495a.f503i.m595a(new C0174d((byte) 11, substring, C0202q.m727a(f495a.f499e), f495a.f502h));
                f497c--;
                if (f497c <= 0) {
                    C2JBridge.cSetStatus(5, 15);
                    f498d = null;
                }
            }
        }
    }

    /* renamed from: a */
    private void m600a(String str, String str2, ImageView imageView, int i, BaseAdapter baseAdapter) {
        if (this.f503i != null) {
            if (this.f503i.getState() == State.NEW) {
                this.f503i.start();
            }
            synchronized (this.f501g) {
                this.f501g.add(str);
            }
            this.f503i.m595a(new C0174d((byte) 2, str, str2, imageView, i, baseAdapter));
        }
    }

    /* renamed from: a */
    private void m601a(List<C0048i> list, int i, MyUri myUri, BaseAdapter baseAdapter) {
        if (this.f503i != null) {
            if (this.f504j == null) {
                this.f504j = new C0171a(this);
            }
            if (this.f504j.getState() == State.NEW) {
                this.f504j.start();
            }
            if (list.size() > i) {
                String substring;
                StringBuilder stringBuilder;
                String str;
                int i2;
                int i3;
                C0048i c0048i = (C0048i) list.get(i);
                String fragment = c0048i instanceof C0052g ? ((C0052g) c0048i).m133l().getFragment() : myUri.getFragment();
                if (fragment.length() > 0) {
                    fragment = fragment.replace("/./", "/");
                    if (fragment.charAt(0) == '/') {
                        fragment = fragment.substring(1, fragment.length());
                    }
                    if (fragment.endsWith("/")) {
                        substring = fragment.substring(0, fragment.length() - 1);
                        stringBuilder = new StringBuilder();
                        str = substring.isEmpty() ? null : substring + '/';
                        i2 = i;
                        i3 = 0;
                        while (i2 < f496b + i && i2 < list.size()) {
                            c0048i = (C0048i) list.get(i2);
                            if (c0048i.mo29h() == (byte) 11 && !this.f500f.containsKey(c0048i.mo28e())) {
                                if (str != null) {
                                    stringBuilder.append(str);
                                }
                                stringBuilder.append(c0048i.mo28e());
                                stringBuilder.append('\\');
                                i3++;
                            }
                            i2++;
                        }
                        if (!substring.isEmpty()) {
                            substring = "-z" + substring;
                        }
                        str = C0061a.m207a(myUri.getPath(), false) ? substring + "\\-mmt=1" : substring;
                        if (i3 != 0) {
                            this.f502h = baseAdapter;
                            this.f504j.m585a(new C0173c(myUri.getPath(), str, stringBuilder.toString(), i, i + f496b, i3));
                        }
                    }
                }
                substring = fragment;
                stringBuilder = new StringBuilder();
                if (substring.isEmpty()) {
                }
                i2 = i;
                i3 = 0;
                while (i2 < f496b + i) {
                    c0048i = (C0048i) list.get(i2);
                    if (str != null) {
                        stringBuilder.append(str);
                    }
                    stringBuilder.append(c0048i.mo28e());
                    stringBuilder.append('\\');
                    i3++;
                    i2++;
                }
                if (substring.isEmpty()) {
                    substring = "-z" + substring;
                }
                if (C0061a.m207a(myUri.getPath(), false)) {
                }
                if (i3 != 0) {
                    this.f502h = baseAdapter;
                    this.f504j.m585a(new C0173c(myUri.getPath(), str, stringBuilder.toString(), i, i + f496b, i3));
                }
            }
        }
    }

    /* renamed from: b */
    private Bitmap m602b(List<C0048i> list, int i, MyUri myUri, BaseAdapter baseAdapter, boolean z) {
        try {
            Bitmap bitmap;
            String e = ((C0048i) list.get(i)).mo28e();
            synchronized (this.f500f) {
                bitmap = (Bitmap) this.f500f.get(e);
            }
            if (z || bitmap != null) {
                return bitmap;
            }
            if ((this.f504j != null && this.f504j.m586a(i)) || this.f501g.contains(e)) {
                return bitmap;
            }
            m601a(list, i, myUri, baseAdapter);
            return bitmap;
        } catch (Throwable e2) {
            C0166c.m556a(e2);
            return null;
        }
    }

    /* renamed from: b */
    public static void m605b(int i) {
        if (f495a != null && f495a.f499e != null && (f495a.f499e instanceof ZArchiver)) {
            ZArchiver zArchiver = (ZArchiver) f495a.f499e;
            zArchiver.runOnUiThread(new C0177g(zArchiver, i));
        }
    }

    /* renamed from: e */
    public static void m609e() {
        if (f495a != null && f495a.f499e != null && (f495a.f499e instanceof ZArchiver)) {
            ZArchiver zArchiver = (ZArchiver) f495a.f499e;
            zArchiver.runOnUiThread(new C0177g(zArchiver, 0));
        }
    }

    /* renamed from: g */
    private void m611g() {
        int i = 0;
        if (this.f500f.size() >= Settings.sImgCashSize) {
            try {
                synchronized (this.f501g) {
                    while (true) {
                        i++;
                        if (i <= (Settings.sImgCashSize * 2) / 3) {
                            synchronized (this.f500f) {
                                this.f500f.remove(this.f501g.get(0));
                            }
                        }
                    }
                }
            } catch (Exception e) {
                synchronized (this.f500f) {
                    this.f500f.remove(this.f501g.get(0));
                }
            }
        }
    }

    /* renamed from: a */
    public Bitmap m612a(byte b, String str, String str2, ImageView imageView, int i, BaseAdapter baseAdapter, boolean z) {
        try {
            Bitmap bitmap;
            synchronized (this.f500f) {
                bitmap = (Bitmap) this.f500f.get(str);
            }
            if (z) {
                return bitmap;
            }
            if (bitmap != null || this.f501g.contains(str)) {
                synchronized (this.f501g) {
                    this.f501g.remove(str);
                    this.f501g.add(str);
                }
                return bitmap;
            }
            m597a(b, str, str2, imageView, i, baseAdapter);
            return bitmap;
        } catch (Exception e) {
            return null;
        }
    }

    /* renamed from: a */
    public Bitmap m613a(String str, String str2, ImageView imageView, int i, BaseAdapter baseAdapter, boolean z) {
        try {
            Bitmap bitmap;
            synchronized (this.f500f) {
                bitmap = (Bitmap) this.f500f.get(str);
            }
            if (z) {
                return bitmap;
            }
            if (bitmap != null || this.f501g.contains(str)) {
                synchronized (this.f501g) {
                    this.f501g.remove(str);
                    this.f501g.add(str);
                }
                return bitmap;
            }
            m600a(str, str2, imageView, i, baseAdapter);
            return bitmap;
        } catch (Exception e) {
            return null;
        }
    }

    /* renamed from: a */
    public Bitmap m614a(List<C0049e> list, int i, MyUri myUri, BaseAdapter baseAdapter, boolean z) {
        return m602b(list, i, myUri, baseAdapter, z);
    }

    /* renamed from: a */
    public void m615a() {
        f495a = null;
        if (this.f503i != null) {
            this.f503i.interrupt();
            this.f503i = null;
        }
        if (this.f504j != null) {
            this.f504j.interrupt();
            this.f504j = null;
        }
        m620d();
    }

    /* renamed from: a */
    public void m616a(Context context) {
        this.f499e = context;
    }

    /* renamed from: a */
    public void m617a(String str, String str2) {
        synchronized (this.f501g) {
            if (this.f501g.contains(str)) {
                this.f501g.remove(str);
                this.f501g.add(str2);
            }
        }
        synchronized (this.f500f) {
            if (this.f500f.containsKey(str)) {
                Bitmap bitmap = (Bitmap) this.f500f.get(str);
                this.f500f.remove(str);
                this.f500f.put(str2, bitmap);
            }
        }
    }

    /* renamed from: b */
    public void m618b() {
        f495a = this;
        if (this.f503i == null) {
            this.f503i = new C0172b();
            this.f503i.setPriority(4);
        }
    }

    /* renamed from: c */
    public boolean m619c() {
        return this.f503i != null;
    }

    /* renamed from: d */
    public void m620d() {
        this.f502h = null;
        if (this.f503i != null) {
            this.f503i.m594a();
        }
        if (this.f504j != null) {
            this.f504j.m582a();
        }
        synchronized (this.f500f) {
            this.f500f.clear();
        }
        synchronized (this.f501g) {
            this.f501g.clear();
        }
    }
}
