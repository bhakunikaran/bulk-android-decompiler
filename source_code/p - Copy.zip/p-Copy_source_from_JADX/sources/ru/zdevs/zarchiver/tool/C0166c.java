package ru.zdevs.zarchiver.tool;

/* renamed from: ru.zdevs.zarchiver.tool.c */
public class C0166c {
    /* renamed from: a */
    public static void m554a(Error error) {
    }

    /* renamed from: a */
    public static void m555a(String str, String str2) {
    }

    /* renamed from: a */
    public static void m556a(Throwable th) {
    }

    /* renamed from: b */
    public static void m557b(String str, String str2) {
    }

    /* renamed from: c */
    public static void m558c(String str, String str2) {
    }

    /* renamed from: d */
    public static void m559d(String str, String str2) {
    }
}
