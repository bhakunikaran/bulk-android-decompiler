package ru.zdevs.zarchiver.tool;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import ru.zdevs.zarchiver.Actions;
import ru.zdevs.zarchiver.R;
import ru.zdevs.zarchiver.ZArchiverExtInterface;
import ru.zdevs.zarchiver.settings.Settings;
import ru.zdevs.zarchiver.widget.bottomsheet.ViewDragHelper;

/* renamed from: ru.zdevs.zarchiver.tool.f */
public class C0169f {
    /* renamed from: a */
    public static Bitmap[] f465a = new Bitmap[19];
    /* renamed from: b */
    public static Bitmap[] f466b = new Bitmap[1];
    /* renamed from: c */
    private static Bitmap[] f467c = new Bitmap[31];
    /* renamed from: d */
    private static int f468d = Settings.sFMItemSize;
    /* renamed from: e */
    private static int f469e = (Settings.sFMItemSize / 4);
    /* renamed from: f */
    private static int f470f = 0;
    /* renamed from: g */
    private static int f471g = 0;

    /* renamed from: a */
    public static int m574a(int i) {
        switch (Settings.sFSIconTheme) {
            case 1:
                switch (i) {
                    case -2:
                        return R.drawable.folderm_root;
                    case ViewDragHelper.INVALID_POINTER /*-1*/:
                        return R.drawable.folderm_internal;
                    case 0:
                        return R.drawable.folderm_usb;
                    case 1:
                        return R.drawable.folderm_sd;
                    case 2:
                        return R.drawable.folderm_home;
                    case 3:
                        return R.drawable.folderm_archive;
                    case 4:
                        return R.drawable.folderm_document;
                    case 5:
                        return R.drawable.folderm_download;
                    case Actions.CHECK_ACTION_RENAME /*6*/:
                        return R.drawable.folderm_music;
                    case ZArchiverExtInterface.COMPRESSION_LAVEL_MAX /*7*/:
                        return R.drawable.folderm_picture;
                    case ViewDragHelper.EDGE_BOTTOM /*8*/:
                        return R.drawable.folderm_video;
                    case 9:
                        return R.drawable.folderm_games;
                    default:
                        return R.drawable.folderm_default;
                }
            default:
                switch (i) {
                    case -2:
                        return R.drawable.folder_root;
                    case ViewDragHelper.INVALID_POINTER /*-1*/:
                        return R.drawable.folder_internal;
                    case 0:
                        return R.drawable.folder_usb;
                    case 1:
                        return R.drawable.folder_sd;
                    case 2:
                        return R.drawable.folder_home;
                    case 3:
                        return R.drawable.folder_archive;
                    case 4:
                        return R.drawable.folder_document;
                    case 5:
                        return R.drawable.folder_download;
                    case Actions.CHECK_ACTION_RENAME /*6*/:
                        return R.drawable.folder_music;
                    case ZArchiverExtInterface.COMPRESSION_LAVEL_MAX /*7*/:
                        return R.drawable.folder_picture;
                    case ViewDragHelper.EDGE_BOTTOM /*8*/:
                        return R.drawable.folder_video;
                    case 9:
                        return R.drawable.folder_games;
                    default:
                        return R.drawable.folder_default;
                }
        }
    }

    /* renamed from: a */
    public static Bitmap m575a(Bitmap bitmap, int i) {
        if (i >= 32 || i == 0 || f467c[i - 1] == null) {
            return bitmap;
        }
        Bitmap createBitmap = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Config.ARGB_8888);
        Canvas canvas = new Canvas(createBitmap);
        canvas.drawBitmap(bitmap, 0.0f, 0.0f, null);
        if (i >= 30) {
            canvas.drawBitmap(f467c[i - 1], 0.0f, 0.0f, null);
        } else {
            canvas.drawBitmap(f467c[i - 1], (float) f470f, (float) f471g, null);
        }
        return createBitmap;
    }

    /* renamed from: a */
    public static Bitmap m576a(Bitmap bitmap, Bitmap bitmap2) {
        if (bitmap2 == null) {
            return bitmap;
        }
        float max = ((float) f469e) / ((float) Math.max(bitmap2.getWidth(), bitmap2.getHeight()));
        Bitmap createScaledBitmap = Bitmap.createScaledBitmap(bitmap2, (int) (((float) bitmap2.getWidth()) * max), (int) (max * ((float) bitmap2.getHeight())), false);
        Bitmap createBitmap = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Config.ARGB_8888);
        Canvas canvas = new Canvas(createBitmap);
        canvas.drawBitmap(bitmap, 0.0f, 0.0f, null);
        canvas.drawBitmap(createScaledBitmap, (float) (f470f + ((f469e - createScaledBitmap.getWidth()) / 2)), (float) (f471g + ((f469e - createScaledBitmap.getHeight()) / 2)), null);
        return createBitmap;
    }

    /* renamed from: a */
    public static void m577a(Context context) {
        f468d = Settings.sFMItemSize;
        if (Settings.sGUIGridView) {
            f468d = (int) (((float) f468d) * 1.6f);
        }
        f469e = (int) (((double) f468d) * 0.4d);
        switch (Settings.sFSIconTheme) {
            case 1:
                f470f = f468d / 2;
                f471g = (int) (((float) f468d) / 2.5f);
                C0169f.m579c(context);
                break;
            default:
                f470f = (int) (((float) f468d) / 1.9f);
                f471g = (int) (((float) f468d) / 2.75f);
                C0169f.m578b(context);
                break;
        }
        C0169f.m580d(context);
        C0169f.m581e(context);
    }

    /* renamed from: b */
    private static void m578b(Context context) {
        Resources resources = context.getResources();
        f465a[0] = C0202q.m724a(resources, R.drawable.fs_unknown, f468d, f468d);
        f465a[1] = C0202q.m724a(resources, R.drawable.fs_up, f468d, f468d);
        f465a[2] = C0202q.m724a(resources, R.drawable.fs_folder, f468d, f468d);
        f465a[4] = C0202q.m724a(resources, R.drawable.fs_encrypt, f468d, f468d);
        f465a[5] = C0202q.m724a(resources, R.drawable.fs_word, f468d, f468d);
        f465a[6] = C0202q.m724a(resources, R.drawable.fs_apk, f468d, f468d);
        f465a[7] = C0202q.m724a(resources, R.drawable.fs_archive, f468d, f468d);
        f465a[8] = C0202q.m724a(resources, R.drawable.fs_archive, f468d, f468d);
        f465a[9] = C0202q.m724a(resources, R.drawable.fs_audio, f468d, f468d);
        f465a[10] = C0202q.m724a(resources, R.drawable.fs_excel, f468d, f468d);
        f465a[11] = C0202q.m724a(resources, R.drawable.fs_picture, f468d, f468d);
        f465a[12] = C0202q.m724a(resources, R.drawable.fs_powerpoint, f468d, f468d);
        f465a[13] = C0202q.m724a(resources, R.drawable.fs_text, f468d, f468d);
        f465a[14] = C0202q.m724a(resources, R.drawable.fs_web, f468d, f468d);
        f465a[15] = C0202q.m724a(resources, R.drawable.fs_acrobat, f468d, f468d);
        f465a[16] = C0202q.m724a(resources, R.drawable.fs_video, f468d, f468d);
        f465a[18] = C0202q.m724a(resources, R.drawable.fs_xml, f468d, f468d);
        f465a[17] = C0202q.m724a(resources, R.drawable.fs_ebook, f468d, f468d);
    }

    /* renamed from: c */
    private static void m579c(Context context) {
        Resources resources = context.getResources();
        f465a[0] = C0202q.m724a(resources, R.drawable.fsm_unknown, f468d, f468d);
        f465a[1] = C0202q.m724a(resources, R.drawable.fsm_up, f468d, f468d);
        f465a[2] = C0202q.m724a(resources, R.drawable.fsm_folder, f468d, f468d);
        f465a[4] = C0202q.m724a(resources, R.drawable.fsm_encrypt, f468d, f468d);
        f465a[5] = C0202q.m724a(resources, R.drawable.fsm_word, f468d, f468d);
        f465a[6] = C0202q.m724a(resources, R.drawable.fsm_apk, f468d, f468d);
        f465a[7] = C0202q.m724a(resources, R.drawable.fsm_archive, f468d, f468d);
        f465a[8] = C0202q.m724a(resources, R.drawable.fsm_cd_image, f468d, f468d);
        f465a[9] = C0202q.m724a(resources, R.drawable.fsm_audio, f468d, f468d);
        f465a[10] = C0202q.m724a(resources, R.drawable.fsm_excel, f468d, f468d);
        f465a[11] = C0202q.m724a(resources, R.drawable.fsm_picture, f468d, f468d);
        f465a[12] = C0202q.m724a(resources, R.drawable.fsm_powerpoint, f468d, f468d);
        f465a[13] = C0202q.m724a(resources, R.drawable.fsm_text, f468d, f468d);
        f465a[14] = C0202q.m724a(resources, R.drawable.fsm_web, f468d, f468d);
        f465a[15] = C0202q.m724a(resources, R.drawable.fsm_acrobat, f468d, f468d);
        f465a[16] = C0202q.m724a(resources, R.drawable.fsm_video, f468d, f468d);
        f465a[18] = C0202q.m724a(resources, R.drawable.fsm_xml, f468d, f468d);
        f465a[17] = C0202q.m724a(resources, R.drawable.fsm_ebook, f468d, f468d);
    }

    /* renamed from: d */
    private static void m580d(Context context) {
        Resources resources = context.getResources();
        f467c[0] = C0202q.m724a(resources, R.drawable.ic_android, f469e, f469e);
        f467c[1] = C0202q.m724a(resources, R.drawable.ic_alarm, f469e, f469e);
        f467c[2] = C0202q.m724a(resources, R.drawable.ic_app, f469e, f469e);
        f467c[3] = C0202q.m724a(resources, R.drawable.ic_audio, f469e, f469e);
        f467c[4] = C0202q.m724a(resources, R.drawable.ic_bin, f469e, f469e);
        f467c[5] = C0202q.m724a(resources, R.drawable.ic_camera, f469e, f469e);
        f467c[6] = C0202q.m724a(resources, R.drawable.ic_dev, f469e, f469e);
        f467c[7] = C0202q.m724a(resources, R.drawable.ic_document, f469e, f469e);
        f467c[8] = C0202q.m724a(resources, R.drawable.ic_download, f469e, f469e);
        f467c[9] = C0202q.m724a(resources, R.drawable.ic_home, f469e, f469e);
        f467c[10] = C0202q.m724a(resources, R.drawable.ic_music, f469e, f469e);
        f467c[11] = C0202q.m724a(resources, R.drawable.ic_notifications, f469e, f469e);
        f467c[12] = C0202q.m724a(resources, R.drawable.ic_phone, f469e, f469e);
        f467c[13] = C0202q.m724a(resources, R.drawable.ic_picture, f469e, f469e);
        f467c[14] = C0202q.m724a(resources, R.drawable.ic_podcast, f469e, f469e);
        f467c[15] = C0202q.m724a(resources, R.drawable.ic_ringtone, f469e, f469e);
        f467c[16] = C0202q.m724a(resources, R.drawable.ic_root, f469e, f469e);
        f467c[17] = C0202q.m724a(resources, R.drawable.ic_sd, f469e, f469e);
        f467c[18] = C0202q.m724a(resources, R.drawable.ic_settings, f469e, f469e);
        f467c[19] = C0202q.m724a(resources, R.drawable.ic_storage, f469e, f469e);
        f467c[20] = C0202q.m724a(resources, R.drawable.ic_trash, f469e, f469e);
        f467c[21] = C0202q.m724a(resources, R.drawable.ic_usb, f469e, f469e);
        f467c[22] = C0202q.m724a(resources, R.drawable.ic_video, f469e, f469e);
        f467c[23] = C0202q.m724a(resources, R.drawable.ic_bluetooth, f469e, f469e);
        f467c[24] = C0202q.m724a(resources, R.drawable.ic_framework, f469e, f469e);
        f467c[25] = C0202q.m724a(resources, R.drawable.ic_font, f469e, f469e);
        f467c[26] = C0202q.m724a(resources, R.drawable.ic_book, f469e, f469e);
        f467c[27] = C0202q.m724a(resources, R.drawable.ic_archive, f469e, f469e);
        f467c[29] = C0202q.m724a(resources, R.drawable.fsm_encrypt, f468d, f468d);
        f467c[30] = C0202q.m724a(resources, R.drawable.fsm_assumption, f468d, f468d);
    }

    /* renamed from: e */
    private static void m581e(Context context) {
        f466b[0] = C0202q.m724a(context.getResources(), R.drawable.ic_play_circle, f468d, f468d);
    }
}
