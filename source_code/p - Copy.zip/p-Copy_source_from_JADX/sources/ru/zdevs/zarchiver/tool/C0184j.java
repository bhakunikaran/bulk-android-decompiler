package ru.zdevs.zarchiver.tool;

import android.os.Build.VERSION;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import ru.zdevs.zarchiver.p004b.C0073a;
import ru.zdevs.zarchiver.p004b.C0075c;
import ru.zdevs.zarchiver.p004b.C0085k;
import ru.zdevs.zarchiver.p004b.C0085k.C0084a;
import ru.zdevs.zarchiver.settings.Settings;

/* renamed from: ru.zdevs.zarchiver.tool.j */
public class C0184j {
    /* renamed from: a */
    private static final String[] f520a = new String[]{"ext", "rootfs", "yaffs", "f2fs", "ubifs", "reiserfs", "btrfs", "jffs", "unionfs", "aufs"};
    /* renamed from: b */
    private static final String[] f521b = new String[]{"cramfs", "squashfs"};
    /* renamed from: c */
    private static final String[] f522c = new String[]{"tmpfs", "proc", "sysfs", "cgroup"};
    /* renamed from: d */
    private static final String[] f523d = new String[]{"vfat", "msdos", "exfat", "ntfs"};
    /* renamed from: e */
    private static final String[] f524e = new String[]{"fuse"};
    /* renamed from: f */
    private static final ArrayList<C0183a> f525f = new ArrayList();

    /* renamed from: ru.zdevs.zarchiver.tool.j$a */
    public static class C0183a implements Comparable<C0183a> {
        /* renamed from: a */
        String f515a;
        /* renamed from: b */
        String f516b;
        /* renamed from: c */
        String f517c;
        /* renamed from: d */
        String f518d;
        /* renamed from: e */
        byte f519e;

        /* renamed from: a */
        public int m636a(C0183a c0183a) {
            int length = this.f516b.length();
            int length2 = c0183a.f516b.length();
            return length == length2 ? 0 : length > length2 ? 1 : -1;
        }

        /* renamed from: a */
        public String m637a() {
            return this.f516b;
        }

        /* renamed from: b */
        public String m638b() {
            return this.f517c;
        }

        /* renamed from: c */
        public boolean m639c() {
            return this.f518d != null && this.f518d.contains("rw");
        }

        public /* synthetic */ int compareTo(Object obj) {
            return m636a((C0183a) obj);
        }

        /* renamed from: d */
        public byte m640d() {
            int i = 0;
            if (this.f519e != (byte) -1) {
                return this.f519e;
            }
            this.f519e = (byte) 0;
            for (String startsWith : C0184j.f520a) {
                if (this.f517c.startsWith(startsWith)) {
                    this.f519e = (byte) 1;
                    return this.f519e;
                }
            }
            for (String startsWith2 : C0184j.f521b) {
                if (this.f517c.startsWith(startsWith2)) {
                    this.f519e = (byte) 2;
                    return this.f519e;
                }
            }
            for (String startsWith22 : C0184j.f522c) {
                if (this.f517c.startsWith(startsWith22)) {
                    this.f519e = (byte) 3;
                    return this.f519e;
                }
            }
            for (String startsWith222 : C0184j.f523d) {
                if (this.f517c.startsWith(startsWith222)) {
                    this.f519e = (byte) 4;
                    return this.f519e;
                }
            }
            String[] g = C0184j.f524e;
            int length = g.length;
            while (i < length) {
                if (this.f517c.startsWith(g[i])) {
                    this.f519e = (byte) 5;
                    return this.f519e;
                }
                i++;
            }
            C0166c.m559d("StorageList", "Unknown FS type: '" + this.f517c + "'");
            return this.f519e;
        }
    }

    /* renamed from: a */
    public static byte m641a(File file) {
        if (f525f.size() <= 0) {
            C0184j.m645b();
        }
        do {
            String absolutePath = file.getAbsolutePath();
            synchronized (f525f) {
                Iterator it = f525f.iterator();
                while (it.hasNext()) {
                    C0183a c0183a = (C0183a) it.next();
                    if (c0183a.f516b.equals(absolutePath)) {
                        byte d = c0183a.m640d();
                        return d;
                    }
                }
                file = file.getParentFile();
            }
        } while (file != null);
        return (byte) 0;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    /* renamed from: a */
    public static ru.zdevs.zarchiver.tool.C0184j.C0183a m642a(java.lang.String r6) {
        /*
        r0 = f525f;
        r0 = r0.size();
        if (r0 > 0) goto L_0x000b;
    L_0x0008:
        ru.zdevs.zarchiver.tool.C0184j.m645b();
    L_0x000b:
        r0 = new java.io.File;
        r1 = ru.zdevs.zarchiver.tool.C0168e.m573c(r6);
        r0.<init>(r1);
        r1 = r0;
    L_0x0015:
        r2 = r1.getAbsolutePath();
        r3 = f525f;
        monitor-enter(r3);
        r0 = f525f;	 Catch:{ all -> 0x0041 }
        r4 = r0.iterator();	 Catch:{ all -> 0x0041 }
    L_0x0022:
        r0 = r4.hasNext();	 Catch:{ all -> 0x0041 }
        if (r0 == 0) goto L_0x0038;
    L_0x0028:
        r0 = r4.next();	 Catch:{ all -> 0x0041 }
        r0 = (ru.zdevs.zarchiver.tool.C0184j.C0183a) r0;	 Catch:{ all -> 0x0041 }
        r5 = r0.f516b;	 Catch:{ all -> 0x0041 }
        r5 = r5.equals(r2);	 Catch:{ all -> 0x0041 }
        if (r5 == 0) goto L_0x0022;
    L_0x0036:
        monitor-exit(r3);	 Catch:{ all -> 0x0041 }
    L_0x0037:
        return r0;
    L_0x0038:
        monitor-exit(r3);	 Catch:{ all -> 0x0041 }
        r0 = r1.getParentFile();
        if (r0 != 0) goto L_0x0044;
    L_0x003f:
        r0 = 0;
        goto L_0x0037;
    L_0x0041:
        r0 = move-exception;
        monitor-exit(r3);	 Catch:{ all -> 0x0041 }
        throw r0;
    L_0x0044:
        r1 = r0;
        goto L_0x0015;
        */
        throw new UnsupportedOperationException("Method not decompiled: ru.zdevs.zarchiver.tool.j.a(java.lang.String):ru.zdevs.zarchiver.tool.j$a");
    }

    /* renamed from: a */
    public static void m643a(C0073a c0073a) {
        if (VERSION.SDK_INT < 18 || !C0184j.m647b(c0073a)) {
            C0184j.m644a();
        }
    }

    /* renamed from: a */
    public static boolean m644a() {
        FileInputStream fileInputStream;
        BufferedReader bufferedReader;
        Throwable e;
        FileInputStream fileInputStream2 = null;
        File file = new File("/proc/mounts");
        synchronized (f525f) {
            f525f.clear();
            if (file.exists()) {
                try {
                    fileInputStream = new FileInputStream(file);
                    try {
                        bufferedReader = new BufferedReader(new InputStreamReader(fileInputStream));
                        while (true) {
                            try {
                                String readLine = bufferedReader.readLine();
                                if (readLine == null) {
                                    break;
                                }
                                String[] a = C0202q.m734a(readLine, ' ');
                                if (a.length >= 2) {
                                    C0183a c0183a = new C0183a();
                                    c0183a.f515a = a[0];
                                    c0183a.f516b = a[1];
                                    c0183a.f517c = "";
                                    if (a.length > 2 && a[2] != null) {
                                        c0183a.f517c = a[2];
                                    }
                                    c0183a.f518d = "";
                                    if (a.length > 3 && a[3] != null) {
                                        c0183a.f518d = a[3];
                                    }
                                    c0183a.f519e = (byte) -1;
                                    f525f.add(c0183a);
                                }
                            } catch (Exception e2) {
                                e = e2;
                                fileInputStream2 = fileInputStream;
                            } catch (Throwable th) {
                                e = th;
                            }
                        }
                        if (bufferedReader != null) {
                            try {
                                bufferedReader.close();
                            } catch (Throwable e3) {
                                C0166c.m556a(e3);
                            }
                        }
                        if (fileInputStream != null) {
                            fileInputStream.close();
                        }
                    } catch (Exception e4) {
                        e3 = e4;
                        bufferedReader = null;
                        fileInputStream2 = fileInputStream;
                        try {
                            C0166c.m556a(e3);
                            if (bufferedReader != null) {
                                try {
                                    bufferedReader.close();
                                } catch (Throwable e32) {
                                    C0166c.m556a(e32);
                                }
                            }
                            if (fileInputStream2 != null) {
                                fileInputStream2.close();
                            }
                            Collections.sort(f525f);
                            return true;
                        } catch (Throwable th2) {
                            e32 = th2;
                            fileInputStream = fileInputStream2;
                            if (bufferedReader != null) {
                                try {
                                    bufferedReader.close();
                                } catch (Throwable e5) {
                                    C0166c.m556a(e5);
                                    throw e32;
                                }
                            }
                            if (fileInputStream != null) {
                                fileInputStream.close();
                            }
                            throw e32;
                        }
                    } catch (Throwable th3) {
                        e32 = th3;
                        bufferedReader = null;
                        if (bufferedReader != null) {
                            bufferedReader.close();
                        }
                        if (fileInputStream != null) {
                            fileInputStream.close();
                        }
                        throw e32;
                    }
                } catch (Exception e6) {
                    e32 = e6;
                    bufferedReader = null;
                    C0166c.m556a(e32);
                    if (bufferedReader != null) {
                        bufferedReader.close();
                    }
                    if (fileInputStream2 != null) {
                        fileInputStream2.close();
                    }
                    Collections.sort(f525f);
                    return true;
                } catch (Throwable th4) {
                    e32 = th4;
                    bufferedReader = null;
                    fileInputStream = null;
                    if (bufferedReader != null) {
                        bufferedReader.close();
                    }
                    if (fileInputStream != null) {
                        fileInputStream.close();
                    }
                    throw e32;
                }
            }
        }
        Collections.sort(f525f);
        return true;
    }

    /* renamed from: b */
    public static void m645b() {
        C0184j.m643a(null);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    /* renamed from: b */
    public static boolean m646b(java.lang.String r7) {
        /*
        r2 = 0;
        r0 = f525f;
        r0 = r0.size();
        if (r0 > 0) goto L_0x000c;
    L_0x0009:
        ru.zdevs.zarchiver.tool.C0184j.m645b();
    L_0x000c:
        r0 = new java.io.File;
        r0.<init>(r7);
        r1 = r0;
    L_0x0012:
        r3 = r1.getAbsolutePath();
        r4 = f525f;
        monitor-enter(r4);
        r0 = f525f;	 Catch:{ all -> 0x004c }
        r5 = r0.iterator();	 Catch:{ all -> 0x004c }
    L_0x001f:
        r0 = r5.hasNext();	 Catch:{ all -> 0x004c }
        if (r0 == 0) goto L_0x0043;
    L_0x0025:
        r0 = r5.next();	 Catch:{ all -> 0x004c }
        r0 = (ru.zdevs.zarchiver.tool.C0184j.C0183a) r0;	 Catch:{ all -> 0x004c }
        r6 = r0.f516b;	 Catch:{ all -> 0x004c }
        r6 = r6.equals(r3);	 Catch:{ all -> 0x004c }
        if (r6 == 0) goto L_0x001f;
    L_0x0033:
        r1 = r0.m639c();	 Catch:{ all -> 0x004c }
        if (r1 == 0) goto L_0x0041;
    L_0x0039:
        r0 = r0.f519e;	 Catch:{ all -> 0x004c }
        r1 = 2;
        if (r0 == r1) goto L_0x0041;
    L_0x003e:
        r0 = 1;
    L_0x003f:
        monitor-exit(r4);	 Catch:{ all -> 0x004c }
    L_0x0040:
        return r0;
    L_0x0041:
        r0 = r2;
        goto L_0x003f;
    L_0x0043:
        monitor-exit(r4);	 Catch:{ all -> 0x004c }
        r0 = r1.getParentFile();
        if (r0 != 0) goto L_0x004f;
    L_0x004a:
        r0 = r2;
        goto L_0x0040;
    L_0x004c:
        r0 = move-exception;
        monitor-exit(r4);	 Catch:{ all -> 0x004c }
        throw r0;
    L_0x004f:
        r1 = r0;
        goto L_0x0012;
        */
        throw new UnsupportedOperationException("Method not decompiled: ru.zdevs.zarchiver.tool.j.b(java.lang.String):boolean");
    }

    /* renamed from: b */
    private static boolean m647b(C0073a c0073a) {
        if (!Settings.sRoot || !C0073a.m304f()) {
            return false;
        }
        if (c0073a == null) {
            c0073a = new C0075c();
        }
        if (!c0073a.mo52b()) {
            return false;
        }
        List<C0084a> arrayList = new ArrayList();
        if (C0085k.m344a(c0073a, arrayList)) {
            synchronized (f525f) {
                f525f.clear();
                for (C0084a c0084a : arrayList) {
                    C0183a c0183a = new C0183a();
                    c0183a.f515a = c0084a.f280a;
                    c0183a.f516b = c0084a.f281b;
                    c0183a.f517c = c0084a.f282c;
                    c0183a.f518d = c0084a.f283d ? "rw" : "ro";
                    c0183a.f519e = (byte) -1;
                    f525f.add(c0183a);
                }
            }
            c0073a.mo54c();
            Collections.sort(f525f);
            return f525f.size() > 0;
        }
        c0073a.mo54c();
        return false;
    }
}
