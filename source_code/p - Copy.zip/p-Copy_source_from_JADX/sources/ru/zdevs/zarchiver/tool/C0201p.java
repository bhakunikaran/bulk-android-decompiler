package ru.zdevs.zarchiver.tool;

/* renamed from: ru.zdevs.zarchiver.tool.p */
public class C0201p {
    /* renamed from: a */
    public static String m720a(String str, String str2) {
        if (str == null || str2 == null) {
            try {
                return "";
            } catch (Throwable e) {
                C0166c.m556a(e);
                return "";
            }
        }
        char[] toCharArray = str2.toCharArray();
        char[] toCharArray2 = str.toCharArray();
        int length = toCharArray2.length;
        int length2 = toCharArray.length;
        char[] cArr = new char[length];
        for (int i = 0; i < length; i++) {
            cArr[i] = (char) (toCharArray2[i] ^ toCharArray[i % length2]);
        }
        return new String(cArr);
    }

    /* renamed from: a */
    public static String m721a(byte[] bArr) {
        StringBuilder stringBuilder = new StringBuilder();
        for (byte append : bArr) {
            stringBuilder.append(append);
            stringBuilder.append(';');
        }
        return stringBuilder.toString();
    }

    /* renamed from: a */
    public static byte[] m722a(String str) {
        String[] a = C0202q.m734a(str, ';');
        byte[] bArr = new byte[a.length];
        for (int i = 0; i < a.length; i++) {
            bArr[i] = Byte.parseByte(a[i]);
        }
        return bArr;
    }
}
