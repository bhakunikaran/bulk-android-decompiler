package ru.zdevs.zarchiver.tool;

import android.util.Xml;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import org.xmlpull.v1.XmlPullParser;

/* renamed from: ru.zdevs.zarchiver.tool.b */
public class C0165b {
    /* renamed from: a */
    private String f459a;
    /* renamed from: b */
    private String f460b;

    /* renamed from: b */
    private void m550b(String str) {
        try {
            InputStream fileInputStream = !str.startsWith("/SAF/") ? new FileInputStream(str) : C0187l.m671d(str);
            if (fileInputStream == null) {
                C0166c.m559d("BookMetadata", "Fail to open: " + str);
                return;
            }
            XmlPullParser newPullParser = Xml.newPullParser();
            newPullParser.setFeature("http://xmlpull.org/v1/doc/features.html#process-namespaces", false);
            newPullParser.setInput(fileInputStream, null);
            Object obj = null;
            Object obj2 = null;
            Object obj3 = null;
            Object obj4 = null;
            for (int eventType = newPullParser.getEventType(); eventType != 1; eventType = newPullParser.next()) {
                if (newPullParser.getEventType() == 3) {
                    if (!newPullParser.getName().equalsIgnoreCase("title-info")) {
                        if (newPullParser.getName().equalsIgnoreCase("author")) {
                            obj = null;
                        } else if (newPullParser.getName().equalsIgnoreCase("book-title")) {
                            obj2 = null;
                        }
                    } else {
                        return;
                    }
                } else if (newPullParser.getEventType() == 2) {
                    if (obj3 != null) {
                        if (obj != null) {
                            if (newPullParser.getName().contains("name")) {
                                int i = 1;
                            }
                        } else if (newPullParser.getName().equalsIgnoreCase("book-title")) {
                            int i2 = 1;
                        } else if (newPullParser.getName().equalsIgnoreCase("author")) {
                            int i3 = 1;
                        }
                    } else if (newPullParser.getName().equalsIgnoreCase("title-info")) {
                        int i4 = 1;
                    }
                } else if (newPullParser.getEventType() == 4) {
                    if (obj2 != null) {
                        this.f460b = newPullParser.getText();
                        obj2 = null;
                    } else if (obj4 != null) {
                        if (this.f459a == null) {
                            this.f459a = newPullParser.getText();
                        } else {
                            this.f459a += " " + newPullParser.getText();
                        }
                        obj4 = null;
                    }
                }
            }
        } catch (Throwable e) {
            C0166c.m556a(e);
        }
    }

    /* renamed from: c */
    private void m551c(String str) {
        try {
            InputStream fileInputStream = !str.startsWith("/SAF/") ? new FileInputStream(str) : C0187l.m671d(str);
            if (fileInputStream == null) {
                C0166c.m559d("BookMetadata", "Fail to open: " + str);
                return;
            }
            InputStream zipInputStream = new ZipInputStream(fileInputStream);
            ZipEntry nextEntry;
            do {
                nextEntry = zipInputStream.getNextEntry();
                if (nextEntry == null) {
                    return;
                }
            } while (!nextEntry.getName().equalsIgnoreCase("content.opf"));
            XmlPullParser newPullParser = Xml.newPullParser();
            newPullParser.setFeature("http://xmlpull.org/v1/doc/features.html#process-namespaces", true);
            newPullParser.setInput(zipInputStream, null);
            Object obj = null;
            Object obj2 = null;
            Object obj3 = null;
            for (int eventType = newPullParser.getEventType(); eventType != 1; eventType = newPullParser.next()) {
                if (newPullParser.getEventType() == 3) {
                    C0166c.m559d("BookMetadata", "end: " + newPullParser.getName());
                    if (newPullParser.getName().equalsIgnoreCase("metadata")) {
                        return;
                    }
                } else if (newPullParser.getEventType() == 2) {
                    C0166c.m559d("BookMetadata", "start: " + newPullParser.getName());
                    if (obj2 != null) {
                        if (newPullParser.getName().equalsIgnoreCase("title")) {
                            obj3 = null;
                            int i = 1;
                        } else if (newPullParser.getName().equalsIgnoreCase("creator")) {
                            int i2 = 1;
                            obj = null;
                        } else {
                            obj3 = null;
                            obj = null;
                        }
                    } else if (newPullParser.getName().equalsIgnoreCase("metadata")) {
                        int i3 = 1;
                    }
                } else if (newPullParser.getEventType() == 4) {
                    C0166c.m559d("BookMetadata", "text: " + newPullParser.getName());
                    if (obj != null) {
                        this.f460b = newPullParser.getText();
                    } else if (obj3 != null) {
                        this.f459a = newPullParser.getText();
                    } else {
                        continue;
                    }
                } else {
                    continue;
                }
            }
        } catch (Throwable e) {
            C0166c.m556a(e);
        }
    }

    /* renamed from: a */
    public String m552a(int i) {
        switch (i) {
            case 0:
                return this.f459a;
            case 1:
                return this.f460b;
            default:
                return null;
        }
    }

    /* renamed from: a */
    public void m553a(String str) {
        this.f460b = null;
        this.f459a = null;
        if (str.endsWith(".fb2")) {
            m550b(str);
        } else if (str.endsWith(".epub")) {
            m551c(str);
        }
    }
}
