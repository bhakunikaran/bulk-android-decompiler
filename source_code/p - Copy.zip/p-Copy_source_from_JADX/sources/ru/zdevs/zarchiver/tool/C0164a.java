package ru.zdevs.zarchiver.tool;

import ru.zdevs.zarchiver.Actions;

/* renamed from: ru.zdevs.zarchiver.tool.a */
public class C0164a {
    /* renamed from: a */
    private static char m547a(char c) {
        return c == '.' ? ' ' : c == ' ' ? '.' : c < '' ? (Actions.ACTION_PAST > c || c > 'Z') ? c : (char) (c + 32) : Character.toLowerCase(c);
    }

    /* renamed from: a */
    public static int m548a(CharSequence charSequence, CharSequence charSequence2) {
        int i;
        int i2;
        int i3 = 0;
        int length = charSequence.length();
        int length2 = charSequence2.length();
        if (length2 < length) {
            i = length2;
            i2 = 0;
        } else {
            i = length;
            i2 = 0;
        }
        while (i2 < i) {
            int i4;
            char c;
            char charAt = charSequence.charAt(i2);
            char charAt2 = charSequence2.charAt(i2);
            int i5 = charAt - charAt2;
            char c2;
            if (i5 != 0) {
                charAt = C0164a.m547a(charAt);
                charAt2 = C0164a.m547a(charAt2);
                c2 = charAt2;
                i4 = charAt - charAt2;
                c = charAt;
                charAt = c2;
            } else {
                c2 = charAt2;
                i4 = i5;
                c = charAt;
                charAt = c2;
            }
            if (c <= '9' && r2 <= '9' && c >= '0' && r2 >= '0') {
                if (i3 != 0) {
                    i4 = i3;
                }
                Object obj = length2 - i2 < 2 ? 1 : null;
                if (length - i2 < 2) {
                    return obj == null ? -1 : i4;
                } else {
                    if (obj != null) {
                        return 1;
                    }
                    boolean b = C0164a.m549b(charSequence2.charAt(i2 + 1));
                    if (C0164a.m549b(charSequence.charAt(i2 + 1))) {
                        if (b && i4 != 0) {
                            return i4;
                        }
                        if (!b) {
                            return -1;
                        }
                    } else if (b) {
                        return 1;
                    }
                }
            } else if (i4 != 0) {
                return i4;
            } else {
                i4 = 0;
            }
            i2++;
            i3 = i4;
        }
        return length - length2;
    }

    /* renamed from: b */
    private static boolean m549b(char c) {
        return c > '9' || c < '0';
    }
}
