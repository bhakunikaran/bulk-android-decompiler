package ru.zdevs.zarchiver.tool;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Build.VERSION;
import java.io.File;
import ru.zdevs.zarchiver.archiver.C0061a;
import ru.zdevs.zarchiver.fs.MyUri;
import ru.zdevs.zarchiver.io.C0143a;

/* renamed from: ru.zdevs.zarchiver.tool.o */
public class C0200o {
    /* renamed from: a */
    public static byte m708a(Context context, String str) {
        return C0200o.m709a(context, new MyUri(str));
    }

    /* renamed from: a */
    public static byte m709a(Context context, MyUri myUri) {
        return myUri.isExternal() ? (byte) 1 : myUri.isLocalFS() ? !C0200o.m714b(context, myUri) ? C0184j.m646b(myUri.toLocalPath()) ? (byte) 2 : (byte) 3 : (byte) 1 : (byte) 4;
    }

    /* renamed from: a */
    public static byte m710a(File file) {
        try {
            file = file.getCanonicalFile();
        } catch (Exception e) {
        }
        return !C0200o.m713a(file, false) ? (byte) 2 : C0200o.m719d(file);
    }

    /* renamed from: a */
    public static byte m711a(String str) {
        return C0200o.m710a(new File(str));
    }

    /* renamed from: a */
    public static byte m712a(MyUri myUri) {
        return myUri.isRoot() ? (byte) 2 : myUri.isExternal() ? (byte) 1 : C0200o.m711a(myUri.toLocalPath());
    }

    /* renamed from: a */
    private static boolean m713a(File file, boolean z) {
        File file2;
        boolean z2 = false;
        File a = C0168e.m570a(file);
        if (!a.exists()) {
            a = a.getParentFile();
        }
        if (a != null && a.isDirectory()) {
            File[] listFiles = a.listFiles();
            if (listFiles != null) {
                int length = listFiles.length;
                for (int i = z2; i < length; i++) {
                    file2 = listFiles[i];
                    if (file2.isFile()) {
                        break;
                    }
                }
            }
        }
        file2 = a;
        if (file2 == null) {
            return z2;
        }
        if (file2.isFile()) {
            if (!file2.canRead()) {
                return z2;
            }
            if (z && !file2.canWrite()) {
                return z2;
            }
        } else if (z && file2.isDirectory()) {
            a = new File(file2, ".rw");
            try {
                z2 = a.createNewFile();
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
            a.delete();
            return z2;
        }
        return true;
    }

    /* renamed from: b */
    private static boolean m714b(Context context, MyUri myUri) {
        if (!myUri.isLocalFS()) {
            return myUri.isArchive() ? C0061a.m205a(context, myUri.getPath()) : false;
        } else {
            File toFile = myUri.toFile();
            try {
                toFile = toFile.getCanonicalFile();
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
            if (C0200o.m719d(toFile) == (byte) 2) {
                return false;
            }
            if (VERSION.SDK_INT >= 21) {
                if (C0143a.m430b(context)) {
                    return true;
                }
                String absolutePath = toFile.getAbsolutePath();
                if (C0143a.m432b(absolutePath)) {
                    return C0143a.m433c(absolutePath);
                }
            }
            return C0200o.m713a(toFile, true);
        }
    }

    /* renamed from: b */
    public static boolean m715b(File file) {
        byte a = C0184j.m641a(file);
        return a == (byte) 2 || a == (byte) 1;
    }

    /* renamed from: b */
    public static boolean m716b(String str) {
        return C0200o.m715b(new File(str));
    }

    /* renamed from: b */
    public static boolean m717b(MyUri myUri) {
        File toFile = myUri.toFile();
        return toFile == null ? false : C0200o.m718c(toFile);
    }

    /* renamed from: c */
    public static boolean m718c(File file) {
        byte a = C0184j.m641a(file);
        return a == (byte) 1 || a == (byte) 3;
    }

    @SuppressLint({"SdCardPath"})
    /* renamed from: d */
    private static byte m719d(File file) {
        String absolutePath = file.getAbsolutePath();
        return (absolutePath.startsWith("/storage/") || absolutePath.startsWith("/sdcard")) ? (byte) 1 : (VERSION.SDK_INT >= 21 || !absolutePath.startsWith("/mnt/")) ? (byte) 2 : (byte) 1;
    }
}
