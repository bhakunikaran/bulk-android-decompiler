package ru.zdevs.zarchiver.tool;

import android.annotation.TargetApi;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.DocumentsContract;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import ru.zdevs.zarchiver.fs.MyUri;
import ru.zdevs.zarchiver.io.LollipopExtSD;

@TargetApi(21)
/* renamed from: ru.zdevs.zarchiver.tool.l */
public class C0187l {
    /* renamed from: a */
    private static final String[] f532a = new String[]{"_display_name", "mime_type", "last_modified", "_size", "document_id"};

    /* renamed from: ru.zdevs.zarchiver.tool.l$a */
    public static class C0186a {
        /* renamed from: a */
        public String f527a = null;
        /* renamed from: b */
        public boolean f528b = false;
        /* renamed from: c */
        public long f529c = 0;
        /* renamed from: d */
        public long f530d = 0;
        /* renamed from: e */
        public Uri f531e;
    }

    /* renamed from: a */
    public static ParcelFileDescriptor m662a(String str, String str2) {
        Uri uriFromPath = LollipopExtSD.getUriFromPath(str, false, true);
        if (uriFromPath != null) {
            return LollipopExtSD.getContentResolver().openFileDescriptor(uriFromPath, str2);
        }
        throw new FileNotFoundException();
    }

    /* renamed from: a */
    public static OutputStream m663a(C0186a c0186a, String str) {
        if (c0186a.f531e == null) {
            c0186a.f531e = LollipopExtSD.getUriFromPath(str, false, true);
        }
        return LollipopExtSD.getContentResolver().openOutputStream(c0186a.f531e);
    }

    /* renamed from: a */
    public static List<C0186a> m664a(String str) {
        AutoCloseable query;
        Object e;
        Throwable th;
        List<C0186a> arrayList = new ArrayList();
        Uri uriFromPath = LollipopExtSD.getUriFromPath(str, true, false);
        if (uriFromPath == null) {
            return null;
        }
        Uri buildChildDocumentsUriUsingTree = DocumentsContract.buildChildDocumentsUriUsingTree(uriFromPath, DocumentsContract.getDocumentId(uriFromPath));
        try {
            query = LollipopExtSD.query(buildChildDocumentsUriUsingTree, f532a);
            while (query != null) {
                try {
                    if (!query.moveToNext()) {
                        break;
                    } else if (query.getString(0) != null) {
                        C0186a c0186a = new C0186a();
                        c0186a.f527a = query.getString(0);
                        c0186a.f528b = "vnd.android.document/directory".equals(query.getString(1));
                        c0186a.f529c = query.getLong(2);
                        c0186a.f530d = query.getLong(3);
                        c0186a.f531e = DocumentsContract.buildDocumentUriUsingTree(buildChildDocumentsUriUsingTree, query.getString(4));
                        arrayList.add(c0186a);
                    }
                } catch (Exception e2) {
                    e = e2;
                }
            }
            LollipopExtSD.closeQuery(query);
        } catch (Exception e3) {
            Exception exception = e3;
            query = null;
            Exception exception2 = exception;
            try {
                C0166c.m559d("SAFramework", "Failed query: " + e);
                LollipopExtSD.closeQuery(query);
                return arrayList;
            } catch (Throwable th2) {
                th = th2;
                LollipopExtSD.closeQuery(query);
                throw th;
            }
        } catch (Throwable th3) {
            query = null;
            th = th3;
            LollipopExtSD.closeQuery(query);
            throw th;
        }
        return arrayList;
    }

    /* renamed from: a */
    public static boolean m665a(MyUri myUri, String str, String str2) {
        return LollipopExtSD.renameTo(myUri.getPath(), str, str2);
    }

    /* renamed from: a */
    public static String[] m666a(C0186a c0186a) {
        int i = 0;
        String[] strArr = new String[0];
        AutoCloseable autoCloseable = null;
        try {
            autoCloseable = LollipopExtSD.query(DocumentsContract.buildChildDocumentsUriUsingTree(c0186a.f531e, DocumentsContract.getDocumentId(c0186a.f531e)), f532a);
            if (autoCloseable != null) {
                strArr = new String[autoCloseable.getCount()];
                while (autoCloseable.moveToNext()) {
                    int i2 = i + 1;
                    strArr[i] = autoCloseable.getString(0);
                    i = i2;
                }
                LollipopExtSD.closeQuery(autoCloseable);
            }
        } catch (Exception e) {
            C0166c.m559d("SAFramework", "Failed query: " + e);
        } finally {
            LollipopExtSD.closeQuery(autoCloseable);
        }
        return strArr;
    }

    /* renamed from: b */
    public static C0186a m667b(String str) {
        Object e;
        Throwable th;
        Exception exception;
        int lastIndexOf = str.lastIndexOf(47);
        if (lastIndexOf <= 4) {
            return null;
        }
        String substring = str.substring(0, lastIndexOf);
        String substring2 = str.substring(lastIndexOf + 1);
        Uri uriFromPath = LollipopExtSD.getUriFromPath(substring, true, false);
        if (uriFromPath == null) {
            return null;
        }
        C0186a c0186a;
        Uri buildChildDocumentsUriUsingTree = DocumentsContract.buildChildDocumentsUriUsingTree(uriFromPath, DocumentsContract.getDocumentId(uriFromPath));
        AutoCloseable query;
        try {
            query = LollipopExtSD.query(buildChildDocumentsUriUsingTree, f532a);
            while (query != null) {
                try {
                    if (!query.moveToNext()) {
                        break;
                    } else if (query.getString(0) != null && query.getString(0).equals(substring2)) {
                        c0186a = new C0186a();
                        try {
                            c0186a.f527a = query.getString(0);
                            c0186a.f528b = "vnd.android.document/directory".equals(query.getString(1));
                            c0186a.f529c = query.getLong(2);
                            c0186a.f530d = query.getLong(3);
                            c0186a.f531e = DocumentsContract.buildDocumentUriUsingTree(buildChildDocumentsUriUsingTree, query.getString(4));
                            break;
                        } catch (Exception e2) {
                            e = e2;
                            try {
                                C0166c.m559d("SAFramework", "Failed query: " + e);
                                LollipopExtSD.closeQuery(query);
                                return c0186a;
                            } catch (Throwable th2) {
                                th = th2;
                                LollipopExtSD.closeQuery(query);
                                throw th;
                            }
                        }
                    }
                } catch (Exception e3) {
                    exception = e3;
                    c0186a = null;
                    Exception exception2 = exception;
                }
            }
            c0186a = null;
            LollipopExtSD.closeQuery(query);
        } catch (Exception e32) {
            query = null;
            exception = e32;
            c0186a = null;
            e = exception;
            C0166c.m559d("SAFramework", "Failed query: " + e);
            LollipopExtSD.closeQuery(query);
            return c0186a;
        } catch (Throwable th3) {
            th = th3;
            query = null;
            LollipopExtSD.closeQuery(query);
            throw th;
        }
        return c0186a;
    }

    /* renamed from: b */
    public static C0186a[] m668b(C0186a c0186a) {
        int i = 0;
        C0186a[] c0186aArr = new C0186a[0];
        if (c0186a != null) {
            Uri buildChildDocumentsUriUsingTree = DocumentsContract.buildChildDocumentsUriUsingTree(c0186a.f531e, DocumentsContract.getDocumentId(c0186a.f531e));
            AutoCloseable autoCloseable = null;
            try {
                autoCloseable = LollipopExtSD.query(c0186a.f531e, f532a);
                if (autoCloseable != null) {
                    c0186aArr = new C0186a[autoCloseable.getCount()];
                    while (autoCloseable.moveToNext()) {
                        c0186aArr[i].f527a = autoCloseable.getString(0);
                        c0186aArr[i].f528b = "vnd.android.document/directory".equals(autoCloseable.getString(1));
                        c0186aArr[i].f529c = autoCloseable.getLong(2);
                        c0186aArr[i].f530d = autoCloseable.getLong(3);
                        c0186aArr[i].f531e = DocumentsContract.buildDocumentUriUsingTree(buildChildDocumentsUriUsingTree, autoCloseable.getString(4));
                        i++;
                    }
                    LollipopExtSD.closeQuery(autoCloseable);
                }
            } catch (Exception e) {
                C0166c.m559d("SAFramework", "Failed query: " + e);
            } finally {
                LollipopExtSD.closeQuery(autoCloseable);
            }
        }
        return c0186aArr;
    }

    /* renamed from: c */
    public static boolean m669c(String str) {
        return LollipopExtSD.mkdir(str) == 0;
    }

    /* renamed from: c */
    public static boolean m670c(C0186a c0186a) {
        try {
            return DocumentsContract.deleteDocument(LollipopExtSD.getContentResolver(), c0186a.f531e);
        } catch (Throwable e) {
            C0166c.m556a(e);
            return false;
        }
    }

    /* renamed from: d */
    public static InputStream m671d(String str) {
        Uri uriFromPath = LollipopExtSD.getUriFromPath(str, false, true);
        return uriFromPath == null ? null : LollipopExtSD.getContentResolver().openInputStream(uriFromPath);
    }

    /* renamed from: d */
    public static InputStream m672d(C0186a c0186a) {
        return LollipopExtSD.getContentResolver().openInputStream(c0186a.f531e);
    }
}
