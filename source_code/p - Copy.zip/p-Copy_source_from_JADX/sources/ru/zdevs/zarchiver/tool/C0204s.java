package ru.zdevs.zarchiver.tool;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import ru.zdevs.zarchiver.fs.MyUri;
import ru.zdevs.zarchiver.io.C0143a;
import ru.zdevs.zarchiver.p004b.C0075c;
import ru.zdevs.zarchiver.p004b.C0090p;
import ru.zdevs.zarchiver.service.C0160c;
import ru.zdevs.zarchiver.tool.C0187l.C0186a;

/* renamed from: ru.zdevs.zarchiver.tool.s */
public class C0204s {
    /* renamed from: a */
    private String f557a;
    /* renamed from: b */
    private Boolean f558b;
    /* renamed from: c */
    private C0186a f559c;
    /* renamed from: d */
    private File f560d;

    private C0204s() {
        this.f557a = null;
        this.f558b = Boolean.valueOf(false);
        this.f559c = null;
        this.f560d = null;
    }

    private C0204s(File file) {
        this();
        this.f560d = file;
    }

    public C0204s(String str) {
        if (str.startsWith("/SAF")) {
            this.f557a = str;
            this.f559c = C0187l.m667b(str);
            if (this.f559c == null) {
                this.f559c = new C0186a();
                this.f558b = Boolean.valueOf(false);
                return;
            }
            this.f558b = Boolean.valueOf(true);
            return;
        }
        this.f560d = new File(str);
    }

    public C0204s(MyUri myUri, String str) {
        this(myUri.getPath() + "/" + str);
    }

    private C0204s(C0186a c0186a) {
        this();
        this.f559c = c0186a;
        if (this.f559c == null) {
            this.f559c = new C0186a();
            this.f558b = Boolean.valueOf(false);
            return;
        }
        this.f558b = Boolean.valueOf(true);
    }

    /* renamed from: a */
    public boolean m746a() {
        return this.f560d != null ? this.f560d.isFile() : !this.f559c.f528b;
    }

    /* renamed from: a */
    public boolean m747a(C0075c c0075c, long j) {
        if (c0075c == null || !C0160c.f450b) {
            return false;
        }
        synchronized (c0075c) {
            C0090p.m356a(c0075c, m753f(), j);
        }
        return true;
    }

    /* renamed from: a */
    public boolean m748a(C0204s c0204s) {
        return (this.f560d == null || c0204s.f560d == null) ? false : this.f560d.renameTo(c0204s.f560d);
    }

    /* renamed from: b */
    public boolean m749b() {
        return this.f560d != null ? this.f560d.isDirectory() : this.f559c.f528b;
    }

    /* renamed from: c */
    public long m750c() {
        return this.f560d != null ? this.f560d.length() : this.f559c.f530d;
    }

    /* renamed from: d */
    public String m751d() {
        return this.f560d != null ? this.f560d.getName() : this.f559c.f527a;
    }

    /* renamed from: e */
    public String m752e() {
        return this.f560d != null ? this.f560d.getParent() : this.f557a.substring(0, this.f557a.lastIndexOf(47));
    }

    public boolean equals(Object obj) {
        boolean z = false;
        if (obj instanceof C0204s) {
            try {
                z = m753f().equals(((C0204s) obj).m753f());
            } catch (Exception e) {
            }
        }
        return z;
    }

    /* renamed from: f */
    public String m753f() {
        return this.f560d != null ? this.f560d.getAbsolutePath() : this.f557a;
    }

    /* renamed from: g */
    public String m754g() {
        return this.f560d != null ? this.f560d.getPath() : this.f557a;
    }

    /* renamed from: h */
    public long m755h() {
        return this.f560d != null ? this.f560d.lastModified() : this.f559c.f529c;
    }

    /* renamed from: i */
    public boolean m756i() {
        return this.f560d != null ? this.f560d.exists() : this.f558b.booleanValue();
    }

    /* renamed from: j */
    public boolean m757j() {
        return this.f560d != null ? this.f560d.mkdir() ? true : !C0143a.m433c(this.f560d.getAbsolutePath()) ? false : C0143a.m431b(this.f560d) : C0187l.m669c(this.f557a);
    }

    /* renamed from: k */
    public boolean m758k() {
        return this.f560d != null ? this.f560d.delete() ? true : C0143a.m428a(this.f560d) : C0187l.m670c(this.f559c);
    }

    /* renamed from: l */
    public OutputStream m759l() {
        if (this.f560d == null) {
            return C0187l.m663a(this.f559c, this.f557a);
        }
        try {
            return new FileOutputStream(this.f560d);
        } catch (Exception e) {
            if (C0143a.m433c(this.f560d.getAbsolutePath())) {
                return C0143a.m426a(this.f560d.getAbsolutePath());
            }
            throw new FileNotFoundException();
        }
    }

    /* renamed from: m */
    public InputStream m760m() {
        return this.f560d != null ? new FileInputStream(this.f560d) : C0187l.m672d(this.f559c);
    }

    /* renamed from: n */
    public boolean m761n() {
        if (this.f560d == null) {
            return false;
        }
        try {
            File file = this.f560d.getParent() == null ? this.f560d : new File(this.f560d.getParentFile().getCanonicalFile(), this.f560d.getName());
            return !file.getCanonicalFile().equals(file.getAbsoluteFile());
        } catch (Throwable e) {
            C0166c.m556a(e);
            return false;
        }
    }

    /* renamed from: o */
    public String[] m762o() {
        return this.f560d != null ? this.f560d.list() : C0187l.m666a(this.f559c);
    }

    /* renamed from: p */
    public C0204s[] m763p() {
        int i = 0;
        C0204s[] c0204sArr;
        if (this.f560d != null) {
            File[] listFiles = this.f560d.listFiles();
            if (listFiles == null) {
                return new C0204s[0];
            }
            c0204sArr = new C0204s[listFiles.length];
            while (i < listFiles.length) {
                c0204sArr[i] = new C0204s(listFiles[i]);
                i++;
            }
            return c0204sArr;
        }
        C0186a[] b = C0187l.m668b(this.f559c);
        c0204sArr = new C0204s[b.length];
        while (i < b.length) {
            c0204sArr[i] = new C0204s(b[i]);
            i++;
        }
        return c0204sArr;
    }
}
