package ru.zdevs.zarchiver.tool;

import android.os.MemoryFile;
import java.io.FileDescriptor;
import java.lang.reflect.Method;

/* renamed from: ru.zdevs.zarchiver.tool.h */
public class C0179h {
    /* renamed from: a */
    private MemoryFile f505a;
    /* renamed from: b */
    private int f506b;

    private C0179h(MemoryFile memoryFile, int i) {
        this.f505a = memoryFile;
        this.f506b = i;
    }

    /* renamed from: a */
    private static Object m621a(String str, Object obj, String str2, Object... objArr) {
        try {
            Class cls = Class.forName(str);
            Method declaredMethod;
            if (objArr != null) {
                int length = objArr.length;
                Class[] clsArr = new Class[length];
                for (int i = 0; i < length; i++) {
                    clsArr[i] = objArr[i].getClass();
                }
                declaredMethod = cls.getDeclaredMethod(str2, clsArr);
                declaredMethod.setAccessible(true);
                return declaredMethod.invoke(obj, objArr);
            }
            declaredMethod = cls.getDeclaredMethod(str2, new Class[0]);
            declaredMethod.setAccessible(true);
            return declaredMethod.invoke(obj, new Object[0]);
        } catch (Throwable e) {
            C0166c.m556a(e);
            return null;
        }
    }

    /* renamed from: a */
    public static C0179h m622a(int i) {
        try {
            MemoryFile memoryFile = new MemoryFile("za-" + i, i);
            C0179h.m621a("android.os.MemoryFile", memoryFile, "deactivate", new Object[0]);
            return new C0179h(memoryFile, ((Integer) C0179h.m621a("java.io.FileDescriptor", (FileDescriptor) C0179h.m621a("android.os.MemoryFile", memoryFile, "getFileDescriptor", new Object[0]), "getInt$", new Object[0])).intValue());
        } catch (Throwable e) {
            C0166c.m556a(e);
            return null;
        }
    }

    /* renamed from: a */
    public int m623a() {
        return this.f506b;
    }

    /* renamed from: b */
    public void m624b() {
        try {
            this.f505a.close();
        } catch (Throwable e) {
            C0166c.m556a(e);
        }
        this.f505a = null;
        this.f506b = 0;
    }
}
