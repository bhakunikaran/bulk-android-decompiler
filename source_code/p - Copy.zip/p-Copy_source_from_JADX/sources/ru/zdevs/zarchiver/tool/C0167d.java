package ru.zdevs.zarchiver.tool;

import android.content.Context;
import android.os.AsyncTask;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.util.zip.CRC32;
import java.util.zip.CheckedInputStream;
import ru.zdevs.zarchiver.fs.ZViewFS.FSFileInfo;
import ru.zdevs.zarchiver.io.C0143a;
import ru.zdevs.zarchiver.p004b.C0073a;
import ru.zdevs.zarchiver.p004b.C0075c;
import ru.zdevs.zarchiver.p004b.C0080h;

/* renamed from: ru.zdevs.zarchiver.tool.d */
public class C0167d {
    /* renamed from: a */
    public static String m560a(File file, AsyncTask<?, ?, ?> asyncTask) {
        if (!file.exists()) {
            return "";
        }
        try {
            MessageDigest instance = MessageDigest.getInstance("MD5");
            InputStream fileInputStream = new FileInputStream(file);
            byte[] bArr = new byte[4096];
            do {
                int read = fileInputStream.read(bArr);
                if (read <= 0 || (asyncTask != null && asyncTask.isCancelled())) {
                    fileInputStream.close();
                    String bigInteger = new BigInteger(1, instance.digest()).toString(16);
                    while (bigInteger.length() < 32) {
                        bigInteger = "0" + bigInteger;
                    }
                    return bigInteger;
                }
                instance.update(bArr, 0, read);
            } while (!Thread.interrupted());
            fileInputStream.close();
            return "";
        } catch (Throwable e) {
            C0166c.m556a(e);
            return "";
        }
    }

    /* renamed from: a */
    public static void m561a(File file, FSFileInfo fSFileInfo, AsyncTask<?, ?, ?> asyncTask) {
        File[] listFiles = file.listFiles();
        if (listFiles != null) {
            int i = 0;
            while (i < listFiles.length) {
                if (asyncTask == null || !asyncTask.isCancelled()) {
                    try {
                        if (C0167d.m565a(listFiles[i])) {
                            i++;
                        }
                    } catch (Throwable e) {
                        C0166c.m556a(e);
                    }
                    if (listFiles[i].isDirectory()) {
                        C0167d.m561a(listFiles[i], fSFileInfo, asyncTask);
                    } else {
                        fSFileInfo.mSize += listFiles[i].length();
                        fSFileInfo.mFileCount++;
                    }
                    i++;
                } else {
                    return;
                }
            }
        }
    }

    /* renamed from: a */
    private static void m562a(File file, boolean z) {
        if (file.isDirectory()) {
            File[] listFiles = file.listFiles();
            if (listFiles != null) {
                for (File a : listFiles) {
                    C0167d.m562a(a, true);
                }
            }
        }
        if (z) {
            file.delete();
        }
    }

    /* renamed from: a */
    public static void m563a(String str) {
        File file = new File(str);
        if (!file.exists() && !file.mkdirs() && C0143a.m433c(str)) {
            C0143a.m431b(file);
        }
    }

    /* renamed from: a */
    public static boolean m564a(Context context, String str, String str2, String str3) {
        File file = new File(str + "/" + str2);
        File file2 = new File(str + "/" + str3);
        if (file2.exists()) {
            return false;
        }
        if (file.exists()) {
            if (file.renameTo(file2)) {
                if (file2.isFile()) {
                    C0182i.m633b(context, file.getAbsolutePath());
                    C0182i.m632a(context, file2.getAbsolutePath());
                } else {
                    C0182i.m631a(context);
                }
            } else if (C0143a.m433c(str)) {
                C0143a.m429a(str, str2, str3);
            }
        }
        return true;
    }

    /* renamed from: a */
    public static boolean m565a(File file) {
        if (file.getParent() != null) {
            file = new File(file.getParentFile().getCanonicalFile(), file.getName());
        }
        return !file.getCanonicalFile().equals(file.getAbsoluteFile());
    }

    /* renamed from: b */
    public static long m566b(File file, AsyncTask<?, ?, ?> asyncTask) {
        long j = 0;
        File[] listFiles = file.listFiles();
        if (listFiles != null) {
            for (int i = 0; i < listFiles.length && (asyncTask == null || !asyncTask.isCancelled()); i++) {
                try {
                    if (C0167d.m565a(listFiles[i])) {
                    }
                } catch (Throwable e) {
                    C0166c.m556a(e);
                }
                j = listFiles[i].isDirectory() ? j + C0167d.m566b(listFiles[i], asyncTask) : j + listFiles[i].length();
            }
        }
        return j;
    }

    /* renamed from: b */
    public static String m567b(String str) {
        try {
            CheckedInputStream checkedInputStream = new CheckedInputStream(new FileInputStream(str), new CRC32());
            try {
                byte[] bArr = new byte[128];
                while (checkedInputStream.read(bArr) >= 0) {
                    if (Thread.interrupted()) {
                        checkedInputStream.close();
                        return "";
                    }
                }
                Long valueOf = Long.valueOf(checkedInputStream.getChecksum().getValue());
                checkedInputStream.close();
                return valueOf.toString();
            } catch (Throwable e) {
                C0166c.m556a(e);
                return "";
            }
        } catch (Throwable e2) {
            C0166c.m556a(e2);
            return "";
        }
    }

    /* renamed from: b */
    public static boolean m568b(Context context, String str, String str2, String str3) {
        File file = new File(str + "/" + str2);
        File file2 = new File(str + "/" + str3);
        if (file2.exists()) {
            return false;
        }
        C0073a c0075c = new C0075c();
        if (c0075c.mo52b()) {
            if (C0080h.m338a(c0075c, true, false, true, true, file.getAbsolutePath(), file2.getAbsolutePath())) {
                c0075c.mo54c();
                if (C0200o.m711a(str) == (byte) 1) {
                    C0182i.m633b(context, file.getAbsolutePath());
                    if (file2.isFile()) {
                        C0182i.m632a(context, file2.getAbsolutePath());
                    } else {
                        C0182i.m631a(context);
                    }
                }
                return true;
            }
            c0075c.mo54c();
            return false;
        }
        c0075c.mo54c();
        return false;
    }

    /* renamed from: c */
    public static void m569c(String str) {
        File file = new File(str);
        if (file.exists()) {
            C0167d.m562a(file, false);
        }
    }
}
