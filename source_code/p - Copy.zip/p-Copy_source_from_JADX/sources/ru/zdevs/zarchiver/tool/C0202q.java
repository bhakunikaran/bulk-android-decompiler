package ru.zdevs.zarchiver.tool;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Environment;
import android.os.Parcelable;
import android.webkit.MimeTypeMap;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import ru.zdevs.zarchiver.R;
import ru.zdevs.zarchiver.ZArchiverExtInterface;
import ru.zdevs.zarchiver.fs.MyUri;
import ru.zdevs.zarchiver.fs.ZFileInfo;

/* renamed from: ru.zdevs.zarchiver.tool.q */
public class C0202q {
    /* renamed from: a */
    public static String f553a = "GB";
    /* renamed from: b */
    public static String f554b = "MB";
    /* renamed from: c */
    public static String f555c = "KB";
    /* renamed from: d */
    public static String f556d = "B";

    /* renamed from: a */
    public static Intent m723a(String str, boolean z) {
        File file = new File(str);
        String c = z ? "*/*" : C0202q.m740c(C0202q.m743d(str));
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.addCategory("android.intent.category.DEFAULT");
        intent.setFlags(536870912);
        intent.setDataAndType(Uri.fromFile(file), c);
        return intent;
    }

    /* renamed from: a */
    public static Bitmap m724a(Resources resources, int i, int i2, int i3) {
        try {
            Bitmap decodeResource = BitmapFactory.decodeResource(resources, i);
            if (decodeResource == null) {
                return null;
            }
            int width = decodeResource.getWidth();
            int height = decodeResource.getHeight();
            float f = (((float) i2) * 1.1f) / ((float) width);
            float f2 = (((float) i3) * 1.1f) / ((float) height);
            if (f > 1.0f && f2 > 1.0f) {
                return decodeResource;
            }
            Matrix matrix = new Matrix();
            matrix.postScale(f, f2);
            return Bitmap.createBitmap(decodeResource, 0, 0, width, height, matrix, true);
        } catch (Throwable e) {
            C0166c.m556a(e);
            return null;
        }
    }

    /* renamed from: a */
    public static Drawable m725a(Context context, int i) {
        try {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(new int[]{i});
            Drawable drawable = obtainStyledAttributes.getDrawable(0);
            obtainStyledAttributes.recycle();
            return drawable;
        } catch (Throwable e) {
            C0166c.m556a(e);
            return null;
        }
    }

    /* renamed from: a */
    public static String m726a(long j) {
        if (j > 1073741824) {
            return String.format(Locale.getDefault(), ((float) j) / 1.07374182E9f >= 100.0f ? "%.1f" : "%.2f", new Object[]{Float.valueOf(((float) j) / 1.07374182E9f)}) + f553a;
        } else if (j > 1048576) {
            return String.format(Locale.getDefault(), ((float) j) / 1048576.0f >= 100.0f ? "%.1f" : "%.2f", new Object[]{Float.valueOf(((float) j) / 1048576.0f)}) + f554b;
        } else if (j > 1024) {
            return String.format(Locale.getDefault(), ((float) j) / 1024.0f >= 100.0f ? "%.1f" : "%.2f", new Object[]{Float.valueOf(((float) j) / 1024.0f)}) + f555c;
        } else {
            return String.format(Locale.getDefault(), "%d ", new Object[]{Long.valueOf(j)}) + f556d;
        }
    }

    /* renamed from: a */
    public static String m727a(Context context) {
        File file = null;
        try {
            file = context.getExternalFilesDir(null);
        } catch (Throwable e) {
            C0166c.m556a(e);
        }
        File file2 = file == null ? new File(Environment.getExternalStorageDirectory(), "/Android/data/ru.zdevs.zarchiver/files") : file;
        try {
            new File(file2, ".nomedia").createNewFile();
        } catch (Throwable e2) {
            C0166c.m556a(e2);
        }
        return file2.getAbsolutePath();
    }

    /* renamed from: a */
    public static String m728a(String str) {
        int lastIndexOf = str.lastIndexOf(46);
        return lastIndexOf > 0 ? str.substring(0, lastIndexOf) : str;
    }

    /* renamed from: a */
    public static ArrayList<Uri> m729a(String[] strArr, String str) {
        ArrayList<Uri> arrayList = new ArrayList();
        for (String file : strArr) {
            File file2 = new File(str, file);
            if (!file2.isDirectory()) {
                arrayList.add(Uri.fromFile(file2));
            }
        }
        return arrayList;
    }

    /* renamed from: a */
    public static ArrayList<Uri> m730a(String[] strArr, MyUri[] myUriArr) {
        ArrayList<Uri> arrayList = new ArrayList();
        for (int i = 0; i < strArr.length; i++) {
            File file = new File(myUriArr[i].toLocalPath(), strArr[i]);
            if (!file.isDirectory()) {
                arrayList.add(Uri.fromFile(file));
            }
        }
        return arrayList;
    }

    /* renamed from: a */
    public static void m731a(Context context, String str) {
        if (context != null) {
            Parcelable fromFile = Uri.fromFile(new File(str));
            try {
                Intent intent = new Intent("android.intent.action.SEND");
                intent.setFlags(268435456);
                intent.setType("*/*");
                intent.putExtra("android.intent.extra.STREAM", fromFile);
                context.startActivity(Intent.createChooser(intent, context.getResources().getString(R.string.MENU_SHARE)));
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
        }
    }

    /* renamed from: a */
    public static void m732a(Context context, ArrayList<Uri> arrayList) {
        if (context != null) {
            try {
                Intent intent = new Intent("android.intent.action.SEND_MULTIPLE");
                intent.setFlags(268435456);
                intent.setType("*/*");
                intent.putParcelableArrayListExtra("android.intent.extra.STREAM", arrayList);
                context.startActivity(Intent.createChooser(intent, context.getResources().getString(R.string.MENU_SHARE)));
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
        }
    }

    /* renamed from: a */
    public static boolean m733a(Context context, Intent intent) {
        return context.getPackageManager().queryIntentActivities(intent, 65536).size() > 0;
    }

    /* renamed from: a */
    public static String[] m734a(String str, char c) {
        List arrayList = new ArrayList();
        int i = 0;
        while (true) {
            int indexOf = str.indexOf(c, i);
            if (indexOf <= -1) {
                break;
            }
            if (i != indexOf) {
                arrayList.add(str.substring(i, indexOf));
            }
            i = indexOf + 1;
        }
        if (i < str.length()) {
            arrayList.add(str.substring(i));
        }
        return (String[]) arrayList.toArray(new String[arrayList.size()]);
    }

    /* renamed from: b */
    public static int m735b(Context context, int i) {
        try {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(new int[]{i});
            int color = obtainStyledAttributes.getColor(0, 0);
            obtainStyledAttributes.recycle();
            return color;
        } catch (Throwable e) {
            C0166c.m556a(e);
            return 0;
        }
    }

    /* renamed from: b */
    public static String m736b(long j) {
        if (j > 1073741824) {
            return String.format(Locale.getDefault(), "%.2f", new Object[]{Float.valueOf(((float) j) / 1.07374182E9f)}) + f553a;
        } else if (j > 1048576) {
            return String.format(Locale.getDefault(), "%.2f", new Object[]{Float.valueOf(((float) j) / 1048576.0f)}) + f554b;
        } else if (j > 1024) {
            return String.format(Locale.getDefault(), "%.2f", new Object[]{Float.valueOf(((float) j) / 1024.0f)}) + f555c;
        } else {
            return String.format(Locale.getDefault(), "%d ", new Object[]{Long.valueOf(j)}) + f556d;
        }
    }

    /* renamed from: b */
    public static String m737b(String str) {
        String toLowerCase = str.toLowerCase(Locale.US);
        String str2 = str;
        while (str2.lastIndexOf(46) > 0) {
            try {
                String substring;
                Object obj;
                Object obj2;
                for (String str3 : ZFileInfo.ssExtArchive) {
                    if (toLowerCase.endsWith(str3)) {
                        substring = str2.substring(0, str2.length() - str3.length());
                        toLowerCase = toLowerCase.substring(0, toLowerCase.length() - str3.length());
                        obj = 1;
                        break;
                    }
                }
                substring = str2;
                obj = null;
                for (String str4 : ZFileInfo.ssExtApk) {
                    if (toLowerCase.endsWith(str4)) {
                        substring = substring.substring(0, substring.length() - str4.length());
                        str2 = toLowerCase.substring(0, toLowerCase.length() - str4.length());
                        obj2 = 1;
                        String str5 = str2;
                        str2 = substring;
                        substring = str5;
                        break;
                    }
                }
                Object obj3 = obj;
                str2 = substring;
                substring = toLowerCase;
                obj2 = obj3;
                if (obj2 == null) {
                    return str2;
                }
                toLowerCase = substring;
            } catch (Throwable e) {
                C0166c.m556a(e);
                return str;
            }
        }
        return str2;
    }

    /* renamed from: b */
    public static void m738b(Context context) {
        C0166c.m559d("Tool", "clearTempDir!");
        C0167d.m569c(C0202q.m727a(context));
    }

    /* renamed from: b */
    public static boolean m739b(Context context, String str) {
        File file = new File(str);
        String c = C0202q.m740c(C0202q.m743d(str));
        try {
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.addCategory("android.intent.category.DEFAULT");
            intent.setFlags(268435456);
            intent.setDataAndType(Uri.fromFile(file), c);
            intent.putExtra("isZA", true);
            context.startActivity(intent);
            return true;
        } catch (ActivityNotFoundException e) {
            return C0202q.m742c(context, str);
        } catch (Throwable e2) {
            C0166c.m556a(e2);
            return false;
        }
    }

    /* renamed from: c */
    public static String m740c(String str) {
        String toLowerCase = str.toLowerCase(Locale.US);
        String mimeTypeFromExtension = MimeTypeMap.getSingleton().getMimeTypeFromExtension(toLowerCase);
        return mimeTypeFromExtension == null ? toLowerCase.equals(ZArchiverExtInterface.ARCHIVE_TYPE_7Z) ? "application/x-7z-compressed" : toLowerCase.equals("bz2") ? "application/x-bzip2" : toLowerCase.equals("gz") ? "application/x-gzip" : toLowerCase.equals("xz") ? "application/x-xz" : toLowerCase.equals("lz4") ? "application/x-lz4" : toLowerCase.equals("docx") ? "application/msword" : "*/*" : mimeTypeFromExtension;
    }

    /* renamed from: c */
    public static void m741c(Context context) {
        Resources resources = context.getResources();
        if (resources != null) {
            f553a = resources.getString(R.string.INFO_GB);
            f554b = resources.getString(R.string.INFO_MB);
            f555c = resources.getString(R.string.INFO_KB);
            f556d = resources.getString(R.string.INFO_B);
        }
    }

    /* renamed from: c */
    public static boolean m742c(Context context, String str) {
        File file = new File(str);
        try {
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.setFlags(268435456);
            intent.setDataAndType(Uri.fromFile(file), "*/*");
            intent.putExtra("isZA", true);
            context.startActivity(intent);
            return true;
        } catch (Throwable e) {
            C0166c.m556a(e);
            return false;
        }
    }

    /* renamed from: d */
    public static String m743d(String str) {
        if (str != null && str.contains(".")) {
            int lastIndexOf = str.lastIndexOf(46);
            if (str.length() > lastIndexOf + 1) {
                return str.substring(lastIndexOf + 1).toLowerCase(Locale.ENGLISH);
            }
        }
        return "";
    }

    /* renamed from: e */
    public static String[] m744e(String str) {
        List arrayList = new ArrayList();
        int i = 0;
        while (true) {
            int indexOf = str.indexOf(47, i);
            if (indexOf <= -1) {
                break;
            }
            if (i != indexOf) {
                arrayList.add(str.substring(i, indexOf));
            }
            i = indexOf + 1;
        }
        if (i < str.length()) {
            arrayList.add(str.substring(i));
        }
        return (String[]) arrayList.toArray(new String[arrayList.size()]);
    }
}
