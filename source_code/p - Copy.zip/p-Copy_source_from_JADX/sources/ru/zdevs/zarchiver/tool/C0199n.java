package ru.zdevs.zarchiver.tool;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build.VERSION;
import android.os.Environment;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import android.util.Log;
import java.io.File;
import java.io.FileNotFoundException;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;
import ru.zdevs.zarchiver.fs.FSStorage;

/* renamed from: ru.zdevs.zarchiver.tool.n */
public class C0199n {
    /* renamed from: a */
    private static int f548a = 0;
    /* renamed from: b */
    private static C0198a f549b = null;
    /* renamed from: c */
    private static List<C0198a> f550c = new ArrayList();
    /* renamed from: d */
    private static List<String> f551d = new ArrayList();
    /* renamed from: e */
    private static List<String> f552e = null;

    /* renamed from: ru.zdevs.zarchiver.tool.n$a */
    public static final class C0198a {
        /* renamed from: a */
        public String f541a;
        /* renamed from: b */
        public String f542b;
        /* renamed from: c */
        public String f543c;
        /* renamed from: d */
        public byte f544d;
        /* renamed from: e */
        public byte f545e;
        /* renamed from: f */
        public Object f546f;
        /* renamed from: g */
        private byte f547g;

        private C0198a(String str, byte b, byte b2) {
            this.f541a = null;
            this.f542b = str;
            this.f543c = null;
            this.f544d = b;
            this.f545e = b2;
            this.f546f = null;
            this.f547g = (byte) 0;
        }

        /* renamed from: a */
        public boolean m684a() {
            return (this.f547g & 1) == 1;
        }

        /* renamed from: b */
        public boolean m685b() {
            return (this.f547g & 2) == 2;
        }
    }

    /* renamed from: a */
    private static int m686a(int i) {
        if (i == 0) {
            return f550c.size();
        }
        int i2 = 0;
        for (C0198a a : f550c) {
            i2 = (a.f547g & i) == i ? i2 + 1 : i2;
        }
        return i2;
    }

    /* renamed from: a */
    private static Method m687a(Class<?> cls, String str) {
        Method method = null;
        try {
            method = cls.getMethod(str, new Class[0]);
        } catch (NoSuchMethodException e) {
            C0166c.m557b("StorageList", "Method not found: " + str);
        } catch (SecurityException e2) {
            C0166c.m557b("StorageList", "Fail to get method: " + str);
        }
        return method;
    }

    /* renamed from: a */
    private static List<String> m688a(List<String> list) {
        ArrayList arrayList = new ArrayList();
        try {
            Scanner scanner = new Scanner(new File("/system/etc/vold.fstab"));
            while (scanner.hasNext()) {
                String nextLine = scanner.nextLine();
                if (nextLine.startsWith("dev_mount")) {
                    String[] a = C0202q.m734a(nextLine, ' ');
                    if (a.length < 2) {
                        a = C0202q.m734a(nextLine, '\t');
                    }
                    if (a.length >= 2) {
                        Object obj = a[2];
                        if (obj.contains(":")) {
                            obj = obj.substring(0, obj.indexOf(58));
                        }
                        arrayList.add(obj);
                    }
                }
            }
            scanner.close();
        } catch (FileNotFoundException e) {
        } catch (Exception e2) {
            Log.e("StorageList", e2.getMessage() + ": unknown exception while reading mounts file");
        }
        int i = 0;
        while (i < list.size()) {
            String str = (String) list.get(i);
            if (!(arrayList.contains(str) || str.equals("/storage/sdcard0"))) {
                int i2 = i - 1;
                list.remove(i);
                i = i2;
            }
            i++;
        }
        return list;
    }

    /* renamed from: a */
    public static C0198a m689a() {
        return f549b;
    }

    /* renamed from: a */
    public static C0198a m690a(String str) {
        if (str == null) {
            return null;
        }
        for (C0198a c0198a : f550c) {
            if (c0198a.f542b != null && c0198a.f542b.equals(str)) {
                return c0198a;
            }
        }
        return null;
    }

    @TargetApi(24)
    /* renamed from: a */
    private static void m691a(Context context) {
        try {
            Method a = C0199n.m687a(Class.forName("android.os.storage.StorageVolume"), "getPath");
            if (a == null) {
                C0166c.m557b("StorageList", "StorageVolume class is incompletely!");
                return;
            }
            StorageManager storageManager = (StorageManager) context.getSystemService(FSStorage.SCHEME);
            if (storageManager == null) {
                C0166c.m557b("StorageList", "StorageManager don't available!");
                return;
            }
            for (StorageVolume storageVolume : storageManager.getStorageVolumes()) {
                if (storageVolume != null) {
                    String state = storageVolume.getState();
                    if (state == null || "mounted".equals(state) || "mounted_ro".equals(state)) {
                        state = (String) a.invoke(storageVolume, new Object[0]);
                        if (state != null) {
                            byte b = storageVolume.isRemovable() ? (byte) 2 : (byte) 1;
                            String format = state.startsWith("/mnt/media_rw") ? String.format(Locale.ENGLISH, "/SAF/%s", new Object[]{storageVolume.getUuid()}) : state;
                            C0198a a2 = C0199n.m690a(format);
                            if (a2 == null) {
                                a2 = new C0198a(format, b, (byte) 4);
                                f550c.add(a2);
                            } else {
                                a2.f545e = (byte) 4;
                            }
                            if (b == (byte) 2) {
                                a2.f547g = (byte) (a2.f547g | 2);
                            }
                            a2.f543c = storageVolume.getUuid();
                            a2.f546f = storageVolume;
                            if (storageVolume.isPrimary() && C0199n.m686a(1) <= 0) {
                                a2.f547g = (byte) (a2.f547g | 1);
                            }
                        }
                    }
                }
            }
        } catch (Throwable e) {
            C0166c.m556a(e);
        }
    }

    /* renamed from: a */
    public static void m692a(Context context, int i) {
        f548a = i;
        f549b = null;
        f550c.clear();
        if ((i & 1) != 0 && VERSION.SDK_INT < 19) {
            List c = C0199n.m700c();
            if (VERSION.SDK_INT < 18) {
                c = C0199n.m688a(c);
            }
            C0199n.m698b(c);
            C0199n.m703c(c);
        }
        if ((i & 2) != 0 && VERSION.SDK_INT >= 19 && VERSION.SDK_INT < 24) {
            C0199n.m706d(context);
        }
        if ((i & 4) != 0 && VERSION.SDK_INT >= 19) {
            if (VERSION.SDK_INT < 24) {
                C0199n.m697b(context);
            } else {
                C0199n.m691a(context);
            }
        }
        if ((i & 8) != 0 && VERSION.SDK_INT >= 23) {
            C0199n.m701c(context);
        }
        for (C0198a c0198a : f550c) {
            if (c0198a.m684a()) {
                f549b = c0198a;
                break;
            }
        }
        if (f549b == null) {
            if (f550c.size() > 0) {
                f549b = (C0198a) f550c.get(0);
            } else {
                f549b = new C0198a(Environment.getExternalStorageDirectory().getPath(), (byte) 0, (byte) 1);
            }
        }
        Log.i("StorageList", "Found " + f550c.size() + " storage");
    }

    /* renamed from: b */
    private static String m693b() {
        try {
            return Environment.getExternalStorageDirectory().getCanonicalPath();
        } catch (Exception e) {
            return "/mnt/sdcard";
        }
    }

    /* renamed from: b */
    private static Field m694b(Class<?> cls, String str) {
        Field field = null;
        try {
            field = cls.getField(str);
        } catch (NoSuchFieldException e) {
            C0166c.m557b("StorageList", "Field not found: " + str);
        } catch (SecurityException e2) {
            C0166c.m557b("StorageList", "Fail to get field: " + str);
        }
        return field;
    }

    /* renamed from: b */
    public static List<C0198a> m695b(Context context, int i) {
        if ((f548a & i) != i) {
            C0199n.m692a(context, i);
        }
        if (i == 255) {
            return f550c;
        }
        List<C0198a> arrayList = new ArrayList();
        for (C0198a c0198a : f550c) {
            if ((c0198a.f545e & i) != 0) {
                arrayList.add(c0198a);
            }
        }
        return arrayList;
    }

    /* renamed from: b */
    public static C0198a m696b(String str) {
        if (str == null) {
            return null;
        }
        for (C0198a c0198a : f550c) {
            if (c0198a.f543c != null && c0198a.f543c.equals(str)) {
                return c0198a;
            }
        }
        return null;
    }

    /* renamed from: b */
    private static void m697b(Context context) {
        try {
            StorageManager storageManager = (StorageManager) context.getSystemService(FSStorage.SCHEME);
            if (storageManager == null) {
                C0166c.m557b("StorageList", "StorageManager don't available!");
                return;
            }
            Class cls = Class.forName("android.os.storage.StorageVolume");
            Method a = C0199n.m687a(storageManager.getClass(), "getVolumeList");
            Method a2 = C0199n.m687a(cls, "getPath");
            Method a3 = C0199n.m687a(cls, "getUuid");
            Method a4 = C0199n.m687a(cls, "getState");
            Method a5 = C0199n.m687a(cls, "isPrimary");
            Method a6 = C0199n.m687a(cls, "isRemovable");
            Method a7 = C0199n.m687a(cls, "getUserLabel");
            if (a == null || a2 == null) {
                C0166c.m557b("StorageList", "StorageVolume class is incompletely!");
                return;
            }
            Object invoke = a.invoke(storageManager, new Object[0]);
            int length = Array.getLength(invoke);
            for (int i = 0; i < length; i++) {
                Object obj = Array.get(invoke, i);
                if (obj != null) {
                    String str;
                    if (a4 != null) {
                        str = (String) a4.invoke(obj, new Object[0]);
                        if (!(str == null || "mounted".equals(str) || "mounted_ro".equals(str))) {
                        }
                    }
                    str = (String) a2.invoke(obj, new Object[0]);
                    if (str != null) {
                        byte b = (byte) 2;
                        if (a6 != null) {
                            Boolean bool = (Boolean) a6.invoke(obj, new Object[0]);
                            if (!(bool == null || bool.booleanValue())) {
                                b = (byte) 1;
                            }
                        }
                        C0198a a8 = C0199n.m690a(str);
                        if (a8 == null) {
                            a8 = new C0198a(str, b, (byte) 4);
                            f550c.add(a8);
                        } else {
                            a8.f545e = (byte) 4;
                        }
                        if (b == (byte) 2) {
                            a8.f547g = (byte) (a8.f547g | 2);
                        }
                        if (a7 != null) {
                            a8.f541a = (String) a7.invoke(obj, new Object[0]);
                        }
                        if (a3 != null) {
                            a8.f543c = (String) a3.invoke(obj, new Object[0]);
                        }
                        a8.f546f = obj;
                        if (a5 != null) {
                            Boolean bool2 = (Boolean) a5.invoke(obj, new Object[0]);
                            if (bool2 != null && bool2.booleanValue() && C0199n.m686a(1) <= 0) {
                                a8.f547g = (byte) (a8.f547g | 1);
                            }
                        }
                    }
                }
            }
        } catch (Throwable e) {
            C0166c.m556a(e);
        }
    }

    /* renamed from: b */
    private static void m698b(List<String> list) {
        int i;
        Throwable th;
        int i2 = 0;
        if (VERSION.SDK_INT >= 18) {
            i = 0;
            while (i < list.size()) {
                String str = (String) list.get(i);
                if (str.contains("legacy") || str.contains("/obb")) {
                    int i3 = i - 1;
                    list.remove(i);
                    i = i3;
                }
                i++;
            }
        }
        i = VERSION.SDK_INT >= 19 ? 1 : 0;
        while (i2 < list.size()) {
            File file = new File((String) list.get(i2));
            try {
                if (file.exists() && file.isDirectory() && ((r1 != 0 || file.canWrite()) && !f551d.contains(file.getCanonicalPath()))) {
                    i2++;
                } else {
                    i3 = i2 - 1;
                    try {
                        list.remove(i2);
                        i2 = i3;
                    } catch (Throwable e) {
                        Throwable th2 = e;
                        i2 = i3;
                        th = th2;
                        C0166c.m556a(th);
                        i2++;
                    }
                    i2++;
                }
            } catch (Exception e2) {
                th = e2;
                C0166c.m556a(th);
                i2++;
            }
        }
        f551d.clear();
    }

    /* renamed from: c */
    public static int m699c(Context context, int i) {
        if (f548a != 255) {
            C0199n.m692a(context, 255);
        }
        return C0199n.m686a(i);
    }

    /* renamed from: c */
    private static ArrayList<String> m700c() {
        Object obj;
        Exception e;
        Collection arrayList = new ArrayList();
        ArrayList<String> arrayList2 = new ArrayList();
        try {
            Scanner scanner = new Scanner(new File("/proc/mounts"));
            int i = 0;
            obj = null;
            while (scanner.hasNextLine() && i < 1000) {
                try {
                    Object obj2;
                    int i2 = i + 1;
                    String nextLine = scanner.nextLine();
                    if (nextLine.startsWith("/dev/fuse")) {
                        obj2 = null;
                        obj = 1;
                    } else if (nextLine.startsWith("/dev/block/vold/")) {
                        int i3 = 1;
                    } else {
                        i = i2;
                    }
                    String[] a = C0202q.m734a(nextLine, ' ');
                    if (a.length < 2) {
                        a = C0202q.m734a(nextLine, '\t');
                    }
                    if (a.length < 2) {
                        i = i2;
                    } else {
                        if (obj2 == null) {
                            arrayList2.add(a[1]);
                        } else {
                            arrayList.add(a[1]);
                        }
                        i = i2;
                    }
                } catch (Exception e2) {
                    e = e2;
                }
            }
            scanner.close();
        } catch (Exception e3) {
            e = e3;
            obj = null;
            Log.e("StorageList", e.getMessage() + ": unknown exception while reading mounts file");
            if (obj == null) {
                arrayList2.addAll(arrayList);
            }
            return arrayList2;
        }
        if (obj == null) {
            arrayList2.addAll(arrayList);
        }
        return arrayList2;
    }

    /* renamed from: c */
    private static void m701c(Context context) {
        try {
            StorageManager storageManager = (StorageManager) context.getSystemService(FSStorage.SCHEME);
            if (storageManager == null) {
                C0166c.m557b("StorageList", "StorageManager don't available!");
                return;
            }
            Class cls = Class.forName("android.os.storage.DiskInfo");
            Method method = storageManager.getClass().getMethod("getDisks", new Class[0]);
            Method a = C0199n.m687a(cls, "getId");
            Method a2 = C0199n.m687a(cls, "isUsb");
            Field b = C0199n.m694b(cls, "label");
            if (a == null || a2 == null) {
                C0166c.m557b("StorageList", "DiskInfo class is incompletely!");
                return;
            }
            List list = (List) method.invoke(storageManager, new Object[0]);
            for (int i = 0; i < list.size(); i++) {
                Object obj = list.get(i);
                if (obj != null) {
                    Boolean bool = (Boolean) a2.invoke(obj, new Object[0]);
                    if (bool != null && bool.booleanValue()) {
                        String str = (String) a.invoke(obj, new Object[0]);
                        if (str != null) {
                            String d = C0199n.m705d(str);
                            if (d != null) {
                                C0198a c0198a;
                                C0198a b2 = C0199n.m696b(d);
                                if (b2 == null) {
                                    b2 = new C0198a(String.format(Locale.ENGLISH, "/SAF/%s", new Object[]{d}), (byte) 4, (byte) 8);
                                    b2.f543c = d;
                                    f550c.add(b2);
                                    c0198a = b2;
                                } else {
                                    b2.f544d = (byte) 4;
                                    c0198a = b2;
                                }
                                if (c0198a.f541a == null && b != null) {
                                    c0198a.f541a = (String) b.get(obj);
                                }
                                c0198a.f547g = (byte) (c0198a.f547g | 2);
                            }
                        }
                    }
                }
            }
            C0199n.m705d(null);
        } catch (Throwable e) {
            C0166c.m556a(e);
        }
    }

    /* renamed from: c */
    public static void m702c(String str) {
        C0198a a = C0199n.m690a(str);
        if (a != null) {
            f550c.remove(a);
        }
    }

    /* renamed from: c */
    private static void m703c(List<String> list) {
        String b = C0199n.m693b();
        for (String str : list) {
            byte d;
            boolean equals = b.equals(str);
            if (equals) {
                d = VERSION.SDK_INT < 21 ? C0199n.m704d() : C0199n.m707e(str);
            } else if (VERSION.SDK_INT < 21) {
                String toLowerCase = str.toLowerCase(Locale.ENGLISH);
                d = (toLowerCase.contains("usb") || toLowerCase.contains("udisk")) ? (byte) 4 : (byte) 2;
            } else {
                d = C0199n.m707e(str);
            }
            C0198a c0198a = new C0198a(str, d, (byte) 1);
            if (equals) {
                c0198a.f547g = (byte) (c0198a.f547g | 1);
            }
            f550c.add(c0198a);
        }
    }

    /* renamed from: d */
    private static byte m704d() {
        return (!Environment.isExternalStorageRemovable() || Environment.isExternalStorageEmulated()) ? (byte) 1 : (byte) 2;
    }

    /* renamed from: d */
    private static String m705d(String str) {
        String str2 = null;
        if (str == null) {
            f552e = null;
        } else {
            String str3 = "/dev/block/vold/public" + str.substring(str.indexOf(58), str.length() - 1);
            if (f552e == null) {
                f552e = new ArrayList();
                int i = 0;
                try {
                    Scanner scanner = new Scanner(new File("/proc/mounts"));
                    while (scanner.hasNextLine() && i < 1000) {
                        i++;
                        String nextLine = scanner.nextLine();
                        if (nextLine.startsWith("/dev/block/vold/public")) {
                            f552e.add(nextLine);
                        }
                    }
                    scanner.close();
                } catch (Throwable e) {
                    C0166c.m556a(e);
                }
            }
            for (String str4 : f552e) {
                String str42;
                if (str42.startsWith(str3)) {
                    int indexOf = str42.indexOf("/mnt/media_rw/");
                    if (indexOf < 0) {
                        break;
                    }
                    indexOf += "/mnt/media_rw/".length();
                    int indexOf2 = str42.indexOf(32, indexOf);
                    if (indexOf2 < 0) {
                        indexOf2 = str42.indexOf(9, indexOf);
                    }
                    if (indexOf2 < 0) {
                        indexOf2 = indexOf + 9;
                    }
                    str42 = str42.substring(indexOf, indexOf2);
                } else {
                    str42 = str2;
                }
                str2 = str42;
            }
        }
        return str2;
    }

    @TargetApi(19)
    /* renamed from: d */
    private static void m706d(Context context) {
        String b = C0199n.m693b();
        File[] externalFilesDirs = context.getExternalFilesDirs(null);
        if (externalFilesDirs != null) {
            for (File file : externalFilesDirs) {
                if (file != null) {
                    String absolutePath = file.getAbsolutePath();
                    if (absolutePath.contains("/Android")) {
                        absolutePath = absolutePath.substring(0, absolutePath.indexOf("/Android"));
                    }
                    C0198a a = C0199n.m690a(absolutePath);
                    if (a == null) {
                        a = new C0198a(absolutePath, (byte) 2, (byte) 2);
                        f550c.add(a);
                    }
                    if (VERSION.SDK_INT >= 21) {
                        a.f544d = C0199n.m707e(absolutePath);
                    } else if (b.equals(absolutePath)) {
                        a.f544d = C0199n.m704d();
                    }
                }
            }
        }
    }

    @TargetApi(21)
    /* renamed from: e */
    private static byte m707e(String str) {
        try {
            if (!Environment.isExternalStorageRemovable(new File(str))) {
                return (byte) 1;
            }
        } catch (IllegalArgumentException e) {
            Log.w("StorageList", "Bad path: " + str);
        }
        return (byte) 2;
    }
}
