package ru.zdevs.zarchiver.p003a;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import ru.zdevs.zarchiver.R;

/* renamed from: ru.zdevs.zarchiver.a.k */
public class C0055k extends BaseAdapter {
    /* renamed from: a */
    private final LayoutInflater f167a;
    /* renamed from: b */
    private List<String> f168b = new ArrayList();
    /* renamed from: c */
    private List<Boolean> f169c = new ArrayList();

    public C0055k(Context context) {
        this.f167a = (LayoutInflater) context.getSystemService("layout_inflater");
    }

    /* renamed from: a */
    public void m137a() {
        this.f168b.clear();
        this.f169c.clear();
    }

    /* renamed from: a */
    public void m138a(int i, boolean z) {
        if (i < this.f169c.size()) {
            this.f169c.set(i, Boolean.valueOf(z));
        }
    }

    /* renamed from: a */
    public void m139a(String str) {
        this.f168b.add(str);
        this.f169c.add(Boolean.valueOf(true));
    }

    public int getCount() {
        return this.f168b.size();
    }

    public Object getItem(int i) {
        return this.f168b.get(i);
    }

    public long getItemId(int i) {
        return (long) i;
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        View inflate = view == null ? this.f167a.inflate(R.layout.item_select_dialog_singlechoice, viewGroup, false) : view;
        ((TextView) inflate).setText((CharSequence) this.f168b.get(i));
        inflate.setEnabled(isEnabled(i));
        return inflate;
    }

    public boolean isEnabled(int i) {
        return ((Boolean) this.f169c.get(i)).booleanValue();
    }
}
