package ru.zdevs.zarchiver.p003a;

/* renamed from: ru.zdevs.zarchiver.a.i */
public interface C0048i {
    /* renamed from: a */
    boolean mo27a();

    /* renamed from: e */
    String mo28e();

    /* renamed from: h */
    byte mo29h();
}
