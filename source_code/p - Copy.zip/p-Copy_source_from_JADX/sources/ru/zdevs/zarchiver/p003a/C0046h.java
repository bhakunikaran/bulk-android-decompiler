package ru.zdevs.zarchiver.p003a;

import ru.zdevs.zarchiver.p003a.C0047d.C0031a;

/* renamed from: ru.zdevs.zarchiver.a.h */
public interface C0046h {
    /* renamed from: a */
    void mo13a(int i);

    /* renamed from: a */
    void mo14a(C0031a c0031a);

    /* renamed from: a */
    void mo15a(boolean z);

    /* renamed from: b */
    int mo16b();

    /* renamed from: b */
    C0048i mo17b(int i);

    /* renamed from: b */
    void mo18b(boolean z);

    /* renamed from: c */
    void mo19c();

    /* renamed from: c */
    void mo20c(int i);

    /* renamed from: d */
    void mo21d();

    /* renamed from: e */
    void mo22e();

    /* renamed from: f */
    int[] mo23f();

    /* renamed from: g */
    void mo24g();

    int getCount();

    /* renamed from: i */
    byte mo26i();
}
