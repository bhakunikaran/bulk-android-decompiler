package ru.zdevs.zarchiver.p003a;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import ru.zdevs.zarchiver.R;
import ru.zdevs.zarchiver.tool.C0169f;
import ru.zdevs.zarchiver.tool.C0202q;

/* renamed from: ru.zdevs.zarchiver.a.b */
public class C0043b extends BaseAdapter {
    /* renamed from: a */
    private final LayoutInflater f108a;
    /* renamed from: b */
    private final Context f109b;
    /* renamed from: c */
    private boolean f110c;
    /* renamed from: d */
    private List<C0044c> f111d;

    /* renamed from: ru.zdevs.zarchiver.a.b$a */
    static class C0042a {
        /* renamed from: a */
        protected TextView f104a;
        /* renamed from: b */
        protected ImageView f105b;
        /* renamed from: c */
        protected TextView f106c;
        /* renamed from: d */
        protected TextView f107d;

        C0042a() {
        }
    }

    public C0043b(Context context) {
        this.f109b = context;
        this.f108a = (LayoutInflater) context.getSystemService("layout_inflater");
        this.f110c = false;
        this.f111d = new ArrayList();
    }

    public C0043b(Context context, boolean z) {
        this.f109b = context;
        this.f108a = (LayoutInflater) context.getSystemService("layout_inflater");
        this.f110c = z;
        this.f111d = new ArrayList();
    }

    /* renamed from: b */
    private Drawable m67b(int i) {
        return VERSION.SDK_INT < 21 ? this.f109b.getResources().getDrawable(i) : this.f109b.getDrawable(i);
    }

    /* renamed from: a */
    public C0044c m68a(int i) {
        return (C0044c) this.f111d.get(i);
    }

    /* renamed from: a */
    public void m69a(List<C0044c> list) {
        this.f111d = list;
        for (C0044c c0044c : this.f111d) {
            c0044c.f115d = "";
            if (c0044c.f116e) {
                File file = new File(c0044c.f114c.toViewString());
                if (file.exists()) {
                    c0044c.f115d = C0202q.m736b(file.getFreeSpace()) + "/\n" + C0202q.m736b(file.getTotalSpace());
                }
            }
        }
    }

    public int getCount() {
        return this.f111d.size();
    }

    public /* synthetic */ Object getItem(int i) {
        return m68a(i);
    }

    public long getItemId(int i) {
        return (long) i;
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        C0044c a = m68a(i);
        if (view == null) {
            view = this.f108a.inflate(R.layout.item_favorite, viewGroup, false);
            C0042a c0042a = new C0042a();
            c0042a.f104a = (TextView) view.findViewById(R.id.text);
            c0042a.f106c = (TextView) view.findViewById(R.id.desc);
            c0042a.f107d = (TextView) view.findViewById(R.id.mark);
            c0042a.f105b = (ImageView) view.findViewById(R.id.icon);
            view.setTag(c0042a);
        }
        C0042a c0042a2 = (C0042a) view.getTag();
        c0042a2.f104a.setText(a.f113b);
        c0042a2.f105b.setImageDrawable(m67b(C0169f.m574a(a.f112a)));
        c0042a2.f106c.setText(a.f114c.toViewString());
        if (this.f110c) {
            c0042a2.f107d.setText(a.f115d);
        }
        return view;
    }
}
