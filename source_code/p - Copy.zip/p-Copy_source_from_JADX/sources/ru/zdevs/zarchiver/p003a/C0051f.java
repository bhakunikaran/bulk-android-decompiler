package ru.zdevs.zarchiver.p003a;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import ru.zdevs.zarchiver.R;
import ru.zdevs.zarchiver.p003a.C0047d.C0031a;
import ru.zdevs.zarchiver.settings.Settings;
import ru.zdevs.zarchiver.tool.C0166c;
import ru.zdevs.zarchiver.tool.C0169f;
import ru.zdevs.zarchiver.tool.C0178g;
import ru.zdevs.zarchiver.tool.C0202q;

/* renamed from: ru.zdevs.zarchiver.a.f */
public class C0051f extends BaseAdapter implements OnClickListener, C0046h {
    /* renamed from: a */
    private static C0178g f153a;
    /* renamed from: b */
    private final LayoutInflater f154b;
    /* renamed from: c */
    private List<C0052g> f155c = new ArrayList();
    /* renamed from: d */
    private int f156d = 0;
    /* renamed from: e */
    private int f157e;
    /* renamed from: f */
    private int f158f;
    /* renamed from: g */
    private int f159g;
    /* renamed from: h */
    private boolean f160h;
    /* renamed from: i */
    private C0031a f161i;

    /* renamed from: ru.zdevs.zarchiver.a.f$a */
    static class C0050a {
        /* renamed from: a */
        protected TextView f148a;
        /* renamed from: b */
        protected ImageView f149b;
        /* renamed from: c */
        protected TextView f150c;
        /* renamed from: d */
        protected TextView f151d;
        /* renamed from: e */
        protected View f152e;

        C0050a() {
        }
    }

    public C0051f(Context context) {
        this.f154b = (LayoutInflater) context.getSystemService("layout_inflater");
        this.f157e = C0202q.m735b(context, (int) R.attr.defaultTextColorFileList);
        this.f158f = -1;
        this.f159g = C0202q.m735b(context, (int) R.attr.colorPrimary);
        this.f160h = false;
    }

    /* renamed from: a */
    public static void m117a(C0178g c0178g) {
        f153a = c0178g;
    }

    /* renamed from: a */
    public void mo13a(int i) {
        this.f159g = i;
    }

    /* renamed from: a */
    public void m119a(List<C0052g> list) {
        synchronized (this.f155c) {
            this.f155c = list;
            this.f156d = 0;
            for (C0052g a : this.f155c) {
                if (a.mo27a()) {
                    this.f156d++;
                }
            }
        }
    }

    /* renamed from: a */
    public void mo14a(C0031a c0031a) {
        this.f161i = c0031a;
    }

    /* renamed from: a */
    public void m121a(C0052g c0052g) {
        synchronized (this.f155c) {
            this.f155c.add(c0052g);
        }
    }

    /* renamed from: a */
    public void mo15a(boolean z) {
    }

    /* renamed from: b */
    public int mo16b() {
        return this.f156d;
    }

    /* renamed from: b */
    public C0048i mo17b(int i) {
        C0052g c0052g;
        synchronized (this.f155c) {
            c0052g = (C0052g) this.f155c.get(i);
        }
        return c0052g;
    }

    /* renamed from: b */
    public void mo18b(boolean z) {
        this.f160h = z;
    }

    /* renamed from: c */
    public void mo19c() {
        boolean z = this.f156d > 0;
        synchronized (this.f155c) {
            for (C0052g c0052g : this.f155c) {
                if (c0052g.mo27a()) {
                    c0052g.m105a(false);
                }
            }
        }
        this.f156d = 0;
        if (!(this.f161i == null || z)) {
            this.f161i.onSelectItemChange(false, 0);
        }
        notifyDataSetChanged();
    }

    /* renamed from: c */
    public void mo20c(int i) {
        try {
            C0052g c0052g = (C0052g) this.f155c.get(i);
            if (c0052g != null) {
                if (c0052g.mo27a()) {
                    this.f156d--;
                } else {
                    this.f156d++;
                }
                c0052g.m105a(!c0052g.mo27a());
                if (this.f161i != null) {
                    this.f161i.onSelectItemChange(c0052g.mo27a(), this.f156d);
                }
                notifyDataSetChanged();
            }
        } catch (Throwable e) {
            C0166c.m556a(e);
        }
    }

    /* renamed from: d */
    public void mo21d() {
        boolean z = this.f156d > 0;
        synchronized (this.f155c) {
            for (C0052g a : this.f155c) {
                a.m105a(true);
            }
            this.f156d = this.f155c.size();
        }
        if (!(this.f161i == null || z)) {
            this.f161i.onSelectItemChange(true, 1);
        }
        notifyDataSetChanged();
    }

    /* renamed from: e */
    public void mo22e() {
        int i = 0;
        int i2 = this.f156d > 0 ? 1 : 0;
        this.f156d = 0;
        synchronized (this.f155c) {
            for (C0052g c0052g : this.f155c) {
                c0052g.m105a(!c0052g.mo27a());
                if (c0052g.mo27a()) {
                    this.f156d++;
                }
            }
        }
        if (this.f161i != null) {
            if (i2 != (this.f156d > 0 ? 1 : 0)) {
                C0031a c0031a = this.f161i;
                boolean z = i2 == 0;
                if (i2 == 0) {
                    i = 1;
                }
                c0031a.onSelectItemChange(z, i);
            }
        }
        notifyDataSetChanged();
    }

    /* renamed from: f */
    public int[] mo23f() {
        int[] iArr = new int[this.f156d];
        synchronized (this.f155c) {
            int size = this.f155c.size();
            int i = 0;
            int i2 = 0;
            while (i < size) {
                int i3;
                if (((C0052g) this.f155c.get(i)).mo27a()) {
                    iArr[i2] = i;
                    i3 = i2 + 1;
                } else {
                    i3 = i2;
                }
                i++;
                i2 = i3;
            }
        }
        return iArr;
    }

    /* renamed from: g */
    public void mo24g() {
        notifyDataSetChanged();
    }

    public int getCount() {
        int size;
        synchronized (this.f155c) {
            size = this.f155c.size();
        }
        return size;
    }

    public /* synthetic */ Object getItem(int i) {
        return mo17b(i);
    }

    public long getItemId(int i) {
        return (long) i;
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        C0052g c0052g = (C0052g) mo17b(i);
        if (view == null) {
            view = this.f154b.inflate(R.layout.item_find, viewGroup, false);
            C0050a c0050a = new C0050a();
            c0050a.f152e = view;
            c0050a.f148a = (TextView) view.findViewById(R.id.name);
            c0050a.f148a.setTextSize((float) Settings.sFMItemFontSize);
            c0050a.f148a.setMinHeight(Settings.sFMItemSize >> 1);
            c0050a.f151d = (TextView) view.findViewById(R.id.desc);
            c0050a.f151d.setTextSize(0.7f * ((float) Settings.sFMItemFontSize));
            c0050a.f151d.setMinHeight(Settings.sFMItemSize >> 1);
            c0050a.f150c = (TextView) view.findViewById(R.id.info);
            c0050a.f150c.setTextSize(0.6f * ((float) Settings.sFMItemFontSize));
            c0050a.f149b = (ImageView) view.findViewById(R.id.icon);
            c0050a.f149b.setPadding(5, 0, 5, 0);
            LayoutParams layoutParams = c0050a.f149b.getLayoutParams();
            layoutParams.width = Settings.sFMItemSize;
            layoutParams.height = Settings.sFMItemSize;
            c0050a.f149b.setLayoutParams(layoutParams);
            c0050a.f149b.setOnClickListener(this);
            view.setTag(c0050a);
        }
        C0050a c0050a2 = (C0050a) view.getTag();
        c0050a2.f149b.setTag(Integer.valueOf(i));
        c0050a2.f148a.setText(c0052g.mo28e());
        Bitmap bitmap = null;
        if (f153a != null && c0052g.m133l() != null && c0052g.m133l().isStorage() && ((c0052g.mo29h() == (byte) 11 && Settings.sFMShowThumbnails) || ((c0052g.mo29h() == (byte) 15 && Settings.sFMShowPdfThumb) || (c0052g.mo29h() == (byte) 6 && Settings.sFMShowApkIcon)))) {
            bitmap = f153a.m612a(c0052g.mo29h(), c0052g.mo28e(), c0052g.m133l().toLocalPath(), c0050a2.f149b, i, this, this.f160h);
        }
        if (bitmap == null) {
            bitmap = C0169f.f465a[c0052g.mo29h()];
        }
        c0050a2.f149b.setImageBitmap(bitmap);
        if (c0052g.mo27a()) {
            c0050a2.f148a.setTextColor(this.f158f);
            if (c0050a2.f150c != null) {
                c0050a2.f150c.setTextColor(this.f158f);
            }
            if (c0050a2.f151d != null) {
                c0050a2.f151d.setTextColor(this.f158f);
            }
            c0050a2.f152e.setBackgroundColor(this.f159g);
        } else {
            c0050a2.f148a.setTextColor(this.f157e);
            if (c0050a2.f150c != null) {
                c0050a2.f150c.setTextColor(this.f157e);
            }
            if (c0050a2.f151d != null) {
                c0050a2.f151d.setTextColor(this.f157e);
            }
            c0050a2.f152e.setBackgroundColor(16777215);
        }
        c0050a2.f151d.setText(c0052g.m133l().toShortViewString());
        c0050a2.f150c.setText(c0052g.m134m());
        return view;
    }

    /* renamed from: i */
    public byte mo26i() {
        return (byte) 1;
    }

    public void onClick(View view) {
        if (view != null && view.getTag() != null) {
            C0052g c0052g;
            synchronized (this.f155c) {
                int intValue = ((Integer) view.getTag()).intValue();
                c0052g = intValue < this.f155c.size() ? (C0052g) this.f155c.get(intValue) : null;
            }
            if (c0052g != null) {
                if (c0052g.mo27a()) {
                    this.f156d--;
                } else {
                    this.f156d++;
                }
                c0052g.m105a(!c0052g.mo27a());
                if (this.f161i != null) {
                    this.f161i.onSelectItemChange(c0052g.mo27a(), this.f156d);
                }
                notifyDataSetChanged();
            }
        }
    }
}
