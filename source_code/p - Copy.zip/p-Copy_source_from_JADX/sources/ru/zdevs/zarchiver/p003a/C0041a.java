package ru.zdevs.zarchiver.p003a;

import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import ru.zdevs.zarchiver.R;

/* renamed from: ru.zdevs.zarchiver.a.a */
public class C0041a extends BaseAdapter {
    /* renamed from: b */
    private static final String[] f101b = new String[]{"Default", "Pink", "Purple", "Deep Purple", "Indigo", "Blue", "Light Blue", "Cyan", "Teal", "Green", "Light Green", "Lime", "Yellow", "Amber", "Orange", "Deep Orange", "Brown", "Grey", "Blue Grey", "Dark Grey"};
    /* renamed from: c */
    private static final int[] f102c = new int[]{0, -1499549, -6543440, -10011977, -12627531, -14575885, -16537100, -16728876, -16738680, -11751600, -7617718, -3285959, -5317, -16121, -26624, -43230, -8825528, -6381922, -10453621, -12434878};
    /* renamed from: a */
    private final LayoutInflater f103a;

    /* renamed from: ru.zdevs.zarchiver.a.a$a */
    static class C0040a {
        /* renamed from: a */
        protected ImageView f99a;
        /* renamed from: b */
        protected TextView f100b;

        C0040a() {
        }
    }

    public C0041a(Context context) {
        this.f103a = (LayoutInflater) context.getSystemService("layout_inflater");
    }

    /* renamed from: a */
    public static String m66a(int i) {
        return f101b[i];
    }

    public int getCount() {
        return f101b.length;
    }

    public Object getItem(int i) {
        return f101b[i];
    }

    public long getItemId(int i) {
        return (long) i;
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = this.f103a.inflate(R.layout.item_color_select, viewGroup, false);
            C0040a c0040a = new C0040a();
            c0040a.f99a = (ImageView) view.findViewById(R.id.iv_icon);
            c0040a.f100b = (TextView) view.findViewById(R.id.tv_text);
            view.setTag(c0040a);
        }
        C0040a c0040a2 = (C0040a) view.getTag();
        c0040a2.f100b.setText(f101b[i]);
        c0040a2.f99a.setImageDrawable(new ColorDrawable(f102c[i]));
        return view;
    }
}
