package ru.zdevs.zarchiver.p003a;

import android.graphics.drawable.Drawable;

/* renamed from: ru.zdevs.zarchiver.a.l */
public class C0056l {
    /* renamed from: a */
    public String f170a;
    /* renamed from: b */
    public String f171b;
    /* renamed from: c */
    public Drawable f172c;
    /* renamed from: d */
    public int f173d;
    /* renamed from: e */
    public boolean f174e;

    public C0056l(int i, String str, Drawable drawable) {
        this.f170a = str;
        this.f171b = "";
        this.f172c = drawable;
        this.f173d = i;
        this.f174e = false;
    }

    public C0056l(int i, String str, Drawable drawable, boolean z) {
        this(i, str, drawable);
        this.f174e = z;
    }

    public C0056l(int i, String str, String str2, Drawable drawable) {
        this.f170a = str;
        this.f171b = str2;
        this.f172c = drawable;
        this.f173d = i;
    }

    public C0056l(String str, String str2) {
        this.f170a = str;
        this.f171b = str2;
        this.f173d = -1;
    }

    public C0056l(String str, String str2, Drawable drawable) {
        this.f170a = str;
        this.f171b = str2;
        this.f172c = drawable;
        this.f173d = -1;
    }
}
