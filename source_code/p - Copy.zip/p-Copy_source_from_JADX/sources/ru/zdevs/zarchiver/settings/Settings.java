package ru.zdevs.zarchiver.settings;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.Resources;
import android.os.Build.VERSION;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import java.io.File;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;
import ru.zdevs.zarchiver.C0058a;
import ru.zdevs.zarchiver.R;
import ru.zdevs.zarchiver.ZArchiverExtInterface;
import ru.zdevs.zarchiver.fs.ZFileInfo;
import ru.zdevs.zarchiver.fs.ZViewFS;
import ru.zdevs.zarchiver.io.C0143a;
import ru.zdevs.zarchiver.p003a.C0049e;
import ru.zdevs.zarchiver.service.C0160c;
import ru.zdevs.zarchiver.tool.C0166c;
import ru.zdevs.zarchiver.tool.C0199n;
import ru.zdevs.zarchiver.tool.C0199n.C0198a;
import ru.zdevs.zarchiver.tool.C0201p;

public class Settings {
    static final int CURRENT_VERSION_HELP = 3;
    static final int CURRENT_VERSION_THEME = 2;
    public static final float GRID_ITEM_FONT_SCALE = 0.8f;
    public static final float GRID_ITEM_SIZE_SCALE = 1.6f;
    public static final byte GUI_FLAGS_SHOW_HELP = (byte) 1;
    public static final byte GUI_FLAGS_SHOW_MAIN_OPTIONS = (byte) 4;
    public static final byte GUI_FLAGS_SHOW_ROOT_WARNING = (byte) 16;
    public static final byte GUI_FLAGS_SHOW_SD_WARNING = (byte) 2;
    private static final int IMG_CASH_120_MEMORY = 700000;
    private static final int IMG_CASH_70_MEMORY = 400000;
    public static final byte P7ZIP_FLAGS_USE_LZMA2 = (byte) 1;
    public static final byte P7ZIP_FLAGS_USE_PIPE = (byte) 4;
    public static final byte P7ZIP_FLAGS_USE_SOLID = (byte) 2;
    private static final int SYSTEM_MEMORY_2 = 112640;
    private static final int SYSTEM_MEMORY_4 = 215040;
    private static final int SYSTEM_MEMORY_4_3 = 317440;
    private static final int SYSTEM_MEMORY_5 = 409600;
    private static final int[] mThemeDarkResource = new int[]{R.style.AppTheme.Dark, R.style.AppTheme.Dark.Material.Pink, R.style.AppTheme.Dark.Material.Purple, R.style.AppTheme.Dark.Material.DeepPurple, R.style.AppTheme.Dark.Material.Indigo, R.style.AppTheme.Dark.Material.Blue, R.style.AppTheme.Dark.Material.LightBlue, R.style.AppTheme.Dark.Material.Cyan, R.style.AppTheme.Dark.Material.Teal, R.style.AppTheme.Dark.Material.Green, R.style.AppTheme.Dark.Material.LightGreen, R.style.AppTheme.Dark.Material.Lime, R.style.AppTheme.Dark.Material.Yellow, R.style.AppTheme.Dark.Material.Amber, R.style.AppTheme.Dark.Material.Orange, R.style.AppTheme.Dark.Material.DeepOrange, R.style.AppTheme.Dark.Material.Brown, R.style.AppTheme.Dark.Material.Grey, R.style.AppTheme.Dark.Material.BlueGrey, R.style.AppTheme.Dark.Material.DarkGrey};
    private static final int[] mThemeLightDarkABResource = new int[]{R.style.AppTheme.Dark, R.style.AppTheme.Dark.Material.Pink, R.style.AppTheme.Dark.Material.Purple, R.style.AppTheme.Dark.Material.DeepPurple, R.style.AppTheme.Dark.Material.Indigo, R.style.AppTheme.Dark.Material.Blue, R.style.AppTheme.Dark.Material.LightBlue, R.style.AppTheme.Dark.Material.Cyan, R.style.AppTheme.Dark.Material.Teal, R.style.AppTheme.Dark.Material.Green, R.style.AppTheme.Dark.Material.LightGreen, R.style.AppTheme.Dark.Material.Lime, R.style.AppTheme.Dark.Material.Yellow, R.style.AppTheme.Dark.Material.Amber, R.style.AppTheme.Dark.Material.Orange, R.style.AppTheme.Dark.Material.DeepOrange, R.style.AppTheme.Dark.Material.Brown, R.style.AppTheme.Dark.Material.Grey, R.style.AppTheme.Dark.Material.BlueGrey, R.style.AppTheme.Dark.Material.DarkGrey};
    private static final int[] mThemeLightResource = new int[]{R.style.AppTheme.Dark, R.style.AppTheme.Dark.Material.Pink, R.style.AppTheme.Dark.Material.Purple, R.style.AppTheme.Dark.Material.DeepPurple, R.style.AppTheme.Dark.Material.Indigo, R.style.AppTheme.Dark.Material.Blue, R.style.AppTheme.Dark.Material.LightBlue, R.style.AppTheme.Dark.Material.Cyan, R.style.AppTheme.Dark.Material.Teal, R.style.AppTheme.Dark.Material.Green, R.style.AppTheme.Dark.Material.LightGreen, R.style.AppTheme.Dark.Material.Lime, R.style.AppTheme.Dark.Material.Yellow, R.style.AppTheme.Dark.Material.Amber, R.style.AppTheme.Dark.Material.Orange, R.style.AppTheme.Dark.Material.DeepOrange, R.style.AppTheme.Dark.Material.Brown, R.style.AppTheme.Dark.Material.Grey, R.style.AppTheme.Dark.Material.BlueGrey, R.style.AppTheme.Dark.Material.DarkGrey};
    public static byte s7zOptions = (byte) 4;
    public static int sActionbarColor = 0;
    public static String sArchiveDir = null;
    public static String sBGCustomPath = null;
    public static byte sBackType = (byte) 1;
    public static String sCPUCoreN = null;
    public static int sCompressDefEncrypt = 0;
    public static int sCompressDefLevel = 3;
    public static String sCompressDefType = ZArchiverExtInterface.ARCHIVE_TYPE_7Z;
    public static boolean sCompressRemoveFile = false;
    public static boolean sConfirmCancel = true;
    public static Boolean sExtIgnoreRAMLimit = Boolean.valueOf(false);
    public static int sExtOpenArchive = 0;
    public static int sFMItemFontSize = 22;
    public static int sFMItemSize = 70;
    public static boolean sFMShowApkIcon = true;
    public static boolean sFMShowArchiveThumb = false;
    public static boolean sFMShowPdfThumb = false;
    public static boolean sFMShowThumbnails = true;
    public static boolean sFMShowVideoThumb = false;
    public static boolean sFMSortDesc = true;
    public static byte sFMSortType = (byte) 0;
    public static int sFSIconTheme = 1;
    public static boolean sFavoriteBar = true;
    private static long sFreeMemSize = 0;
    public static boolean sGUIAnimation = true;
    public static byte sGUIBackground = (byte) 3;
    public static boolean sGUIFastScroll = false;
    public static boolean sGUIFloatButton = true;
    public static boolean sGUIGridView = true;
    public static boolean sGUIWideBar = true;
    public static String sHomeDir = "";
    public static int sImgCashSize = 50;
    public static boolean sInteractivePast = true;
    public static String sLanguage = "";
    public static String sLevel7z = "3";
    public static String sLevelZip = "3";
    public static boolean sNeedRestartGUI = false;
    public static int sOEMCP = 0;
    public static boolean sOpenArchive = true;
    public static boolean sOpenFile = true;
    public static boolean sRemoveAfterCompress = false;
    public static boolean sRoot = false;
    public static boolean sRootWarning = true;
    public static List<String> sSavedPassword = new ArrayList();
    public static boolean sShortFileName = true;
    public static byte sShowHelp = ZFileInfo.OVERLAY_TYPE_VIDEO;
    public static byte sTheme = (byte) 0;
    public static int sThemeResource = 0;
    private static long sTotalMemSize = 0;
    public static boolean sUpSetting = false;
    private static int sWriteAvailable = 0;

    public static void LoadSettings(Context context, boolean z) {
        boolean z2;
        int i;
        Resources resources;
        String path;
        Editor edit;
        String[] split;
        int length;
        String str;
        long maxMemory;
        int i2 = 0;
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        sNeedRestartGUI = false;
        sOEMCP = Integer.parseInt(defaultSharedPreferences.getString("iOEMCP", "0"));
        if (sOEMCP <= 700) {
            sOEMCP = C0160c.m538b(context);
        }
        sCPUCoreN = defaultSharedPreferences.getString("iCPUCoreN", null);
        sShowHelp = (byte) 0;
        if (defaultSharedPreferences.getInt("iShowHelp", 0) < 3) {
            sShowHelp = (byte) (sShowHelp | 1);
        }
        if (defaultSharedPreferences.getBoolean("bShowSDWarning2", true)) {
            sShowHelp = (byte) (sShowHelp | 2);
        }
        if (!(z || defaultSharedPreferences.getInt("iShowMainOptions", 0) == 2)) {
            sShowHelp = (byte) (sShowHelp | 4);
        }
        sGUIAnimation = defaultSharedPreferences.getBoolean("iGUIAnimation", true);
        sGUIFastScroll = defaultSharedPreferences.getBoolean("iGUIFastScroll", true);
        sInteractivePast = defaultSharedPreferences.getBoolean("iGUIInterectivPast", true);
        sGUIBackground = getByte(defaultSharedPreferences.getString("iGUIBackground", "0"));
        if (sGUIBackground == (byte) 0) {
            sGUIBackground = (byte) 3;
        }
        ZViewFS.sFMHideFile = defaultSharedPreferences.getBoolean("iFMHidenFile", false);
        sShortFileName = defaultSharedPreferences.getBoolean("iFMShortName", false);
        C0049e.f139c = defaultSharedPreferences.getBoolean("iFMFileSize", true);
        C0049e.f137a = defaultSharedPreferences.getBoolean("iFMFileLastMod", false);
        C0049e.f138b = defaultSharedPreferences.getBoolean("iFMFileLastModTime", false);
        if (VERSION.SDK_INT < 21) {
            z2 = sNeedRestartGUI;
            i = (!z || sGUIWideBar == defaultSharedPreferences.getBoolean("iSplitToolbar", true)) ? 0 : 1;
            sNeedRestartGUI = i | z2;
            sGUIWideBar = defaultSharedPreferences.getBoolean("iSplitToolbar", true);
        } else {
            sGUIWideBar = false;
        }
        z2 = sNeedRestartGUI;
        if (z) {
            if (sGUIGridView != (!defaultSharedPreferences.getBoolean("iListView", true))) {
                i = 1;
                sNeedRestartGUI = i | z2;
                sGUIGridView = defaultSharedPreferences.getBoolean("iListView", true);
                z2 = sNeedRestartGUI;
                if (z) {
                    if (sGUIFloatButton != defaultSharedPreferences.getBoolean("iFloatButon", VERSION.SDK_INT < 21)) {
                        i = 1;
                        sNeedRestartGUI = i | z2;
                        sGUIFloatButton = defaultSharedPreferences.getBoolean("iFloatButon", VERSION.SDK_INT < 21);
                        sFavoriteBar = defaultSharedPreferences.getBoolean("iFavoBar", true);
                        resources = context.getResources();
                        sFMItemFontSize = defaultSharedPreferences.getInt("iFMItemFontSize", resources.getDimensionPixelSize(R.dimen.list_item_text_size));
                        sFMItemSize = defaultSharedPreferences.getInt("iFMItemSize2", resources.getDimensionPixelSize(R.dimen.list_item_size));
                        sFMSortType = getByte(defaultSharedPreferences.getString("iFMSortType", "0"));
                        sFMSortDesc = defaultSharedPreferences.getBoolean("iFMSortDesc", false);
                        path = Environment.getExternalStorageDirectory().getPath();
                        sHomeDir = defaultSharedPreferences.getString("iHomePath", path);
                        if (!(sHomeDir.compareTo(path) == 0 || new File(sHomeDir).exists())) {
                            sHomeDir = path;
                        }
                        if (defaultSharedPreferences.getBoolean("iUseArcPath", false)) {
                            sArchiveDir = null;
                        } else {
                            sArchiveDir = defaultSharedPreferences.getString("iArcPath", path + "/archives");
                            if (!(sArchiveDir.compareTo(path + "/archives") == 0 || new File(sArchiveDir).exists())) {
                                sArchiveDir = path + "/archives";
                            }
                        }
                        sLevel7z = defaultSharedPreferences.getString("iLavel7z", "3");
                        sLevelZip = defaultSharedPreferences.getString("iLavelZIP", "3");
                        sExtIgnoreRAMLimit = Boolean.valueOf(defaultSharedPreferences.getBoolean("iExtIgnoreRAMLimit", false));
                        sBGCustomPath = defaultSharedPreferences.getString("iGUICustomBGPath", null);
                        sFMShowThumbnails = defaultSharedPreferences.getBoolean("iFMImgThumd", true);
                        sFMShowPdfThumb = defaultSharedPreferences.getBoolean("iFMPdfThumb", false);
                        sFMShowVideoThumb = defaultSharedPreferences.getBoolean("iFMVideoThumb", false);
                        sFMShowApkIcon = defaultSharedPreferences.getBoolean("iFMApkIcon", true);
                        sFMShowArchiveThumb = defaultSharedPreferences.getBoolean("iFMShowArchiveThumb", false);
                        if (!sFMShowPdfThumb && defaultSharedPreferences.getBoolean("iFMPdfThumb", true)) {
                            sFMShowPdfThumb = true;
                            i = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode % 10;
                            if (VERSION.SDK_INT >= 21) {
                                sFMShowPdfThumb = false;
                            } else if (VERSION.SDK_INT != 21 || VERSION.SDK_INT == 22) {
                                if (i == 0 || i == 3 || i == 5) {
                                    sFMShowPdfThumb = false;
                                }
                            } else if (VERSION.SDK_INT == 23) {
                                if (i == 0 || i == 3 || i == 5) {
                                    sFMShowPdfThumb = false;
                                }
                            } else if ((VERSION.SDK_INT == 24 || VERSION.SDK_INT == 25) && (i == 0 || i == 3 || i == 5)) {
                                sFMShowPdfThumb = false;
                            }
                            edit = defaultSharedPreferences.edit();
                            edit.putBoolean("iFMPdfThumb", sFMShowPdfThumb);
                            edit.apply();
                        }
                        sConfirmCancel = defaultSharedPreferences.getBoolean("iGUIConfirmCancel", true);
                        sRemoveAfterCompress = defaultSharedPreferences.getBoolean("iGUIRemoveAfterCompress", false);
                        ZViewFS.sAddFolderUp = defaultSharedPreferences.getBoolean("iFMFolderUpItem", true);
                        sExtOpenArchive = getByte(defaultSharedPreferences.getString("iActionOpenArc", "0"));
                        sOpenArchive = defaultSharedPreferences.getString("iOpenArchive", "1").equals("0");
                        sOpenFile = defaultSharedPreferences.getString("iOpenFile", "1").equals("0");
                        z2 = sNeedRestartGUI;
                        i = (z || sFSIconTheme == getByte(defaultSharedPreferences.getString("iFSIconTheme", "1"))) ? 0 : 1;
                        sNeedRestartGUI = i | z2;
                        sFSIconTheme = getByte(defaultSharedPreferences.getString("iFSIconTheme", "1"));
                        z2 = sNeedRestartGUI;
                        i = (z || sTheme == getByte(defaultSharedPreferences.getString("iTheme", "0"))) ? 0 : 1;
                        sNeedRestartGUI = i | z2;
                        sTheme = getByte(defaultSharedPreferences.getString("iTheme", "0"));
                        z2 = sNeedRestartGUI;
                        i = (z || sActionbarColor == defaultSharedPreferences.getInt("iActionbarColorN", 0)) ? 0 : 1;
                        sNeedRestartGUI = i | z2;
                        sActionbarColor = defaultSharedPreferences.getInt("iActionbarColorN", 0);
                        sLanguage = defaultSharedPreferences.getString("iLanguage", "").trim();
                        sCompressDefType = defaultSharedPreferences.getString("sCompressDefType", ZArchiverExtInterface.ARCHIVE_TYPE_7Z);
                        sCompressDefLevel = defaultSharedPreferences.getInt("iCompressDefLevel", 3);
                        sCompressDefEncrypt = defaultSharedPreferences.getInt("iCompressDefEncrypt", 0);
                        s7zOptions = (byte) 0;
                        if (getByte(defaultSharedPreferences.getString("i7ZCompressionMethod", "0")) != (byte) 0) {
                            s7zOptions = (byte) (s7zOptions | 1);
                        }
                        if (defaultSharedPreferences.getBoolean("i7ZUseSolidMode", false)) {
                            s7zOptions = (byte) (s7zOptions | 2);
                        }
                        if (defaultSharedPreferences.getBoolean("i7ZUsePipe", true)) {
                            s7zOptions = (byte) (s7zOptions | 4);
                        }
                        sBackType = getByte(defaultSharedPreferences.getString("iBackType", "0"));
                        sRoot = defaultSharedPreferences.getBoolean("bRoot", false);
                        if (!defaultSharedPreferences.getBoolean("bShowRootWarning", true)) {
                            sShowHelp = (byte) (sShowHelp | 16);
                        } else if (!sRoot) {
                            setShowRootWarning(context, true);
                        }
                        sRootWarning = true;
                        sSavedPassword.clear();
                        split = TextUtils.split(defaultSharedPreferences.getString("sSavedPassword", ""), "!\\x24!@");
                        length = split.length;
                        while (i2 < length) {
                            str = split[i2];
                            if (str != null && str.length() > 0) {
                                sSavedPassword.add(str);
                            }
                            i2++;
                        }
                        maxMemory = getMaxMemory();
                        if (maxMemory <= 700000) {
                            sImgCashSize = 120;
                        } else if (maxMemory > 400000) {
                            sImgCashSize = 70;
                        }
                        sThemeResource = getTheme(sTheme);
                    }
                }
                i = 0;
                sNeedRestartGUI = i | z2;
                if (VERSION.SDK_INT < 21) {
                }
                sGUIFloatButton = defaultSharedPreferences.getBoolean("iFloatButon", VERSION.SDK_INT < 21);
                sFavoriteBar = defaultSharedPreferences.getBoolean("iFavoBar", true);
                resources = context.getResources();
                sFMItemFontSize = defaultSharedPreferences.getInt("iFMItemFontSize", resources.getDimensionPixelSize(R.dimen.list_item_text_size));
                sFMItemSize = defaultSharedPreferences.getInt("iFMItemSize2", resources.getDimensionPixelSize(R.dimen.list_item_size));
                sFMSortType = getByte(defaultSharedPreferences.getString("iFMSortType", "0"));
                sFMSortDesc = defaultSharedPreferences.getBoolean("iFMSortDesc", false);
                path = Environment.getExternalStorageDirectory().getPath();
                sHomeDir = defaultSharedPreferences.getString("iHomePath", path);
                sHomeDir = path;
                if (defaultSharedPreferences.getBoolean("iUseArcPath", false)) {
                    sArchiveDir = null;
                } else {
                    sArchiveDir = defaultSharedPreferences.getString("iArcPath", path + "/archives");
                    sArchiveDir = path + "/archives";
                }
                sLevel7z = defaultSharedPreferences.getString("iLavel7z", "3");
                sLevelZip = defaultSharedPreferences.getString("iLavelZIP", "3");
                sExtIgnoreRAMLimit = Boolean.valueOf(defaultSharedPreferences.getBoolean("iExtIgnoreRAMLimit", false));
                sBGCustomPath = defaultSharedPreferences.getString("iGUICustomBGPath", null);
                sFMShowThumbnails = defaultSharedPreferences.getBoolean("iFMImgThumd", true);
                sFMShowPdfThumb = defaultSharedPreferences.getBoolean("iFMPdfThumb", false);
                sFMShowVideoThumb = defaultSharedPreferences.getBoolean("iFMVideoThumb", false);
                sFMShowApkIcon = defaultSharedPreferences.getBoolean("iFMApkIcon", true);
                sFMShowArchiveThumb = defaultSharedPreferences.getBoolean("iFMShowArchiveThumb", false);
                sFMShowPdfThumb = true;
                i = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode % 10;
                if (VERSION.SDK_INT >= 21) {
                    if (VERSION.SDK_INT != 21) {
                    }
                    sFMShowPdfThumb = false;
                } else {
                    sFMShowPdfThumb = false;
                }
                edit = defaultSharedPreferences.edit();
                edit.putBoolean("iFMPdfThumb", sFMShowPdfThumb);
                edit.apply();
                sConfirmCancel = defaultSharedPreferences.getBoolean("iGUIConfirmCancel", true);
                sRemoveAfterCompress = defaultSharedPreferences.getBoolean("iGUIRemoveAfterCompress", false);
                ZViewFS.sAddFolderUp = defaultSharedPreferences.getBoolean("iFMFolderUpItem", true);
                sExtOpenArchive = getByte(defaultSharedPreferences.getString("iActionOpenArc", "0"));
                sOpenArchive = defaultSharedPreferences.getString("iOpenArchive", "1").equals("0");
                sOpenFile = defaultSharedPreferences.getString("iOpenFile", "1").equals("0");
                z2 = sNeedRestartGUI;
                if (z) {
                }
                sNeedRestartGUI = i | z2;
                sFSIconTheme = getByte(defaultSharedPreferences.getString("iFSIconTheme", "1"));
                z2 = sNeedRestartGUI;
                if (z) {
                }
                sNeedRestartGUI = i | z2;
                sTheme = getByte(defaultSharedPreferences.getString("iTheme", "0"));
                z2 = sNeedRestartGUI;
                if (z) {
                }
                sNeedRestartGUI = i | z2;
                sActionbarColor = defaultSharedPreferences.getInt("iActionbarColorN", 0);
                sLanguage = defaultSharedPreferences.getString("iLanguage", "").trim();
                sCompressDefType = defaultSharedPreferences.getString("sCompressDefType", ZArchiverExtInterface.ARCHIVE_TYPE_7Z);
                sCompressDefLevel = defaultSharedPreferences.getInt("iCompressDefLevel", 3);
                sCompressDefEncrypt = defaultSharedPreferences.getInt("iCompressDefEncrypt", 0);
                s7zOptions = (byte) 0;
                if (getByte(defaultSharedPreferences.getString("i7ZCompressionMethod", "0")) != (byte) 0) {
                    s7zOptions = (byte) (s7zOptions | 1);
                }
                if (defaultSharedPreferences.getBoolean("i7ZUseSolidMode", false)) {
                    s7zOptions = (byte) (s7zOptions | 2);
                }
                if (defaultSharedPreferences.getBoolean("i7ZUsePipe", true)) {
                    s7zOptions = (byte) (s7zOptions | 4);
                }
                sBackType = getByte(defaultSharedPreferences.getString("iBackType", "0"));
                sRoot = defaultSharedPreferences.getBoolean("bRoot", false);
                if (!defaultSharedPreferences.getBoolean("bShowRootWarning", true)) {
                    sShowHelp = (byte) (sShowHelp | 16);
                } else if (sRoot) {
                    setShowRootWarning(context, true);
                }
                sRootWarning = true;
                sSavedPassword.clear();
                split = TextUtils.split(defaultSharedPreferences.getString("sSavedPassword", ""), "!\\x24!@");
                length = split.length;
                while (i2 < length) {
                    str = split[i2];
                    sSavedPassword.add(str);
                    i2++;
                }
                maxMemory = getMaxMemory();
                if (maxMemory <= 700000) {
                    sImgCashSize = 120;
                } else if (maxMemory > 400000) {
                    sImgCashSize = 70;
                }
                sThemeResource = getTheme(sTheme);
            }
        }
        i = 0;
        sNeedRestartGUI = i | z2;
        if (defaultSharedPreferences.getBoolean("iListView", true)) {
        }
        sGUIGridView = defaultSharedPreferences.getBoolean("iListView", true);
        z2 = sNeedRestartGUI;
        if (z) {
            if (VERSION.SDK_INT < 21) {
            }
            if (sGUIFloatButton != defaultSharedPreferences.getBoolean("iFloatButon", VERSION.SDK_INT < 21)) {
                i = 1;
                sNeedRestartGUI = i | z2;
                if (VERSION.SDK_INT < 21) {
                }
                sGUIFloatButton = defaultSharedPreferences.getBoolean("iFloatButon", VERSION.SDK_INT < 21);
                sFavoriteBar = defaultSharedPreferences.getBoolean("iFavoBar", true);
                resources = context.getResources();
                sFMItemFontSize = defaultSharedPreferences.getInt("iFMItemFontSize", resources.getDimensionPixelSize(R.dimen.list_item_text_size));
                sFMItemSize = defaultSharedPreferences.getInt("iFMItemSize2", resources.getDimensionPixelSize(R.dimen.list_item_size));
                sFMSortType = getByte(defaultSharedPreferences.getString("iFMSortType", "0"));
                sFMSortDesc = defaultSharedPreferences.getBoolean("iFMSortDesc", false);
                path = Environment.getExternalStorageDirectory().getPath();
                sHomeDir = defaultSharedPreferences.getString("iHomePath", path);
                sHomeDir = path;
                if (defaultSharedPreferences.getBoolean("iUseArcPath", false)) {
                    sArchiveDir = defaultSharedPreferences.getString("iArcPath", path + "/archives");
                    sArchiveDir = path + "/archives";
                } else {
                    sArchiveDir = null;
                }
                sLevel7z = defaultSharedPreferences.getString("iLavel7z", "3");
                sLevelZip = defaultSharedPreferences.getString("iLavelZIP", "3");
                sExtIgnoreRAMLimit = Boolean.valueOf(defaultSharedPreferences.getBoolean("iExtIgnoreRAMLimit", false));
                sBGCustomPath = defaultSharedPreferences.getString("iGUICustomBGPath", null);
                sFMShowThumbnails = defaultSharedPreferences.getBoolean("iFMImgThumd", true);
                sFMShowPdfThumb = defaultSharedPreferences.getBoolean("iFMPdfThumb", false);
                sFMShowVideoThumb = defaultSharedPreferences.getBoolean("iFMVideoThumb", false);
                sFMShowApkIcon = defaultSharedPreferences.getBoolean("iFMApkIcon", true);
                sFMShowArchiveThumb = defaultSharedPreferences.getBoolean("iFMShowArchiveThumb", false);
                sFMShowPdfThumb = true;
                i = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode % 10;
                if (VERSION.SDK_INT >= 21) {
                    sFMShowPdfThumb = false;
                } else {
                    if (VERSION.SDK_INT != 21) {
                    }
                    sFMShowPdfThumb = false;
                }
                edit = defaultSharedPreferences.edit();
                edit.putBoolean("iFMPdfThumb", sFMShowPdfThumb);
                edit.apply();
                sConfirmCancel = defaultSharedPreferences.getBoolean("iGUIConfirmCancel", true);
                sRemoveAfterCompress = defaultSharedPreferences.getBoolean("iGUIRemoveAfterCompress", false);
                ZViewFS.sAddFolderUp = defaultSharedPreferences.getBoolean("iFMFolderUpItem", true);
                sExtOpenArchive = getByte(defaultSharedPreferences.getString("iActionOpenArc", "0"));
                sOpenArchive = defaultSharedPreferences.getString("iOpenArchive", "1").equals("0");
                sOpenFile = defaultSharedPreferences.getString("iOpenFile", "1").equals("0");
                z2 = sNeedRestartGUI;
                if (z) {
                }
                sNeedRestartGUI = i | z2;
                sFSIconTheme = getByte(defaultSharedPreferences.getString("iFSIconTheme", "1"));
                z2 = sNeedRestartGUI;
                if (z) {
                }
                sNeedRestartGUI = i | z2;
                sTheme = getByte(defaultSharedPreferences.getString("iTheme", "0"));
                z2 = sNeedRestartGUI;
                if (z) {
                }
                sNeedRestartGUI = i | z2;
                sActionbarColor = defaultSharedPreferences.getInt("iActionbarColorN", 0);
                sLanguage = defaultSharedPreferences.getString("iLanguage", "").trim();
                sCompressDefType = defaultSharedPreferences.getString("sCompressDefType", ZArchiverExtInterface.ARCHIVE_TYPE_7Z);
                sCompressDefLevel = defaultSharedPreferences.getInt("iCompressDefLevel", 3);
                sCompressDefEncrypt = defaultSharedPreferences.getInt("iCompressDefEncrypt", 0);
                s7zOptions = (byte) 0;
                if (getByte(defaultSharedPreferences.getString("i7ZCompressionMethod", "0")) != (byte) 0) {
                    s7zOptions = (byte) (s7zOptions | 1);
                }
                if (defaultSharedPreferences.getBoolean("i7ZUseSolidMode", false)) {
                    s7zOptions = (byte) (s7zOptions | 2);
                }
                if (defaultSharedPreferences.getBoolean("i7ZUsePipe", true)) {
                    s7zOptions = (byte) (s7zOptions | 4);
                }
                sBackType = getByte(defaultSharedPreferences.getString("iBackType", "0"));
                sRoot = defaultSharedPreferences.getBoolean("bRoot", false);
                if (!defaultSharedPreferences.getBoolean("bShowRootWarning", true)) {
                    sShowHelp = (byte) (sShowHelp | 16);
                } else if (sRoot) {
                    setShowRootWarning(context, true);
                }
                sRootWarning = true;
                sSavedPassword.clear();
                split = TextUtils.split(defaultSharedPreferences.getString("sSavedPassword", ""), "!\\x24!@");
                length = split.length;
                while (i2 < length) {
                    str = split[i2];
                    sSavedPassword.add(str);
                    i2++;
                }
                maxMemory = getMaxMemory();
                if (maxMemory <= 700000) {
                    sImgCashSize = 120;
                } else if (maxMemory > 400000) {
                    sImgCashSize = 70;
                }
                sThemeResource = getTheme(sTheme);
            }
        }
        i = 0;
        sNeedRestartGUI = i | z2;
        if (VERSION.SDK_INT < 21) {
        }
        sGUIFloatButton = defaultSharedPreferences.getBoolean("iFloatButon", VERSION.SDK_INT < 21);
        sFavoriteBar = defaultSharedPreferences.getBoolean("iFavoBar", true);
        resources = context.getResources();
        try {
            sFMItemFontSize = defaultSharedPreferences.getInt("iFMItemFontSize", resources.getDimensionPixelSize(R.dimen.list_item_text_size));
        } catch (Throwable e) {
            sFMItemFontSize = 22;
            C0166c.m556a(e);
        }
        sFMItemSize = defaultSharedPreferences.getInt("iFMItemSize2", resources.getDimensionPixelSize(R.dimen.list_item_size));
        sFMSortType = getByte(defaultSharedPreferences.getString("iFMSortType", "0"));
        sFMSortDesc = defaultSharedPreferences.getBoolean("iFMSortDesc", false);
        path = Environment.getExternalStorageDirectory().getPath();
        sHomeDir = defaultSharedPreferences.getString("iHomePath", path);
        sHomeDir = path;
        if (defaultSharedPreferences.getBoolean("iUseArcPath", false)) {
            sArchiveDir = null;
        } else {
            sArchiveDir = defaultSharedPreferences.getString("iArcPath", path + "/archives");
            sArchiveDir = path + "/archives";
        }
        sLevel7z = defaultSharedPreferences.getString("iLavel7z", "3");
        sLevelZip = defaultSharedPreferences.getString("iLavelZIP", "3");
        sExtIgnoreRAMLimit = Boolean.valueOf(defaultSharedPreferences.getBoolean("iExtIgnoreRAMLimit", false));
        sBGCustomPath = defaultSharedPreferences.getString("iGUICustomBGPath", null);
        sFMShowThumbnails = defaultSharedPreferences.getBoolean("iFMImgThumd", true);
        sFMShowPdfThumb = defaultSharedPreferences.getBoolean("iFMPdfThumb", false);
        sFMShowVideoThumb = defaultSharedPreferences.getBoolean("iFMVideoThumb", false);
        sFMShowApkIcon = defaultSharedPreferences.getBoolean("iFMApkIcon", true);
        sFMShowArchiveThumb = defaultSharedPreferences.getBoolean("iFMShowArchiveThumb", false);
        sFMShowPdfThumb = true;
        try {
            i = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode % 10;
        } catch (Throwable e2) {
            C0166c.m556a(e2);
            i = 0;
        }
        if (VERSION.SDK_INT >= 21) {
            if (VERSION.SDK_INT != 21) {
            }
            sFMShowPdfThumb = false;
        } else {
            sFMShowPdfThumb = false;
        }
        edit = defaultSharedPreferences.edit();
        edit.putBoolean("iFMPdfThumb", sFMShowPdfThumb);
        edit.apply();
        sConfirmCancel = defaultSharedPreferences.getBoolean("iGUIConfirmCancel", true);
        sRemoveAfterCompress = defaultSharedPreferences.getBoolean("iGUIRemoveAfterCompress", false);
        ZViewFS.sAddFolderUp = defaultSharedPreferences.getBoolean("iFMFolderUpItem", true);
        sExtOpenArchive = getByte(defaultSharedPreferences.getString("iActionOpenArc", "0"));
        sOpenArchive = defaultSharedPreferences.getString("iOpenArchive", "1").equals("0");
        sOpenFile = defaultSharedPreferences.getString("iOpenFile", "1").equals("0");
        z2 = sNeedRestartGUI;
        if (z) {
        }
        sNeedRestartGUI = i | z2;
        sFSIconTheme = getByte(defaultSharedPreferences.getString("iFSIconTheme", "1"));
        z2 = sNeedRestartGUI;
        if (z) {
        }
        sNeedRestartGUI = i | z2;
        sTheme = getByte(defaultSharedPreferences.getString("iTheme", "0"));
        z2 = sNeedRestartGUI;
        if (z) {
        }
        sNeedRestartGUI = i | z2;
        sActionbarColor = defaultSharedPreferences.getInt("iActionbarColorN", 0);
        sLanguage = defaultSharedPreferences.getString("iLanguage", "").trim();
        sCompressDefType = defaultSharedPreferences.getString("sCompressDefType", ZArchiverExtInterface.ARCHIVE_TYPE_7Z);
        sCompressDefLevel = defaultSharedPreferences.getInt("iCompressDefLevel", 3);
        sCompressDefEncrypt = defaultSharedPreferences.getInt("iCompressDefEncrypt", 0);
        s7zOptions = (byte) 0;
        if (getByte(defaultSharedPreferences.getString("i7ZCompressionMethod", "0")) != (byte) 0) {
            s7zOptions = (byte) (s7zOptions | 1);
        }
        if (defaultSharedPreferences.getBoolean("i7ZUseSolidMode", false)) {
            s7zOptions = (byte) (s7zOptions | 2);
        }
        if (defaultSharedPreferences.getBoolean("i7ZUsePipe", true)) {
            s7zOptions = (byte) (s7zOptions | 4);
        }
        sBackType = getByte(defaultSharedPreferences.getString("iBackType", "0"));
        sRoot = defaultSharedPreferences.getBoolean("bRoot", false);
        if (!defaultSharedPreferences.getBoolean("bShowRootWarning", true)) {
            sShowHelp = (byte) (sShowHelp | 16);
        } else if (sRoot) {
            setShowRootWarning(context, true);
        }
        sRootWarning = true;
        sSavedPassword.clear();
        split = TextUtils.split(defaultSharedPreferences.getString("sSavedPassword", ""), "!\\x24!@");
        length = split.length;
        while (i2 < length) {
            str = split[i2];
            sSavedPassword.add(str);
            i2++;
        }
        maxMemory = getMaxMemory();
        if (maxMemory <= 700000) {
            sImgCashSize = 120;
        } else if (maxMemory > 400000) {
            sImgCashSize = 70;
        }
        sThemeResource = getTheme(sTheme);
    }

    private static byte getByte(String str) {
        try {
            return Byte.parseByte(str);
        } catch (Exception e) {
            return (byte) 0;
        }
    }

    public static long getMaxMemory() {
        if (sFreeMemSize > 0) {
            return sFreeMemSize;
        }
        if (VERSION.SDK_INT >= 21 || isUseArt()) {
            sFreeMemSize = Runtime.getRuntime().maxMemory() / 1024;
        } else if (VERSION.SDK_INT < 14) {
            sFreeMemSize = getTotalMemory() - 112640;
        } else if (VERSION.SDK_INT < 18) {
            sFreeMemSize = getTotalMemory() - 215040;
        } else if (VERSION.SDK_INT < 21) {
            sFreeMemSize = getTotalMemory() - 317440;
        } else {
            sFreeMemSize = getTotalMemory() - 409600;
        }
        return sFreeMemSize;
    }

    public static String getSavedPwd(String str, String str2) {
        return (str + "#^#$") + C0201p.m721a(C0201p.m720a(str2, "ZA" + str + "!").getBytes());
    }

    public static String getSavedPwdName(String str) {
        return (str == null || str.indexOf("#^#$") < 1) ? "" : str.substring(0, str.indexOf("#^#$"));
    }

    public static String getSavedPwdPassword(String str) {
        return (str == null || str.indexOf("#^#$") < 1) ? "" : C0201p.m720a(new String(C0201p.m722a(str.substring(str.indexOf("#^#$") + 4))), "ZA" + getSavedPwdName(str) + "!");
    }

    private static String getStoragePermissionCode(Context context) {
        StringBuilder stringBuilder = new StringBuilder();
        for (C0198a c0198a : C0199n.m695b(context, 255)) {
            if (c0198a.m685b() && c0198a.f543c != null) {
                stringBuilder.append(c0198a.f543c);
                stringBuilder.append('-');
            }
        }
        if (VERSION.RELEASE != null) {
            stringBuilder.append(VERSION.RELEASE);
        }
        if (VERSION.INCREMENTAL != null) {
            stringBuilder.append(VERSION.INCREMENTAL);
        }
        return stringBuilder.toString();
    }

    public static int getTheme(int i) {
        return i == 1 ? sActionbarColor != 0 ? mThemeLightResource[sActionbarColor] : R.style.AppTheme.Dark : i == 2 ? sActionbarColor != 0 ? mThemeLightDarkABResource[sActionbarColor] : R.style.AppTheme.Dark : sActionbarColor != 0 ? mThemeDarkResource[sActionbarColor] : C0058a.m149c() ? R.style.AppTheme.Samsung : R.style.AppTheme.Dark;
    }

    public static long getTotalMemory() {
        Throwable e;
        long j = 0;
        if (sTotalMemSize != 0) {
            return sTotalMemSize;
        }
        long j2;
        try {
            RandomAccessFile randomAccessFile = new RandomAccessFile("/proc/meminfo", "r");
            j2 = 0;
            String readLine = randomAccessFile.readLine();
            while (readLine != null) {
                try {
                    if (readLine.contains("MemTotal") || readLine.contains("SwapTotal")) {
                        j = (Long.parseLong(readLine.substring(readLine.lastIndexOf(":") + 1, readLine.lastIndexOf(" ")).trim()) * ((long) (readLine.contains("mB") ? 1000 : 1))) + j2;
                    } else {
                        j = j2;
                    }
                    j2 = j;
                    readLine = randomAccessFile.readLine();
                } catch (Exception e2) {
                    e = e2;
                }
            }
            randomAccessFile.close();
        } catch (Throwable e3) {
            Throwable th = e3;
            j2 = j;
            e = th;
        }
        sTotalMemSize = j2;
        return j2;
        C0166c.m556a(e);
        sTotalMemSize = j2;
        return j2;
    }

    public static boolean isNeedRestartGUI() {
        return sNeedRestartGUI;
    }

    public static boolean isNeedStoragePermission(Context context) {
        boolean z = false;
        int i = 1;
        int c = C0199n.m699c(context, 2);
        if (c == 0) {
            return false;
        }
        if (sWriteAvailable == 1) {
            return true;
        }
        if (sWriteAvailable == c + 1) {
            return false;
        }
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        String storagePermissionCode = getStoragePermissionCode(context);
        if (defaultSharedPreferences.getString("sExtSDCheckedOn", "").equals(storagePermissionCode)) {
            z = defaultSharedPreferences.getBoolean("bNeedWritePermission", false);
        } else {
            if (!C0143a.m430b(context)) {
                z = true;
            }
            Editor edit = defaultSharedPreferences.edit();
            edit.putBoolean("bNeedWritePermission", z);
            edit.putString("sExtSDCheckedOn", storagePermissionCode);
            edit.putBoolean("bShowSDWarning2", true);
            edit.commit();
            sShowHelp = (byte) (sShowHelp | 2);
        }
        if (!z) {
            i = c + 1;
        }
        sWriteAvailable = i;
        return z;
    }

    public static boolean isNeedUpdateSettings() {
        if (!sUpSetting) {
            return false;
        }
        sUpSetting = false;
        return true;
    }

    private static boolean isUseArt() {
        String property = System.getProperty("java.vm.version");
        return property != null && property.startsWith("2");
    }

    public static void removeSavedPwd(int i) {
        if (i >= 0 && i < sSavedPassword.size()) {
            sSavedPassword.remove(i);
        }
    }

    public static void savePassword(Context context) {
        if (context != null) {
            Editor edit = PreferenceManager.getDefaultSharedPreferences(context).edit();
            StringBuilder stringBuilder = new StringBuilder();
            for (String append : sSavedPassword) {
                stringBuilder.append(append);
                stringBuilder.append("!$!@");
            }
            edit.putString("sSavedPassword", stringBuilder.toString());
            edit.commit();
        }
    }

    public static void setHelpRead(Context context) {
        if (context != null) {
            Editor edit = PreferenceManager.getDefaultSharedPreferences(context).edit();
            edit.putInt("iShowHelp", 3);
            edit.commit();
            sShowHelp = (byte) (sShowHelp & -2);
        }
    }

    public static void setLateCompressOpt(Context context, String str, int i, int i2, boolean z) {
        if (!sCompressDefType.equals(str) || sCompressDefLevel != i || sCompressDefEncrypt != i2 || sCompressRemoveFile != z) {
            sCompressDefType = str;
            sCompressDefLevel = i;
            sCompressDefEncrypt = i2;
            sCompressRemoveFile = z;
            if (context != null) {
                Editor edit = PreferenceManager.getDefaultSharedPreferences(context).edit();
                edit.putString("sCompressDefType", sCompressDefType);
                edit.putInt("iCompressDefLevel", sCompressDefLevel);
                edit.putInt("iCompressDefEncrypt", sCompressDefEncrypt);
                edit.putBoolean("bCompressRemoveFile", sCompressRemoveFile);
                edit.commit();
            }
        }
    }

    public static boolean setSelectedMainOptions(Context context, String str, String str2, String str3, String str4) {
        boolean z = false;
        if (context != null) {
            Editor edit = PreferenceManager.getDefaultSharedPreferences(context).edit();
            if (!(sFSIconTheme == getByte(str2) && sTheme == getByte(str) && sLanguage != null && sLanguage.equals(str3))) {
                edit.putString("iFSIconTheme", str2);
                edit.putString("iTheme", str);
                edit.putString("iLanguage", str3);
                sFSIconTheme = getByte(str2);
                sTheme = getByte(str);
                sLanguage = str3;
                z = true;
            }
            edit.putString("iOEMCP", str4);
            sOEMCP = Integer.parseInt(str4);
            edit.putInt("iShowMainOptions", 2);
            edit.commit();
        }
        return z;
    }

    public static void setShowRootWarning(Context context, boolean z) {
        if (z) {
            sShowHelp = (byte) (sShowHelp | 16);
        } else {
            sShowHelp = (byte) (sShowHelp & -17);
        }
        if (context != null) {
            Editor edit = PreferenceManager.getDefaultSharedPreferences(context).edit();
            edit.putBoolean("bShowRootWarning", z);
            edit.commit();
        }
    }

    public static void setShowSDWarning(Context context, boolean z) {
        if (z) {
            sShowHelp = (byte) (sShowHelp | 2);
        } else {
            sShowHelp = (byte) (sShowHelp & -3);
        }
        if (context != null) {
            Editor edit = PreferenceManager.getDefaultSharedPreferences(context).edit();
            edit.putBoolean("bShowSDWarning2", z);
            edit.commit();
        }
    }

    public static void updateStoragePermission(Context context) {
        int i = 1;
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        String storagePermissionCode = getStoragePermissionCode(context);
        boolean z = !C0143a.m430b(context);
        Editor edit = defaultSharedPreferences.edit();
        edit.putBoolean("bNeedWritePermission", z);
        edit.putString("sExtSDCheckedOn", storagePermissionCode);
        edit.commit();
        if (!z) {
            i = C0199n.m699c(context, 2) + 1;
        }
        sWriteAvailable = i;
    }
}
