package ru.zdevs.zarchiver.settings;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.Resources;
import android.os.Environment;
import android.preference.PreferenceManager;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import ru.zdevs.zarchiver.R;
import ru.zdevs.zarchiver.fs.FSStorage;
import ru.zdevs.zarchiver.fs.MyUri;
import ru.zdevs.zarchiver.p003a.C0044c;
import ru.zdevs.zarchiver.tool.C0199n;
import ru.zdevs.zarchiver.tool.C0199n.C0198a;
import ru.zdevs.zarchiver.tool.C0202q;

public class Favorites {
    private static final int[] FAVORITE_ICONS = new int[]{5, 6, 4};
    private static final int[] FAVORITE_NAMES = new int[]{R.string.FVR_DOWNLOAD, R.string.FVR_MUSIC, R.string.FVR_DOCUMENTS};
    private static final String[] FAVORITE_PATHS = new String[]{Environment.DIRECTORY_DOWNLOADS, Environment.DIRECTORY_MUSIC, "Documents"};
    private static List<C0044c> mCustomName;
    private static int mFavoriteAuto;
    private static int mFavoriteConst;
    private static final List<C0044c> mFavoriteList = new ArrayList();

    public static void addFavorite(Context context, int i, String str, String str2) {
        if (context != null) {
            SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
            String str3 = defaultSharedPreferences.getString("sFavorite", "") + "(" + i + ")[" + str + "]" + str2 + "|";
            Editor edit = defaultSharedPreferences.edit();
            edit.putString("sFavorite", str3);
            edit.commit();
            MyUri myUri = str2.startsWith("/SAF") ? new MyUri(FSStorage.SCHEME, str2) : new MyUri(str2);
            synchronized (mFavoriteList) {
                mFavoriteList.add(new C0044c(i, str, myUri));
            }
        }
    }

    private static void buildFaveList(Context context) {
        Resources resources = context.getResources();
        List<C0198a> b = C0199n.m695b(context, 255);
        mFavoriteList.clear();
        if (C0199n.m690a(Settings.sHomeDir) == null) {
            mFavoriteList.add(new C0044c(2, resources.getString(R.string.FVR_HOME), new MyUri(Settings.sHomeDir)));
        }
        if (Settings.sArchiveDir != null) {
            mFavoriteList.add(new C0044c(3, resources.getString(R.string.FVR_ARCHIVE), new MyUri(Settings.sArchiveDir)));
        }
        if (Settings.sRoot) {
            mFavoriteList.add(new C0044c(-2, "ROOT", new MyUri("/")));
        }
        mFavoriteConst = mFavoriteList.size();
        if (mCustomName == null) {
            loadCustomName(context);
        }
        int i = 0;
        int i2 = 0;
        int i3 = 0;
        for (C0198a c0198a : b) {
            int i4;
            int i5;
            switch (c0198a.f544d) {
                case (byte) 0:
                    i4 = i;
                    i5 = i2;
                    i = i3 + 1;
                    break;
                case (byte) 2:
                    i4 = i;
                    i5 = i2 + 1;
                    i = i3;
                    break;
                case (byte) 4:
                    i4 = i + 1;
                    i5 = i2;
                    i = i3;
                    break;
                default:
                    i4 = i;
                    i5 = i2;
                    i = i3;
                    break;
            }
            i2 = i5;
            i3 = i;
            i = i4;
        }
        int i6 = 1;
        int i7 = 1;
        int i8 = 1;
        for (C0198a c0198a2 : b) {
            String str = null;
            i5 = -1;
            if (mCustomName != null) {
                String str2 = null;
                int i9 = -1;
                for (C0044c c0044c : mCustomName) {
                    if (c0198a2.f542b.equals(c0044c.f114c.toLocalPath())) {
                        str2 = c0044c.f113b;
                        i9 = c0044c.f112a;
                    }
                }
                i5 = i9;
                str = str2;
            }
            if (str == null) {
                switch (c0198a2.f544d) {
                    case (byte) 0:
                        str = resources.getString(R.string.FVR_DEVICE).replace("%1", i3 > 1 ? "" + i8 : "");
                        i5 = i6;
                        i6 = i7;
                        i7 = i8 + 1;
                        i8 = -1;
                        break;
                    case (byte) 1:
                        str = resources.getString(R.string.FVR_INTERNAL);
                        i5 = i6;
                        i6 = i7;
                        i7 = i8;
                        i8 = -1;
                        break;
                    case (byte) 2:
                        str = resources.getString(R.string.FVR_EXTERNAL).replace("%1", i2 > 1 ? "" + i7 : "");
                        i5 = i6;
                        i6 = i7 + 1;
                        i7 = i8;
                        i8 = 1;
                        break;
                    case (byte) 4:
                        str = resources.getString(R.string.FVR_EXTERNAL_USB).replace("%1", i > 1 ? "" + i6 : "");
                        i5 = i6 + 1;
                        i6 = i7;
                        i7 = i8;
                        i8 = 0;
                        break;
                }
            }
            int i10 = i5;
            i5 = i6;
            i6 = i7;
            i7 = i8;
            i8 = i10;
            if (str == null) {
                i8 = i7;
                i7 = i6;
                i6 = i5;
            } else {
                synchronized (mFavoriteList) {
                    mFavoriteList.add(new C0044c(i8, str, new MyUri(c0198a2.f542b), true));
                }
                i8 = i7;
                i7 = i6;
                i6 = i5;
            }
        }
        mFavoriteAuto = mFavoriteList.size();
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        String string = defaultSharedPreferences.getString("sFavorite", "");
        if ((string == null || string.length() <= 0) && !defaultSharedPreferences.getBoolean("sFavoGenerated", false)) {
            string = defaultFaveList(context);
        }
        for (String str3 : C0202q.m734a(r1, '|')) {
            String str32;
            if (str32.length() >= 6) {
                if (str32.charAt(0) == '(') {
                    string = str32.substring(1, str32.indexOf(41));
                    str32 = str32.substring(str32.indexOf(41) + 1);
                } else {
                    string = "0";
                }
                String substring = str32.substring(1, str32.indexOf(93));
                str32 = str32.substring(str32.indexOf(93) + 1);
                synchronized (mFavoriteList) {
                    mFavoriteList.add(new C0044c(Integer.parseInt(string), substring, str32.startsWith("/SAF") ? new MyUri(FSStorage.SCHEME, str32) : new MyUri(str32)));
                }
            }
        }
    }

    private static String defaultFaveList(Context context) {
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < FAVORITE_PATHS.length; i++) {
            try {
                File externalStoragePublicDirectory = Environment.getExternalStoragePublicDirectory(FAVORITE_PATHS[i]);
                if (externalStoragePublicDirectory.exists()) {
                    stringBuilder.append('(');
                    stringBuilder.append(FAVORITE_ICONS[i]);
                    stringBuilder.append(")[");
                    stringBuilder.append(context.getString(FAVORITE_NAMES[i]));
                    stringBuilder.append(']');
                    stringBuilder.append(externalStoragePublicDirectory.getAbsolutePath());
                    stringBuilder.append('|');
                }
            } catch (Exception e) {
            }
        }
        String stringBuilder2 = stringBuilder.toString();
        Editor edit = PreferenceManager.getDefaultSharedPreferences(context).edit();
        edit.putBoolean("sFavoGenerated", true);
        edit.putString("sFavorite", stringBuilder2);
        edit.commit();
        return stringBuilder2;
    }

    public static void delFavorite(Context context, int i) {
        if (context != null && isRemovable(i)) {
            int i2 = i - mFavoriteAuto;
            if (i2 >= 0) {
                SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
                String string = defaultSharedPreferences.getString("sFavorite", "");
                if (string.length() > 0) {
                    String[] a = C0202q.m734a(string, '|');
                    StringBuilder stringBuilder = new StringBuilder();
                    for (int i3 = 0; i3 < a.length; i3++) {
                        if (i3 != i2) {
                            stringBuilder.append(a[i3]).append('|');
                        }
                    }
                    Editor edit = defaultSharedPreferences.edit();
                    edit.putString("sFavorite", stringBuilder.toString());
                    edit.commit();
                    synchronized (mFavoriteList) {
                        mFavoriteList.remove(i2);
                    }
                }
            }
        }
    }

    public static List<C0044c> getFavorites(Context context) {
        if (mFavoriteList.size() <= 0) {
            updateFavorites(context);
        }
        return mFavoriteList;
    }

    public static C0044c getItem(int i) {
        if (i >= mFavoriteList.size() || i < 0) {
            return null;
        }
        C0044c c0044c;
        synchronized (mFavoriteList) {
            c0044c = (C0044c) mFavoriteList.get(i);
        }
        return c0044c;
    }

    public static boolean isRemovable(int i) {
        return i < mFavoriteList.size() && i >= 0 && i >= mFavoriteAuto;
    }

    public static boolean isRename(int i) {
        return i < mFavoriteList.size() && i >= 0 && i >= mFavoriteConst;
    }

    private static void loadCustomName(Context context) {
        mCustomName = new ArrayList();
        mCustomName.clear();
        String string = PreferenceManager.getDefaultSharedPreferences(context).getString("sFavoriteCustomName", "");
        if (string.length() > 0) {
            String[] a = C0202q.m734a(string, '|');
            if (a.length > 0) {
                for (String string2 : a) {
                    if (string2.length() >= 6) {
                        String substring = string2.substring(1, string2.indexOf(41));
                        string2 = string2.substring(string2.indexOf(41) + 1);
                        String substring2 = string2.substring(1, string2.indexOf(93));
                        String substring3 = string2.substring(string2.indexOf(93) + 1);
                        mCustomName.add(new C0044c(Integer.parseInt(substring), substring2, substring3.startsWith("/SAF") ? new MyUri(FSStorage.SCHEME, substring3) : new MyUri(substring3)));
                    }
                }
            }
        }
    }

    public static void renameFavorite(Context context, int i, int i2, String str) {
        int i3 = 0;
        if (context != null || isRename(i)) {
            C0044c c0044c;
            synchronized (mFavoriteList) {
                c0044c = (C0044c) mFavoriteList.get(i);
            }
            if (i >= mFavoriteAuto) {
                i -= mFavoriteAuto;
                if (i >= 0) {
                    SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
                    String string = defaultSharedPreferences.getString("sFavorite", "");
                    if (string.length() > 0) {
                        String[] a = C0202q.m734a(string, '|');
                        StringBuilder stringBuilder = new StringBuilder();
                        while (i3 < a.length) {
                            if (i3 != i) {
                                stringBuilder.append(a[i3]);
                                stringBuilder.append('|');
                            } else {
                                stringBuilder.append('(');
                                stringBuilder.append(i2);
                                stringBuilder.append(")[");
                                stringBuilder.append(str);
                                stringBuilder.append(']');
                                stringBuilder.append(c0044c.f114c.toLocalPath());
                                stringBuilder.append('|');
                            }
                            i3++;
                        }
                        Editor edit = defaultSharedPreferences.edit();
                        edit.putString("sFavorite", stringBuilder.toString());
                        edit.commit();
                    } else {
                        return;
                    }
                }
                return;
            }
            if (mCustomName == null) {
                loadCustomName(context);
            }
            if (mCustomName != null) {
                int i4 = 0;
                for (C0044c c0044c2 : mCustomName) {
                    if (c0044c.f114c.compareTo(c0044c2.f114c) == 0) {
                        c0044c2.f113b = str;
                        c0044c2.f112a = i2;
                        i3 = 1;
                    } else {
                        i3 = i4;
                    }
                    i4 = i3;
                }
                if (i4 == 0) {
                    mCustomName.add(new C0044c(i2, str, c0044c.f114c));
                }
                saveCustomName(context);
            } else {
                return;
            }
            synchronized (mFavoriteList) {
                if (i < mFavoriteList.size()) {
                    ((C0044c) mFavoriteList.get(i)).f113b = str;
                    ((C0044c) mFavoriteList.get(i)).f112a = i2;
                }
            }
        }
    }

    private static void saveCustomName(Context context) {
        if (mCustomName != null) {
            StringBuilder stringBuilder = new StringBuilder();
            for (C0044c c0044c : mCustomName) {
                if (c0044c != null) {
                    stringBuilder.append('(');
                    stringBuilder.append(c0044c.f112a);
                    stringBuilder.append(")[");
                    stringBuilder.append(c0044c.f113b);
                    stringBuilder.append(']');
                    stringBuilder.append(c0044c.f114c.toLocalPath());
                    stringBuilder.append('|');
                }
            }
            Editor edit = PreferenceManager.getDefaultSharedPreferences(context).edit();
            edit.putString("sFavoriteCustomName", stringBuilder.toString());
            edit.commit();
        }
    }

    public static void updateFavorites(Context context) {
        synchronized (mFavoriteList) {
            mFavoriteList.clear();
        }
        buildFaveList(context);
    }
}
