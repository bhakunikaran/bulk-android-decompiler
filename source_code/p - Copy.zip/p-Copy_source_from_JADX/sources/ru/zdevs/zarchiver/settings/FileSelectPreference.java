package ru.zdevs.zarchiver.settings;

import android.annotation.SuppressLint;
import android.content.Context;
import android.preference.DialogPreference;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.io.File;
import ru.zdevs.zarchiver.R;
import ru.zdevs.zarchiver.fs.MyUri;
import ru.zdevs.zarchiver.p003a.C0047d;
import ru.zdevs.zarchiver.tool.C0178g;
import ru.zdevs.zarchiver.tool.C0199n;
import ru.zdevs.zarchiver.widget.FSSelect;
import ru.zdevs.zarchiver.widget.FSSelect.OnFileSelectListener;
import ru.zdevs.zarchiver.widget.FSSelect.OnPathChangeListener;

public class FileSelectPreference extends DialogPreference implements OnFileSelectListener, OnPathChangeListener {
    private static final String ANDROID_NS = "http://schemas.android.com/apk/res/android";
    private static final String ATTR_DEFAULT_VALUE = "defaultValue";
    private static final String ATTR_TYPE_VALUE = "folderSelect";
    private static final String PREFERENCE_NS = "http://schemas.android.com/apk/res/ru.zdevs.zarchiver";
    private String mCurrentValue;
    private String mDefaultValue;
    private FSSelect mFSSelect;
    private C0178g mImageLoader;
    private int mType;
    private TextView mValueText;

    @SuppressLint({"SdCardPath"})
    public FileSelectPreference(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.mType = attributeSet.getAttributeIntValue(PREFERENCE_NS, ATTR_TYPE_VALUE, 0);
        if (this.mType == 0) {
            setPositiveButtonText(null);
        }
        this.mDefaultValue = attributeSet.getAttributeValue(ANDROID_NS, ATTR_DEFAULT_VALUE);
        if (this.mDefaultValue != null && this.mDefaultValue.contains("$SD$")) {
            this.mDefaultValue = this.mDefaultValue.replace("$SD$", C0199n.m689a() == null ? "/sdcard" : C0199n.m689a().f542b);
        }
        this.mCurrentValue = "";
    }

    private void getCurrentValue() {
        this.mCurrentValue = getPersistedString(this.mDefaultValue);
    }

    protected View onCreateDialogView() {
        super.onCreateDialogView();
        getCurrentValue();
        if (this.mCurrentValue == null) {
            this.mCurrentValue = C0199n.m689a().f542b;
        }
        View inflate = ((LayoutInflater) getContext().getSystemService("layout_inflater")).inflate(R.layout.dialog_select_file, new LinearLayout(getContext()));
        this.mValueText = (TextView) inflate.findViewById(R.id.current_value);
        this.mFSSelect = (FSSelect) inflate.findViewById(R.id.fs_select);
        this.mFSSelect.setOnFileSelectListener(this);
        this.mFSSelect.setOnPathChangeListener(this);
        File file = new File(this.mCurrentValue);
        if (file.exists()) {
            if (file.isDirectory()) {
                this.mFSSelect.setCurrentPath(new MyUri(file.getAbsolutePath()));
            } else {
                this.mFSSelect.setCurrentPath(new MyUri(file.getParentFile().getAbsolutePath()));
            }
        }
        this.mImageLoader = new C0178g(getContext());
        this.mImageLoader.m618b();
        C0047d.m84a(this.mImageLoader);
        return inflate;
    }

    protected View onCreateView(ViewGroup viewGroup) {
        getCurrentValue();
        if (this.mCurrentValue != null) {
            setSummary(this.mCurrentValue);
        }
        return super.onCreateView(viewGroup);
    }

    protected void onDialogClosed(boolean z) {
        super.onDialogClosed(z);
        C0047d.m84a(null);
        if (this.mImageLoader != null) {
            this.mImageLoader.m615a();
            this.mImageLoader = null;
        }
        if (z) {
            if (shouldPersist()) {
                this.mCurrentValue = this.mFSSelect.mCurrentPath.toLocalPath();
                persistString(this.mCurrentValue);
            }
            notifyChanged();
        }
    }

    public void onFileSelect(String str, String str2) {
        if (this.mType == 0) {
            this.mCurrentValue = str + "/" + str2;
            if (shouldPersist()) {
                persistString(this.mCurrentValue);
            }
            notifyChanged();
            getDialog().dismiss();
        }
    }

    public void onPathChange(String str) {
        this.mValueText.setText(str);
    }
}
