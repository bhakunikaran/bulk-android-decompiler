package ru.zdevs.zarchiver.fs;

import android.content.Context;
import android.os.AsyncTask;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import ru.zdevs.zarchiver.R;
import ru.zdevs.zarchiver.fs.ZViewFS.FSFileInfo;
import ru.zdevs.zarchiver.p003a.C0049e;
import ru.zdevs.zarchiver.p004b.C0073a;
import ru.zdevs.zarchiver.p004b.C0074b;
import ru.zdevs.zarchiver.p004b.C0075c;
import ru.zdevs.zarchiver.p004b.C0082i.C0081a;
import ru.zdevs.zarchiver.p004b.C0083j;
import ru.zdevs.zarchiver.settings.Settings;
import ru.zdevs.zarchiver.tool.C0166c;

public class FSRoot extends ZViewFS {
    private static final byte OVERLAY_APP_APP = (byte) 3;
    private static final byte OVERLAY_APP_DATA = (byte) 2;
    private static final byte OVERLAY_DATA = (byte) 1;
    private static final byte OVERLAY_NONE = (byte) 0;
    public static final String SCHEME = "root";
    private int mMes = 0;
    private C0075c mSu = null;

    public static FSFileInfo getFileInfo(File file) {
        C0073a c0074b = new C0074b();
        FSFileInfo fileInfo = getFileInfo(c0074b, file);
        c0074b.mo54c();
        return fileInfo;
    }

    public static FSFileInfo getFileInfo(C0073a c0073a, File file) {
        boolean z = true;
        if (c0073a == null) {
            return null;
        }
        List arrayList = new ArrayList();
        if (!C0083j.m342a(c0073a, arrayList, file.getAbsolutePath(), sFMHideFile, true) || arrayList.size() <= 0) {
            return null;
        }
        FSFileInfo fSFileInfo = new FSFileInfo();
        C0081a c0081a = (C0081a) arrayList.get(0);
        if (c0081a.f271a != null && c0081a.f271a.endsWith(file.getName())) {
            if (c0081a.f277g) {
                z = false;
            }
            fSFileInfo.mIsFile = z;
            fSFileInfo.mLastMod = c0081a.f273c;
            fSFileInfo.mSize = c0081a.f272b;
            fSFileInfo.mIsLink = c0081a.f278h;
            fSFileInfo.mLinkTo = c0081a.f279i;
            fSFileInfo.mGID = c0081a.f276f;
            fSFileInfo.mUID = c0081a.f275e;
            fSFileInfo.mPermissions = c0081a.f274d;
        }
        return fSFileInfo;
    }

    private byte getOverlay(String str, byte b) {
        if (str == null || b == (byte) 0) {
            return (byte) 0;
        }
        switch (b) {
            case (byte) 1:
                return str.equals("app") ? (byte) 3 : str.equals("data") ? (byte) 19 : (byte) 0;
            case (byte) 2:
                return ZFileInfo.OVERLAY_TYPE_APP_DATA;
            case (byte) 3:
                return ZFileInfo.OVERLAY_TYPE_APP_APP;
            default:
                return (byte) 0;
        }
    }

    private byte getOverlayScheme(File file) {
        try {
            String canonicalPath = file.getCanonicalPath();
            if (canonicalPath.equals("/data")) {
                return (byte) 1;
            }
            if (canonicalPath.equals("/data/data") || canonicalPath.equals("/data/app")) {
                return (byte) 2;
            }
            if (canonicalPath.equals("/system/app") || canonicalPath.equals("/system/priv-app")) {
                return (byte) 3;
            }
            return (byte) 0;
        } catch (Throwable e) {
            C0166c.m556a(e);
        }
    }

    private boolean list_local(Context context, MyUri myUri, List<C0049e> list) {
        for (ZViewFS zViewFS : ZViewFS.get()) {
            if (zViewFS instanceof FSLocal) {
                boolean list2 = zViewFS.list(context, myUri, list, 2);
                this.mMes = zViewFS.getMessage();
                return list2;
            }
        }
        this.mMes = R.string.MES_ACCESS_DENIED;
        return true;
    }

    private void startSu() {
        if (C0073a.m304f()) {
            this.mSu = new C0075c();
            if (!this.mSu.mo52b()) {
                this.mSu = null;
            }
        }
    }

    private void stopSu() {
        if (this.mSu != null) {
            this.mSu.mo54c();
            this.mSu = null;
        }
    }

    public FSFileInfo getFileInfo(MyUri myUri, AsyncTask<?, ?, ?> asyncTask) {
        FSFileInfo fSFileInfo = null;
        if (myUri.isLocalFS()) {
            startSu();
            try {
                fSFileInfo = getFileInfo(this.mSu, myUri.toFile());
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
            stopSu();
        }
        return fSFileInfo;
    }

    public FSFileInfo getFilesInfo(MyUri myUri, String[] strArr, AsyncTask<?, ?, ?> asyncTask) {
        return null;
    }

    public FSFileInfo getFilesInfo(MyUri[] myUriArr, String[] strArr, AsyncTask<?, ?, ?> asyncTask) {
        return null;
    }

    public int getMessage() {
        return this.mMes;
    }

    public boolean list(Context context, MyUri myUri, List<C0049e> list, int i) {
        this.mMes = 0;
        if (!Settings.sRoot || !C0073a.m304f()) {
            return list_local(context, myUri, list);
        }
        File toFile = myUri.toFile();
        if (toFile == null) {
            return false;
        }
        list.clear();
        C0073a c0075c = new C0075c();
        if (!c0075c.mo52b()) {
            return list_local(context, myUri, list);
        }
        List<C0081a> arrayList = new ArrayList();
        if (C0083j.m342a(c0075c, arrayList, toFile.getAbsolutePath(), sFMHideFile, false)) {
            byte overlayScheme = getOverlayScheme(toFile);
            try {
                for (C0081a c0081a : arrayList) {
                    if (c0081a.f271a != null) {
                        boolean z;
                        byte b;
                        byte overlay;
                        if (!c0081a.f278h || c0081a.f279i == null) {
                            z = c0081a.f277g;
                        } else {
                            List arrayList2 = new ArrayList();
                            C0083j.m342a(c0075c, arrayList2, !c0081a.f279i.startsWith("/") ? toFile.getAbsolutePath() + "/" + c0081a.f279i : c0081a.f279i, true, true);
                            if (arrayList2.size() == 1) {
                                C0081a c0081a2 = (C0081a) arrayList2.get(0);
                                boolean z2 = c0081a2.f277g;
                                c0081a.f272b = c0081a2.f272b;
                                z = z2;
                            } else {
                                z = arrayList2.size() > 1 ? true : c0081a.f277g;
                            }
                        }
                        if (z) {
                            b = (byte) 2;
                            overlay = getOverlay(c0081a.f271a, overlayScheme);
                        } else {
                            b = ZFileInfo.getFileType(c0081a.f271a);
                            overlay = (byte) 0;
                        }
                        list.add(new C0049e(c0081a.f271a, b, overlay, c0081a.f273c, c0081a.f278h ? -2 : c0081a.f272b));
                    }
                }
                if (list.size() <= 0) {
                    this.mMes = R.string.MES_EMPTY_FOLDER;
                }
                ZViewFS.sort(list);
            } catch (Throwable e) {
                C0166c.m556a(e);
                this.mMes = R.string.MES_EMPTY_FOLDER;
            }
            c0075c.mo54c();
            if (toFile.getParent() != null && (sAddFolderUp || (i & 4) != 0)) {
                list.add(0, new C0049e("..", (byte) 1, 0, 0));
            }
            myUri.setScheme(SCHEME);
            return true;
        }
        c0075c.mo54c();
        if (toFile.getParent() != null && (sAddFolderUp || (i & 4) != 0)) {
            list.add(0, new C0049e("..", (byte) 1, 0, 0));
        }
        this.mMes = R.string.MES_ACCESS_DENIED;
        return true;
    }
}
