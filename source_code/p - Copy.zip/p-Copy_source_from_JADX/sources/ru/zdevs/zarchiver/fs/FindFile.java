package ru.zdevs.zarchiver.fs;

import android.app.Activity;
import java.util.Iterator;
import java.util.Locale;
import ru.zdevs.zarchiver.fs.ZViewFS.FSFileInfo;
import ru.zdevs.zarchiver.fs.ZViewFS.FindResultListener;
import ru.zdevs.zarchiver.tool.C0166c;

public class FindFile implements FindResultListener {
    private static final String TAG = "FindFile";
    private Activity mContext;
    private C0141a mFindFileThread;
    private FindResultListener mFindResultListener;

    /* renamed from: ru.zdevs.zarchiver.fs.FindFile$2 */
    class C01382 implements Runnable {
        /* renamed from: a */
        final /* synthetic */ FindFile f367a;

        C01382(FindFile findFile) {
            this.f367a = findFile;
        }

        public void run() {
            this.f367a.mFindResultListener.onEndFind();
        }
    }

    /* renamed from: ru.zdevs.zarchiver.fs.FindFile$3 */
    class C01393 implements Runnable {
        /* renamed from: a */
        final /* synthetic */ FindFile f368a;

        C01393(FindFile findFile) {
            this.f368a = findFile;
        }

        public void run() {
            this.f368a.mFindResultListener.onStartFind();
        }
    }

    /* renamed from: ru.zdevs.zarchiver.fs.FindFile$a */
    private final class C0141a extends Thread {
        /* renamed from: a */
        String f371a;
        /* renamed from: b */
        MyUri f372b;
        /* renamed from: c */
        FindResultListener f373c;
        /* renamed from: d */
        final /* synthetic */ FindFile f374d;

        C0141a(FindFile findFile, MyUri myUri, String str, FindResultListener findResultListener) {
            this.f374d = findFile;
            this.f371a = str;
            this.f372b = myUri;
            this.f373c = findResultListener;
        }

        public void run() {
            try {
                Iterator it = ZViewFS.get().iterator();
                while (it.hasNext() && !((ZViewFS) it.next()).getSearchFile(this, this.f372b, this.f371a, this.f373c)) {
                    if (isInterrupted()) {
                        break;
                    }
                }
                synchronized (this.f374d.mFindFileThread) {
                    this.f374d.mFindFileThread = null;
                }
                if (isInterrupted()) {
                    this.f374d.onEndFind();
                }
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
        }
    }

    public FindFile(FindResultListener findResultListener, Activity activity) {
        this.mFindResultListener = findResultListener;
        this.mContext = activity;
    }

    public boolean isSearch() {
        return this.mFindFileThread != null && this.mFindFileThread.isAlive();
    }

    public void onEndFind() {
        if (this.mContext != null && this.mFindResultListener != null) {
            this.mContext.runOnUiThread(new C01382(this));
        }
    }

    public void onFoundNewFile(final FSFileInfo fSFileInfo, final MyUri myUri, final String str) {
        if (this.mContext != null && this.mFindResultListener != null) {
            this.mContext.runOnUiThread(new Runnable(this) {
                /* renamed from: d */
                final /* synthetic */ FindFile f366d;

                public void run() {
                    this.f366d.mFindResultListener.onFoundNewFile(fSFileInfo, myUri, str);
                }
            });
        }
    }

    public void onSetFindProcess(final int i) {
        if (this.mContext != null && this.mFindResultListener != null) {
            this.mContext.runOnUiThread(new Runnable(this) {
                /* renamed from: b */
                final /* synthetic */ FindFile f370b;

                public void run() {
                    this.f370b.mFindResultListener.onSetFindProcess(i);
                }
            });
        }
    }

    public void onStartFind() {
        if (this.mContext != null && this.mFindResultListener != null) {
            this.mContext.runOnUiThread(new C01393(this));
        }
    }

    public void startFindFile(MyUri myUri, String str) {
        if (this.mFindFileThread != null) {
            this.mFindFileThread.interrupt();
        }
        String replace = str.toLowerCase(Locale.getDefault()).replace("\\*", "\\###").replace("*", ".*").replace("\\###", "\\*");
        if (!replace.contains(".*")) {
            replace = ".*" + replace + ".*";
        }
        C0166c.m555a(TAG, "Start. Pattern: " + replace);
        this.mFindFileThread = new C0141a(this, myUri, replace, this);
        this.mFindFileThread.start();
    }

    public void stopFindFile() {
        if (this.mFindFileThread != null) {
            this.mFindFileThread.interrupt();
            this.mFindFileThread = null;
        }
    }
}
