package ru.zdevs.zarchiver.fs;

import android.content.Context;
import android.os.AsyncTask;
import java.util.ArrayList;
import java.util.List;
import ru.zdevs.zarchiver.R;
import ru.zdevs.zarchiver.ZArchiver;
import ru.zdevs.zarchiver.archiver.C0061a;
import ru.zdevs.zarchiver.archiver.C0066d;
import ru.zdevs.zarchiver.archiver.C0071e;
import ru.zdevs.zarchiver.fs.ZViewFS.FSFileInfo;
import ru.zdevs.zarchiver.fs.ZViewFS.FindResultListener;
import ru.zdevs.zarchiver.p003a.C0049e;
import ru.zdevs.zarchiver.tool.C0166c;

public class FSArchive extends ZViewFS {
    public static final String SCHEME = "arch";
    private int mMes = 0;

    private void search_file(Thread thread, String str, String str2, String str3, FindResultListener findResultListener) {
        if (thread != null) {
            try {
                if (thread.isInterrupted()) {
                    return;
                }
            } catch (Throwable e) {
                C0166c.m556a(e);
                return;
            }
        }
        List<C0049e> arrayList = new ArrayList();
        C0061a.m204a(str2, arrayList, null);
        for (C0049e c0049e : arrayList) {
            if (c0049e.mo28e().matches(str3)) {
                FSFileInfo fSFileInfo = new FSFileInfo();
                fSFileInfo.mIsFile = !c0049e.m107b();
                fSFileInfo.mLastMod = c0049e.m116k();
                fSFileInfo.mSize = c0049e.m115j();
                findResultListener.onFoundNewFile(fSFileInfo, new MyUri(SCHEME, "", str, str2), c0049e.mo28e());
            }
            if (c0049e.m107b()) {
                search_file(thread, str, str2 + c0049e.mo28e() + '/', str3, findResultListener);
            }
            if (thread != null && thread.isInterrupted()) {
                return;
            }
        }
    }

    public FSFileInfo getFileInfo(MyUri myUri, AsyncTask<?, ?, ?> asyncTask) {
        FSFileInfo fSFileInfo = null;
        if (myUri.isArchive()) {
            try {
                fSFileInfo = C0061a.m202a(myUri.getFragment(), (AsyncTask) asyncTask);
            } catch (Exception e) {
            }
        }
        return fSFileInfo;
    }

    public FSFileInfo getFilesInfo(MyUri myUri, String[] strArr, AsyncTask<?, ?, ?> asyncTask) {
        FSFileInfo fSFileInfo = null;
        if (myUri.isArchive()) {
            try {
                List arrayList = new ArrayList();
                String fragment = myUri.getFragment();
                for (String str : strArr) {
                    if (str != null) {
                        arrayList.add(fragment + "/" + str);
                    }
                }
                fSFileInfo = C0061a.m203a(arrayList, (AsyncTask) asyncTask);
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
        }
        return fSFileInfo;
    }

    public FSFileInfo getFilesInfo(MyUri[] myUriArr, String[] strArr, AsyncTask<?, ?, ?> asyncTask) {
        FSFileInfo fSFileInfo = null;
        int i = 0;
        if (myUriArr != null && myUriArr[0].isArchive()) {
            try {
                List arrayList = new ArrayList();
                while (i < strArr.length) {
                    if (!(myUriArr[i] == null || strArr[i] == null)) {
                        arrayList.add(myUriArr[i].getFragment() + "/" + strArr[i]);
                    }
                    i++;
                }
                fSFileInfo = C0061a.m203a(arrayList, (AsyncTask) asyncTask);
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
        }
        return fSFileInfo;
    }

    public int getMessage() {
        return this.mMes;
    }

    public boolean getSearchFile(Thread thread, MyUri myUri, String str, FindResultListener findResultListener) {
        if (!myUri.isArchive() || findResultListener == null) {
            return false;
        }
        String path = myUri.getPath();
        String fragment = myUri.getFragment();
        if (fragment.length() > 0 && !fragment.endsWith("/")) {
            fragment = fragment + "/";
        }
        try {
            if (!C0061a.m213c(path)) {
                return false;
            }
        } catch (Throwable e) {
            C0166c.m556a(e);
        }
        findResultListener.onStartFind();
        try {
            findResultListener.onSetFindProcess(10);
            List<C0066d> a = C0061a.m201a(fragment, str, true, thread);
            if (a == null) {
                List<C0049e> arrayList = new ArrayList();
                C0061a.m204a(fragment, arrayList, null);
                String substring = (fragment.length() <= 0 || !fragment.startsWith("/")) ? fragment : fragment.substring(1);
                int size = arrayList.size();
                int i = 0;
                for (C0049e c0049e : arrayList) {
                    if (c0049e.mo28e().matches(str)) {
                        FSFileInfo fSFileInfo = new FSFileInfo();
                        fSFileInfo.mIsFile = !c0049e.m107b();
                        fSFileInfo.mLastMod = c0049e.m116k();
                        fSFileInfo.mSize = c0049e.m115j();
                        findResultListener.onFoundNewFile(fSFileInfo, new MyUri(SCHEME, "", path, substring), c0049e.mo28e());
                    }
                    if (c0049e.m107b()) {
                        search_file(thread, path, substring + c0049e.mo28e() + '/', str, findResultListener);
                    }
                    if (thread != null && thread.isInterrupted()) {
                        break;
                    }
                    int i2 = i + 1;
                    findResultListener.onSetFindProcess((i2 * 100) / size);
                    i = i2;
                }
            } else {
                findResultListener.onSetFindProcess(66);
                for (C0066d c0066d : a) {
                    String b = c0066d.m275b();
                    if (b.length() > 0 && b.charAt(0) == '/') {
                        b = b.substring(1);
                    }
                    String str2 = "";
                    int lastIndexOf = b.lastIndexOf(47);
                    if (lastIndexOf > 0 && lastIndexOf + 1 < b.length()) {
                        str2 = b.substring(0, lastIndexOf);
                        b = b.substring(lastIndexOf + 1);
                    }
                    findResultListener.onFoundNewFile(c0066d.m271a(), new MyUri(SCHEME, "", path, str2), b);
                }
                findResultListener.onSetFindProcess(100);
            }
        } catch (Throwable e2) {
            C0166c.m556a(e2);
        }
        findResultListener.onEndFind();
        return true;
    }

    public boolean list(Context context, MyUri myUri, List<C0049e> list, int i) {
        this.mMes = 0;
        if (!myUri.isArchive()) {
            return false;
        }
        list.clear();
        String path = myUri.getPath();
        String fragment = myUri.getFragment();
        try {
            if (!(C0061a.m213c(path) && (i & 1) == 0 && (C0061a.m218f() == 0 || C0061a.m218f() == 3))) {
                C0071e.m291a(((ZArchiver) context).cs, context, path);
            }
            if (!C0061a.m213c(path) || ((i & 1) == 0 && C0061a.m218f() == 13)) {
                this.mMes = R.string.MES_CANCEL_PROCES;
                if (sAddFolderUp && (i & 4) == 0) {
                    return true;
                }
                list.add(0, new C0049e("..", (byte) 1, 0, 0));
                return true;
            }
            C0061a.m204a(fragment, list, null);
            if (list.size() <= 0) {
                int f = C0061a.m218f();
                if (f == 2) {
                    this.mMes = R.string.ERROR_WRONG_PASSWORD;
                } else if (f == 3) {
                    this.mMes = R.string.MES_CORRUP_ARCHICHE;
                } else if (f == 13) {
                    this.mMes = R.string.MES_CANCEL_PROCES;
                } else if (f == 200) {
                    this.mMes = R.string.MES_ACCESS_DENIED;
                } else {
                    this.mMes = R.string.MES_EMPTY_FOLDER;
                }
            }
            ZViewFS.sort(list);
            if (sAddFolderUp) {
            }
            list.add(0, new C0049e("..", (byte) 1, 0, 0));
            return true;
        } catch (Throwable e) {
            C0166c.m556a(e);
        }
    }
}
