package ru.zdevs.zarchiver.fs;

import android.content.Context;
import java.util.ArrayList;
import java.util.List;
import ru.zdevs.zarchiver.C0093d;
import ru.zdevs.zarchiver.C0136e;
import ru.zdevs.zarchiver.R;
import ru.zdevs.zarchiver.archiver.C0061a;
import ru.zdevs.zarchiver.dialog.ZMenuDialog;
import ru.zdevs.zarchiver.p003a.C0049e;
import ru.zdevs.zarchiver.p003a.C0052g;
import ru.zdevs.zarchiver.settings.Settings;

public class FileArchive extends ZOpenFile {
    public C0136e mCS;

    public FileArchive(C0136e c0136e) {
        this.mCS = c0136e;
    }

    public boolean open(Context context, MyUri myUri, int[] iArr, List<C0049e> list, int i, int i2) {
        if (this.mCS.m414j() != '\u0000') {
            return false;
        }
        if (!myUri.isArchive()) {
            return false;
        }
        List arrayList = new ArrayList();
        C0093d c0093d = new C0093d(context);
        String path = myUri.getPath();
        String e = iArr.length == 1 ? ((C0049e) list.get(iArr[0])).mo28e() : context.getString(R.string.MENU_SELECTED_FILES);
        if (iArr.length == 1) {
            c0093d.m374a(arrayList, 2);
        }
        c0093d.m374a(arrayList, 4);
        if (iArr.length == 1 && C0061a.m211b(context, path)) {
            c0093d.m374a(arrayList, 57);
        }
        if (C0061a.m205a(context, path)) {
            c0093d.m374a(arrayList, 56);
        }
        ZMenuDialog zMenuDialog = new ZMenuDialog(this.mCS, context, arrayList, e, i, i2);
        zMenuDialog.setOnOkListener(this.mCS.f350a);
        zMenuDialog.show();
        this.mCS.f350a.fillFileListAction(iArr, false);
        return true;
    }

    public boolean open_find(Context context, MyUri myUri, int[] iArr, List<C0052g> list, int i, int i2) {
        if (this.mCS.m414j() != '\u0000' || !myUri.isArchive() || iArr.length <= 0) {
            return false;
        }
        List arrayList = new ArrayList();
        C0093d c0093d = new C0093d(context);
        String path = myUri.getPath();
        String e = iArr.length == 1 ? ((C0052g) list.get(iArr[0])).mo28e() : context.getString(R.string.MENU_SELECTED_FILES);
        if (iArr.length == 1 && !Settings.sOpenFile) {
            c0093d.m374a(arrayList, 2);
        }
        c0093d.m374a(arrayList, 4);
        c0093d.m374a(arrayList, 22);
        if (C0061a.m205a(context, path)) {
            c0093d.m374a(arrayList, 56);
        }
        c0093d.m374a(arrayList, 24);
        ZMenuDialog zMenuDialog = new ZMenuDialog(this.mCS, context, arrayList, e, i, i2);
        zMenuDialog.setOnOkListener(this.mCS.f350a);
        zMenuDialog.show();
        this.mCS.f350a.fillFileListAction(iArr, true);
        return true;
    }

    public boolean open_long(Context context, MyUri myUri, int[] iArr, List<C0049e> list, int i, int i2) {
        if (this.mCS.m414j() != '\u0000') {
            return false;
        }
        if (!myUri.isArchive()) {
            return false;
        }
        String string;
        List arrayList = new ArrayList();
        C0093d c0093d = new C0093d(context);
        String path = myUri.getPath();
        if (iArr.length > 1) {
            if (Settings.sOpenFile) {
                c0093d.m374a(arrayList, 4);
            }
            c0093d.m374a(arrayList, 22);
            c0093d.m374a(arrayList, 24);
            if (C0061a.m205a(context, path)) {
                c0093d.m374a(arrayList, 56);
            }
            string = context.getString(R.string.MENU_SELECTED_FILES);
        } else if (iArr[0] < 0 || iArr[0] >= list.size()) {
            return false;
        } else {
            if (Settings.sOpenFile) {
                c0093d.m374a(arrayList, 4);
            }
            c0093d.m374a(arrayList, 22);
            c0093d.m374a(arrayList, 24);
            if (C0061a.m211b(context, path)) {
                c0093d.m374a(arrayList, 57);
            }
            if (C0061a.m205a(context, path)) {
                c0093d.m374a(arrayList, 56);
            }
            string = ((C0049e) list.get(iArr[0])).mo28e();
        }
        ZMenuDialog zMenuDialog = new ZMenuDialog(this.mCS, context, arrayList, string, i, i2);
        zMenuDialog.setOnOkListener(this.mCS.f350a);
        zMenuDialog.show();
        this.mCS.f350a.fillFileListAction(iArr, false);
        return true;
    }
}
