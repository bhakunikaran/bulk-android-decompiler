package ru.zdevs.zarchiver.fs;

import android.content.Context;
import java.util.ArrayList;
import java.util.List;
import ru.zdevs.zarchiver.C0093d;
import ru.zdevs.zarchiver.C0136e;
import ru.zdevs.zarchiver.R;
import ru.zdevs.zarchiver.dialog.ZMenuDialog;
import ru.zdevs.zarchiver.p003a.C0049e;
import ru.zdevs.zarchiver.p003a.C0052g;
import ru.zdevs.zarchiver.p004b.C0073a;
import ru.zdevs.zarchiver.settings.Settings;
import ru.zdevs.zarchiver.tool.C0200o;

public class FileLocal extends ZOpenFile {
    public C0136e mCS;

    public FileLocal(C0136e c0136e) {
        this.mCS = c0136e;
    }

    public boolean open(Context context, MyUri myUri, int[] iArr, List<C0049e> list, int i, int i2) {
        if (this.mCS.m414j() != '\u0000' || !myUri.isLocalFS()) {
            return false;
        }
        List arrayList = new ArrayList();
        C0093d c0093d = new C0093d(context);
        Object obj = 1;
        Object obj2 = null;
        int length = iArr.length;
        int i3 = 0;
        while (i3 < length) {
            int i4 = iArr[i3];
            if (((C0049e) list.get(i4)).m107b()) {
                Object obj3 = null;
                obj = null;
                break;
            }
            byte h = ((C0049e) list.get(i4)).mo29h();
            if (h != (byte) 7 && h != (byte) 6 && h != (byte) 8) {
                Object obj4 = obj2;
                obj2 = null;
                obj3 = obj4;
            } else if (h == (byte) 6) {
                obj3 = 1;
                obj2 = obj;
            } else {
                obj3 = obj2;
                obj2 = obj;
            }
            i3++;
            obj = obj2;
            obj2 = obj3;
        }
        int i5 = 1;
        byte a = C0200o.m709a(context, myUri);
        if (obj3 != null && iArr.length == 1 && (obj == null || obj2 != null)) {
            c0093d.m374a(arrayList, 2);
        }
        if (obj != null) {
            if (iArr.length == 1) {
                c0093d.m374a(arrayList, 1);
            }
            if (a == (byte) 1) {
                c0093d.m374a(arrayList, 5);
                c0093d.m374a(arrayList, 6);
            }
            c0093d.m374a(arrayList, 4);
            c0093d.m374a(arrayList, 10);
        }
        if ((a == (byte) 1 || Settings.sArchiveDir != null) && (obj == null || obj2 != null)) {
            c0093d.m375a(arrayList, 8, "*.zip");
            c0093d.m375a(arrayList, 9, "*.7z");
        }
        c0093d.m374a(arrayList, 7);
        ZMenuDialog zMenuDialog = new ZMenuDialog(this.mCS, context, arrayList, iArr.length > 1 ? context.getString(R.string.MENU_SELECTED_FILES) : ((C0049e) list.get(iArr[0])).mo28e(), i, i2);
        zMenuDialog.setOnOkListener(this.mCS.f350a);
        zMenuDialog.setOnCancelListener(this.mCS.f350a);
        zMenuDialog.show();
        this.mCS.f350a.fillFileListAction(iArr, false);
        return true;
    }

    public boolean open_find(Context context, MyUri myUri, int[] iArr, List<C0052g> list, int i, int i2) {
        if (this.mCS.m414j() != '\u0000' || !myUri.isLocalFS()) {
            return false;
        }
        List arrayList = new ArrayList();
        C0093d c0093d = new C0093d(context);
        byte a = C0200o.m709a(context, myUri);
        int i3 = myUri.isRoot() ? 2 : 1;
        Object obj = (Settings.sRoot && C0073a.m304f()) ? 1 : null;
        Object obj2 = 1;
        Object obj3 = null;
        int length = iArr.length;
        int i4 = 0;
        while (i4 < length) {
            int i5 = iArr[i4];
            if (i5 >= list.size()) {
                return false;
            }
            if (((C0052g) list.get(i5)).m107b()) {
                Object obj4 = null;
                obj2 = null;
                break;
            }
            byte h = ((C0052g) list.get(i5)).mo29h();
            if (h != (byte) 7 && h != (byte) 6 && h != (byte) 8) {
                Object obj5 = obj3;
                obj3 = null;
                obj4 = obj5;
            } else if (h == (byte) 6) {
                obj4 = 1;
                obj3 = obj2;
            } else {
                obj4 = obj3;
                obj3 = obj2;
            }
            i4++;
            obj2 = obj3;
            obj3 = obj4;
        }
        int i6 = 1;
        if (obj4 != null && iArr.length == 1 && (obj2 == null || obj3 != null)) {
            c0093d.m374a(arrayList, 2);
            c0093d.m374a(arrayList, 18);
        }
        if (obj2 != null) {
            if (iArr.length == 1) {
                c0093d.m374a(arrayList, 1);
            }
            c0093d.m374a(arrayList, 10);
            c0093d.m374a(arrayList, 4);
        }
        c0093d.m374a(arrayList, 7);
        if (obj4 != null && iArr.length == 1) {
            c0093d.m374a(arrayList, 22);
        }
        c0093d.m374a(arrayList, 24);
        if (a == (byte) 1 || (obj != null && a == (byte) 2)) {
            c0093d.m374a(arrayList, 25);
            c0093d.m374a(arrayList, 23);
        }
        if (obj4 == null || iArr.length > 1) {
            c0093d.m374a(arrayList, 22);
        }
        if (i3 == 1) {
            c0093d.m374a(arrayList, 20);
        }
        ZMenuDialog zMenuDialog = new ZMenuDialog(this.mCS, context, arrayList, iArr.length > 1 ? context.getString(R.string.MENU_SELECTED_FILES) : ((C0052g) list.get(iArr[0])).mo28e(), i, i2);
        zMenuDialog.setOnOkListener(this.mCS.f350a);
        zMenuDialog.show();
        this.mCS.f350a.fillFileListAction(iArr, true);
        return true;
    }

    public boolean open_long(Context context, MyUri myUri, int[] iArr, List<C0049e> list, int i, int i2) {
        if (this.mCS.m414j() != '\u0000' || !myUri.isLocalFS()) {
            return false;
        }
        String string;
        List arrayList = new ArrayList();
        C0093d c0093d = new C0093d(context);
        byte a = C0200o.m709a(context, myUri);
        int i3 = myUri.isRoot() ? 2 : 1;
        Object obj = (Settings.sRoot && C0073a.m304f()) ? 1 : null;
        if (iArr.length > 1) {
            Object obj2;
            Object obj3 = 1;
            int length = iArr.length;
            int i4 = 0;
            while (i4 < length) {
                int i5 = iArr[i4];
                if (((C0049e) list.get(i5)).m107b()) {
                    obj2 = null;
                    obj3 = null;
                    break;
                }
                byte h = ((C0049e) list.get(i5)).mo29h();
                obj2 = (h == (byte) 7 || h == (byte) 6 || h == (byte) 8) ? obj3 : null;
                i4++;
                obj3 = obj2;
            }
            int i6 = 1;
            if (Settings.sOpenArchive && r4 != null && (a == (byte) 1 || (obj != null && a == (byte) 2))) {
                c0093d.m374a(arrayList, 10);
                if (a == (byte) 1) {
                    c0093d.m374a(arrayList, 6);
                }
                c0093d.m374a(arrayList, 4);
            }
            if (Settings.sOpenFile && r4 == null && (a == (byte) 1 || Settings.sArchiveDir != null)) {
                c0093d.m375a(arrayList, 8, "*.zip");
                c0093d.m375a(arrayList, 9, "*.7z");
            }
            c0093d.m374a(arrayList, 7);
            c0093d.m374a(arrayList, 22);
            c0093d.m374a(arrayList, 24);
            if (a == (byte) 1 || (obj != null && a == (byte) 2)) {
                c0093d.m374a(arrayList, 25);
                c0093d.m374a(arrayList, 23);
            }
            if (obj2 != null && i3 == 1) {
                c0093d.m374a(arrayList, 20);
            }
            string = context.getString(R.string.MENU_SELECTED_FILES);
        } else if (iArr[0] < 0 || iArr[0] >= list.size()) {
            return false;
        } else {
            boolean b = ((C0049e) list.get(iArr[0])).m107b();
            boolean checkEndsWithInStringArray = ZFileInfo.checkEndsWithInStringArray(((C0049e) list.get(iArr[0])).mo28e(), ZFileInfo.ssExtArchive);
            if (!b) {
                if (!checkEndsWithInStringArray || !Settings.sOpenArchive) {
                    if (!checkEndsWithInStringArray) {
                        c0093d.m374a(arrayList, 18);
                    }
                    if (!Settings.sOpenFile) {
                        c0093d.m374a(arrayList, 7);
                    }
                } else if (a == (byte) 1 || (obj != null && a == (byte) 2)) {
                    c0093d.m374a(arrayList, 10);
                    if (a == (byte) 1) {
                        c0093d.m374a(arrayList, 6);
                    }
                    c0093d.m374a(arrayList, 4);
                }
            }
            if (b || Settings.sOpenFile) {
                if (!checkEndsWithInStringArray && (a == (byte) 1 || Settings.sArchiveDir != null)) {
                    c0093d.m375a(arrayList, 8, "*.zip");
                    c0093d.m375a(arrayList, 9, "*.7z");
                }
                c0093d.m374a(arrayList, 7);
            }
            if (!b) {
                c0093d.m374a(arrayList, 22);
            }
            c0093d.m374a(arrayList, 24);
            if (a == (byte) 1 || (obj != null && a == (byte) 2)) {
                c0093d.m374a(arrayList, 25);
                c0093d.m374a(arrayList, 23);
                c0093d.m374a(arrayList, 27);
            }
            if (b) {
                c0093d.m374a(arrayList, 22);
            }
            if (!(a == (byte) 1 || obj == null || !C0200o.m717b(myUri))) {
                c0093d.m374a(arrayList, 98);
            }
            if (i3 == 1) {
                c0093d.m374a(arrayList, 20);
            }
            if (b) {
                c0093d.m374a(arrayList, 70);
            }
            string = ((C0049e) list.get(iArr[0])).mo28e();
        }
        ZMenuDialog zMenuDialog = new ZMenuDialog(this.mCS, context, arrayList, string, i, i2);
        zMenuDialog.setOnOkListener(this.mCS.f350a);
        zMenuDialog.show();
        this.mCS.f350a.fillFileListAction(iArr, false);
        return true;
    }
}
