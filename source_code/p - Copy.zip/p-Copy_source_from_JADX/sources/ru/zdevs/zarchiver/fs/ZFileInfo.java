package ru.zdevs.zarchiver.fs;

import android.content.res.Resources;
import java.util.Locale;
import ru.zdevs.zarchiver.R;
import ru.zdevs.zarchiver.tool.C0166c;

public class ZFileInfo {
    public static final byte FILE_TYPE_ACROBAT = (byte) 15;
    public static final byte FILE_TYPE_APK = (byte) 6;
    public static final byte FILE_TYPE_ARCHIVE = (byte) 7;
    public static final byte FILE_TYPE_AUDIO = (byte) 9;
    public static final byte FILE_TYPE_CD_IMAGE = (byte) 8;
    public static final byte FILE_TYPE_EBOOK = (byte) 17;
    public static final byte FILE_TYPE_FOLDER = (byte) 2;
    public static final byte FILE_TYPE_MAX = (byte) 19;
    public static final byte FILE_TYPE_MSEXCEL = (byte) 10;
    public static final byte FILE_TYPE_MSPOWERPOINT = (byte) 12;
    public static final byte FILE_TYPE_MSWORD = (byte) 5;
    public static final byte FILE_TYPE_PICTURE = (byte) 11;
    public static final byte FILE_TYPE_TEXT = (byte) 13;
    public static final byte FILE_TYPE_UNKNOWN = (byte) 0;
    public static final byte FILE_TYPE_UP_FOLDER = (byte) 1;
    public static final byte FILE_TYPE_VIDEO = (byte) 16;
    public static final byte FILE_TYPE_WEB = (byte) 14;
    public static final byte FILE_TYPE_XML = (byte) 18;
    public static final byte OVERLAY_FULL_MAX = (byte) 2;
    public static final byte OVERLAY_FULL_NONE = (byte) 0;
    public static final byte OVERLAY_FULL_VIDEO = (byte) 1;
    public static final byte OVERLAY_TYPE_ALARM = (byte) 2;
    public static final byte OVERLAY_TYPE_ANDROID = (byte) 1;
    public static final byte OVERLAY_TYPE_APP = (byte) 3;
    public static final byte OVERLAY_TYPE_APP_APP = (byte) 126;
    public static final byte OVERLAY_TYPE_APP_DATA = Byte.MAX_VALUE;
    public static final byte OVERLAY_TYPE_ARCHIVE = (byte) 28;
    public static final byte OVERLAY_TYPE_ASSUMPTION = (byte) 31;
    public static final byte OVERLAY_TYPE_AUDIO = (byte) 4;
    public static final byte OVERLAY_TYPE_BIN = (byte) 5;
    public static final byte OVERLAY_TYPE_BLUETOOTH = (byte) 24;
    public static final byte OVERLAY_TYPE_BOOK = (byte) 27;
    public static final byte OVERLAY_TYPE_CAMERA = (byte) 6;
    public static final byte OVERLAY_TYPE_DEV = (byte) 7;
    public static final byte OVERLAY_TYPE_DOCUMENT = (byte) 8;
    public static final byte OVERLAY_TYPE_DOWNLOAD = (byte) 9;
    public static final byte OVERLAY_TYPE_ENCRYPTED = (byte) 30;
    public static final byte OVERLAY_TYPE_FILES_START = (byte) 30;
    public static final byte OVERLAY_TYPE_FONT = (byte) 26;
    public static final byte OVERLAY_TYPE_FRAMEWORK = (byte) 25;
    public static final byte OVERLAY_TYPE_HOME = (byte) 10;
    public static final byte OVERLAY_TYPE_MAX = (byte) 32;
    public static final byte OVERLAY_TYPE_MUSIC = (byte) 11;
    public static final byte OVERLAY_TYPE_NONE = (byte) 0;
    public static final byte OVERLAY_TYPE_NOTIFI = (byte) 12;
    public static final byte OVERLAY_TYPE_PHONE = (byte) 13;
    public static final byte OVERLAY_TYPE_PICTURE = (byte) 14;
    public static final byte OVERLAY_TYPE_PODCAST = (byte) 15;
    public static final byte OVERLAY_TYPE_RINGTONE = (byte) 16;
    public static final byte OVERLAY_TYPE_ROOT = (byte) 17;
    public static final byte OVERLAY_TYPE_SD = (byte) 18;
    public static final byte OVERLAY_TYPE_SETTINGS = (byte) 19;
    public static final byte OVERLAY_TYPE_STORAGE = (byte) 20;
    public static final byte OVERLAY_TYPE_TRASH = (byte) 21;
    public static final byte OVERLAY_TYPE_USB = (byte) 22;
    public static final byte OVERLAY_TYPE_VIDEO = (byte) 23;
    public static String[] ssExtAcrobat = new String[0];
    public static String[] ssExtApk = new String[0];
    public static String[] ssExtArchive = new String[0];
    public static String[] ssExtAudio = new String[0];
    public static String[] ssExtEBook = new String[0];
    public static String[] ssExtExcel = new String[0];
    public static String[] ssExtImage = new String[0];
    public static String[] ssExtPicture = new String[0];
    public static String[] ssExtPowerpoint = new String[0];
    public static String[] ssExtText = new String[0];
    public static String[] ssExtVideo = new String[0];
    public static String[] ssExtWeb = new String[0];
    public static String[] ssExtWord = new String[0];
    public static String[] ssExtXml = new String[0];

    public static boolean checkEndsWithInStringArray(String str, String[] strArr) {
        String toLowerCase = str.toLowerCase(Locale.US);
        for (String endsWith : strArr) {
            if (toLowerCase.endsWith(endsWith)) {
                return true;
            }
        }
        return false;
    }

    public static byte getFileType(String str) {
        if (str == null) {
            return (byte) 0;
        }
        String toLowerCase = str.toLowerCase(Locale.US);
        return checkEndsWithInStringArray(toLowerCase, ssExtPicture) ? (byte) 11 : checkEndsWithInStringArray(toLowerCase, ssExtArchive) ? (byte) 7 : checkEndsWithInStringArray(toLowerCase, ssExtAudio) ? (byte) 9 : checkEndsWithInStringArray(toLowerCase, ssExtApk) ? (byte) 6 : checkEndsWithInStringArray(toLowerCase, ssExtWord) ? (byte) 5 : checkEndsWithInStringArray(toLowerCase, ssExtExcel) ? (byte) 10 : checkEndsWithInStringArray(toLowerCase, ssExtPowerpoint) ? (byte) 12 : checkEndsWithInStringArray(toLowerCase, ssExtText) ? (byte) 13 : checkEndsWithInStringArray(toLowerCase, ssExtWeb) ? (byte) 14 : checkEndsWithInStringArray(toLowerCase, ssExtAcrobat) ? (byte) 15 : checkEndsWithInStringArray(toLowerCase, ssExtVideo) ? (byte) 16 : checkEndsWithInStringArray(toLowerCase, ssExtXml) ? (byte) 18 : checkEndsWithInStringArray(toLowerCase, ssExtEBook) ? (byte) 17 : checkEndsWithInStringArray(toLowerCase, ssExtImage) ? (byte) 8 : (byte) 0;
    }

    public static void loadFileType(Resources resources) {
        try {
            ssExtAcrobat = resources.getStringArray(R.array.fs_acrobat_ext);
            ssExtApk = resources.getStringArray(R.array.fs_apk_ext);
            ssExtArchive = resources.getStringArray(R.array.fs_archive_ext);
            ssExtImage = resources.getStringArray(R.array.fs_image_ext);
            ssExtAudio = resources.getStringArray(R.array.fs_audio_ext);
            ssExtExcel = resources.getStringArray(R.array.fs_excel_ext);
            ssExtPicture = resources.getStringArray(R.array.fs_picture_ext);
            ssExtPowerpoint = resources.getStringArray(R.array.fs_powerpoint_ext);
            ssExtText = resources.getStringArray(R.array.fs_text_ext);
            ssExtWeb = resources.getStringArray(R.array.fs_web_ext);
            ssExtWord = resources.getStringArray(R.array.fs_word_ext);
            ssExtVideo = resources.getStringArray(R.array.fs_video_ext);
            ssExtEBook = resources.getStringArray(R.array.fs_ebook_ext);
            ssExtXml = resources.getStringArray(R.array.fs_xml_ext);
        } catch (Throwable e) {
            C0166c.m556a(e);
        }
    }
}
