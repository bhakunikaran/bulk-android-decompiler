package ru.zdevs.zarchiver.fs;

import android.net.Uri;
import java.io.File;

public class MyUri implements Comparable<MyUri> {
    private String mFragment;
    private String mHost;
    private String mPath;
    private String mScheme;

    public MyUri(File file) {
        this(file.getAbsolutePath());
    }

    public MyUri(String str) {
        if (str.startsWith("/SAF")) {
            this.mScheme = FSStorage.SCHEME;
        } else {
            this.mScheme = FSLocal.SCHEME;
        }
        this.mHost = "";
        this.mPath = str;
        this.mFragment = "";
    }

    public MyUri(String str, String str2) {
        this.mScheme = str;
        this.mHost = "";
        this.mPath = str2;
        this.mFragment = "";
    }

    public MyUri(String str, String str2, String str3) {
        this.mScheme = str;
        this.mHost = str2;
        this.mPath = str3;
        this.mFragment = "";
    }

    public MyUri(String str, String str2, String str3, String str4) {
        this.mScheme = str;
        this.mHost = str2;
        this.mPath = str3;
        this.mFragment = str4;
    }

    public MyUri(MyUri myUri) {
        this.mScheme = myUri.mScheme;
        this.mHost = myUri.mHost;
        this.mPath = myUri.mPath;
        this.mFragment = myUri.mFragment;
    }

    public boolean add(String str) {
        if (str == null || str.length() <= 0) {
            return true;
        }
        if (str.equals("..")) {
            return del();
        }
        if (this.mFragment == null || this.mFragment.length() <= 0) {
            if (this.mPath.endsWith("/") == str.startsWith("/")) {
                if (str.length() <= 0 || str.charAt(0) != '/') {
                    this.mPath += "/";
                } else {
                    str = str.substring(1);
                }
            }
            this.mPath += str;
            return true;
        }
        if (this.mFragment.endsWith("/") == str.startsWith("/")) {
            if (str.length() <= 0 || str.charAt(0) != '/') {
                this.mFragment += "/";
            } else {
                str = str.substring(1);
            }
        }
        this.mFragment += str;
        return true;
    }

    public int compareTo(MyUri myUri) {
        return toString().compareTo(myUri.toString());
    }

    public boolean del() {
        int lastIndexOf;
        if (this.mFragment != null && this.mFragment.length() > 0) {
            lastIndexOf = this.mFragment.lastIndexOf(47);
            if (lastIndexOf < 0 || this.mFragment.equals("/")) {
                this.mFragment = "";
            } else {
                this.mFragment = this.mFragment.substring(0, lastIndexOf);
                if (this.mFragment.length() <= 0) {
                    this.mFragment = "/";
                }
            }
            if (this.mFragment.length() <= 0 && this.mScheme.equals(FSArchive.SCHEME)) {
                if (this.mPath.startsWith("/SAF")) {
                    this.mScheme = FSStorage.SCHEME;
                } else {
                    this.mScheme = FSLocal.SCHEME;
                }
            }
            if (this.mFragment.length() > 0) {
                return true;
            }
        }
        lastIndexOf = this.mPath.lastIndexOf(47);
        if (lastIndexOf < 0) {
            this.mPath = "/";
            return false;
        } else if (this.mPath.equals("/")) {
            return false;
        } else {
            this.mPath = this.mPath.substring(0, lastIndexOf);
            if (this.mPath.length() > 0) {
                return true;
            }
            this.mPath = "/";
            return true;
        }
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof Uri)) {
            return false;
        }
        return toString().equals(((Uri) obj).toString());
    }

    public String getFragment() {
        return this.mFragment;
    }

    public String getHost() {
        return this.mHost;
    }

    public String getName() {
        int lastIndexOf;
        if (this.mFragment == null || this.mFragment.length() <= 0) {
            lastIndexOf = this.mPath.lastIndexOf(47);
            return lastIndexOf >= 0 ? this.mPath.equals("/") ? "ROOT" : this.mPath.substring(lastIndexOf + 1) : null;
        } else {
            lastIndexOf = this.mFragment.lastIndexOf(47);
            return (lastIndexOf < 0 || this.mFragment.equals("/")) ? this.mFragment : this.mFragment.substring(lastIndexOf + 1);
        }
    }

    public String getPath() {
        return this.mPath;
    }

    public String getScheme() {
        return this.mScheme;
    }

    public boolean isArchive() {
        return (this.mScheme == null || this.mScheme.length() <= 0) ? false : this.mScheme.equals(FSArchive.SCHEME);
    }

    public boolean isExternal() {
        return (this.mScheme == null || this.mScheme.length() <= 0) ? false : this.mScheme.equals(FSStorage.SCHEME);
    }

    public boolean isLocalFS() {
        return (this.mScheme == null || this.mScheme.length() <= 0) ? false : this.mScheme.equals(FSLocal.SCHEME) || this.mScheme.equals(FSRoot.SCHEME);
    }

    public boolean isRoot() {
        return (this.mScheme == null || this.mScheme.length() <= 0) ? false : this.mScheme.equals(FSRoot.SCHEME);
    }

    public boolean isStorage() {
        return (this.mScheme == null || this.mScheme.length() <= 0) ? false : this.mScheme.equals(FSLocal.SCHEME) || this.mScheme.equals(FSRoot.SCHEME) || this.mScheme.equals(FSStorage.SCHEME);
    }

    public void setPath(String str) {
        this.mPath = str;
    }

    public void setScheme(String str) {
        this.mScheme = str;
    }

    public File toFile() {
        return (!isLocalFS() || this.mHost.length() > 0 || this.mFragment.length() > 0) ? null : new File(this.mPath);
    }

    public String toLocalPath() {
        return isExternal() ? this.mPath : !isLocalFS() ? "" : this.mPath;
    }

    public String toShortViewString() {
        if (!isArchive()) {
            return toViewString();
        }
        String str = "~/";
        return (this.mFragment == null || this.mFragment.length() <= 0) ? str : str + this.mFragment;
    }

    public String toString() {
        return (this.mFragment == null || this.mFragment.length() <= 0) ? this.mScheme + "://" + this.mHost + this.mPath : this.mScheme + "://" + this.mHost + this.mPath + "#" + this.mFragment;
    }

    public String toViewString() {
        String str = this.mPath;
        if (this.mFragment != null && this.mFragment.length() > 0) {
            str = str + "/" + this.mFragment;
        }
        return (this.mHost == null || this.mHost.length() <= 0) ? str : "/" + this.mHost + str;
    }
}
