package ru.zdevs.zarchiver;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.ActionBar;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.IBinder;
import android.os.storage.StorageVolume;
import android.util.Log;
import android.view.ActionMode;
import android.view.ActionMode.Callback;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListPopupWindow;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.SearchView;
import android.widget.SearchView.OnCloseListener;
import android.widget.SearchView.OnQueryTextListener;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileReader;
import java.io.LineNumberReader;
import java.io.Reader;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import p000a.p001a.p002a.C0002a;
import ru.zdevs.zarchiver.C0136e.C0135a;
import ru.zdevs.zarchiver.activity.AboutDlg;
import ru.zdevs.zarchiver.activity.SettingsDlg;
import ru.zdevs.zarchiver.archiver.C0061a;
import ru.zdevs.zarchiver.archiver.C0071e;
import ru.zdevs.zarchiver.archiver.C0072g;
import ru.zdevs.zarchiver.archiver.C2JBridge;
import ru.zdevs.zarchiver.dialog.ZCompressDialog;
import ru.zdevs.zarchiver.dialog.ZDialog;
import ru.zdevs.zarchiver.dialog.ZDialog.OnCancelListener;
import ru.zdevs.zarchiver.dialog.ZDialog.OnOkListener;
import ru.zdevs.zarchiver.dialog.ZEnterTextDialog;
import ru.zdevs.zarchiver.dialog.ZFileInfoDialog;
import ru.zdevs.zarchiver.dialog.ZFixSDDialog;
import ru.zdevs.zarchiver.dialog.ZMainOptionDialog;
import ru.zdevs.zarchiver.dialog.ZMenuDialog;
import ru.zdevs.zarchiver.dialog.ZMessageDialog;
import ru.zdevs.zarchiver.dialog.ZProcDialog;
import ru.zdevs.zarchiver.fs.FSArchive;
import ru.zdevs.zarchiver.fs.FSLocal;
import ru.zdevs.zarchiver.fs.FindFile;
import ru.zdevs.zarchiver.fs.MyUri;
import ru.zdevs.zarchiver.fs.ZFileInfo;
import ru.zdevs.zarchiver.fs.ZOpenFile;
import ru.zdevs.zarchiver.fs.ZViewFS;
import ru.zdevs.zarchiver.fs.ZViewFS.FSFileInfo;
import ru.zdevs.zarchiver.fs.ZViewFS.FindResultListener;
import ru.zdevs.zarchiver.io.C0143a;
import ru.zdevs.zarchiver.io.LollipopExtSD;
import ru.zdevs.zarchiver.p003a.C0043b;
import ru.zdevs.zarchiver.p003a.C0046h;
import ru.zdevs.zarchiver.p003a.C0047d;
import ru.zdevs.zarchiver.p003a.C0047d.C0031a;
import ru.zdevs.zarchiver.p003a.C0049e;
import ru.zdevs.zarchiver.p003a.C0051f;
import ru.zdevs.zarchiver.p003a.C0052g;
import ru.zdevs.zarchiver.p004b.C0073a;
import ru.zdevs.zarchiver.p004b.C0075c;
import ru.zdevs.zarchiver.p004b.C0085k;
import ru.zdevs.zarchiver.service.C0144e;
import ru.zdevs.zarchiver.service.C0144e.C0145a;
import ru.zdevs.zarchiver.service.C0160c;
import ru.zdevs.zarchiver.service.ZArchiverClearTemp;
import ru.zdevs.zarchiver.service.ZArchiverService;
import ru.zdevs.zarchiver.settings.Favorites;
import ru.zdevs.zarchiver.settings.Settings;
import ru.zdevs.zarchiver.tool.C0166c;
import ru.zdevs.zarchiver.tool.C0167d;
import ru.zdevs.zarchiver.tool.C0169f;
import ru.zdevs.zarchiver.tool.C0178g;
import ru.zdevs.zarchiver.tool.C0184j;
import ru.zdevs.zarchiver.tool.C0184j.C0183a;
import ru.zdevs.zarchiver.tool.C0199n;
import ru.zdevs.zarchiver.tool.C0199n.C0198a;
import ru.zdevs.zarchiver.tool.C0200o;
import ru.zdevs.zarchiver.tool.C0202q;
import ru.zdevs.zarchiver.tool.C0203r;
import ru.zdevs.zarchiver.tool.C0204s;
import ru.zdevs.zarchiver.widget.ExtendRelativeLayout;
import ru.zdevs.zarchiver.widget.IListView;
import ru.zdevs.zarchiver.widget.IListView.OnListMeasure;
import ru.zdevs.zarchiver.widget.SwipeView;
import ru.zdevs.zarchiver.widget.SwipeView.OnRefreshListener;
import ru.zdevs.zarchiver.widget.SwipeView.OnShowListener;

public class ZArchiver extends Activity implements OnItemClickListener, OnItemLongClickListener, C0031a, FindResultListener {
    private static final String TAG = "ZArchiver";
    private static ZArchiver sHackSuppressDouble;
    public C0136e cs;
    private Drawable iDefIcon = null;
    public C0144e iService;
    public ActionMode mActionMode;
    private ServiceConnection mConnection = new C00164(this);
    private View mCustomNav;
    private boolean mExit = false;
    private boolean mExitOnOperationComplete = false;
    public FindFile mFindFile;
    private ImageButton mFloatButton;
    private AsyncTask<?, ?, ?> mFolderInfo;
    boolean mHeaderIsRoot = false;
    public C0178g mImageLoader;
    private AbsListView mListView;
    private View mLlFolderInfo;
    private View mLlStorage;
    private ProgressBar mLoadingProgressBar;
    private Menu mMenu;
    private String mOpenFileName;
    private ProgressBar mPbFree;
    private ListPopupWindow mPopupNavigation;
    private boolean mReconfigure = false;
    private C0026e mRemount;
    private boolean mRestartGUI = false;
    private boolean mSaveSearchResult = false;
    private SearchView mSearch;
    private boolean mServiceReloadSettings = false;
    private C0025d mSetPath;
    private TextView mSubtitle;
    private TextView mTVMes;
    private boolean mTestExternalSD = true;
    private TextView mTitle;
    private Toast mToastInfo;
    private TextView mTvFolder;
    private TextView mTvFolderSize;
    private TextView mTvStorage;
    private TextView mTvStorageSpace;

    /* renamed from: ru.zdevs.zarchiver.ZArchiver$1 */
    class C00131 implements OnOkListener {
        /* renamed from: a */
        final /* synthetic */ ZArchiver f38a;

        C00131(ZArchiver zArchiver) {
            this.f38a = zArchiver;
        }

        public void onOk(ZDialog zDialog) {
            this.f38a.finish();
        }
    }

    /* renamed from: ru.zdevs.zarchiver.ZArchiver$2 */
    class C00142 implements OnClickListener {
        /* renamed from: a */
        final /* synthetic */ ZArchiver f39a;

        C00142(ZArchiver zArchiver) {
            this.f39a = zArchiver;
        }

        public void onClick(View view) {
            if (this.f39a.mFloatButton != null) {
                if (this.f39a.mActionMode == null || this.f39a.cs.m414j() == '\u0000') {
                    if (this.f39a.mFloatButton.getTag() != null) {
                        this.f39a.onToolbarClick(((Integer) this.f39a.mFloatButton.getTag()).intValue());
                    }
                } else if (this.f39a.cs.f350a.onFinishActionMode(this.f39a, true)) {
                    this.f39a.mActionMode.finish();
                }
            }
        }
    }

    /* renamed from: ru.zdevs.zarchiver.ZArchiver$3 */
    class C00153 implements OnListMeasure {
        /* renamed from: a */
        final /* synthetic */ ZArchiver f40a;

        C00153(ZArchiver zArchiver) {
            this.f40a = zArchiver;
        }

        public void onListMeasure(int i, int i2) {
            LayoutParams layoutParams = (LayoutParams) this.f40a.mFloatButton.getLayoutParams();
            if (layoutParams != null) {
                TypedArray obtainStyledAttributes = this.f40a.obtainStyledAttributes(R.style.FloatingActionButtonStyle, new int[]{16842999, 16843000, 16843001, 16843002});
                layoutParams.setMargins(obtainStyledAttributes.getDimensionPixelSize(0, 0) + this.f40a.mListView.getPaddingLeft(), obtainStyledAttributes.getDimensionPixelSize(1, 0) + this.f40a.mListView.getPaddingTop(), obtainStyledAttributes.getDimensionPixelSize(2, 0) + this.f40a.mListView.getPaddingRight(), obtainStyledAttributes.getDimensionPixelSize(3, 0) + this.f40a.mListView.getPaddingBottom());
                this.f40a.mFloatButton.setLayoutParams(layoutParams);
                obtainStyledAttributes.recycle();
            }
        }
    }

    /* renamed from: ru.zdevs.zarchiver.ZArchiver$4 */
    class C00164 implements ServiceConnection {
        /* renamed from: a */
        final /* synthetic */ ZArchiver f41a;

        C00164(ZArchiver zArchiver) {
            this.f41a = zArchiver;
        }

        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            this.f41a.iService = C0145a.asInterface(iBinder);
            C0166c.m559d(ZArchiver.TAG, "Service connected");
            try {
                this.f41a.iService.GUIStatus(1);
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
            try {
                if (!(this.f41a.cs == null || this.f41a.cs.f350a == null)) {
                    this.f41a.cs.f350a.setZArchiver(this.f41a, this.f41a.iService);
                    this.f41a.cs.f350a.serviceSetRun();
                    this.f41a.cs.f350a.dialogsUpdate();
                }
            } catch (Throwable e2) {
                C0166c.m556a(e2);
            }
            try {
                if (this.f41a.mServiceReloadSettings) {
                    this.f41a.mServiceReloadSettings = false;
                    this.f41a.iService.SetSettings();
                }
            } catch (Throwable e22) {
                C0166c.m556a(e22);
            }
        }

        public void onServiceDisconnected(ComponentName componentName) {
            this.f41a.iService = null;
            if (!(this.f41a.cs == null || this.f41a.cs.f350a == null)) {
                this.f41a.cs.f350a.setZArchiver(this.f41a, null);
            }
            C0166c.m559d(ZArchiver.TAG, "Service disconnected");
        }
    }

    /* renamed from: ru.zdevs.zarchiver.ZArchiver$5 */
    class C00175 implements OnRefreshListener {
        /* renamed from: a */
        final /* synthetic */ ZArchiver f42a;

        C00175(ZArchiver zArchiver) {
            this.f42a = zArchiver;
        }

        public void onRefresh() {
            C0166c.m559d(ZArchiver.TAG, "Update list!");
            if (this.f42a.mImageLoader != null) {
                this.f42a.mImageLoader.m620d();
            }
            this.f42a.onUpdateList(false);
        }
    }

    /* renamed from: ru.zdevs.zarchiver.ZArchiver$6 */
    class C00186 implements OnShowListener {
        /* renamed from: a */
        final /* synthetic */ ZArchiver f43a;

        C00186(ZArchiver zArchiver) {
            this.f43a = zArchiver;
        }

        public void onShow() {
            if (this.f43a.mTvFolderSize.getTag() == null) {
                MyUri g = this.f43a.cs.m411g();
                this.f43a.mTvFolderSize.setTag(g);
                this.f43a.mTvFolderSize.setText(this.f43a.getString(R.string.FINFO_SIZE) + " ...");
                this.f43a.mFolderInfo = new C0024c(g).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Void[0]);
            }
        }
    }

    /* renamed from: ru.zdevs.zarchiver.ZArchiver$7 */
    class C00197 implements OnCloseListener {
        /* renamed from: a */
        final /* synthetic */ ZArchiver f44a;

        C00197(ZArchiver zArchiver) {
            this.f44a = zArchiver;
        }

        public boolean onClose() {
            if (!this.f44a.mSaveSearchResult) {
                this.f44a.cs.f354e.clear();
                this.f44a.cs.f355f = "";
            }
            C0046h listAdapter = this.f44a.getListAdapter();
            if (listAdapter == null || listAdapter.mo26i() != (byte) 0) {
                listAdapter = new C0047d(this.f44a);
                listAdapter.m89a(this.f44a.cs.f351b, this.f44a.cs.m411g());
                this.f44a.setListAdapter(listAdapter);
                if (!this.f44a.mSaveSearchResult) {
                    C0135a o = this.f44a.cs.m419o();
                    if (o != null && o.f345a.compareTo(this.f44a.cs.m411g()) == 0 && o.f347c >= 0) {
                        this.f44a.getListView().setSelection(o.f347c);
                        this.f44a.setFSMessage(o.f349e);
                    }
                }
            }
            this.f44a.cs.f356g = false;
            if (this.f44a.mFindFile != null) {
                this.f44a.mFindFile.stopFindFile();
                this.f44a.mFindFile = null;
            }
            this.f44a.onChangeInArchiveState();
            this.f44a.setFloatAction();
            this.f44a.onSetFindProcess(0);
            this.f44a.setMyProgressBarVisibility(false);
            this.f44a.mSearch.setVisibility(C0058a.m148b(this.f44a) ? 8 : 0);
            return false;
        }
    }

    /* renamed from: ru.zdevs.zarchiver.ZArchiver$8 */
    class C00208 implements OnClickListener {
        /* renamed from: a */
        final /* synthetic */ ZArchiver f45a;

        C00208(ZArchiver zArchiver) {
            this.f45a = zArchiver;
        }

        public void onClick(View view) {
            this.f45a.mSearch.setVisibility(0);
            this.f45a.mSaveSearchResult = false;
            this.f45a.cs.m401a(this.f45a.getPosition());
            this.f45a.setRepeatSearch(true);
            this.f45a.onChangeInArchiveState();
            this.f45a.setFloatAction();
        }
    }

    /* renamed from: ru.zdevs.zarchiver.ZArchiver$9 */
    class C00219 implements OnQueryTextListener {
        /* renamed from: a */
        final /* synthetic */ ZArchiver f46a;

        C00219(ZArchiver zArchiver) {
            this.f46a = zArchiver;
        }

        public boolean onQueryTextChange(String str) {
            return false;
        }

        public boolean onQueryTextSubmit(String str) {
            this.f46a.cs.f355f = str;
            if (this.f46a.mFindFile == null) {
                this.f46a.mFindFile = new FindFile(this.f46a, this.f46a);
            }
            this.f46a.mFindFile.startFindFile(this.f46a.cs.m411g(), this.f46a.cs.f355f);
            this.f46a.mSearch.clearFocus();
            return true;
        }
    }

    /* renamed from: ru.zdevs.zarchiver.ZArchiver$a */
    private final class C0022a implements Callback {
        /* renamed from: a */
        final /* synthetic */ ZArchiver f47a;

        private C0022a(ZArchiver zArchiver) {
            this.f47a = zArchiver;
        }

        public boolean onActionItemClicked(ActionMode actionMode, MenuItem menuItem) {
            if (menuItem.getItemId() == R.id.bCreateArchive) {
                this.f47a.cs.f350a.onFinishActionMode(this.f47a, true);
                actionMode.finish();
            }
            return true;
        }

        public boolean onCreateActionMode(ActionMode actionMode, Menu menu) {
            int i = 0;
            this.f47a.mMenu = menu;
            MenuInflater menuInflater = this.f47a.getMenuInflater();
            menuInflater.inflate(R.menu.toolbar_action_select, menu);
            menuInflater.inflate(R.menu.menu_main, menu);
            if (!C0058a.m146a(this.f47a)) {
                this.f47a.setVisibleMenuItems(menu, new int[]{R.id.bOk}, false);
            }
            if (this.f47a.cs.m414j() == Actions.ACTION_CREATE_ARCHIVE) {
                this.f47a.setVisibleMenuItems(menu, new int[]{R.id.bMenuAdd, R.id.bMenuNew}, false);
            } else if (this.f47a.cs.m414j() == '\u0002') {
                this.f47a.setVisibleMenuItems(menu, new int[]{R.id.bMenuAdd, R.id.bMenuNew, R.id.bCreateArchive}, false);
            }
            this.f47a.setSortFileList(menu);
            C0046h listAdapter = this.f47a.getListAdapter();
            if (listAdapter != null) {
                StringBuilder append = new StringBuilder().append(listAdapter.mo16b()).append(" / ");
                int count = listAdapter.getCount();
                if (ZViewFS.sAddFolderUp) {
                    i = 1;
                }
                actionMode.setTitle(append.append(count - i).toString());
            }
            this.f47a.setCustomDivider(true);
            return true;
        }

        public void onDestroyActionMode(ActionMode actionMode) {
            this.f47a.cs.f350a.onFinishActionMode(this.f47a, false);
            this.f47a.mActionMode = null;
            this.f47a.setFloatAction();
            this.f47a.setCustomDivider(false);
            this.f47a.invalidateOptionsMenu();
        }

        public boolean onPrepareActionMode(ActionMode actionMode, Menu menu) {
            this.f47a.setIconInMenu(menu);
            return false;
        }
    }

    /* renamed from: ru.zdevs.zarchiver.ZArchiver$b */
    private final class C0023b implements Callback {
        /* renamed from: a */
        final /* synthetic */ ZArchiver f48a;

        private C0023b(ZArchiver zArchiver) {
            this.f48a = zArchiver;
        }

        public boolean onActionItemClicked(ActionMode actionMode, MenuItem menuItem) {
            if ((menuItem.getItemId() == R.id.bSelectPath || menuItem.getItemId() == R.id.bPast) && this.f48a.cs.f350a.onFinishActionMode(this.f48a, true)) {
                actionMode.finish();
            }
            return true;
        }

        public boolean onCreateActionMode(ActionMode actionMode, Menu menu) {
            this.f48a.mMenu = menu;
            ActionBar actionBar = this.f48a.getActionBar();
            if (actionBar != null) {
                actionBar.setCustomView(null);
            }
            actionMode.setCustomView(this.f48a.mCustomNav);
            if (!(this.f48a.mSearch == null || C0058a.m148b(this.f48a))) {
                this.f48a.mSearch.setVisibility(8);
            }
            MenuInflater menuInflater = this.f48a.getMenuInflater();
            menuInflater.inflate(R.menu.toolbar_action, menu);
            menuInflater.inflate(R.menu.menu_main, menu);
            if (!C0058a.m146a(this.f48a)) {
                this.f48a.setVisibleMenuItems(menu, new int[]{R.id.bCancel}, false);
            }
            if (this.f48a.cs.m414j() == '\t' || this.f48a.cs.m414j() == '\u0011') {
                this.f48a.setVisibleMenuItems(menu, new int[]{R.id.bMenuAdd, R.id.bPast}, false);
            } else if (this.f48a.cs.m414j() == Actions.ACTION_PAST) {
                this.f48a.setVisibleMenuItems(menu, new int[]{R.id.bMenuAdd, R.id.bSelectPath}, false);
            }
            this.f48a.setEnabledMenuItems(menu, new int[]{R.id.bNewArchive}, false);
            if (Settings.sRoot && C0073a.m304f() && this.f48a.cs.m410f() != (byte) 1) {
                if (this.f48a.cs.m397a(this.f48a) == (byte) 3) {
                    this.f48a.setEnabledMenuItems(menu, new int[]{R.id.bRemountRW}, true);
                } else if (this.f48a.cs.m397a(this.f48a) == (byte) 2) {
                    this.f48a.setEnabledMenuItems(menu, new int[]{R.id.bRemountRO}, true);
                }
            }
            this.f48a.setSortFileList(menu);
            this.f48a.setCustomDivider(true);
            return true;
        }

        public void onDestroyActionMode(ActionMode actionMode) {
            ActionBar actionBar = this.f48a.getActionBar();
            actionMode.setCustomView(null);
            if (actionBar != null) {
                actionBar.setCustomView(this.f48a.mCustomNav);
            }
            if (!(this.f48a.mSearch == null || C0058a.m148b(this.f48a))) {
                this.f48a.mSearch.setVisibility(0);
            }
            C0046h listAdapter = this.f48a.getListAdapter();
            if (listAdapter != null) {
                listAdapter.mo15a(true);
            }
            this.f48a.cs.f350a.onFinishActionMode(this.f48a, false);
            this.f48a.mActionMode = null;
            this.f48a.setFloatAction();
            this.f48a.setCustomDivider(false);
            this.f48a.invalidateOptionsMenu();
        }

        public boolean onPrepareActionMode(ActionMode actionMode, Menu menu) {
            this.f48a.setIconInMenu(menu);
            if ((this.f48a.cs.m404a() || this.f48a.cs.m408d()) && this.f48a.cs.m411g().getPath().startsWith(C0202q.m727a(this.f48a))) {
                this.f48a.setCurrentPath(new MyUri(Settings.sHomeDir));
            }
            if (!this.f48a.cs.m404a()) {
                if (this.f48a.cs.m408d()) {
                    String path = this.f48a.cs.m411g().getPath();
                    this.f48a.setCurrentPath(new MyUri(FSLocal.SCHEME, path.substring(0, path.lastIndexOf("/"))));
                } else {
                    C0166c.m557b(ZArchiver.TAG, "Error: incorrect file scheme!");
                }
            }
            C0046h listAdapter = this.f48a.getListAdapter();
            if (listAdapter != null) {
                listAdapter.mo19c();
                listAdapter.mo15a(false);
            }
            if (this.f48a.cs.f356g) {
                this.f48a.setCurrentPath(this.f48a.cs.m411g());
            }
            return false;
        }
    }

    /* renamed from: ru.zdevs.zarchiver.ZArchiver$c */
    private class C0024c extends AsyncTask<Void, Void, Long> {
        /* renamed from: a */
        final /* synthetic */ ZArchiver f49a;
        /* renamed from: b */
        private MyUri f50b;

        private C0024c(ZArchiver zArchiver, MyUri myUri) {
            this.f49a = zArchiver;
            this.f50b = null;
            this.f50b = myUri;
            C0166c.m557b(ZArchiver.TAG, "DIRSizeTask: " + this.f50b);
        }

        /* renamed from: a */
        protected Long m25a(Void... voidArr) {
            FSFileInfo fSFileInfo = null;
            for (ZViewFS fileInfo : ZViewFS.get()) {
                fSFileInfo = fileInfo.getFileInfo(this.f50b, this);
                if (fSFileInfo == null) {
                    if (isCancelled()) {
                        break;
                    }
                }
                break;
            }
            return fSFileInfo != null ? Long.valueOf(fSFileInfo.mSize) : Long.valueOf(-1);
        }

        /* renamed from: a */
        protected void m26a(Long l) {
            this.f49a.mFolderInfo = null;
            if (!isCancelled()) {
                try {
                    if (this.f49a.mTvFolderSize == null) {
                        return;
                    }
                    if (l.longValue() != -1) {
                        this.f49a.mTvFolderSize.setText(this.f49a.getString(R.string.FINFO_SIZE) + " " + C0202q.m726a(l.longValue()));
                    } else {
                        this.f49a.mTvFolderSize.setText(this.f49a.getString(R.string.FINFO_SIZE) + " ---");
                    }
                } catch (Throwable e) {
                    C0166c.m556a(e);
                }
            }
        }

        protected /* synthetic */ Object doInBackground(Object[] objArr) {
            return m25a((Void[]) objArr);
        }

        protected /* synthetic */ void onPostExecute(Object obj) {
            m26a((Long) obj);
        }
    }

    /* renamed from: ru.zdevs.zarchiver.ZArchiver$d */
    private abstract class C0025d extends AsyncTask<Void, Void, Void> {
        /* renamed from: a */
        final /* synthetic */ ZArchiver f51a;

        private C0025d(ZArchiver zArchiver) {
            this.f51a = zArchiver;
        }

        /* renamed from: a */
        public void mo7a() {
        }
    }

    /* renamed from: ru.zdevs.zarchiver.ZArchiver$e */
    private class C0026e extends AsyncTask<Void, Void, Boolean> {
        /* renamed from: a */
        final /* synthetic */ ZArchiver f52a;
        /* renamed from: b */
        private final String f53b;
        /* renamed from: c */
        private boolean f54c;

        C0026e(ZArchiver zArchiver, String str, boolean z) {
            this.f52a = zArchiver;
            this.f53b = str;
            this.f54c = z;
        }

        /* renamed from: a */
        protected Boolean m28a(Void... voidArr) {
            C0073a c0075c = new C0075c(true);
            if (c0075c.mo52b()) {
                C0183a a = C0184j.m642a(new File(this.f53b).getAbsolutePath());
                boolean a2 = C0085k.m343a(c0075c, a != null ? a.m637a() : this.f53b, this.f54c);
                c0075c.mo54c();
                C0184j.m645b();
                return Boolean.valueOf(a2);
            }
            c0075c.mo54c();
            return Boolean.valueOf(false);
        }

        /* renamed from: a */
        protected void m29a(Boolean bool) {
            if (this.f52a.mToastInfo != null) {
                this.f52a.mToastInfo.cancel();
                this.f52a.mToastInfo = null;
            }
            if (bool.booleanValue()) {
                this.f52a.mToastInfo = Toast.makeText(this.f52a.getApplicationContext(), this.f52a.getResources().getString(R.string.MES_REMOUNT_SUCESSFUL).replace("%1", this.f53b).replace("%2", this.f54c ? "RW" : "RO"), 0);
                this.f52a.mToastInfo.show();
                this.f52a.cs.m413i();
                if (this.f52a.cs.m415k() == '\u0000') {
                    this.f52a.setFloatAction();
                }
                if (this.f52a.mMenu != null) {
                    MenuItem findItem = this.f52a.mMenu.findItem(R.id.bRemountRO);
                    MenuItem findItem2 = this.f52a.mMenu.findItem(R.id.bRemountRW);
                    if (findItem != null && findItem2 != null) {
                        if (this.f52a.cs.m397a(this.f52a) == (byte) 2) {
                            findItem.setVisible(true);
                            findItem2.setVisible(false);
                            return;
                        } else if (this.f52a.cs.m397a(this.f52a) == (byte) 3) {
                            findItem.setVisible(false);
                            findItem2.setVisible(true);
                            return;
                        } else {
                            return;
                        }
                    }
                    return;
                }
                return;
            }
            this.f52a.mToastInfo = Toast.makeText(this.f52a.getApplicationContext(), this.f52a.getResources().getString(R.string.MES_ERROR_ON_REMOUNT).replace("%1", this.f53b), 0);
            this.f52a.mToastInfo.show();
        }

        protected /* synthetic */ Object doInBackground(Object[] objArr) {
            return m28a((Void[]) objArr);
        }

        protected /* synthetic */ void onPostExecute(Object obj) {
            m29a((Boolean) obj);
        }
    }

    /* renamed from: ru.zdevs.zarchiver.ZArchiver$f */
    private class C0028f extends C0025d {
        /* renamed from: b */
        final /* synthetic */ ZArchiver f56b;
        /* renamed from: c */
        private final MyUri f57c;
        /* renamed from: d */
        private final int f58d;
        /* renamed from: e */
        private final boolean f59e;
        /* renamed from: f */
        private final boolean f60f;
        /* renamed from: g */
        private final boolean f61g;
        /* renamed from: h */
        private ZProcDialog f62h;
        /* renamed from: i */
        private int f63i;
        /* renamed from: j */
        private List<C0049e> f64j;

        /* renamed from: ru.zdevs.zarchiver.ZArchiver$f$1 */
        class C00271 implements OnCancelListener {
            /* renamed from: a */
            final /* synthetic */ C0028f f55a;

            C00271(C0028f c0028f) {
                this.f55a = c0028f;
            }

            public void onCancel(ZDialog zDialog) {
                C2JBridge.cSetStatus(0, 15);
            }
        }

        C0028f(ZArchiver zArchiver, MyUri myUri) {
            this.f56b = zArchiver;
            super();
            this.f57c = myUri;
            this.f58d = 0;
            this.f63i = 0;
            this.f59e = false;
            this.f60f = false;
            this.f61g = false;
            this.f62h = null;
            this.f64j = null;
        }

        C0028f(ZArchiver zArchiver, MyUri myUri, boolean z, int i) {
            this.f56b = zArchiver;
            super();
            this.f57c = myUri;
            this.f63i = 0;
            this.f59e = z;
            this.f60f = false;
            this.f61g = true;
            this.f58d = i;
            this.f62h = null;
            this.f64j = null;
        }

        C0028f(ZArchiver zArchiver, MyUri myUri, boolean z, boolean z2) {
            this.f56b = zArchiver;
            super();
            this.f57c = myUri;
            this.f58d = 0;
            this.f63i = 0;
            this.f59e = z;
            if (z) {
                this.f60f = z2;
            } else {
                this.f60f = false;
            }
            this.f61g = false;
            this.f62h = null;
            this.f64j = null;
        }

        /* renamed from: a */
        protected Void m30a(Void... voidArr) {
            Thread.currentThread().setPriority(10);
            this.f64j = new ArrayList();
            for (ZViewFS zViewFS : ZViewFS.get()) {
                if (!isCancelled()) {
                    if (zViewFS.list(this.f56b, this.f57c, this.f64j, this.f60f ? 1 : 0)) {
                        this.f63i = zViewFS.getMessage();
                        break;
                    }
                }
                break;
            }
            return null;
        }

        /* renamed from: a */
        public void mo7a() {
            C0071e.m296e();
            cancel(true);
        }

        /* renamed from: a */
        protected void m32a(Void voidR) {
            boolean z = true;
            if (this.f62h != null) {
                this.f62h.close();
                this.f62h = null;
            }
            if (!isCancelled() && this.f64j != null) {
                Animation loadAnimation;
                boolean d;
                MenuItem findItem;
                MenuItem findItem2;
                AdapterView listView;
                C0046h listAdapter;
                int i;
                this.f56b.mSetPath = null;
                if (!this.f59e && Settings.sGUIAnimation) {
                    try {
                        loadAnimation = AnimationUtils.loadAnimation(this.f56b, R.anim.file_list_in);
                    } catch (Throwable e) {
                        C0166c.m556a(e);
                    }
                    this.f56b.cs.f351b = this.f64j;
                    d = this.f56b.cs.m408d();
                    this.f56b.cs.m403a(this.f57c);
                    if (this.f56b.mMenu == null) {
                        findItem = this.f56b.mMenu.findItem(R.id.bRemountRO);
                        findItem2 = this.f56b.mMenu.findItem(R.id.bRemountRW);
                    } else {
                        findItem2 = null;
                        findItem = null;
                    }
                    if (this.f57c.isStorage() || this.f56b.cs.m397a(this.f56b) == (byte) 1) {
                        if (this.f57c.isRoot()) {
                            this.f56b.setHeaderMode(true);
                        } else if (this.f57c.isLocalFS()) {
                            this.f56b.setHeaderMode(false);
                        } else {
                            this.f56b.setHeaderMode(this.f56b.cs.m410f() == (byte) 1);
                        }
                        if (findItem != null) {
                            findItem.setVisible(false);
                        }
                        if (findItem2 != null) {
                            findItem2.setVisible(false);
                        }
                    } else {
                        this.f56b.setHeaderMode(true);
                        if (!(!Settings.sRoot || findItem == null || findItem2 == null)) {
                            if (this.f56b.cs.m397a(this.f56b) == (byte) 2) {
                                findItem.setVisible(true);
                                findItem2.setVisible(false);
                            } else if (this.f56b.cs.m397a(this.f56b) == (byte) 3) {
                                findItem.setVisible(false);
                                findItem2.setVisible(true);
                            }
                        }
                    }
                    listView = this.f56b.getListView();
                    listView.setAnimation(loadAnimation);
                    if (loadAnimation != null) {
                        listView.startLayoutAnimation();
                    }
                    listAdapter = this.f56b.getListAdapter();
                    if (listAdapter == null || listAdapter.mo26i() != (byte) 0) {
                        z = false;
                    }
                    listAdapter = z ? (C0047d) listAdapter : new C0047d(this.f56b);
                    if (!(this.f59e || !Settings.sGUIAnimation || loadAnimation == null)) {
                        listView.startLayoutAnimation();
                    }
                    listAdapter.m89a(this.f56b.cs.f351b, this.f56b.cs.m411g());
                    if (this.f60f || !z) {
                        this.f56b.setListAdapter(listAdapter);
                    } else {
                        listAdapter.notifyDataSetChanged();
                    }
                    if (this.f61g && this.f58d > 0) {
                        listView.setSelection(this.f58d);
                    }
                    this.f56b.setFSMessage(this.f63i, loadAnimation);
                    this.f56b.onUpdatePath();
                    this.f56b.setFloatAction();
                    if ((this.f59e && !this.f60f) || d != this.f56b.cs.m408d()) {
                        this.f56b.onChangeInArchiveState();
                    }
                    if (this.f56b.mOpenFileName != null) {
                        i = 0;
                        for (C0049e e2 : ((C0047d) this.f56b.getListAdapter()).m87a()) {
                            if (e2.mo28e().equals(this.f56b.mOpenFileName)) {
                                listView.setSelection(i);
                                this.f56b.onItemClick(listView, null, i, 0);
                                break;
                            }
                            i++;
                        }
                        this.f56b.mOpenFileName = null;
                    }
                }
                loadAnimation = null;
                this.f56b.cs.f351b = this.f64j;
                d = this.f56b.cs.m408d();
                this.f56b.cs.m403a(this.f57c);
                if (this.f56b.mMenu == null) {
                    findItem2 = null;
                    findItem = null;
                } else {
                    findItem = this.f56b.mMenu.findItem(R.id.bRemountRO);
                    findItem2 = this.f56b.mMenu.findItem(R.id.bRemountRW);
                }
                if (this.f57c.isStorage()) {
                }
                if (this.f57c.isRoot()) {
                    this.f56b.setHeaderMode(true);
                } else if (this.f57c.isLocalFS()) {
                    this.f56b.setHeaderMode(false);
                } else {
                    if (this.f56b.cs.m410f() == (byte) 1) {
                    }
                    this.f56b.setHeaderMode(this.f56b.cs.m410f() == (byte) 1);
                }
                if (findItem != null) {
                    findItem.setVisible(false);
                }
                if (findItem2 != null) {
                    findItem2.setVisible(false);
                }
                listView = this.f56b.getListView();
                listView.setAnimation(loadAnimation);
                if (loadAnimation != null) {
                    listView.startLayoutAnimation();
                }
                listAdapter = this.f56b.getListAdapter();
                z = false;
                if (z) {
                }
                listView.startLayoutAnimation();
                listAdapter.m89a(this.f56b.cs.f351b, this.f56b.cs.m411g());
                if (this.f60f) {
                }
                this.f56b.setListAdapter(listAdapter);
                listView.setSelection(this.f58d);
                this.f56b.setFSMessage(this.f63i, loadAnimation);
                this.f56b.onUpdatePath();
                this.f56b.setFloatAction();
                this.f56b.onChangeInArchiveState();
                if (this.f56b.mOpenFileName != null) {
                    i = 0;
                    while (r4.hasNext()) {
                        if (e2.mo28e().equals(this.f56b.mOpenFileName)) {
                            listView.setSelection(i);
                            this.f56b.onItemClick(listView, null, i, 0);
                            break;
                        }
                        i++;
                    }
                    this.f56b.mOpenFileName = null;
                }
            }
        }

        protected /* synthetic */ Object doInBackground(Object[] objArr) {
            return m30a((Void[]) objArr);
        }

        protected void onCancelled() {
            if (this.f62h != null) {
                this.f62h.close();
                this.f62h = null;
            }
        }

        protected /* synthetic */ void onPostExecute(Object obj) {
            m32a((Void) obj);
        }

        protected void onPreExecute() {
            if (!this.f59e) {
                this.f56b.cs.m401a(this.f56b.getPosition());
            }
            if (this.f56b.cs.f356g) {
                this.f56b.setCancelSearch(true);
            }
            if (!this.f57c.isLocalFS()) {
                this.f62h = new ZProcDialog(this.f56b.cs, this.f56b, R.string.MES_GET_FILE_LIST_PROCESS);
                this.f62h.setTaskID(0);
                this.f62h.setOnCancelListener(new C00271(this));
                this.f62h.show();
            }
        }
    }

    /* renamed from: ru.zdevs.zarchiver.ZArchiver$g */
    private class C0030g extends C0025d {
        /* renamed from: b */
        final /* synthetic */ ZArchiver f66b;
        /* renamed from: c */
        private final MyUri f67c;
        /* renamed from: d */
        private ZProcDialog f68d = null;

        /* renamed from: ru.zdevs.zarchiver.ZArchiver$g$1 */
        class C00291 implements OnCancelListener {
            /* renamed from: a */
            final /* synthetic */ C0030g f65a;

            C00291(C0030g c0030g) {
                this.f65a = c0030g;
            }

            public void onCancel(ZDialog zDialog) {
                C2JBridge.cSetStatus(0, 15);
            }
        }

        C0030g(ZArchiver zArchiver, MyUri myUri) {
            this.f66b = zArchiver;
            super();
            this.f67c = myUri;
        }

        /* renamed from: a */
        protected Void m33a(Void... voidArr) {
            Thread.currentThread().setPriority(10);
            C0071e.m291a(this.f66b.cs, this.f66b, this.f67c.getPath());
            return null;
        }

        /* renamed from: a */
        public void mo7a() {
            C0071e.m296e();
            cancel(true);
        }

        /* renamed from: a */
        protected void m35a(Void voidR) {
            if (this.f68d != null) {
                this.f68d.close();
                this.f68d = null;
            }
            if (!isCancelled()) {
                if (this.f66b.mFindFile == null) {
                    this.f66b.mFindFile = new FindFile(this.f66b, this.f66b);
                }
                this.f66b.mFindFile.startFindFile(this.f67c, this.f66b.cs.f355f);
            }
        }

        protected /* synthetic */ Object doInBackground(Object[] objArr) {
            return m33a((Void[]) objArr);
        }

        protected void onCancelled() {
            if (this.f68d != null) {
                this.f68d.close();
                this.f68d = null;
            }
        }

        protected /* synthetic */ void onPostExecute(Object obj) {
            m35a((Void) obj);
        }

        protected void onPreExecute() {
            this.f68d = new ZProcDialog(this.f66b.cs, this.f66b, R.string.MES_GET_FILE_LIST_PROCESS);
            this.f68d.setTaskID(0);
            this.f68d.setOnCancelListener(new C00291(this));
            this.f68d.show();
        }
    }

    private void _onDestroy() {
        if (this.cs != null) {
            if (this.cs.f350a != null) {
                try {
                    unregisterReceiver(this.cs.f350a.mMessageReceiver);
                    unregisterReceiver(this.cs.f350a);
                } catch (Throwable e) {
                    C0166c.m556a(e);
                }
            }
            if (isFinishing()) {
                this.cs.m420p();
            }
            this.cs = null;
        }
    }

    private void _onStart() {
        this.cs.f350a.setZArchiver(this, this.iService);
        sHackSuppressDouble = this;
        C0199n.m692a((Context) this, 255);
        C0143a.m427a((Context) this);
        startZService();
        if (Settings.sFMShowThumbnails || Settings.sFMShowApkIcon) {
            if (this.mImageLoader == null) {
                this.mImageLoader = new C0178g(this);
            }
            this.mImageLoader.m616a((Context) this);
            C0047d.m84a(this.mImageLoader);
            C0051f.m117a(this.mImageLoader);
            this.mImageLoader.m618b();
        } else {
            C0047d.m84a(null);
            C0051f.m117a(null);
            if (this.mImageLoader != null) {
                if (this.mImageLoader.m619c()) {
                    this.mImageLoader.m615a();
                }
                this.mImageLoader = null;
            }
        }
        setMyProgressBarVisibility(false);
        if (VERSION.SDK_INT <= 19 || !this.mTestExternalSD || (Settings.sShowHelp & 2) == 0 || !Settings.isNeedStoragePermission(this)) {
            checkPermission();
            return;
        }
        this.mTestExternalSD = false;
        new ZFixSDDialog(this.cs, this).show();
    }

    private void fillFileList() {
        boolean z = true;
        C0046h listAdapter = getListAdapter();
        if (listAdapter != null && listAdapter.mo16b() > 0) {
            Actions actions = this.cs.f350a;
            int[] f = listAdapter.mo23f();
            if (listAdapter.mo26i() != (byte) 1) {
                z = false;
            }
            actions.fillFileListAction(f, z);
            listAdapter.mo19c();
        }
    }

    private void findModifiedFile() {
        if (this.cs != null) {
            File file = new File(C0202q.m727a((Context) this));
            if (!file.exists()) {
                return;
            }
            if (!this.cs.m408d() || !this.cs.m411g().getPath().startsWith(C0202q.m727a((Context) this))) {
                File[] listFiles = file.listFiles();
                if (listFiles != null) {
                    for (File file2 : listFiles) {
                        file = new File(file2.getAbsolutePath() + ".hash");
                        if (file.exists()) {
                            String str = null;
                            try {
                                Reader fileReader = new FileReader(file);
                                LineNumberReader lineNumberReader = new LineNumberReader(fileReader);
                                str = lineNumberReader.readLine();
                                lineNumberReader.close();
                                fileReader.close();
                            } catch (Throwable e) {
                                C0166c.m556a(e);
                            }
                            if (str != null) {
                                String b = str.startsWith("S:") ? "S:" + file2.length() : C0167d.m567b(file2.getAbsolutePath());
                                if (str.length() > 0 && b.length() > 0 && !str.equals(b)) {
                                    ZMessageDialog zMessageDialog = new ZMessageDialog(this.cs, this, (byte) 1, getString(R.string.MOD_UPDATE_FILE).replace("%1", file2.getName()));
                                    zMessageDialog.setSubType(15);
                                    zMessageDialog.setOnOkListener(this.cs.f350a);
                                    zMessageDialog.setOnCancelListener(this.cs.f350a);
                                    zMessageDialog.setStringData(0, file2.getAbsolutePath());
                                    zMessageDialog.show();
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private void onBack(boolean z) {
        if (this.mToastInfo != null) {
            this.mToastInfo.cancel();
            this.mToastInfo = null;
        }
        if (this.cs.f356g && Settings.sBackType == (byte) 1) {
            setCancelSearch(false);
        } else if (z && this.cs.m416l()) {
            this.mExit = true;
            this.mToastInfo = Toast.makeText(getApplicationContext(), getResources().getString(R.string.MES_PRESS_BACK_FOR_EXIT), 0);
            this.mToastInfo.show();
        } else {
            C0135a o = this.cs.m419o();
            if (this.cs.m414j() == '\u0000') {
                while (o != null && o.f346b != '\u0000') {
                    o = this.cs.m419o();
                }
                while (o != null && o.f345a.compareTo(this.cs.m411g()) == 0 && o.f348d == this.cs.f356g) {
                    o = this.cs.m419o();
                }
            }
            boolean z2 = false;
            while (o != null && o.f345a.isArchive() && !new File(o.f345a.getPath()).exists()) {
                o = this.cs.m419o();
                z2 = true;
            }
            if (z2) {
                while (o != null && o.f345a.compareTo(this.cs.m411g()) == 0 && o.f348d == this.cs.f356g) {
                    o = this.cs.m419o();
                }
            }
            if (o == null || !o.f348d || (this.cs.f355f != null && this.cs.f355f.length() > 0)) {
                z2 = false;
            } else {
                o = this.cs.m419o();
                z2 = true;
            }
            if (z2) {
                while (o != null && o.f345a.compareTo(this.cs.m411g()) == 0 && o.f348d == this.cs.f356g) {
                    o = this.cs.m419o();
                }
            }
            C0166c.m559d(TAG, "Back use: " + (o != null ? o.toString() : "null"));
            z2 = this.cs.m408d() && this.cs.m414j() == '\u0000';
            if (o == null) {
                MyUri g = this.cs.m411g();
                g.del();
                this.cs.m403a(g);
                onUpdateList(false);
            } else {
                this.cs.m403a(o.f345a);
                if (!(o.f346b != '\u0000' || this.cs.m414j() == '\u0000' || this.mActionMode == null)) {
                    this.mActionMode.finish();
                    this.cs.m399a('\u0000');
                }
                if (this.cs.f356g && !o.f348d) {
                    this.cs.m401a(o.f347c);
                    setCancelSearch(false);
                }
                if (o.f348d) {
                    setRepeatSearch(true);
                    setFSMessage(o.f349e);
                    if (getListView() != null && o.f347c >= 0) {
                        getListView().setSelection(o.f347c);
                    }
                } else {
                    onUpdateList(false, o.f347c);
                }
            }
            if (z2 && !this.cs.m408d() && this.cs.m414j() == '\u0000') {
                try {
                    if (C0072g.m300a(C0061a.m214d())) {
                        C0061a.m216e();
                    }
                    C0072g.m302b();
                } catch (Throwable e) {
                    C0166c.m556a(e);
                }
            }
        }
    }

    private void onShowMenu() {
        Object obj;
        Object obj2;
        Object obj3;
        Object obj4 = 1;
        if (this.cs.m414j() == '\u0000') {
            C0046h listAdapter = getListAdapter();
            if (listAdapter != null) {
                obj = listAdapter.mo16b() > 0 ? 1 : null;
            } else {
                obj = null;
            }
            if (obj != null) {
                for (int b : listAdapter.mo23f()) {
                    if (listAdapter.mo17b(b).mo29h() != (byte) 7) {
                        obj2 = null;
                        break;
                    }
                }
                int i = 1;
                this.cs.f350a.fillFileListAction(listAdapter.mo23f(), listAdapter.mo26i() == (byte) 1);
                obj3 = obj;
            } else {
                obj2 = null;
                obj3 = obj;
            }
        } else {
            obj2 = null;
            obj3 = null;
        }
        boolean d = this.cs.m408d();
        obj = (d && C0061a.m205a((Context) this, this.cs.m411g().getPath())) ? 1 : null;
        if (!this.cs.f350a.isCopy() || this.cs.f356g) {
            obj4 = null;
        }
        List arrayList = new ArrayList();
        C0093d c0093d = new C0093d(this);
        if (this.cs.m414j() == '\u0000') {
            if (!(obj3 == null || d || obj2 != null || this.cs.f356g)) {
                c0093d.m374a(arrayList, 7);
            }
            if (obj2 != null || (d && obj3 != null)) {
                c0093d.m374a(arrayList, 4);
            }
            if (!(obj3 != null || r1 == null || (d && obj == null))) {
                c0093d.m374a(arrayList, 26);
            }
            if (obj3 != null) {
                c0093d.m374a(arrayList, 24);
                if (!d) {
                    c0093d.m374a(arrayList, 25);
                    c0093d.m374a(arrayList, 23);
                } else if (obj != null) {
                    c0093d.m374a(arrayList, 56);
                }
            }
            c0093d.m374a(arrayList, 14);
            if (obj3 != null) {
                c0093d.m374a(arrayList, 16);
                c0093d.m374a(arrayList, 15);
            } else {
                c0093d.m374a(arrayList, 91);
            }
        } else {
            if (this.cs.m414j() == '\t' || this.cs.m414j() == '\u0011') {
                c0093d.m374a(arrayList, 92);
            } else if (this.cs.m414j() == Actions.ACTION_PAST) {
                c0093d.m374a(arrayList, 93);
            } else if (this.cs.m414j() == Actions.ACTION_CREATE_ARCHIVE) {
                c0093d.m374a(arrayList, 94);
            }
            if (this.cs.m415k() == '\u0002') {
                c0093d.m374a(arrayList, 14);
                c0093d.m374a(arrayList, 16);
                c0093d.m374a(arrayList, 15);
            }
            if (this.cs.m414j() == '\u0002') {
                c0093d.m374a(arrayList, 95);
            } else {
                c0093d.m374a(arrayList, 96);
            }
        }
        c0093d.m374a(arrayList, 90);
        c0093d.m374a(arrayList, 97);
        ZMenuDialog zMenuDialog = new ZMenuDialog(this.cs, (Context) this, arrayList, (int) R.string.app_name);
        zMenuDialog.setOnOkListener(this.cs.f350a);
        zMenuDialog.show();
    }

    private void onUpdatePath() {
        CharSequence charSequence;
        String substring;
        String h = (this.cs.m404a() || this.cs.m409e()) ? this.cs.m412h() : this.cs.m408d() ? this.cs.m411g().getFragment().length() > 1 ? this.cs.m411g().getPath() + this.cs.m411g().getFragment() : this.cs.m411g().getPath() : "";
        if (h.startsWith(C0202q.m727a((Context) this))) {
            h = h.replace(C0202q.m727a((Context) this), "~");
        }
        int lastIndexOf = h.lastIndexOf(47);
        if (lastIndexOf < 0 || h.length() <= 1) {
            charSequence = "/";
        } else {
            substring = h.substring(lastIndexOf + 1);
            String str;
            if (lastIndexOf > 0) {
                str = substring;
                charSequence = h.substring(0, lastIndexOf);
                h = str;
            } else {
                str = substring;
                Object obj = "/";
                h = str;
            }
        }
        if (this.mSubtitle != null) {
            try {
                this.mSubtitle.setText(charSequence);
            } catch (Throwable e) {
                C0166c.m556a(e);
                this.mSubtitle.setEllipsize(null);
                this.mSubtitle.setGravity(8388613);
                this.mSubtitle.setText(charSequence);
            }
        }
        if (this.mTitle != null) {
            this.mTitle.setText(h);
        }
        if (this.mLlFolderInfo != null) {
            if (this.mFolderInfo != null) {
                this.mFolderInfo.cancel(true);
            }
            this.mLlFolderInfo.setVisibility(0);
            if (this.cs.m408d()) {
                if (this.mLlStorage != null) {
                    this.mLlStorage.setVisibility(0);
                }
                substring = this.cs.m411g().getPath();
                if (substring.contains("/") && substring.lastIndexOf(47) + 1 < substring.length()) {
                    substring = substring.substring(substring.lastIndexOf(47) + 1);
                }
                this.mTvStorage.setText(getString(R.string.FINFO_ARCHIVE) + " " + substring);
                float f = -1.0f;
                try {
                    f = C0061a.m220g() * 100.0f;
                } catch (Throwable e2) {
                    C0166c.m556a(e2);
                }
                if (f >= 0.0f) {
                    this.mTvStorageSpace.setText(String.format(Locale.getDefault(), "%s %.1f%%", new Object[]{getString(R.string.FINFO_COMPRESSION_RATIO), Float.valueOf(f)}));
                    if (this.mPbFree != null) {
                        this.mPbFree.setMax(100);
                        this.mPbFree.setProgress((int) f);
                    }
                } else {
                    this.mTvStorageSpace.setText(getString(R.string.FINFO_COMPRESSION_RATIO) + " ---");
                    if (this.mPbFree != null) {
                        this.mPbFree.setMax(100);
                        this.mPbFree.setProgress(0);
                    }
                }
                if (this.cs.m411g().getFragment() == null || this.cs.m411g().getFragment().equals("/")) {
                    this.mTvFolder.setText(getString(R.string.FINFO_TYPE_FOLDER) + ": /");
                } else {
                    this.mTvFolder.setText(getString(R.string.FINFO_TYPE_FOLDER) + ": " + h);
                }
            } else {
                long j;
                this.mTvFolder.setText(getString(R.string.FINFO_TYPE_FOLDER) + ": " + h);
                long j2 = -1;
                File canonicalFile;
                long j3;
                if (this.cs.m404a()) {
                    try {
                        canonicalFile = this.cs.m411g().toFile().getCanonicalFile();
                        j2 = canonicalFile.getFreeSpace();
                        j3 = j2;
                        j2 = canonicalFile.getTotalSpace();
                        j = j3;
                    } catch (Throwable e3) {
                        C0166c.m556a(e3);
                        j = j2;
                        j2 = -1;
                    }
                } else {
                    if (this.cs.m409e()) {
                        try {
                            canonicalFile = new File(this.cs.m411g().toLocalPath().replace("/SAF", "/mnt/media_rw"));
                            j2 = canonicalFile.getFreeSpace();
                            j3 = j2;
                            j2 = canonicalFile.getTotalSpace();
                            j = j3;
                        } catch (Throwable e32) {
                            C0166c.m556a(e32);
                        }
                    }
                    j = j2;
                    j2 = -1;
                }
                if (j2 < 0 || j < 0) {
                    if (this.mPbFree != null) {
                        this.mPbFree.setMax(1);
                        this.mPbFree.setProgress(0);
                    }
                    if (this.mLlStorage != null) {
                        this.mLlStorage.setVisibility(8);
                    }
                } else {
                    this.mTvStorage.setText(getString(R.string.FINFO_TYPE) + ' ' + getString(R.string.FINFO_TYPE_FOLDER));
                    this.mTvStorageSpace.setText(String.format(Locale.getDefault(), "%s %s/\n%s", new Object[]{getString(R.string.FINFO_FREE_SPACE), C0202q.m726a(j), C0202q.m726a(j2)}));
                    if (this.mPbFree != null) {
                        if (j2 > 2147483647L) {
                            j2 >>= 10;
                            j >>= 10;
                        }
                        this.mPbFree.setMax((int) j2);
                        this.mPbFree.setProgress((int) (j2 - j));
                    }
                }
            }
            if (this.mLlFolderInfo.getId() != R.id.svSwipe) {
                this.mTvFolderSize.setText(getString(R.string.FINFO_SIZE) + " ...");
                this.mFolderInfo = new C0024c(this.cs.m411g()).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Void[0]);
                return;
            }
            this.mTvFolderSize.setTag(null);
        }
    }

    private void openFile(MyUri myUri, String str) {
        if (myUri.isArchive()) {
            this.cs.f350a.archiveOpenFile(myUri, str);
        } else if (myUri.isLocalFS()) {
            C0202q.m739b((Context) this, myUri.toLocalPath() + "/" + str);
        }
    }

    private void setEnabledMenuItems(Menu menu, int[] iArr, boolean z) {
        if (menu != null) {
            for (int findItem : iArr) {
                MenuItem findItem2 = menu.findItem(findItem);
                if (findItem2 != null) {
                    findItem2.setEnabled(z);
                }
            }
        }
    }

    @SuppressLint({"NewApi"})
    private void setFloatColor() {
        if (this.mFloatButton != null && VERSION.SDK_INT >= 16 && VERSION.SDK_INT < 21) {
            int b = C0202q.m735b((Context) this, (int) R.attr.colorPrimary);
            int b2 = C0202q.m735b((Context) this, (int) R.attr.colorPrimaryLight);
            try {
                GradientDrawable gradientDrawable = (GradientDrawable) getResources().getDrawable(R.drawable.floating_button);
                gradientDrawable.setColor(b);
                GradientDrawable gradientDrawable2 = (GradientDrawable) getResources().getDrawable(R.drawable.floating_button_pressed);
                gradientDrawable2.setColor(b2);
                Drawable stateListDrawable = new StateListDrawable();
                stateListDrawable.addState(new int[]{16842919}, gradientDrawable2);
                stateListDrawable.addState(new int[]{16842908}, gradientDrawable2);
                stateListDrawable.addState(new int[0], gradientDrawable);
                if (VERSION.SDK_INT < 16) {
                    this.mFloatButton.setBackgroundDrawable(stateListDrawable);
                } else {
                    this.mFloatButton.setBackground(stateListDrawable);
                }
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
        }
    }

    private void setHeaderMode(boolean z) {
        if (this.mHeaderIsRoot != z) {
            this.mHeaderIsRoot = z;
            ActionBar actionBar = getActionBar();
            if (actionBar != null) {
                int b = z ? C0202q.m735b((Context) this, (int) R.attr.actionBarBackgroundInRoot) : C0202q.m735b((Context) this, (int) R.attr.colorPrimary);
                Drawable colorDrawable;
                if (Settings.sActionbarColor != 0) {
                    if (VERSION.SDK_INT < 21) {
                        C0002a c0002a = new C0002a(this);
                        c0002a.m15a(true);
                        if (Settings.sGUIWideBar) {
                            c0002a.m17b(true);
                        }
                        c0002a.m14a(b);
                    }
                    colorDrawable = new ColorDrawable(b);
                    actionBar.setBackgroundDrawable(colorDrawable);
                    actionBar.setSplitBackgroundDrawable(colorDrawable);
                } else if (z) {
                    colorDrawable = new ColorDrawable(b);
                    actionBar.setBackgroundDrawable(colorDrawable);
                    actionBar.setSplitBackgroundDrawable(colorDrawable);
                } else {
                    TypedArray obtainStyledAttributes = obtainStyledAttributes(new int[]{16843470});
                    b = obtainStyledAttributes.getResourceId(0, 0);
                    if (b == 0) {
                        b = C0058a.m146a(this) ? Settings.sTheme == (byte) 1 ? 16974243 : 16974187 : Settings.sTheme == (byte) 1 ? 16974247 : 16974195;
                    }
                    obtainStyledAttributes.recycle();
                    TypedArray obtainStyledAttributes2 = obtainStyledAttributes(b, new int[]{16842964, 16843659});
                    if (Settings.sTheme == (byte) 0 && !Settings.sGUIWideBar && VERSION.SDK_INT == 19) {
                        actionBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#90000000")));
                    } else {
                        actionBar.setBackgroundDrawable(obtainStyledAttributes2.getDrawable(0));
                    }
                    actionBar.setSplitBackgroundDrawable(obtainStyledAttributes2.getDrawable(1));
                    obtainStyledAttributes2.recycle();
                }
            }
        }
    }

    private void setIconActionMode(boolean z) {
        View findViewById = findViewById(Resources.getSystem().getIdentifier("action_mode_close_button", "id", "android"));
        if (findViewById != null) {
            try {
                if (findViewById instanceof ImageView) {
                    ImageView imageView = (ImageView) findViewById;
                    if (this.iDefIcon == null) {
                        this.iDefIcon = imageView.getDrawable();
                    }
                    if (z) {
                        imageView.setImageDrawable(C0202q.m725a((Context) this, (int) R.attr.menuIconCancel));
                        return;
                    } else {
                        imageView.setImageDrawable(this.iDefIcon);
                        return;
                    }
                }
                LinearLayout linearLayout = (LinearLayout) findViewById;
                if (linearLayout.getChildCount() > 0 && linearLayout.getChildAt(0) != null) {
                    ImageView imageView2 = (ImageView) linearLayout.getChildAt(0);
                    if (this.iDefIcon == null) {
                        this.iDefIcon = imageView2.getDrawable();
                    }
                    if (z) {
                        imageView2.setImageDrawable(C0202q.m725a((Context) this, (int) R.attr.menuIconCancel));
                    } else {
                        imageView2.setImageDrawable(this.iDefIcon);
                    }
                    if (linearLayout.getChildCount() > 1 && linearLayout.getChildAt(1) != null) {
                        TextView textView = (TextView) linearLayout.getChildAt(1);
                        if (z) {
                            textView.setText(17039360);
                        } else {
                            textView.setText(17039370);
                        }
                    }
                }
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
        }
    }

    private void setIconInMenu(Menu menu) {
        if (menu != null && !C0058a.m145a()) {
            try {
                if (menu.getClass().getSimpleName().equals("MenuBuilder")) {
                    Method declaredMethod = menu.getClass().getDeclaredMethod("setOptionalIconsVisible", new Class[]{Boolean.TYPE});
                    if (declaredMethod != null) {
                        declaredMethod.setAccessible(true);
                        declaredMethod.invoke(menu, new Object[]{Boolean.valueOf(true)});
                    }
                }
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
        }
    }

    @SuppressLint({"NewApi"})
    public static void setLanguage(Context context) {
        Resources resources = context.getResources();
        if (resources != null) {
            Locale locale;
            if (Settings.sLanguage == null || Settings.sLanguage.length() <= 0) {
                locale = Locale.getDefault();
            } else {
                String substring;
                String substring2;
                int lastIndexOf = Settings.sLanguage.lastIndexOf(95);
                if (lastIndexOf >= 0) {
                    substring = Settings.sLanguage.substring(lastIndexOf + 1);
                    substring2 = Settings.sLanguage.substring(0, lastIndexOf);
                } else {
                    substring2 = Settings.sLanguage;
                    substring = "";
                }
                locale = new Locale(substring2, substring);
            }
            Configuration configuration = resources.getConfiguration();
            if (VERSION.SDK_INT < 17) {
                configuration.locale = locale;
            } else {
                configuration.setLocale(locale);
            }
            resources.updateConfiguration(configuration, resources.getDisplayMetrics());
        }
    }

    private void setSortFileList(byte b, boolean z) {
        Settings.sFMSortType = b;
        Settings.sFMSortDesc = z;
        ZViewFS.setSort(Settings.sFMSortType, Settings.sFMSortDesc);
        setSortFileList(this.mMenu);
    }

    private void setSortFileList(Menu menu) {
        if (menu != null) {
            MenuItem findItem;
            switch (Settings.sFMSortType) {
                case (byte) 0:
                    findItem = menu.findItem(R.id.bSortByName);
                    break;
                case (byte) 1:
                    findItem = menu.findItem(R.id.bSortByType);
                    break;
                case (byte) 2:
                    findItem = menu.findItem(R.id.bSortBySize);
                    break;
                case (byte) 3:
                    findItem = menu.findItem(R.id.bSortByDate);
                    break;
                default:
                    findItem = null;
                    break;
            }
            if (findItem != null) {
                findItem.setChecked(true);
            }
            findItem = menu.findItem(R.id.bSortDesс);
            if (findItem != null) {
                findItem.setChecked(Settings.sFMSortDesc);
            }
        }
    }

    @SuppressLint({"InlinedApi"})
    private void setTheme() {
        if (VERSION.SDK_INT >= 19) {
            if ((getResources().getConfiguration().screenLayout & 15) != 3 && ((Settings.sTheme == (byte) 0 && !Settings.sGUIWideBar) || ((Settings.sActionbarColor != 0 && Settings.sGUIWideBar) || VERSION.SDK_INT >= 21))) {
                getWindow().setFlags(134217728, 134217728);
            }
            if (Settings.sActionbarColor != 0 && VERSION.SDK_INT == 19) {
                getWindow().setFlags(67108864, 67108864);
            }
        }
        setTheme(Settings.sThemeResource);
        try {
            if (getActionBar() != null) {
                getActionBar().show();
            }
        } catch (Throwable e) {
            C0166c.m556a(e);
        }
        setHeaderMode(false);
    }

    private void setVisibleMenuItems(Menu menu, int[] iArr, boolean z) {
        if (menu != null) {
            for (int findItem : iArr) {
                MenuItem findItem2 = menu.findItem(findItem);
                if (findItem2 != null) {
                    findItem2.setVisible(z);
                }
            }
        }
    }

    private void startZService() {
        if (this.iService == null) {
            Intent intent = new Intent(this, ZArchiverService.class);
            startService(intent);
            bindService(intent, this.mConnection, 72);
        }
    }

    private void stopZService() {
        if (this.iService != null) {
            try {
                if (!this.mReconfigure) {
                    this.iService.GUIStatus(0);
                }
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
            this.iService = null;
        }
        try {
            unbindService(this.mConnection);
        } catch (Throwable e2) {
            C0166c.m556a(e2);
        }
    }

    public void ProcessIntent(Intent intent, boolean z, boolean z2) {
        boolean z3 = true;
        if (intent != null) {
            if (C0092c.m373c(intent)) {
                this.cs.f350a.compressSend(this, intent, z);
            } else if (C0091b.m358a(intent) && C0091b.m370m(intent)) {
                r0 = C0091b.m364g(intent);
                this.cs.m401a(getPosition());
                this.cs.m403a(new MyUri(FSArchive.SCHEME, "", r0, "/"));
                if (z2) {
                    onUpdateList(false);
                }
                if (z) {
                    this.cs.m417m();
                }
            } else if (C0092c.m371a(intent)) {
                this.cs.f350a.onReceive(this, intent);
            } else {
                Uri data = intent.getData();
                intent.setData(null);
                if (data != null) {
                    String scheme = data.getScheme();
                    boolean equals = "file".equals(scheme);
                    if ("content".equals(scheme)) {
                        scheme = intent.getStringExtra("AbsolutePath");
                        if (scheme != null) {
                            File file = new File(scheme);
                            if (file.exists()) {
                                data = Uri.fromFile(file);
                                equals = true;
                            } else {
                                scheme = null;
                            }
                        }
                        if (scheme == null) {
                            this.cs.f350a.openContent(this, data);
                        }
                    }
                    if (equals) {
                        File file2 = new File(data.getPath());
                        if (file2.isDirectory()) {
                            this.cs.m403a(new MyUri(FSLocal.SCHEME, file2.getAbsolutePath()));
                            if (z2) {
                                onUpdateList(false);
                            }
                            if (z) {
                                this.cs.m417m();
                            }
                        } else if (intent.getBooleanExtra("isZA", false) || Settings.sExtOpenArchive <= 0) {
                            r0 = data.getPath().replace("//", "/");
                            this.cs.m401a(getPosition());
                            this.cs.m403a(new MyUri(FSArchive.SCHEME, "", r0, "/"));
                            C0166c.m559d(TAG, "ProcessIntent: set path = " + this.cs.m411g().toString());
                            if (z2) {
                                onUpdateList(false);
                            }
                            if (z) {
                                this.cs.m417m();
                            }
                        } else {
                            String path = data.getPath();
                            String substring = path.substring(0, path.lastIndexOf(47));
                            this.mOpenFileName = path.substring(path.lastIndexOf(47) + 1);
                            if (Settings.sExtOpenArchive != 2) {
                                z3 = false;
                            }
                            this.mExitOnOperationComplete = z3;
                            this.cs.m403a(new MyUri(FSLocal.SCHEME, substring));
                            if (z2) {
                                onUpdateList(false);
                            }
                            if (z) {
                                this.cs.m417m();
                            }
                        }
                    }
                }
            }
        }
    }

    public void UpdateFavoriteList() {
        Favorites.updateFavorites(this);
        ListView listView = (ListView) findViewById(R.id.lvFavorite);
        if (listView != null) {
            ListAdapter c0043b = new C0043b(this);
            c0043b.m69a(Favorites.getFavorites(this));
            listView.setAdapter(c0043b);
        }
        if (this.mPopupNavigation != null) {
            this.mPopupNavigation.dismiss();
        }
    }

    @TargetApi(24)
    public void checkPermission() {
        if (VERSION.SDK_INT >= 23) {
            List arrayList = new ArrayList();
            if (checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") == -1) {
                arrayList.add("android.permission.READ_EXTERNAL_STORAGE");
            }
            if (checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") == -1) {
                arrayList.add("android.permission.WRITE_EXTERNAL_STORAGE");
            }
            if (arrayList.size() > 0) {
                requestPermissions((String[]) arrayList.toArray(new String[arrayList.size()]), 0);
            }
        }
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        if (this.cs == null || this.cs.m415k() != '\u0001' || keyEvent.getKeyCode() != 4 || keyEvent.getAction() != 1) {
            return super.dispatchKeyEvent(keyEvent);
        }
        onBack(true);
        return true;
    }

    public void finish() {
        if (this.mToastInfo != null) {
            this.mToastInfo.cancel();
            this.mToastInfo = null;
        }
        if (this.cs != null) {
            this.cs.m420p();
            C0202q.m738b((Context) this);
        }
        super.finish();
    }

    @SuppressLint({"NewApi"})
    public void finishAndRemoveTask() {
        if (VERSION.SDK_INT < 21) {
            finish();
        } else {
            super.finishAndRemoveTask();
        }
    }

    public C0046h getListAdapter() {
        return this.mListView == null ? null : (C0046h) this.mListView.getAdapter();
    }

    public AbsListView getListView() {
        return this.mListView;
    }

    public MenuInflater getMenuInflater() {
        return VERSION.SDK_INT < 16 ? new MenuInflater(this) : super.getMenuInflater();
    }

    public int getPosition() {
        AbsListView listView = getListView();
        return listView != null ? ((IListView) listView).getFirsItemPosition() : -1;
    }

    @SuppressLint({"NewApi"})
    public boolean isListViewFitsSystemWindows() {
        return VERSION.SDK_INT >= 19 && this.mListView != null && this.mListView.getFitsSystemWindows();
    }

    @SuppressLint({"NewApi"})
    protected void onActivityResult(int i, int i2, Intent intent) {
        boolean z = true;
        if (i == 105 && i2 == -1 && intent != null) {
            if (sHackSuppressDouble == null) {
                _onStart();
            }
            Uri data = intent.getData();
            int flags = intent.getFlags() & 3;
            C0198a b = C0199n.m696b(LollipopExtSD.getVolumeIdFromTreeUri(data));
            if (b == null || data == null) {
                z = false;
            } else {
                boolean z2;
                if (b.f542b.startsWith("/SAF")) {
                    String path = data.getPath();
                    if (path != null) {
                        if (path.indexOf(58) != path.length() - 1) {
                            z = false;
                        }
                        z2 = z;
                    } else {
                        z2 = true;
                    }
                } else {
                    LollipopExtSD.setContext(this);
                    z2 = LollipopExtSD.isCorrect(data, b);
                }
                if (z2) {
                    getApplicationContext().getContentResolver().takePersistableUriPermission(data, flags);
                    LollipopExtSD.setContext(null);
                    LollipopExtSD.setContext(this);
                }
                try {
                    if (this.iService != null) {
                        this.iService.SetSettings();
                    } else {
                        this.mServiceReloadSettings = true;
                    }
                } catch (Throwable e) {
                    C0166c.m556a(e);
                }
                Settings.updateStoragePermission(this);
                if (z2 && Settings.isNeedStoragePermission(this)) {
                    new ZFixSDDialog(this.cs, this).show();
                    z = z2;
                } else {
                    checkPermission();
                    z = z2;
                }
            }
            if (!z) {
                Toast.makeText(getApplicationContext(), getResources().getString(R.string.FSD_INCORRECT_PATH), 0).show();
            }
        }
        if (i == 106 && i2 == -1 && intent != null && intent.getData() != null) {
            if (sHackSuppressDouble == null) {
                _onStart();
            }
            getContentResolver().takePersistableUriPermission(intent.getData(), intent.getFlags() & 3);
            LollipopExtSD.setContext(null);
            LollipopExtSD.setContext(this);
            try {
                if (this.iService != null) {
                    this.iService.SetSettings();
                } else {
                    this.mServiceReloadSettings = true;
                }
            } catch (Throwable e2) {
                C0166c.m556a(e2);
            }
            Settings.updateStoragePermission(this);
            if (Settings.isNeedStoragePermission(this)) {
                new ZFixSDDialog(this.cs, this).show();
            } else {
                checkPermission();
            }
        }
        super.onActivityResult(i, i2, intent);
    }

    public void onChangeInArchiveState() {
        invalidateOptionsMenu();
    }

    public void onCheckSearchResult() {
        if (!this.cs.f356g) {
            return;
        }
        if (this.cs.m408d()) {
            C0061a.m216e();
            if (this.mSetPath != null) {
                this.mSetPath.mo7a();
            }
            this.mSetPath = new C0030g(this, this.cs.m411g());
            this.mSetPath.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Void[0]);
            if (this.mFindFile == null) {
                this.mFindFile = new FindFile(this, this);
            }
            this.mFindFile.startFindFile(this.cs.m411g(), this.cs.f355f);
            return;
        }
        synchronized (this.cs.f354e) {
            List<C0052g> arrayList = new ArrayList(this.cs.f354e);
            this.cs.f354e.clear();
        }
        for (C0052g c0052g : arrayList) {
            if (c0052g.m133l().isLocalFS() && new File(c0052g.m133l().getPath() + "/" + c0052g.mo28e()).exists()) {
                this.cs.f354e.add(c0052g);
            }
        }
        C0046h listAdapter = getListAdapter();
        if (listAdapter == null || listAdapter.mo26i() != (byte) 1) {
            listAdapter = new C0051f(this);
            listAdapter.m119a(this.cs.f354e);
            setListAdapter(listAdapter);
            return;
        }
        C0051f c0051f = (C0051f) listAdapter;
        c0051f.m119a(this.cs.f354e);
        c0051f.notifyDataSetChanged();
    }

    public void onCreate(Bundle bundle) {
        boolean z = true;
        C0166c.m558c(TAG, "onCreate");
        ((ZApplication) getApplication()).m24a();
        if (sHackSuppressDouble != null) {
            super.onCreate(bundle);
            sHackSuppressDouble.onNewIntent(getIntent());
            finish();
            return;
        }
        boolean z2;
        sHackSuppressDouble = this;
        Settings.LoadSettings(this, false);
        ZViewFS.setSort(Settings.sFMSortType, Settings.sFMSortDesc);
        if (VERSION.SDK_INT < 21) {
            requestWindowFeature(2);
            if (Settings.sGUIWideBar) {
                try {
                    getWindow().setUiOptions(1);
                } catch (Throwable e) {
                    C0166c.m556a(e);
                }
            }
        }
        try {
            ViewConfiguration viewConfiguration = ViewConfiguration.get(this);
            Field declaredField = ViewConfiguration.class.getDeclaredField("sHasPermanentMenuKey");
            Field declaredField2 = ViewConfiguration.class.getDeclaredField("sHasPermanentMenuKeySet");
            if (declaredField != null) {
                declaredField.setAccessible(true);
                declaredField.setBoolean(viewConfiguration, false);
                declaredField2.setAccessible(true);
                declaredField2.setBoolean(viewConfiguration, true);
            }
        } catch (Throwable e2) {
            C0166c.m556a(e2);
        }
        setTheme();
        setLanguage(this);
        super.onCreate(bundle);
        setContent();
        this.mSetPath = null;
        C0202q.m741c((Context) this);
        C0169f.m577a((Context) this);
        ZFileInfo.loadFileType(getResources());
        this.mHeaderIsRoot = true;
        setHeaderMode(false);
        setCS((C0136e) getLastNonConfigurationInstance());
        if (this.cs == null) {
            setCS(new C0136e());
            z2 = false;
        } else {
            z2 = true;
        }
        this.cs.f350a.setZArchiver(this, this.iService);
        C0143a.m427a((Context) this);
        setContentParam();
        if (this.cs.f356g) {
            setRepeatSearch(true);
        }
        if (z2) {
            setFloatAction();
        }
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("ZArchiver.iMES");
        registerReceiver(this.cs.f350a.mMessageReceiver, intentFilter);
        if (C2JBridge.m199a(this)) {
            List<ZDialog> arrayList = new ArrayList();
            synchronized (this.cs.f358i) {
                arrayList.addAll(this.cs.f358i);
            }
            for (ZDialog reShow : arrayList) {
                reShow.reShow(this);
            }
            intentFilter = new IntentFilter();
            intentFilter.addAction("android.intent.action.MEDIA_UNMOUNTED");
            intentFilter.addAction("android.intent.action.MEDIA_MOUNTED");
            intentFilter.addAction("android.intent.action.MEDIA_EJECT");
            intentFilter.addAction("android.intent.action.MEDIA_REMOVED");
            intentFilter.addAction("android.intent.action.MEDIA_BAD_REMOVAL");
            intentFilter.addDataScheme("file");
            registerReceiver(this.cs.f350a, intentFilter);
            Intent intent = getIntent();
            if (intent != null) {
                if (intent.getBooleanExtra("isZA", false)) {
                    z = false;
                }
                ProcessIntent(intent, z, false);
                setIntent(null);
            } else {
                this.mExitOnOperationComplete = false;
            }
            if (!z2) {
                showStartMessage(false);
                return;
            }
            return;
        }
        ZMessageDialog zMessageDialog = new ZMessageDialog(this.cs, this, (byte) 4, "Error load the p7zip library!\nNot found library for architecture of your phone.\nTry download ZArchiver application from Google Play / Yandes Store!");
        zMessageDialog.setOnOkListener(new C00131(this));
        zMessageDialog.showWithoutCancel();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        this.mMenu = menu;
        if (menu == null || this.cs == null) {
            return false;
        }
        int i;
        boolean z;
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.toolbar_default, menu);
        menuInflater.inflate(R.menu.menu_main, menu);
        MenuItem findItem = menu.findItem(R.id.bArchiveComent);
        MenuItem findItem2 = menu.findItem(R.id.bMenuNew);
        MenuItem findItem3 = menu.findItem(R.id.bNewArchive);
        MenuItem findItem4 = menu.findItem(R.id.bMenuAdd);
        MenuItem findItem5 = menu.findItem(R.id.bCopy);
        MenuItem findItem6 = menu.findItem(R.id.bCut);
        MenuItem findItem7 = menu.findItem(R.id.bPast);
        MenuItem findItem8 = menu.findItem(R.id.bExtract);
        MenuItem findItem9 = menu.findItem(R.id.bTest);
        MenuItem findItem10 = menu.findItem(R.id.bCompress);
        MenuItem findItem11 = menu.findItem(R.id.bDelete);
        MenuItem findItem12 = menu.findItem(R.id.bSearch);
        boolean d = this.cs.m408d();
        Object obj = (d && C0061a.m205a((Context) this, this.cs.m411g().getPath())) ? 1 : null;
        if (findItem != null) {
            boolean z2 = d && C0061a.m206a(this.cs.m411g().getPath());
            findItem.setVisible(z2);
        }
        if (findItem2 != null) {
            z2 = ((d || this.cs.f356g) && obj == null) ? false : true;
            findItem2.setVisible(z2);
        }
        if (findItem3 != null) {
            findItem3.setVisible(!d);
        }
        if (findItem4 != null) {
            z2 = d && obj != null;
            findItem4.setVisible(z2);
        }
        if (findItem12 != null) {
            z2 = !C0058a.m146a(this) && C0058a.m148b(this) && !this.cs.f356g && this.cs.m414j() == '\u0000';
            findItem12.setVisible(z2);
        }
        C0046h listAdapter = getListAdapter();
        boolean z3 = listAdapter != null && listAdapter.mo16b() > 0;
        if (z3) {
            for (int b : listAdapter.mo23f()) {
                if (listAdapter.mo17b(b).mo29h() != (byte) 7) {
                    z = false;
                    break;
                }
            }
        }
        z = z3;
        if (findItem5 != null) {
            findItem5.setEnabled(z3);
        }
        if (findItem6 != null) {
            z2 = z3 && !d;
            findItem6.setEnabled(z2);
        }
        if (findItem7 != null) {
            z2 = this.cs.f350a.isCopy() && !this.cs.f356g;
            findItem7.setEnabled(z2);
        }
        if (findItem8 != null) {
            z2 = z3 && (d || z);
            findItem8.setEnabled(z2);
        }
        if (findItem9 != null) {
            z2 = z3 && z;
            findItem9.setEnabled(z2);
        }
        if (findItem10 != null) {
            z2 = (!z3 || d || this.cs.f356g) ? false : true;
            findItem10.setEnabled(z2);
        }
        if (findItem11 != null) {
            z2 = z3 && !((d && obj == null) || this.cs.f356g);
            findItem11.setEnabled(z2);
        }
        setSortFileList(menu);
        MenuItem findItem13 = menu.findItem(R.id.bRemountRO);
        findItem = menu.findItem(R.id.bRemountRW);
        if (!(findItem13 == null || findItem == null)) {
            if (!Settings.sRoot || !C0073a.m304f() || !this.cs.m404a() || this.cs.m397a((Context) this) == (byte) 1) {
                findItem13.setVisible(false);
                findItem.setVisible(false);
            } else if (this.cs.m397a((Context) this) == (byte) 3) {
                findItem13.setVisible(false);
                findItem.setVisible(true);
            } else if (this.cs.m397a((Context) this) == (byte) 2) {
                findItem13.setVisible(true);
                findItem.setVisible(false);
            } else {
                findItem13.setVisible(false);
                findItem.setVisible(false);
            }
        }
        if (!(C0058a.m146a(this) || C0058a.m150c(this))) {
            try {
                int a = C0203r.m745a(this);
                int size = menu.size();
                if (a > 1 && size >= a) {
                    int i2;
                    i = 2;
                    for (i2 = 0; i2 < size; i2++) {
                        findItem3 = menu.getItem(i2);
                        if (findItem3.isVisible() && findItem3.getTitle() == null) {
                            i++;
                        }
                    }
                    for (i2 = 0; i2 < size; i2++) {
                        findItem3 = menu.getItem(i2);
                        if (findItem3.isVisible() && findItem3.getTitle() != null) {
                            i++;
                            if (i > a) {
                                findItem3.setShowAsActionFlags(0);
                            }
                        }
                    }
                }
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
        }
        return true;
    }

    protected void onDestroy() {
        _onDestroy();
        super.onDestroy();
    }

    public void onEndFind() {
        if (this.cs != null && this.mFindFile != null) {
            onSetFindProcess(100);
            C0046h listAdapter = getListAdapter();
            if (listAdapter != null && listAdapter.mo26i() == (byte) 1) {
                ((C0051f) listAdapter).notifyDataSetChanged();
                if (this.cs.f354e != null) {
                    synchronized (this.cs.f354e) {
                        if (this.cs.f354e.size() <= 0) {
                            setFSMessage(R.string.MES_FILE_NOT_FOUND);
                        } else {
                            setFSMessage(0);
                        }
                    }
                }
            }
            onSetFindProcess(0);
            setMyProgressBarVisibility(false);
        }
    }

    public void onFoundNewFile(FSFileInfo fSFileInfo, MyUri myUri, String str) {
        if (this.cs != null && this.mFindFile != null) {
            C0052g c0052g = new C0052g(myUri, str, fSFileInfo.mIsFile ? ZFileInfo.getFileType(str) : (byte) 2, fSFileInfo.mSize, fSFileInfo.mLastMod);
            C0046h listAdapter = getListAdapter();
            if (listAdapter == null) {
                return;
            }
            if (listAdapter.mo26i() == (byte) 1) {
                ((C0051f) listAdapter).m121a(c0052g);
                ((C0051f) listAdapter).notifyDataSetChanged();
            } else if (this.cs.f354e != null) {
                synchronized (this.cs.f354e) {
                    this.cs.f354e.add(c0052g);
                }
            }
        }
    }

    public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
        this.mExit = false;
        C0046h listAdapter = getListAdapter();
        if (listAdapter != null) {
            if (this.cs.m415k() == '\u0002') {
                listAdapter.mo20c(i);
                return;
            }
            int clickRawX;
            int clickRawY;
            AbsListView listView = getListView();
            if (listView != null) {
                clickRawX = ((IListView) listView).getClickRawX();
                clickRawY = ((IListView) listView).getClickRawY();
            } else {
                clickRawY = 0;
                clickRawX = 0;
            }
            if (listAdapter.mo16b() > 0) {
                if (listAdapter.mo17b(i).mo27a()) {
                    for (ZOpenFile zOpenFile : this.cs.f357h) {
                        if (!this.cs.f356g) {
                            if (zOpenFile.open(this, this.cs.m411g(), listAdapter.mo23f(), this.cs.f351b, clickRawX, clickRawY)) {
                                return;
                            }
                        }
                        if (this.cs.f356g) {
                            if (zOpenFile.open_find(this, this.cs.m411g(), listAdapter.mo23f(), this.cs.f354e, clickRawX, clickRawY)) {
                                return;
                            }
                        }
                    }
                    return;
                }
                List arrayList = new ArrayList();
                C0093d c0093d = new C0093d(this);
                c0093d.m374a(arrayList, 14);
                c0093d.m374a(arrayList, 15);
                c0093d.m374a(arrayList, 16);
                ZMenuDialog zMenuDialog = new ZMenuDialog(this.cs, this, arrayList, getString(R.string.MENU_SELECT), clickRawX, clickRawY);
                zMenuDialog.setOnOkListener(this.cs.f350a);
                zMenuDialog.show();
            } else if (this.cs.f356g) {
                if (i >= 0 && i < this.cs.f354e.size()) {
                    C0052g c0052g = (C0052g) this.cs.f354e.get(i);
                    if (c0052g != null) {
                        r1 = null;
                        if (c0052g.m107b()) {
                            r1 = 3;
                        } else if (c0052g.mo29h() == (byte) 7 || c0052g.mo29h() == (byte) 8) {
                            if ((Settings.sOpenArchive || j == -8) && this.cs.m404a()) {
                                r1 = 2;
                            }
                        } else if (j == -8 || (Settings.sOpenFile && j != -7)) {
                            r1 = 1;
                        }
                        switch (r1) {
                            case null:
                                r3 = new int[]{i};
                                for (ZOpenFile zOpenFile2 : this.cs.f357h) {
                                    if (zOpenFile2.open_find(this, this.cs.m411g(), r3, this.cs.f354e, clickRawX, clickRawY)) {
                                        return;
                                    }
                                }
                                return;
                            case 1:
                                openFile(c0052g.m133l(), c0052g.mo28e());
                                return;
                            case 2:
                                r1 = new MyUri(c0052g.m133l());
                                r1.add(c0052g.mo28e());
                                r0 = new MyUri(FSArchive.SCHEME, "", r1.getPath(), "/");
                                C0061a.m210b(r0.getPath());
                                setCurrentPath(r0);
                                return;
                            case 3:
                                r1 = new MyUri(c0052g.m133l());
                                r1.add(c0052g.mo28e());
                                setCurrentPath(r1);
                                return;
                            default:
                                return;
                        }
                    }
                }
            } else if (i >= 0 && i < this.cs.f351b.size()) {
                C0049e c0049e = (C0049e) this.cs.f351b.get(i);
                if (c0049e == null) {
                    return;
                }
                if (c0049e.m107b()) {
                    r1 = new MyUri(this.cs.m411g());
                    if (c0049e.m108c()) {
                        boolean isArchive = r1.isArchive();
                        if (r1.del()) {
                            setCurrentPath(r1);
                            if (isArchive && !r1.isArchive()) {
                                try {
                                    C0072g.m302b();
                                } catch (Throwable e) {
                                    C0166c.m556a(e);
                                }
                            }
                            this.cs.m418n();
                            return;
                        }
                        return;
                    } else if (r1.add(c0049e.mo28e())) {
                        setCurrentPath(r1);
                        return;
                    } else {
                        return;
                    }
                }
                r1 = null;
                if (c0049e.mo29h() == (byte) 7 || c0049e.mo29h() == (byte) 8) {
                    if ((Settings.sOpenArchive || j == -8 || this.cs.m414j() == Actions.ACTION_PAST) && this.cs.m404a()) {
                        r1 = 2;
                    }
                } else if (j == -8 || (Settings.sOpenFile && j != -7)) {
                    r1 = 1;
                }
                switch (r1) {
                    case null:
                        r3 = new int[]{i};
                        for (ZOpenFile zOpenFile22 : this.cs.f357h) {
                            if (zOpenFile22.open(this, this.cs.m411g(), r3, this.cs.f351b, clickRawX, clickRawY)) {
                                return;
                            }
                        }
                        return;
                    case 1:
                        openFile(this.cs.m411g(), c0049e.mo28e());
                        return;
                    case 2:
                        r1 = new MyUri(this.cs.m411g());
                        r1.add(c0049e.mo28e());
                        r0 = new MyUri(FSArchive.SCHEME, "", r1.getPath(), "/");
                        C0061a.m210b(r0.getPath());
                        setCurrentPath(r0);
                        return;
                    default:
                        return;
                }
            }
        }
    }

    public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long j) {
        this.mExit = false;
        C0046h listAdapter = getListAdapter();
        if (listAdapter == null) {
            return false;
        }
        if (this.cs.m414j() != '\u0000' && this.cs.m414j() != '\u0002') {
            return false;
        }
        int[] iArr;
        int clickRawX;
        int clickRawY;
        if (this.cs.m414j() == '\u0002') {
            if (this.mActionMode != null) {
                this.mActionMode.finish();
            }
            this.cs.m399a('\u0000');
        }
        if (listAdapter.mo16b() <= 0) {
            iArr = new int[]{i};
        } else if (!listAdapter.mo17b(i).mo27a()) {
            return false;
        } else {
            iArr = listAdapter.mo23f();
        }
        AbsListView listView = getListView();
        if (listView != null) {
            clickRawX = ((IListView) listView).getClickRawX();
            clickRawY = ((IListView) listView).getClickRawY();
        } else {
            clickRawY = 0;
            clickRawX = 0;
        }
        if (!this.cs.f356g) {
            C0049e c0049e = (i < 0 || i >= this.cs.f351b.size()) ? null : (C0049e) this.cs.f351b.get(i);
            if (c0049e != null && !c0049e.m108c()) {
                for (ZOpenFile open_long : this.cs.f357h) {
                    if (open_long.open_long(this, this.cs.m411g(), iArr, this.cs.f351b, clickRawX, clickRawY)) {
                        break;
                    }
                }
            }
            return false;
        }
        C0052g c0052g = (i < 0 || i >= this.cs.f354e.size()) ? null : (C0052g) this.cs.f354e.get(i);
        if (c0052g != null) {
            for (ZOpenFile open_long2 : this.cs.f357h) {
                if (open_long2.open_find(this, this.cs.m411g(), iArr, this.cs.f354e, clickRawX, clickRawY)) {
                    break;
                }
            }
        }
        return false;
        return true;
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (i != 4) {
            return i != 82 ? super.onKeyDown(i, keyEvent) : true;
        } else {
            if (this.mExit) {
                finish();
                return true;
            }
            onBack(true);
            return true;
        }
    }

    public boolean onKeyUp(int i, KeyEvent keyEvent) {
        if (i == 82) {
            onShowMenu();
            return true;
        }
        if (!this.cs.f356g && this.cs.m414j() == '\u0000' && i == 84) {
            this.cs.f355f = "";
            this.cs.f354e.clear();
            setRepeatSearch(false);
        }
        return super.onKeyUp(i, keyEvent);
    }

    public void onLowMemory() {
        if (this.mImageLoader != null) {
            Log.e(TAG, "Low memory image cash release!");
            this.mImageLoader.m620d();
        }
    }

    public boolean onMenuOpened(int i, Menu menu) {
        if (i == 8) {
            setIconInMenu(menu);
        }
        return super.onMenuOpened(i, menu);
    }

    public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        C0166c.m557b(TAG, "onNewIntent");
        this.cs.f350a.setZArchiver(this, this.iService);
        if (C0092c.m371a(intent) && this.cs != null && this.cs.f350a != null) {
            this.cs.f350a.onReceive(this, intent);
        } else if (C0091b.m358a(intent) && C0091b.m370m(intent)) {
            ProcessIntent(intent, false, true);
        } else if (C0092c.m372b(intent) || C0092c.m373c(intent)) {
            ProcessIntent(intent, false, true);
        }
    }

    public void onOperationComplete(boolean z) {
        if (z && this.mExitOnOperationComplete) {
            finishAndRemoveTask();
        }
        this.mExitOnOperationComplete = false;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 16908332) {
            return super.onOptionsItemSelected(menuItem);
        }
        onBack(false);
        return true;
    }

    public void onPause() {
        super.onPause();
        C0166c.m557b(TAG, "onPause");
    }

    public void onResume() {
        super.onResume();
        C0166c.m557b(TAG, "onResume");
        Settings.LoadSettings(this, true);
        if (Settings.isNeedRestartGUI()) {
            restartGUI();
            return;
        }
        try {
            if (this.iService != null) {
                this.iService.GUIStatus(1);
                this.iService.SetSettings();
            }
        } catch (Throwable e) {
            C0166c.m556a(e);
        }
        if (Settings.isNeedUpdateSettings()) {
            setLanguage(this);
            C0202q.m741c((Context) this);
            if (this.cs.f356g) {
                setRepeatSearch(true);
            }
        }
        if (!this.cs.f356g) {
            if (this.cs.m408d()) {
                String path = this.cs.m411g().getPath();
                if (path.startsWith("/uri/") || path.startsWith("/SAF/")) {
                    onUpdateList(false);
                } else if (new File(path).exists()) {
                    onUpdateList(false);
                } else {
                    setCurrentPath(new MyUri(Settings.sHomeDir));
                }
            } else if (this.cs.m404a()) {
                onUpdateList(true);
            }
        }
        Favorites.updateFavorites(this);
        this.cs.f350a.dialogsUpdate();
        findModifiedFile();
    }

    public Object onRetainNonConfigurationInstance() {
        if (this.mPopupNavigation != null) {
            this.mPopupNavigation.dismiss();
            this.mPopupNavigation = null;
        }
        synchronized (this.cs.f358i) {
            List<ZDialog> arrayList = new ArrayList(this.cs.f358i);
        }
        for (ZDialog hide : arrayList) {
            try {
                hide.hide();
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
        }
        this.mReconfigure = true;
        return this.cs;
    }

    public void onSelectItemChange(boolean z, int i) {
        int count;
        int i2 = 1;
        if ((z && i == 1) || (!z && i == 0)) {
            if (this.mMenu != null) {
                boolean z2;
                MenuItem findItem;
                MenuItem findItem2;
                MenuItem findItem3;
                MenuItem findItem4;
                MenuItem findItem5;
                MenuItem findItem6;
                boolean z3;
                int i3 = (this.cs == null || !this.cs.m408d()) ? 0 : 1;
                int i4 = (i3 == 0 || !C0061a.m205a((Context) this, this.cs.m411g().getPath())) ? 0 : 1;
                if (z) {
                    C0046h listAdapter = getListAdapter();
                    if (listAdapter != null) {
                        for (int b : listAdapter.mo23f()) {
                            if (listAdapter.mo17b(b).mo29h() != (byte) 7) {
                                z2 = false;
                                break;
                            }
                        }
                    } else {
                        z2 = false;
                    }
                    findItem = this.mMenu.findItem(R.id.bCopy);
                    findItem2 = this.mMenu.findItem(R.id.bCut);
                    findItem3 = this.mMenu.findItem(R.id.bExtract);
                    findItem4 = this.mMenu.findItem(R.id.bTest);
                    findItem5 = this.mMenu.findItem(R.id.bCompress);
                    findItem6 = this.mMenu.findItem(R.id.bDelete);
                    if (findItem != null) {
                        findItem.setEnabled(z);
                    }
                    if (findItem2 != null) {
                        z3 = z && i3 == 0;
                        findItem2.setEnabled(z3);
                    }
                    if (findItem3 != null) {
                        z3 = z && (i3 != 0 || z2);
                        findItem3.setEnabled(z3);
                    }
                    if (findItem4 != null) {
                        z2 = z && z2;
                        findItem4.setEnabled(z2);
                    }
                    if (findItem5 != null) {
                        z2 = z && i3 == 0 && !this.cs.f356g;
                        findItem5.setEnabled(z2);
                    }
                    if (findItem6 != null) {
                        z2 = z && ((i3 == 0 || i4 != 0) && !this.cs.f356g);
                        findItem6.setEnabled(z2);
                    }
                }
                z2 = z;
                findItem = this.mMenu.findItem(R.id.bCopy);
                findItem2 = this.mMenu.findItem(R.id.bCut);
                findItem3 = this.mMenu.findItem(R.id.bExtract);
                findItem4 = this.mMenu.findItem(R.id.bTest);
                findItem5 = this.mMenu.findItem(R.id.bCompress);
                findItem6 = this.mMenu.findItem(R.id.bDelete);
                if (findItem != null) {
                    findItem.setEnabled(z);
                }
                if (findItem2 != null) {
                    if (!z) {
                    }
                    findItem2.setEnabled(z3);
                }
                if (findItem3 != null) {
                    if (!z) {
                    }
                    findItem3.setEnabled(z3);
                }
                if (findItem4 != null) {
                    if (!z) {
                    }
                    findItem4.setEnabled(z2);
                }
                if (findItem5 != null) {
                    if (!z) {
                    }
                    findItem5.setEnabled(z2);
                }
                if (findItem6 != null) {
                    if (!z) {
                    }
                    findItem6.setEnabled(z2);
                }
            }
            setFloatAction();
        }
        if (this.cs.m415k() == '\u0002' && this.mActionMode != null) {
            C0046h listAdapter2 = getListAdapter();
            if (listAdapter2 != null) {
                ActionMode actionMode = this.mActionMode;
                StringBuilder append = new StringBuilder().append(i).append(" / ");
                count = listAdapter2.getCount();
                if (!ZViewFS.sAddFolderUp) {
                    i2 = 0;
                }
                actionMode.setTitle(append.append(count - i2).toString());
            }
        }
    }

    public void onSetFindProcess(int i) {
        if (this.mFindFile != null) {
            setMyProgress((i * 10000) / 100);
        }
    }

    public void onStart() {
        super.onStart();
        C0166c.m557b(TAG, "onStart");
        _onStart();
    }

    public void onStartFind() {
        onSetFindProcess(0);
        setFSMessage(0);
        synchronized (this.cs.f354e) {
            this.cs.f354e.clear();
        }
        C0046h listAdapter = getListAdapter();
        if (listAdapter.mo26i() == (byte) 1) {
            ((C0051f) listAdapter).m119a(this.cs.f354e);
            ((C0051f) listAdapter).notifyDataSetChanged();
        }
    }

    protected void onStop() {
        super.onStop();
        C0166c.m557b(TAG, "onStop");
        sHackSuppressDouble = null;
        if (this.mRestartGUI) {
            try {
                unbindService(this.mConnection);
                return;
            } catch (Throwable e) {
                C0166c.m556a(e);
                return;
            }
        }
        stopZService();
        if (this.mImageLoader != null) {
            this.mImageLoader.m615a();
            this.mImageLoader = null;
        }
        if (this.mFolderInfo != null) {
            this.mFolderInfo.cancel(true);
            this.mFolderInfo = null;
        }
        if (this.mFindFile != null) {
            this.mFindFile.stopFindFile();
            this.mFindFile = null;
        }
        if (this.mSetPath != null) {
            this.mSetPath.mo7a();
            this.mSetPath = null;
        }
        C0143a.m427a(null);
        if (this.cs != null && this.cs.f350a != null) {
            this.cs.f350a.setZArchiver(null, null);
        }
    }

    public void onToolbarClick(int i) {
        boolean z = true;
        Intent intent;
        ZEnterTextDialog zEnterTextDialog;
        boolean z2;
        int i2;
        C0046h listAdapter;
        ActionMode actionMode;
        StringBuilder append;
        int count;
        switch (i) {
            case R.id.bAbout:
                intent = new Intent(this, AboutDlg.class);
                if (VERSION.SDK_INT < 21) {
                    intent.setFlags(65536);
                }
                startActivity(intent);
                return;
            case R.id.bAddFile:
                this.cs.f350a.onMenuSelect(this, 81);
                return;
            case R.id.bAddFolder:
                this.cs.f350a.onMenuSelect(this, 82);
                return;
            case R.id.bArchiveComent:
                String c = C0061a.m212c();
                if (c != null) {
                    zEnterTextDialog = new ZEnterTextDialog(this.cs, this, new File(C0061a.m214d()).getName(), getString(R.string.CMT_ARCHIVE_COOMENT), true);
                    zEnterTextDialog.setText(c);
                    zEnterTextDialog.show();
                    return;
                }
                return;
            case R.id.bCancel:
            case R.id.bOk:
                if (this.mActionMode != null) {
                    this.mActionMode.finish();
                }
                this.mActionMode = null;
                return;
            case R.id.bCompress:
                fillFileList();
                this.cs.f350a.onMenuSelect(this, 7);
                return;
            case R.id.bCopy:
            case R.id.bCut:
                if (getListAdapter() != null && this.cs.f350a != null) {
                    fillFileList();
                    this.cs.f350a.copy(i == R.id.bCut);
                    boolean d = this.cs.m408d();
                    z2 = d && C0061a.m205a((Context) this, this.cs.m411g().getPath());
                    if (this.mMenu != null) {
                        MenuItem findItem = this.mMenu.findItem(R.id.bPast);
                        if (findItem != null) {
                            if (!this.cs.f350a.isCopy() || ((d && !z2) || this.cs.f356g)) {
                                z = false;
                            }
                            findItem.setEnabled(z);
                        }
                    }
                    if (Settings.sInteractivePast) {
                        setActionMode(Actions.ACTION_PAST);
                        return;
                    }
                    return;
                }
                return;
            case R.id.bDelete:
                fillFileList();
                if (this.cs.m408d()) {
                    this.cs.f350a.onMenuSelect(this, 56);
                    return;
                } else {
                    this.cs.f350a.onMenuSelect(this, 23);
                    return;
                }
            case R.id.bExit:
                finishAndRemoveTask();
                return;
            case R.id.bExtract:
                fillFileList();
                this.cs.f350a.onMenuSelect(this, 4);
                return;
            case R.id.bInfo:
                new ZFileInfoDialog(this.cs, (Context) this, this.cs.m411g(), (String) null).show();
                return;
            case R.id.bMultiSelect:
                if (this.cs.m414j() == '\u0000' && this.mActionMode == null) {
                    setActionMode('\u0002');
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.MES_SELECT_HELP), 0).show();
                    return;
                }
                return;
            case R.id.bNewArchive:
                if (!this.cs.m406b()) {
                    return;
                }
                if (!this.cs.m404a() || C0200o.m709a((Context) this, this.cs.m411g()) == (byte) 1) {
                    ZCompressDialog zCompressDialog = new ZCompressDialog(this.cs, this, "archiveNew", false, false, false);
                    zCompressDialog.setSubType(11);
                    zCompressDialog.setOnOkListener(this.cs.f350a);
                    zCompressDialog.show();
                    return;
                }
                Toast.makeText(this, R.string.MES_PATH_READ_ONLY, 1).show();
                return;
            case R.id.bNewFolder:
                if (this.cs.m406b()) {
                    if (C0200o.m709a((Context) this, this.cs.m411g()) != (byte) 1) {
                        Toast.makeText(this, R.string.MES_PATH_READ_ONLY, 1).show();
                        return;
                    }
                    ZEnterTextDialog zEnterTextDialog2 = new ZEnterTextDialog(this.cs, (Context) this, (int) R.string.NF_TTL_NEW_FOLDER, (int) R.string.NF_ENTER_FOLDER_NAME);
                    zEnterTextDialog2.setSubType(1);
                    zEnterTextDialog2.setOnOkListener(this.cs.f350a);
                    zEnterTextDialog2.show();
                    String str = "New Folder";
                    if (new C0204s(this.cs.m412h() + "/" + str).m756i()) {
                        while (i2 < 1000) {
                            str = "New Folder " + i2;
                            if (new C0204s(this.cs.m412h() + "/" + str).m756i()) {
                                i2++;
                            }
                        }
                    }
                    zEnterTextDialog2.setText(str);
                    return;
                } else if (this.cs.m408d() && C0061a.m205a((Context) this, this.cs.m411g().getPath())) {
                    zEnterTextDialog = new ZEnterTextDialog(this.cs, (Context) this, (int) R.string.NF_TTL_NEW_FOLDER, (int) R.string.NF_ENTER_FOLDER_NAME);
                    zEnterTextDialog.setSubType(1);
                    zEnterTextDialog.setOnOkListener(this.cs.f350a);
                    zEnterTextDialog.show();
                    zEnterTextDialog.setText("New Folder");
                    return;
                } else {
                    return;
                }
            case R.id.bPast:
                if (this.cs.f350a.isCopy()) {
                    if (this.cs.m408d()) {
                        if (!C0061a.m205a((Context) this, this.cs.m411g().getPath())) {
                            Toast.makeText(this, R.string.MES_DONT_SUPPORT_EDIT, 0).show();
                            return;
                        }
                    } else if (!this.cs.f350a.checkCurrentPath(this, 1)) {
                        return;
                    }
                    MyUri myUri = this.cs.f350a.mFileListCopyPath != null ? this.cs.f350a.mFileListCopyPath : this.cs.f350a.mFileListCopyPathS[0];
                    if (this.cs.m408d()) {
                        this.cs.f350a.past();
                        this.cs.f350a.archiveAddFiles();
                    } else if (!this.cs.m404a() && !this.cs.m409e()) {
                        C0166c.m557b(TAG, "bPast: Not handler!");
                    } else if (myUri.isArchive()) {
                        this.cs.f350a.past();
                        this.cs.f350a.archiveExtractFiles(this.cs.m412h(), this.cs.m407c());
                    } else {
                        z2 = this.cs.f350a.mFileListCopyCut;
                        this.cs.f350a.past();
                        this.cs.f350a.fileCopy(this.cs.m412h(), z2, this.cs.m407c());
                    }
                }
                if (this.mMenu != null) {
                    MenuItem findItem2 = this.mMenu.findItem(R.id.bPast);
                    if (findItem2 != null) {
                        findItem2.setEnabled(this.cs.f350a.isCopy());
                        return;
                    }
                    return;
                }
                return;
            case R.id.bRemountRO:
            case R.id.bRemountRW:
                if (this.cs.m404a()) {
                    if (this.mRemount != null) {
                        this.mRemount.cancel(true);
                    }
                    String path = this.cs.m411g().getPath();
                    if (i != R.id.bRemountRW) {
                        z = false;
                    }
                    this.mRemount = new C0026e(this, path, z);
                    this.mRemount.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Void[0]);
                    return;
                }
                return;
            case R.id.bSearch:
                if (!this.cs.f356g && this.cs.m414j() == '\u0000') {
                    if (this.mFindFile != null) {
                        this.mFindFile.stopFindFile();
                    }
                    this.mFindFile = null;
                    this.cs.f355f = "";
                    this.cs.f354e.clear();
                    setRepeatSearch(false);
                    return;
                }
                return;
            case R.id.bSelectAll:
                if (this.cs.m414j() == '\u0000' || this.cs.m415k() == '\u0002') {
                    listAdapter = getListAdapter();
                    if (listAdapter != null) {
                        listAdapter.mo21d();
                        if (this.mActionMode != null) {
                            actionMode = this.mActionMode;
                            append = new StringBuilder().append(listAdapter.mo16b()).append(" / ");
                            count = listAdapter.getCount();
                            if (!ZViewFS.sAddFolderUp) {
                                i2 = 0;
                            }
                            actionMode.setTitle(append.append(count - i2).toString());
                            return;
                        }
                        return;
                    }
                    return;
                }
                return;
            case R.id.bSelectClear:
                if (this.cs.m414j() == '\u0000' || this.cs.m415k() == '\u0002') {
                    listAdapter = getListAdapter();
                    if (listAdapter != null) {
                        listAdapter.mo19c();
                        if (this.mActionMode != null) {
                            actionMode = this.mActionMode;
                            append = new StringBuilder().append(listAdapter.mo16b()).append(" / ");
                            count = listAdapter.getCount();
                            if (!ZViewFS.sAddFolderUp) {
                                i2 = 0;
                            }
                            actionMode.setTitle(append.append(count - i2).toString());
                            return;
                        }
                        return;
                    }
                    return;
                }
                return;
            case R.id.bSelectInvert:
                if (this.cs.m414j() == '\u0000' || this.cs.m415k() == '\u0002') {
                    listAdapter = getListAdapter();
                    if (listAdapter != null) {
                        listAdapter.mo22e();
                        if (this.mActionMode != null) {
                            actionMode = this.mActionMode;
                            append = new StringBuilder().append(listAdapter.mo16b()).append(" / ");
                            count = listAdapter.getCount();
                            if (!ZViewFS.sAddFolderUp) {
                                i2 = 0;
                            }
                            actionMode.setTitle(append.append(count - i2).toString());
                            return;
                        }
                        return;
                    }
                    return;
                }
                return;
            case R.id.bSettings:
                intent = new Intent(this, SettingsDlg.class);
                if (VERSION.SDK_INT < 21) {
                    intent.setFlags(65536);
                }
                startActivity(intent);
                return;
            case R.id.bSortByDate:
                setSortFileList((byte) 3, Settings.sFMSortDesc);
                onUpdateList(false);
                return;
            case R.id.bSortByName:
                setSortFileList((byte) 0, Settings.sFMSortDesc);
                onUpdateList(false);
                return;
            case R.id.bSortBySize:
                setSortFileList((byte) 2, Settings.sFMSortDesc);
                onUpdateList(false);
                return;
            case R.id.bSortByType:
                setSortFileList((byte) 1, Settings.sFMSortDesc);
                onUpdateList(false);
                return;
            case R.id.bSortDesс:
                byte b = Settings.sFMSortType;
                if (Settings.sFMSortDesc) {
                    z = false;
                }
                setSortFileList(b, z);
                onUpdateList(false);
                return;
            case R.id.bTest:
                fillFileList();
                this.cs.f350a.onMenuSelect(this, 10);
                return;
            default:
                return;
        }
    }

    public void onToolbarItemClick(MenuItem menuItem) {
        if (menuItem != null) {
            onToolbarClick(menuItem.getItemId());
        }
    }

    public void onUpdateList(boolean z) {
        onUpdateList(z, 0);
    }

    public void onUpdateList(boolean z, int i) {
        boolean z2 = true;
        if (this.cs.f356g) {
            ZViewFS.sortFind(this.cs.f354e);
            C0046h listAdapter = getListAdapter();
            if (listAdapter == null || listAdapter.mo26i() != (byte) 1) {
                z2 = false;
            }
            if (z2) {
                listAdapter = (C0051f) listAdapter;
            } else {
                listAdapter = new C0051f(this);
                listAdapter.mo14a((C0031a) this);
            }
            listAdapter.m119a(this.cs.f354e);
            if (z && z2) {
                listAdapter.notifyDataSetChanged();
                return;
            } else {
                setListAdapter(listAdapter);
                return;
            }
        }
        if (this.mSetPath != null) {
            this.mSetPath.mo7a();
        }
        if (z) {
            this.mSetPath = new C0028f(this, this.cs.m411g(), true, true);
        } else {
            this.mSetPath = new C0028f(this, this.cs.m411g(), true, i);
        }
        this.mSetPath.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Void[0]);
    }

    @TargetApi(24)
    public void requestAccessExtSD(StorageVolume storageVolume) {
        Intent createAccessIntent = storageVolume.createAccessIntent(null);
        if (createAccessIntent == null) {
            selectExtSD();
            return;
        }
        try {
            startActivityForResult(createAccessIntent, 106);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to request access to SD!", 0).show();
        }
    }

    public void restartGUI() {
        this.mRestartGUI = true;
        sHackSuppressDouble = null;
        _onDestroy();
        overridePendingTransition(0, 0);
        finishAndRemoveTask();
        overridePendingTransition(0, 0);
        if (this.iService != null) {
            C0166c.m557b(TAG, "Restart GUI by Service");
            try {
                this.iService.RestartGUI();
                return;
            } catch (Throwable e) {
                C0166c.m556a(e);
                return;
            }
        }
        C0166c.m557b(TAG, "Restart GUI by Intent");
        Intent intent = new Intent(this, ZArchiver.class);
        intent.setFlags(335609856);
        startActivity(intent);
    }

    @TargetApi(21)
    public void selectExtSD() {
        Intent intent = new Intent("android.intent.action.OPEN_DOCUMENT_TREE");
        intent.setFlags(67);
        intent.putExtra("android.intent.extra.LOCAL_ONLY", true);
        intent.putExtra("android.content.extra.SHOW_ADVANCED", true);
        if (!C0202q.m733a((Context) this, intent)) {
            intent.setFlags(64);
        }
        try {
            startActivityForResult(intent, 105);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "Failed to call ACTION_OPEN_DOCUMENT_TREE", 0).show();
        }
    }

    public void setActionMode(char c) {
        if ((c & 1) == 1) {
            this.cs.m401a(getPosition());
        }
        this.cs.m399a(c);
        if (this.mActionMode != null) {
            this.mActionMode.finish();
        }
        switch (this.cs.m414j()) {
            case '\u0002':
                this.mActionMode = startActionMode(new C0022a());
                setIconActionMode(false);
                break;
            case '\t':
            case '\u0011':
            case 'A':
                this.mActionMode = startActionMode(new C0023b());
                setIconActionMode(true);
                break;
            case '\"':
                this.mActionMode = startActionMode(new C0022a());
                setIconActionMode(true);
                break;
            default:
                this.mActionMode = null;
                break;
        }
        setFloatAction();
    }

    public void setCS(C0136e c0136e) {
        this.cs = c0136e;
    }

    public void setCancelSearch(boolean z) {
        if (this.mSearch != null && !this.mSearch.isIconified()) {
            this.mSaveSearchResult = z;
            this.mSearch.setIconified(true);
            this.mSearch.setIconified(true);
        }
    }

    public void setComment(boolean z) {
        if (this.mMenu != null) {
            MenuItem findItem = this.mMenu.findItem(R.id.bArchiveComent);
            if (findItem != null) {
                findItem.setVisible(z);
            }
        }
    }

    public void setContent() {
        if (Settings.sGUIGridView) {
            setContentView(R.layout.dlg_main_grid);
        } else {
            setContentView(R.layout.dlg_main_list);
        }
        this.mListView = (AbsListView) findViewById(16908298);
        ActionBar actionBar = getActionBar();
        if (actionBar != null) {
            actionBar.setCustomView(R.layout.ctm_navigate);
            this.mCustomNav = actionBar.getCustomView();
            this.mTitle = (TextView) this.mCustomNav.findViewById(R.id.nTitle);
            this.mSubtitle = (TextView) this.mCustomNav.findViewById(R.id.nSubtitle);
            this.mSearch = (SearchView) this.mCustomNav.findViewById(R.id.svSearch);
        } else {
            this.mCustomNav = null;
            this.mSubtitle = null;
            this.mTitle = null;
            this.mSearch = null;
        }
        if (this.mSearch != null) {
            this.mSearch.getContext().setTheme(Settings.sThemeResource);
        }
        this.mTVMes = (TextView) findViewById(R.id.tvFSMessage);
        this.mLlFolderInfo = findViewById(R.id.llFolderInfo);
        if (this.mLlFolderInfo == null) {
            SwipeView swipeView = (SwipeView) findViewById(R.id.svSwipe);
            ExtendRelativeLayout extendRelativeLayout = (ExtendRelativeLayout) LayoutInflater.from(this).inflate(R.layout.extend_info, new ExtendRelativeLayout(this));
            extendRelativeLayout.setBackgroundColor(C0202q.m735b((Context) this, 16842801));
            swipeView.setExtendView(extendRelativeLayout);
            swipeView.setEnabled(true);
            swipeView.setOnRefreshListener(new C00175(this));
            swipeView.setOnShowListener(new C00186(this));
            this.mLlFolderInfo = swipeView;
        }
        this.mLlStorage = this.mLlFolderInfo.findViewById(R.id.llStorage);
        this.mTvStorage = (TextView) this.mLlFolderInfo.findViewById(R.id.tvStorage);
        this.mTvStorageSpace = (TextView) this.mLlFolderInfo.findViewById(R.id.tvStorageSpace);
        this.mTvFolder = (TextView) this.mLlFolderInfo.findViewById(R.id.tvFolder);
        this.mTvFolderSize = (TextView) this.mLlFolderInfo.findViewById(R.id.tvFolderSize);
        this.mPbFree = (ProgressBar) this.mLlFolderInfo.findViewById(R.id.pbFree);
        if (this.mPbFree != null) {
            this.mPbFree.getProgressDrawable().setColorFilter(C0202q.m735b((Context) this, (int) R.attr.colorPrimary), Mode.SRC_IN);
        }
        this.mFloatButton = (ImageButton) findViewById(R.id.ibAction);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void setContentParam() {
        /*
        r9 = this;
        r8 = 23;
        r3 = 8;
        r5 = 0;
        r6 = 1;
        r4 = 0;
        r0 = r9.getActionBar();
        if (r0 == 0) goto L_0x0016;
    L_0x000d:
        r0.setDisplayHomeAsUpEnabled(r6);
        r0.setDisplayShowCustomEnabled(r6);
        r0.setDisplayShowTitleEnabled(r4);
    L_0x0016:
        r0 = android.os.Build.VERSION.SDK_INT;
        if (r0 <= r8) goto L_0x002e;
    L_0x001a:
        r0 = r9.mListView;
        r0 = r0 instanceof android.widget.ListView;
        if (r0 == 0) goto L_0x002e;
    L_0x0020:
        r0 = r9.mListView;
        r0 = (android.widget.ListView) r0;
        r0.setDividerHeight(r4);
        r0 = r9.mListView;
        r0 = (android.widget.ListView) r0;
        r0.setDivider(r5);
    L_0x002e:
        r0 = r9.mSearch;
        if (r0 == 0) goto L_0x006d;
    L_0x0032:
        r0 = r9.mSearch;
        r1 = 2131427485; // 0x7f0b009d float:1.8476588E38 double:1.053065097E-314;
        r1 = r9.getString(r1);
        r0.setQueryHint(r1);
        r0 = r9.mSearch;
        r0.setIconifiedByDefault(r6);
        r1 = r9.mSearch;
        r0 = ru.zdevs.zarchiver.C0058a.m148b(r9);
        if (r0 == 0) goto L_0x018d;
    L_0x004b:
        r0 = r3;
    L_0x004c:
        r1.setVisibility(r0);
        r0 = r9.mSearch;
        r1 = new ru.zdevs.zarchiver.ZArchiver$7;
        r1.<init>(r9);
        r0.setOnCloseListener(r1);
        r0 = r9.mSearch;
        r1 = new ru.zdevs.zarchiver.ZArchiver$8;
        r1.<init>(r9);
        r0.setOnSearchClickListener(r1);
        r0 = r9.mSearch;
        r1 = new ru.zdevs.zarchiver.ZArchiver$9;
        r1.<init>(r9);
        r0.setOnQueryTextListener(r1);
    L_0x006d:
        r0 = r9.mCustomNav;
        r1 = 2131165286; // 0x7f070066 float:1.7944785E38 double:1.0529355534E-314;
        r0 = r0.findViewById(r1);
        r0 = (android.widget.RelativeLayout) r0;
        r1 = r9.getActionBar();
        r2 = r9.mCustomNav;
        r1.setCustomView(r2);
        r1 = r9.getResources();
        r2 = r9.mCustomNav;
        r7 = r1.getDisplayMetrics();
        r7 = r7.widthPixels;
        r2.setMinimumWidth(r7);
        r2 = new ru.zdevs.zarchiver.ZArchiver$10;
        r2.<init>(r9, r1);
        r0.setOnClickListener(r2);
        r0 = r9.mSearch;
        if (r0 == 0) goto L_0x00c4;
    L_0x009c:
        r0 = r9.mSearch;
        r0 = r0.getContext();
        r0 = r0.getResources();
        r1 = "android:id/search_button";
        r0 = r0.getIdentifier(r1, r5, r5);
        r1 = r9.mSearch;
        r0 = r1.findViewById(r0);
        if (r0 == 0) goto L_0x00c4;
    L_0x00b4:
        r1 = r0 instanceof android.widget.ImageView;
        if (r1 == 0) goto L_0x00c4;
    L_0x00b8:
        r0 = (android.widget.ImageView) r0;
        r1 = 2130903078; // 0x7f030026 float:1.7412964E38 double:1.0528060055E-314;
        r1 = ru.zdevs.zarchiver.tool.C0202q.m725a(r9, r1);
        r0.setImageDrawable(r1);
    L_0x00c4:
        r0 = ru.zdevs.zarchiver.settings.Settings.sGUIBackground;
        switch(r0) {
            case 1: goto L_0x0190;
            case 2: goto L_0x019a;
            case 3: goto L_0x01a3;
            case 4: goto L_0x01b6;
            default: goto L_0x00c9;
        };
    L_0x00c9:
        r1 = r5;
    L_0x00ca:
        r2 = r9.getListView();
        r0 = 2131165265; // 0x7f070051 float:1.7944742E38 double:1.052935543E-314;
        r0 = r9.findViewById(r0);
        r0 = (android.widget.ImageView) r0;
        if (r1 == 0) goto L_0x01d5;
    L_0x00d9:
        r7 = r1 instanceof android.graphics.drawable.BitmapDrawable;
        if (r7 == 0) goto L_0x01d5;
    L_0x00dd:
        r1 = (android.graphics.drawable.BitmapDrawable) r1;
        r1 = r1.getBitmap();
        r0.setImageBitmap(r1);
        r1 = android.widget.ImageView.ScaleType.CENTER_CROP;
        r0.setScaleType(r1);
        r2.setCacheColorHint(r4);
        r0 = ru.zdevs.zarchiver.settings.Settings.sGUIBackground;
        r1 = 2;
        if (r0 == r1) goto L_0x00f8;
    L_0x00f3:
        r0 = ru.zdevs.zarchiver.settings.Settings.sGUIBackground;
        r1 = 3;
        if (r0 != r1) goto L_0x01d2;
    L_0x00f8:
        r0 = r6;
    L_0x00f9:
        r2.setDrawingCacheEnabled(r0);
    L_0x00fc:
        r0 = ru.zdevs.zarchiver.settings.Settings.sGUIFastScroll;
        r2.setFastScrollEnabled(r0);
        r2.setOnItemLongClickListener(r9);
        r2.setOnItemClickListener(r9);
        r0 = 2131165285; // 0x7f070065 float:1.7944783E38 double:1.052935553E-314;
        r0 = r9.findViewById(r0);
        r0 = (android.widget.RelativeLayout) r0;
        if (r0 == 0) goto L_0x0161;
    L_0x0112:
        r1 = ru.zdevs.zarchiver.settings.Settings.sFavoriteBar;
        if (r1 == 0) goto L_0x01dd;
    L_0x0116:
        r1 = android.os.Build.VERSION.SDK_INT;
        r7 = 24;
        if (r1 < r7) goto L_0x0122;
    L_0x011c:
        r1 = r9.isInMultiWindowMode();
        if (r1 != 0) goto L_0x01dd;
    L_0x0122:
        if (r6 == 0) goto L_0x0125;
    L_0x0124:
        r3 = r4;
    L_0x0125:
        r0.setVisibility(r3);
        r0 = 2131165273; // 0x7f070059 float:1.7944758E38 double:1.052935547E-314;
        r0 = r9.findViewById(r0);
        r0 = (android.widget.ListView) r0;
        if (r0 == 0) goto L_0x0161;
    L_0x0133:
        if (r6 == 0) goto L_0x0161;
    L_0x0135:
        r1 = new ru.zdevs.zarchiver.a.b;
        r1.<init>(r9);
        r3 = ru.zdevs.zarchiver.settings.Favorites.getFavorites(r9);
        r1.m69a(r3);
        r0.setAdapter(r1);
        r0.setCacheColorHint(r4);
        r1 = android.os.Build.VERSION.SDK_INT;
        if (r1 <= r8) goto L_0x0151;
    L_0x014b:
        r0.setDividerHeight(r4);
        r0.setDivider(r5);
    L_0x0151:
        r1 = new ru.zdevs.zarchiver.ZArchiver$11;
        r1.<init>(r9);
        r0.setOnItemClickListener(r1);
        r1 = new ru.zdevs.zarchiver.ZArchiver$12;
        r1.<init>(r9);
        r0.setOnItemLongClickListener(r1);
    L_0x0161:
        r0 = r9.mFloatButton;
        if (r0 == 0) goto L_0x018c;
    L_0x0165:
        r0 = ru.zdevs.zarchiver.settings.Settings.sGUIFloatButton;
        if (r0 == 0) goto L_0x018c;
    L_0x0169:
        r0 = r9.mFloatButton;
        r0.setVisibility(r4);
        r0 = r9.mFloatButton;
        r1 = new ru.zdevs.zarchiver.ZArchiver$2;
        r1.<init>(r9);
        r0.setOnClickListener(r1);
        r0 = r9.isListViewFitsSystemWindows();
        if (r0 == 0) goto L_0x0189;
    L_0x017e:
        r1 = new ru.zdevs.zarchiver.ZArchiver$3;
        r1.<init>(r9);
        r0 = r2;
        r0 = (ru.zdevs.zarchiver.widget.IListView) r0;
        r0.setOnListMeasure(r1);
    L_0x0189:
        r9.setFloatColor();
    L_0x018c:
        return;
    L_0x018d:
        r0 = r4;
        goto L_0x004c;
    L_0x0190:
        r0 = android.app.WallpaperManager.getInstance(r9);
        r1 = r0.getDrawable();
        goto L_0x00ca;
    L_0x019a:
        r0 = 2130903041; // 0x7f030001 float:1.7412889E38 double:1.052805987E-314;
        r1 = ru.zdevs.zarchiver.tool.C0202q.m725a(r9, r0);
        goto L_0x00ca;
    L_0x01a3:
        r0 = ru.zdevs.zarchiver.settings.Settings.sActionbarColor;
        if (r0 == 0) goto L_0x00c9;
    L_0x01a7:
        r0 = android.os.Build.VERSION.SDK_INT;
        r1 = 21;
        if (r0 >= r1) goto L_0x00c9;
    L_0x01ad:
        r0 = 2130903041; // 0x7f030001 float:1.7412889E38 double:1.052805987E-314;
        r1 = ru.zdevs.zarchiver.tool.C0202q.m725a(r9, r0);
        goto L_0x00ca;
    L_0x01b6:
        r0 = ru.zdevs.zarchiver.settings.Settings.sBGCustomPath;	 Catch:{ Exception -> 0x01c3 }
        if (r0 == 0) goto L_0x01e0;
    L_0x01ba:
        r0 = ru.zdevs.zarchiver.settings.Settings.sBGCustomPath;	 Catch:{ Exception -> 0x01c3 }
        r0 = android.graphics.drawable.Drawable.createFromPath(r0);	 Catch:{ Exception -> 0x01c3 }
    L_0x01c0:
        r1 = r0;
        goto L_0x00ca;
    L_0x01c3:
        r0 = move-exception;
        r0.printStackTrace();
        r0 = "Error on the loading the background image";
        r0 = android.widget.Toast.makeText(r9, r0, r4);
        r0.show();
        goto L_0x00c9;
    L_0x01d2:
        r0 = r4;
        goto L_0x00f9;
    L_0x01d5:
        r0.setImageDrawable(r1);
        r2.setDrawingCacheEnabled(r6);
        goto L_0x00fc;
    L_0x01dd:
        r6 = r4;
        goto L_0x0122;
    L_0x01e0:
        r0 = r5;
        goto L_0x01c0;
        */
        throw new UnsupportedOperationException("Method not decompiled: ru.zdevs.zarchiver.ZArchiver.setContentParam():void");
    }

    public void setCurrentPath(MyUri myUri) {
        if (this.mSetPath != null) {
            this.mSetPath.mo7a();
        }
        this.mSetPath = new C0028f(this, myUri);
        this.mSetPath.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Void[0]);
        if (!this.cs.m408d() && this.mActionMode == null) {
            this.mExitOnOperationComplete = false;
        }
    }

    public void setCustomDivider(boolean z) {
        if (VERSION.SDK_INT < 21 && Settings.sActionbarColor != 0) {
            View findViewById = findViewById(R.id.rlRoot);
            if (findViewById == null) {
                return;
            }
            if (z) {
                findViewById.setBackgroundColor(C0202q.m735b((Context) this, (int) R.attr.colorPrimary));
                findViewById.setPadding(0, getResources().getDimensionPixelSize(R.dimen.action_bar_custom_devider_height), 0, 0);
                return;
            }
            findViewById.setBackgroundColor(0);
            findViewById.setPadding(0, 0, 0, 0);
        }
    }

    public void setFSMessage(int i) {
        setFSMessage(i, null);
    }

    public void setFSMessage(int i, Animation animation) {
        int i2 = 1;
        this.cs.f352c = i;
        C0046h listAdapter = getListAdapter();
        if (this.mTVMes != null && listAdapter != null) {
            int i3 = i > 0 ? 1 : 0;
            if (i3 != 0) {
                int count = listAdapter.getCount();
                if (!ZViewFS.sAddFolderUp) {
                    i2 = 0;
                }
                if (count > i2) {
                    i3 = 0;
                }
            }
            if (i3 != 0) {
                if (animation != null) {
                    this.mTVMes.startAnimation(animation);
                }
                this.mTVMes.setVisibility(0);
                this.mTVMes.setText(i);
                return;
            }
            this.mTVMes.setVisibility(8);
        }
    }

    public void setFloatAction() {
        if (this.mFloatButton != null && this.cs.m411g() != null && Settings.sGUIFloatButton) {
            Animation makeInChildBottomAnimation;
            C0046h listAdapter;
            int i;
            Animation animation = null;
            if (Settings.sGUIAnimation && this.mFloatButton.getTag() != null) {
                try {
                    makeInChildBottomAnimation = AnimationUtils.makeInChildBottomAnimation(this);
                } catch (Throwable e) {
                    C0166c.m556a(e);
                }
                this.mFloatButton.setVisibility(0);
                this.mFloatButton.setScaleType(ScaleType.CENTER_INSIDE);
                if (this.cs.m414j() == '\u0000') {
                    switch (this.cs.m414j()) {
                        case '\u0002':
                            if (!(makeInChildBottomAnimation == null || ((Integer) this.mFloatButton.getTag()).intValue() == R.id.bOk)) {
                                this.mFloatButton.startAnimation(makeInChildBottomAnimation);
                            }
                            this.mFloatButton.setTag(Integer.valueOf(R.id.bOk));
                            this.mFloatButton.setImageResource(R.drawable.l_done_blk);
                            return;
                        case '\t':
                        case '\u0011':
                            if (!(makeInChildBottomAnimation == null || ((Integer) this.mFloatButton.getTag()).intValue() == R.id.bSelectPath)) {
                                this.mFloatButton.startAnimation(makeInChildBottomAnimation);
                            }
                            this.mFloatButton.setTag(Integer.valueOf(R.id.bSelectPath));
                            this.mFloatButton.setImageResource(R.drawable.l_to_blk);
                            return;
                        case '\"':
                            if (!(makeInChildBottomAnimation == null || ((Integer) this.mFloatButton.getTag()).intValue() == R.id.bCreateArchive)) {
                                this.mFloatButton.startAnimation(makeInChildBottomAnimation);
                            }
                            this.mFloatButton.setTag(Integer.valueOf(R.id.bCreateArchive));
                            this.mFloatButton.setImageResource(R.drawable.l_done_blk);
                            return;
                        case 'A':
                            if (!(makeInChildBottomAnimation == null || ((Integer) this.mFloatButton.getTag()).intValue() == R.id.bPast)) {
                                this.mFloatButton.startAnimation(makeInChildBottomAnimation);
                            }
                            this.mFloatButton.setTag(Integer.valueOf(R.id.bPast));
                            this.mFloatButton.setImageResource(R.drawable.l_paste_blk);
                            return;
                        default:
                            return;
                    }
                }
                listAdapter = getListAdapter();
                if (this.cs.m404a()) {
                    if (!this.cs.m408d()) {
                        if (this.cs.m409e()) {
                            if (listAdapter != null || listAdapter.mo16b() <= 0) {
                                this.mFloatButton.setVisibility(8);
                                return;
                            }
                            if (!(makeInChildBottomAnimation == null || ((Integer) this.mFloatButton.getTag()).intValue() == R.id.bCopy)) {
                                this.mFloatButton.startAnimation(makeInChildBottomAnimation);
                            }
                            this.mFloatButton.setTag(Integer.valueOf(R.id.bCopy));
                            this.mFloatButton.setImageResource(R.drawable.l_copy_blk);
                            return;
                        }
                        return;
                    } else if (!this.cs.f356g || ((listAdapter != null && listAdapter.mo16b() > 0) || !C0061a.m205a((Context) this, this.cs.m411g().getPath()))) {
                        if (!(makeInChildBottomAnimation == null || ((Integer) this.mFloatButton.getTag()).intValue() == R.id.bExtract)) {
                            this.mFloatButton.startAnimation(makeInChildBottomAnimation);
                        }
                        this.mFloatButton.setTag(Integer.valueOf(R.id.bExtract));
                        this.mFloatButton.setImageResource(R.drawable.l_upload_blk);
                        return;
                    } else {
                        if (!(makeInChildBottomAnimation == null || ((Integer) this.mFloatButton.getTag()).intValue() == R.id.bAddFile)) {
                            this.mFloatButton.startAnimation(makeInChildBottomAnimation);
                        }
                        this.mFloatButton.setTag(Integer.valueOf(R.id.bAddFile));
                        this.mFloatButton.setImageResource(R.drawable.l_add_blk);
                        return;
                    }
                } else if (this.cs.f356g) {
                    if (listAdapter != null || listAdapter.mo16b() <= 0) {
                        if (Settings.sRoot && C0073a.m304f() && this.cs.m410f() != (byte) 1) {
                            if (this.cs.m397a((Context) this) != (byte) 3) {
                                if (!(makeInChildBottomAnimation == null || ((Integer) this.mFloatButton.getTag()).intValue() == R.id.bRemountRW)) {
                                    this.mFloatButton.startAnimation(makeInChildBottomAnimation);
                                }
                                this.mFloatButton.setTag(Integer.valueOf(R.id.bRemountRW));
                                this.mFloatButton.setImageResource(R.drawable.l_to_rw_float);
                                this.mFloatButton.setScaleType(ScaleType.FIT_CENTER);
                                i = 1;
                            } else if (this.cs.m397a((Context) this) == (byte) 2) {
                                if (!(makeInChildBottomAnimation == null || ((Integer) this.mFloatButton.getTag()).intValue() == R.id.bRemountRO)) {
                                    this.mFloatButton.startAnimation(makeInChildBottomAnimation);
                                }
                                this.mFloatButton.setTag(Integer.valueOf(R.id.bRemountRO));
                                this.mFloatButton.setImageResource(R.drawable.l_to_ro_float);
                                this.mFloatButton.setScaleType(ScaleType.FIT_CENTER);
                                i = 1;
                            }
                            if (i != 0) {
                                return;
                            }
                            if (this.cs.m397a((Context) this) == (byte) 1) {
                                if (!(makeInChildBottomAnimation == null || ((Integer) this.mFloatButton.getTag()).intValue() == R.id.bNewArchive)) {
                                    this.mFloatButton.startAnimation(makeInChildBottomAnimation);
                                }
                                this.mFloatButton.setTag(Integer.valueOf(R.id.bNewArchive));
                                this.mFloatButton.setImageResource(R.drawable.l_add_blk);
                                return;
                            }
                            if (!(makeInChildBottomAnimation == null || ((Integer) this.mFloatButton.getTag()).intValue() == R.id.bInfo)) {
                                this.mFloatButton.startAnimation(makeInChildBottomAnimation);
                            }
                            this.mFloatButton.setTag(Integer.valueOf(R.id.bInfo));
                            this.mFloatButton.setImageResource(R.drawable.l_info_blk);
                            return;
                        }
                        i = 0;
                        if (i != 0) {
                            if (this.cs.m397a((Context) this) == (byte) 1) {
                                this.mFloatButton.startAnimation(makeInChildBottomAnimation);
                                this.mFloatButton.setTag(Integer.valueOf(R.id.bInfo));
                                this.mFloatButton.setImageResource(R.drawable.l_info_blk);
                                return;
                            }
                            this.mFloatButton.startAnimation(makeInChildBottomAnimation);
                            this.mFloatButton.setTag(Integer.valueOf(R.id.bNewArchive));
                            this.mFloatButton.setImageResource(R.drawable.l_add_blk);
                            return;
                        }
                        return;
                    } else if (this.cs.m397a((Context) this) != (byte) 1) {
                        if (!(makeInChildBottomAnimation == null || ((Integer) this.mFloatButton.getTag()).intValue() == R.id.bCopy)) {
                            this.mFloatButton.startAnimation(makeInChildBottomAnimation);
                        }
                        this.mFloatButton.setTag(Integer.valueOf(R.id.bCopy));
                        this.mFloatButton.setImageResource(R.drawable.l_copy_blk);
                        return;
                    } else {
                        if (!(makeInChildBottomAnimation == null || ((Integer) this.mFloatButton.getTag()).intValue() == R.id.bCompress)) {
                            this.mFloatButton.startAnimation(makeInChildBottomAnimation);
                        }
                        this.mFloatButton.setTag(Integer.valueOf(R.id.bCompress));
                        this.mFloatButton.setImageResource(R.drawable.l_download_blk);
                        return;
                    }
                } else if (listAdapter != null || listAdapter.mo16b() <= 0) {
                    this.mFloatButton.setVisibility(8);
                    return;
                } else {
                    if (!(makeInChildBottomAnimation == null || ((Integer) this.mFloatButton.getTag()).intValue() == R.id.bCopy)) {
                        this.mFloatButton.startAnimation(makeInChildBottomAnimation);
                    }
                    this.mFloatButton.setTag(Integer.valueOf(R.id.bCopy));
                    this.mFloatButton.setImageResource(R.drawable.l_copy_blk);
                    return;
                }
            }
            makeInChildBottomAnimation = animation;
            this.mFloatButton.setVisibility(0);
            this.mFloatButton.setScaleType(ScaleType.CENTER_INSIDE);
            if (this.cs.m414j() == '\u0000') {
                listAdapter = getListAdapter();
                if (this.cs.m404a()) {
                    if (!this.cs.m408d()) {
                        if (this.cs.f356g) {
                        }
                        this.mFloatButton.startAnimation(makeInChildBottomAnimation);
                        this.mFloatButton.setTag(Integer.valueOf(R.id.bExtract));
                        this.mFloatButton.setImageResource(R.drawable.l_upload_blk);
                        return;
                    } else if (this.cs.m409e()) {
                        if (listAdapter != null) {
                        }
                        this.mFloatButton.setVisibility(8);
                        return;
                    } else {
                        return;
                    }
                } else if (this.cs.f356g) {
                    if (listAdapter != null) {
                    }
                    this.mFloatButton.setVisibility(8);
                    return;
                } else {
                    if (listAdapter != null) {
                    }
                    if (this.cs.m397a((Context) this) != (byte) 3) {
                        if (this.cs.m397a((Context) this) == (byte) 2) {
                            this.mFloatButton.startAnimation(makeInChildBottomAnimation);
                            this.mFloatButton.setTag(Integer.valueOf(R.id.bRemountRO));
                            this.mFloatButton.setImageResource(R.drawable.l_to_ro_float);
                            this.mFloatButton.setScaleType(ScaleType.FIT_CENTER);
                            i = 1;
                        }
                        i = 0;
                    } else {
                        this.mFloatButton.startAnimation(makeInChildBottomAnimation);
                        this.mFloatButton.setTag(Integer.valueOf(R.id.bRemountRW));
                        this.mFloatButton.setImageResource(R.drawable.l_to_rw_float);
                        this.mFloatButton.setScaleType(ScaleType.FIT_CENTER);
                        i = 1;
                    }
                    if (i != 0) {
                        return;
                    }
                    if (this.cs.m397a((Context) this) == (byte) 1) {
                        this.mFloatButton.startAnimation(makeInChildBottomAnimation);
                        this.mFloatButton.setTag(Integer.valueOf(R.id.bNewArchive));
                        this.mFloatButton.setImageResource(R.drawable.l_add_blk);
                        return;
                    }
                    this.mFloatButton.startAnimation(makeInChildBottomAnimation);
                    this.mFloatButton.setTag(Integer.valueOf(R.id.bInfo));
                    this.mFloatButton.setImageResource(R.drawable.l_info_blk);
                    return;
                }
            }
            switch (this.cs.m414j()) {
                case '\u0002':
                    this.mFloatButton.startAnimation(makeInChildBottomAnimation);
                    this.mFloatButton.setTag(Integer.valueOf(R.id.bOk));
                    this.mFloatButton.setImageResource(R.drawable.l_done_blk);
                    return;
                case '\t':
                case '\u0011':
                    this.mFloatButton.startAnimation(makeInChildBottomAnimation);
                    this.mFloatButton.setTag(Integer.valueOf(R.id.bSelectPath));
                    this.mFloatButton.setImageResource(R.drawable.l_to_blk);
                    return;
                case '\"':
                    this.mFloatButton.startAnimation(makeInChildBottomAnimation);
                    this.mFloatButton.setTag(Integer.valueOf(R.id.bCreateArchive));
                    this.mFloatButton.setImageResource(R.drawable.l_done_blk);
                    return;
                case 'A':
                    this.mFloatButton.startAnimation(makeInChildBottomAnimation);
                    this.mFloatButton.setTag(Integer.valueOf(R.id.bPast));
                    this.mFloatButton.setImageResource(R.drawable.l_paste_blk);
                    return;
                default:
                    return;
            }
        }
    }

    public void setImageLoadProgress(int i) {
        setMyProgress((i * 10000) / 100);
        if (i == 0) {
            setMyProgressBarVisibility(false);
        }
    }

    public void setListAdapter(C0046h c0046h) {
        if (this.mListView != null) {
            if (Settings.sActionbarColor != 0) {
                c0046h.mo13a(C0202q.m735b((Context) this, (int) R.attr.colorPrimary));
            }
            c0046h.mo14a((C0031a) this);
            this.mListView.setAdapter((ListAdapter) c0046h);
        }
    }

    public void setMyProgress(int i) {
        if (VERSION.SDK_INT >= 21) {
            if (this.mLoadingProgressBar == null) {
                int identifier = getResources().getIdentifier("status_bar_height", "dimen", "android");
                int dimensionPixelSize = identifier > 0 ? getResources().getDimensionPixelSize(identifier) : 0;
                ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-1, 20);
                this.mLoadingProgressBar = new ProgressBar(this, null, 16842872);
                this.mLoadingProgressBar.setLayoutParams(layoutParams);
                this.mLoadingProgressBar.setMax(10000);
                if (Settings.sActionbarColor == 0) {
                    this.mLoadingProgressBar.getProgressDrawable().setColorFilter(C0202q.m735b((Context) this, (int) R.attr.colorPrimary), Mode.SRC_IN);
                } else {
                    this.mLoadingProgressBar.getProgressDrawable().setColorFilter(-1, Mode.SRC_IN);
                }
                ((ViewGroup) getWindow().getDecorView()).addView(this.mLoadingProgressBar);
                this.mLoadingProgressBar.setY((float) dimensionPixelSize);
            }
            this.mLoadingProgressBar.setVisibility(0);
            this.mLoadingProgressBar.setProgress(i);
            return;
        }
        setProgress(i);
    }

    public final void setMyProgressBarVisibility(boolean z) {
        if (VERSION.SDK_INT < 21) {
            setProgressBarVisibility(z);
        } else if (this.mLoadingProgressBar != null) {
            this.mLoadingProgressBar.setVisibility(z ? 0 : 8);
        }
    }

    public void setRepeatSearch(boolean z) {
        C0046h c0051f = new C0051f(this);
        c0051f.m119a(this.cs.f354e);
        setListAdapter(c0051f);
        if (this.mSearch != null) {
            if (this.mSearch.isIconified()) {
                this.mSearch.setIconified(false);
                if (z) {
                    this.mSearch.clearFocus();
                }
            }
            if (this.cs.f355f != null) {
                this.mSearch.setQuery(this.cs.f355f, false);
            }
        }
        this.cs.f356g = true;
    }

    public void showStartMessage(boolean z) {
        if ((Settings.sShowHelp & 4) != 0) {
            this.mTestExternalSD = false;
            Settings.sShowHelp = (byte) (Settings.sShowHelp & -5);
            ZMainOptionDialog zMainOptionDialog = new ZMainOptionDialog(this.cs, this);
            zMainOptionDialog.show();
            zMainOptionDialog.setOnOkListener(this.cs.f350a);
            zMainOptionDialog.setLanguage(Settings.sLanguage);
            zMainOptionDialog.setOEMCP(C0160c.m538b(this));
            zMainOptionDialog.setIconTheme(Settings.sFSIconTheme);
            zMainOptionDialog.setTheme(Settings.sTheme);
        } else if ((Settings.sShowHelp & 1) != 0) {
            this.mTestExternalSD = false;
            Settings.setHelpRead(this);
            ZMessageDialog zMessageDialog = new ZMessageDialog(this.cs, this, (byte) 4, getString(R.string.MES_FEATURES));
            zMessageDialog.setSubType(20);
            zMessageDialog.setOnOkListener(this.cs.f350a);
            zMessageDialog.show();
        } else if (VERSION.SDK_INT == 19) {
            if ((Settings.sShowHelp & 2) != 0 && Settings.isNeedStoragePermission(this)) {
                new ZFixSDDialog(this.cs, this).show();
            }
        } else if (VERSION.SDK_INT <= 19 || (Settings.sShowHelp & 2) == 0 || !((this.mTestExternalSD || z) && Settings.isNeedStoragePermission(this))) {
            checkPermission();
        } else {
            this.mTestExternalSD = false;
            new ZFixSDDialog(this.cs, this).show();
        }
    }

    public void startClearTempService() {
        startService(new Intent(this, ZArchiverClearTemp.class));
    }
}
