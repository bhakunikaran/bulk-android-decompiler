package ru.zdevs.zarchiver;

import android.content.Intent;

/* renamed from: ru.zdevs.zarchiver.c */
public class C0092c {
    /* renamed from: a */
    public static boolean m371a(Intent intent) {
        return (intent == null || intent.getIntExtra("ZArchiver.iCMD", 0) == 0) ? false : true;
    }

    /* renamed from: b */
    public static boolean m372b(Intent intent) {
        return intent != null && "android.intent.action.VIEW".equals(intent.getAction());
    }

    /* renamed from: c */
    public static boolean m373c(Intent intent) {
        return intent != null && ("android.intent.action.SEND".equals(intent.getAction()) || "android.intent.action.SEND_MULTIPLE".equals(intent.getAction()));
    }
}
