package ru.zdevs.zarchiver.service.p005a;

import java.util.List;
import ru.zdevs.zarchiver.archiver.C2JBridge;
import ru.zdevs.zarchiver.p004b.C0075c;
import ru.zdevs.zarchiver.service.C0158a;
import ru.zdevs.zarchiver.service.C0159b;
import ru.zdevs.zarchiver.service.C0160c;
import ru.zdevs.zarchiver.service.C0161d;
import ru.zdevs.zarchiver.service.ZArchiverService;
import ru.zdevs.zarchiver.tool.C0166c;
import ru.zdevs.zarchiver.tool.C0182i;
import ru.zdevs.zarchiver.tool.C0200o;
import ru.zdevs.zarchiver.tool.C0204s;

/* renamed from: ru.zdevs.zarchiver.service.a.i */
public class C0156i extends C0148h {
    /* renamed from: d */
    private String f439d;
    /* renamed from: e */
    private String f440e;
    /* renamed from: f */
    private List<String> f441f;
    /* renamed from: g */
    private int f442g;
    /* renamed from: h */
    private float f443h;
    /* renamed from: i */
    private int f444i;

    public C0156i(ZArchiverService zArchiverService, boolean z, int i) {
        this(zArchiverService, z, i, 0);
    }

    public C0156i(ZArchiverService zArchiverService, boolean z, int i, int i2) {
        super(zArchiverService, z ? (byte) 10 : (byte) 4, i, i2);
        this.f443h = 1.0f;
        this.f444i = 0;
    }

    /* renamed from: a */
    public int m501a(C0204s c0204s, C0204s c0204s2) {
        try {
            return C2JBridge.jAskOverwrite(this.c, c0204s2.m751d(), c0204s2.m750c(), (int) (c0204s2.m755h() / 1000), c0204s.m751d(), c0204s.m750c(), (int) (c0204s.m755h() / 1000));
        } catch (Throwable e) {
            C0166c.m556a(e);
            return 0;
        }
    }

    /* renamed from: a */
    public void m502a(float f) {
        int i = (int) ((((float) this.f444i) + f) * this.f443h);
        if (i != C2JBridge.f200e[this.c]) {
            C2JBridge.f200e[this.c] = i;
            try {
                this.a.m458b(this.c, i);
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
        }
    }

    /* renamed from: a */
    public void m503a(String str) {
        C2JBridge.f199d[this.c] = str;
        try {
            this.a.m455a(this.c, str);
        } catch (Throwable e) {
            C0166c.m556a(e);
        }
    }

    /* renamed from: a */
    public void m504a(String str, List<String> list, String str2) {
        this.f439d = str;
        this.f440e = str2;
        this.f441f = list;
    }

    public void a_() {
        if ((this.f439d.compareTo(this.f440e) == 0 && this.b == (byte) 10) || this.f441f == null) {
            m468a(1179648);
            this.a.m461b(this.c, true, false);
            return;
        }
        int i;
        C0075c b = (this.f442g & 1) == 1 ? m469b() : null;
        int i2 = !C0160c.f451c ? 17 : 0;
        if ((this.f442g & 1) == 1) {
            String str = (this.f442g & 2) == 0 ? this.f439d + "/" : "";
            for (String str2 : this.f441f) {
                if (C0161d.f453a[this.c] != 15) {
                    switch (this.b) {
                        case (byte) 4:
                            i2 = C0159b.m524a(b, str + str2, this.f440e, i2, this.c);
                            continue;
                        case (byte) 10:
                            i2 = C0159b.m531b(b, str + str2, this.f440e, i2, this.c);
                            continue;
                        default:
                            break;
                    }
                    if (i2 < 0) {
                    }
                }
                i = i2;
            }
            i = i2;
        } else {
            long j = 0;
            for (String str22 : this.f441f) {
                j += C0158a.m515a(this.f439d + "/" + str22);
            }
            if (j <= 0) {
                j = 1;
            }
            this.f443h = 100.0f / ((float) j);
            this.f444i = 0;
            if (C0160c.f450b && C2JBridge.f203h == null) {
                C2JBridge.f203h = new C0075c();
                if (!C2JBridge.f203h.mo52b()) {
                    C2JBridge.f203h = null;
                }
            }
            String str3 = (this.f442g & 2) == 0 ? this.f439d + "/" : "";
            i = i2;
            for (String str222 : this.f441f) {
                if (C0161d.f453a[this.c] != 15) {
                    switch (this.b) {
                        case (byte) 4:
                            i = C0158a.m521b(this, (C0075c) C2JBridge.f203h, str3 + str222, this.f440e, i, this.f439d.length() + 1);
                            continue;
                        case (byte) 10:
                            i = C0158a.m513a(this, (C0075c) C2JBridge.f203h, str3 + str222, this.f440e, i, this.f439d.length() + 1);
                            continue;
                        default:
                            break;
                    }
                    if (i < 0) {
                    }
                }
                if (!((C0200o.m711a(this.f440e) != (byte) 1 || this.f440e.contains("/Android/data") || this.f440e.contains("/Android/obb")) && (C0200o.m711a(str3) != (byte) 1 || str3.contains("/Android/data") || str3.contains("/Android/obb")))) {
                    C0182i.m631a(this.a);
                }
            }
            C0182i.m631a(this.a);
        }
        if (i == -2) {
            m468a(15);
        }
        m468a(i >= 0 ? 1179648 : 1114112);
        if (b != null) {
            b.mo54c();
        }
        if (this.a != null) {
            this.a.m461b(this.c, i >= 0, i == -2);
            this.a.m453a(this.c);
        }
    }

    /* renamed from: b */
    public void m505b(int i) {
        this.f442g = i;
    }

    /* renamed from: b */
    public void m506b(String str) {
        try {
            this.a.m459b(this.c, 0, str);
        } catch (Throwable e) {
            C0166c.m556a(e);
        }
    }

    /* renamed from: c */
    public boolean m507c() {
        return C0161d.f453a[this.c] == 15;
    }

    /* renamed from: d */
    public void m508d() {
        this.f444i++;
    }

    /* renamed from: e */
    public int m509e() {
        return (int) this.f443h;
    }
}
