package ru.zdevs.zarchiver.service.p005a;

import android.content.Context;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import ru.zdevs.zarchiver.archiver.C0071e;
import ru.zdevs.zarchiver.archiver.C2JBridge;
import ru.zdevs.zarchiver.io.LollipopExtSD;
import ru.zdevs.zarchiver.p004b.C0075c;
import ru.zdevs.zarchiver.service.C0158a;
import ru.zdevs.zarchiver.service.C0158a.C0147a;
import ru.zdevs.zarchiver.service.C0159b;
import ru.zdevs.zarchiver.service.C0161d;
import ru.zdevs.zarchiver.service.ZArchiverService;
import ru.zdevs.zarchiver.tool.C0182i;
import ru.zdevs.zarchiver.tool.C0200o;

/* renamed from: ru.zdevs.zarchiver.service.a.b */
public class C0150b extends C0148h implements C0147a {
    /* renamed from: d */
    private List<String> f410d;
    /* renamed from: e */
    private List<String> f411e;
    /* renamed from: f */
    private String f412f;
    /* renamed from: g */
    private String f413g;
    /* renamed from: h */
    private int f414h;

    public C0150b(ZArchiverService zArchiverService, int i) {
        this(zArchiverService, i, 0);
    }

    public C0150b(ZArchiverService zArchiverService, int i, int i2) {
        super(zArchiverService, (byte) 3, i, i2);
    }

    /* renamed from: c */
    private void m474c() {
        int i = 0;
        for (String str : this.f411e) {
            C2JBridge.f199d[this.c] = str;
            this.a.m455a(this.c, str);
            this.a.m458b(this.c, (i * 100) / this.f411e.size());
            if (C0161d.f453a[this.c] == 15) {
                break;
            }
            C0158a.m517a(this, this.f412f + "/" + str, false);
            i++;
        }
        if (C0200o.m711a(this.f412f) == (byte) 1 && !this.f412f.contains("/Android/data") && !this.f412f.contains("/Android/obb")) {
            C0182i.m631a(this.a);
        }
    }

    /* renamed from: a */
    public Context mo103a() {
        return this.a;
    }

    /* renamed from: a */
    public void m476a(String str) {
        this.f410d = new ArrayList();
        this.f410d.add(str);
    }

    /* renamed from: a */
    public void m477a(String str, int i) {
        this.f413g = str;
        this.f414h = i;
    }

    /* renamed from: a */
    public void m478a(List<String> list) {
        this.f410d = list;
        if (this.f410d.size() > 1) {
            m467a((byte) -125);
        }
    }

    /* renamed from: a */
    public void m479a(List<String> list, String str) {
        this.f411e = list;
        this.f412f = str;
    }

    public void a_() {
        boolean z = true;
        if (this.f410d == null || this.f411e == null || (this.f410d.size() > 1 && this.f410d.size() != this.f411e.size())) {
            m468a(1179648);
            this.a.m461b(this.c, true, false);
            return;
        }
        C0075c b = (this.f414h & 1) == 1 ? m469b() : null;
        if ((this.f414h & 4) == 4) {
            m468a(2097152);
        }
        int i = 0;
        boolean z2 = true;
        while (i < this.f410d.size()) {
            String str;
            boolean z3;
            if (this.f410d.size() > 1) {
                C2JBridge.f202g[this.c] = new File((String) this.f410d.get(i)).getName() + " (" + (i + 1) + "/" + this.f410d.size() + ")";
                this.a.m465d(this.c, C2JBridge.f202g[this.c]);
                str = "\\" + ((String) this.f411e.get(i));
            } else {
                str = C0071e.m289a(this.f411e);
            }
            if (this.f412f.startsWith("/SAF")) {
                LollipopExtSD.chdir(this.f412f + "/");
            }
            boolean z4;
            if ((this.f414h & 1) == 1) {
                z4 = C0159b.m533b(b, this.c, (String) this.f410d.get(i), this.f413g, str, this.f412f) && z2;
                z3 = z4;
            } else {
                z4 = C2JBridge.cCompres(this.c, (String) this.f410d.get(i), this.f413g, str, this.f412f) && z2;
                z3 = z4;
            }
            if (C0200o.m711a((String) this.f410d.get(i)) == (byte) 1) {
                C0182i.m632a(this.a, (String) this.f410d.get(i));
            }
            i++;
            z2 = z3;
        }
        if ((this.f414h & 4) == 4) {
            if (z2) {
                m474c();
            }
            m468a(2162688);
        }
        m468a(z2 ? 1179648 : 1114112);
        if (b != null) {
            b.mo54c();
        }
        if (this.a != null) {
            if (this.f410d.size() > 1) {
                ZArchiverService zArchiverService = this.a;
                int i2 = this.c;
                if ((C0161d.f453a[this.c] & 15) != 15) {
                    z = false;
                }
                zArchiverService.m461b(i2, z2, z);
            }
            this.a.m453a(this.c);
        }
    }
}
