package ru.zdevs.zarchiver.service.p005a;

import ru.zdevs.zarchiver.archiver.C2JBridge;
import ru.zdevs.zarchiver.p004b.C0075c;
import ru.zdevs.zarchiver.service.C0159b;
import ru.zdevs.zarchiver.service.ZArchiverService;
import ru.zdevs.zarchiver.tool.C0204s;

/* renamed from: ru.zdevs.zarchiver.service.a.d */
public class C0152d extends C0148h {
    /* renamed from: d */
    private String f419d;
    /* renamed from: e */
    private String f420e;
    /* renamed from: f */
    private String f421f;
    /* renamed from: g */
    private int f422g;

    public C0152d(ZArchiverService zArchiverService, int i) {
        this(zArchiverService, i, 0);
    }

    public C0152d(ZArchiverService zArchiverService, int i, int i2) {
        super(zArchiverService, (byte) 8, i, i2);
    }

    /* renamed from: a */
    public void m483a(String str) {
        this.f419d = str;
    }

    /* renamed from: a */
    public void m484a(String str, int i) {
        this.f421f = str;
        this.f422g = i;
    }

    public void a_() {
        boolean d;
        C0075c c0075c;
        C0204s c0204s = new C0204s(this.f419d);
        if ((this.f422g & 1) == 1) {
            C0075c b = m469b();
            d = C0159b.m535d(b, this.c, this.f419d, this.f421f, this.f420e, c0204s.m752e());
            c0075c = b;
        } else {
            c0075c = null;
            d = C2JBridge.cDelFiles(this.c, this.f419d, this.f421f, this.f420e, c0204s.m752e());
        }
        m468a(d ? 1179648 : 1114112);
        if (c0075c != null) {
            c0075c.mo54c();
        }
        if (this.a != null && d) {
            this.a.m453a(this.c);
        }
    }

    /* renamed from: b */
    public void m485b(String str) {
        this.f420e = str;
    }
}
