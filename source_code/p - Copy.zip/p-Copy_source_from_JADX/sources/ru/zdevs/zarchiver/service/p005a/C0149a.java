package ru.zdevs.zarchiver.service.p005a;

import java.util.ArrayList;
import java.util.List;
import ru.zdevs.zarchiver.archiver.C2JBridge;
import ru.zdevs.zarchiver.io.LollipopExtSD;
import ru.zdevs.zarchiver.p004b.C0075c;
import ru.zdevs.zarchiver.service.C0159b;
import ru.zdevs.zarchiver.service.C0161d;
import ru.zdevs.zarchiver.service.ZArchiverService;

/* renamed from: ru.zdevs.zarchiver.service.a.a */
public class C0149a extends C0148h {
    /* renamed from: d */
    private String f405d;
    /* renamed from: e */
    private String f406e;
    /* renamed from: f */
    private List<String> f407f;
    /* renamed from: g */
    private List<String> f408g;
    /* renamed from: h */
    private int f409h;

    public C0149a(ZArchiverService zArchiverService, int i) {
        this(zArchiverService, i, 0);
    }

    public C0149a(ZArchiverService zArchiverService, int i, int i2) {
        super(zArchiverService, (byte) 7, i, i2);
    }

    /* renamed from: a */
    public void m470a(String str) {
        this.f405d = str;
    }

    /* renamed from: a */
    public void m471a(String str, int i) {
        this.f406e = str;
        this.f409h = i;
    }

    /* renamed from: a */
    public void m472a(String str, String str2) {
        this.f407f = new ArrayList();
        this.f407f.add(str);
        this.f408g = new ArrayList();
        this.f408g.add(str2);
    }

    /* renamed from: a */
    public void m473a(List<String> list, List<String> list2) {
        this.f407f = list;
        this.f408g = list2;
        if (this.f407f.size() > 1) {
            m467a((byte) -121);
        }
    }

    public void a_() {
        String str = null;
        boolean z = true;
        C0075c b = (this.f409h & 1) == 1 ? m469b() : null;
        int i = 0;
        int i2 = 0;
        boolean z2 = true;
        while (i < this.f407f.size()) {
            String str2 = (String) this.f407f.get(i);
            String str3 = (String) this.f408g.get(i);
            if (str3.startsWith("/SAF")) {
                LollipopExtSD.chdir(str3 + "/");
            }
            boolean c = (this.f409h & 1) == 1 ? C0159b.m534c(b, this.c, this.f405d, this.f406e, str2, str3) : C2JBridge.cAddFiles(this.c, this.f405d, this.f406e, str2, str3);
            boolean z3 = z2 && c;
            int i3 = (i2 != 0 || c) ? true : 0;
            i++;
            i2 = i3;
            z2 = z3;
        }
        m468a(z2 ? 1179648 : 1114112);
        if (b != null) {
            b.mo54c();
        }
        if (this.a != null) {
            if (this.f407f.size() <= 1) {
                String str4 = (String) this.f407f.get(0);
                if (str4.length() > 0 && str4.charAt(0) == '\\') {
                    str4 = str4.substring(1);
                }
                if (!str4.contains("\\")) {
                    str = str4;
                }
                if (str != null) {
                    this.a.m460b(this.c, str);
                }
            } else {
                ZArchiverService zArchiverService = this.a;
                int i4 = this.c;
                if ((C0161d.f453a[this.c] & 15) != 15) {
                    z = false;
                }
                zArchiverService.m461b(i4, z2, z);
            }
            if (i2 != 0) {
                this.a.m453a(this.c);
            }
        }
    }
}
