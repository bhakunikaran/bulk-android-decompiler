package ru.zdevs.zarchiver.service;

import java.util.ArrayList;
import java.util.List;
import ru.zdevs.zarchiver.p004b.C0073a;
import ru.zdevs.zarchiver.p004b.C0074b;
import ru.zdevs.zarchiver.p004b.C0075c;
import ru.zdevs.zarchiver.p004b.C0080h;
import ru.zdevs.zarchiver.p004b.C0086l;
import ru.zdevs.zarchiver.p004b.C0088n;
import ru.zdevs.zarchiver.tool.C0168e;
import ru.zdevs.zarchiver.tool.C0200o;

/* renamed from: ru.zdevs.zarchiver.service.b */
public class C0159b {
    /* renamed from: a */
    private static final List<C0073a> f448a = new ArrayList();

    /* renamed from: a */
    public static int m524a(C0075c c0075c, String str, String str2, int i, int i2) {
        C0073a c0075c2;
        if (c0075c == null) {
            c0075c2 = new C0075c();
        }
        C0073a c0074b = !c0075c2.mo52b() ? new C0074b() : c0075c2;
        if (!c0074b.mo52b()) {
            return -1;
        }
        c0074b.m308a(i2);
        c0074b.m314c("$C");
        C0159b.m527a(c0074b);
        String b = C0168e.m572b(str);
        String b2 = C0168e.m572b(str2);
        if (!C0080h.m338a(c0074b, false, i == 17, true, C0200o.m716b(b2), b, b2)) {
            i = -1;
        }
        C0159b.m532b(c0074b);
        return i;
    }

    /* renamed from: a */
    private static String m525a(String str) {
        String replace = str.replace("\\", "' '");
        if (replace.startsWith("' '")) {
            replace = replace.substring(2);
        }
        if (replace.endsWith("' '")) {
            replace = replace.substring(0, replace.length() - 2);
        }
        return (replace.length() <= 2 || replace.endsWith("'")) ? replace : replace + '\'';
    }

    /* renamed from: a */
    public static void m526a(int i) {
        synchronized (f448a) {
            for (C0073a c0073a : f448a) {
                if (c0073a.m315d() == i) {
                    c0073a.mo53b(c0073a.m316e());
                }
            }
        }
    }

    /* renamed from: a */
    private static void m527a(C0073a c0073a) {
        synchronized (f448a) {
            f448a.add(c0073a);
        }
    }

    /* renamed from: a */
    public static boolean m528a(C0075c c0075c, int i, String str, String str2) {
        C0073a c0075c2 = c0075c == null ? new C0075c() : c0075c;
        if (!c0075c2.mo52b()) {
            c0075c2 = new C0074b();
        }
        if (!c0075c2.mo52b()) {
            return false;
        }
        c0075c2.m308a(i);
        c0075c2.m314c("$C");
        C0159b.m527a(c0075c2);
        boolean a = C0086l.m347a(c0075c2, C0168e.m572b(str), str2.replace('\\', ' '));
        C0159b.m532b(c0075c2);
        if (c0075c2 != c0075c) {
            c0075c2.mo54c();
        }
        return a;
    }

    /* renamed from: a */
    public static boolean m529a(C0075c c0075c, int i, String str, String str2, String str3, String str4) {
        C0073a c0075c2 = c0075c == null ? new C0075c() : c0075c;
        if (!c0075c2.mo52b()) {
            c0075c2 = new C0074b();
        }
        if (!c0075c2.mo52b()) {
            return false;
        }
        c0075c2.m308a(i);
        c0075c2.m314c("$C");
        C0159b.m527a(c0075c2);
        boolean a = C0086l.m349a(c0075c2, C0168e.m572b(str), str2.replace('\\', ' '), C0159b.m525a(str3), C0168e.m572b(str4), C0160c.f452d);
        C0159b.m532b(c0075c2);
        if (c0075c2 != c0075c) {
            c0075c2.mo54c();
        }
        return a;
    }

    /* renamed from: a */
    public static boolean m530a(C0075c c0075c, String str, int i) {
        if (c0075c == null) {
            C0073a c0075c2 = new C0075c();
        }
        if (!c0075c2.mo52b()) {
            c0075c2 = new C0074b();
        }
        if (!c0075c2.mo52b()) {
            return false;
        }
        c0075c2.m308a(i);
        c0075c2.m314c("$C");
        C0159b.m527a(c0075c2);
        boolean a = C0088n.m354a(c0075c2, C0168e.m572b(str), true);
        C0159b.m532b(c0075c2);
        return a;
    }

    /* renamed from: b */
    public static int m531b(C0075c c0075c, String str, String str2, int i, int i2) {
        C0073a c0075c2;
        if (c0075c == null) {
            c0075c2 = new C0075c();
        }
        C0073a c0074b = !c0075c2.mo52b() ? new C0074b() : c0075c2;
        if (!c0074b.mo52b()) {
            return -1;
        }
        c0074b.m308a(i2);
        c0074b.m314c("$C");
        C0159b.m527a(c0074b);
        String b = C0168e.m572b(str);
        String b2 = C0168e.m572b(str2);
        if (!C0080h.m338a(c0074b, true, i == 17, true, C0200o.m716b(b2), b, b2)) {
            i = -1;
        }
        C0159b.m532b(c0074b);
        return i;
    }

    /* renamed from: b */
    private static void m532b(C0073a c0073a) {
        synchronized (f448a) {
            f448a.remove(c0073a);
        }
    }

    /* renamed from: b */
    public static boolean m533b(C0075c c0075c, int i, String str, String str2, String str3, String str4) {
        C0073a c0075c2 = c0075c == null ? new C0075c() : c0075c;
        if (!c0075c2.mo52b()) {
            c0075c2 = new C0074b();
        }
        if (!c0075c2.mo52b()) {
            return false;
        }
        c0075c2.m308a(i);
        c0075c2.m314c("$C");
        C0159b.m527a(c0075c2);
        boolean a = C0086l.m348a(c0075c2, C0168e.m572b(str), str2.replace('\\', ' '), C0159b.m525a(str3), C0168e.m572b(str4));
        C0159b.m532b(c0075c2);
        if (c0075c2 != c0075c) {
            c0075c2.mo54c();
        }
        return a;
    }

    /* renamed from: c */
    public static boolean m534c(C0075c c0075c, int i, String str, String str2, String str3, String str4) {
        C0073a c0075c2 = c0075c == null ? new C0075c() : c0075c;
        if (!c0075c2.mo52b()) {
            c0075c2 = new C0074b();
        }
        if (!c0075c2.mo52b()) {
            return false;
        }
        c0075c2.m308a(i);
        c0075c2.m314c("$C");
        C0159b.m527a(c0075c2);
        boolean a = C0086l.m351a(c0075c2, true, C0168e.m572b(str), str2.replace('\\', ' '), C0159b.m525a(str3), C0168e.m572b(str4));
        C0159b.m532b(c0075c2);
        if (c0075c2 != c0075c) {
            c0075c2.mo54c();
        }
        return a;
    }

    /* renamed from: d */
    public static boolean m535d(C0075c c0075c, int i, String str, String str2, String str3, String str4) {
        boolean z = false;
        C0073a c0075c2 = c0075c == null ? new C0075c() : c0075c;
        if (!c0075c2.mo52b()) {
            c0075c2 = new C0074b();
        }
        if (c0075c2.mo52b()) {
            c0075c2.m308a(i);
            c0075c2.m314c("$C");
            C0159b.m527a(c0075c2);
            z = C0086l.m351a(c0075c2, false, C0168e.m572b(str), str2.replace('\\', ' '), C0159b.m525a(str3), C0168e.m572b(str4));
            C0159b.m532b(c0075c2);
            if (c0075c2 != c0075c) {
                c0075c2.mo54c();
            }
        }
        return z;
    }

    /* renamed from: e */
    public static boolean m536e(C0075c c0075c, int i, String str, String str2, String str3, String str4) {
        C0073a c0075c2 = c0075c == null ? new C0075c() : c0075c;
        if (!c0075c2.mo52b()) {
            c0075c2 = new C0074b();
        }
        if (!c0075c2.mo52b()) {
            return false;
        }
        c0075c2.m308a(i);
        c0075c2.m314c("$C");
        C0159b.m527a(c0075c2);
        boolean b = C0086l.m352b(c0075c2, C0168e.m572b(str), str2.replace('\\', ' '), str3, str4);
        C0159b.m532b(c0075c2);
        if (c0075c2 != c0075c) {
            c0075c2.mo54c();
        }
        return b;
    }
}
