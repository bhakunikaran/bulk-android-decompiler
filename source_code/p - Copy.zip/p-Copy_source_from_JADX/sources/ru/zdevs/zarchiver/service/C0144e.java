package ru.zdevs.zarchiver.service;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import java.util.List;
import ru.zdevs.zarchiver.Actions;
import ru.zdevs.zarchiver.ZArchiverExtInterface;
import ru.zdevs.zarchiver.archiver.AskOverwriteInfo;
import ru.zdevs.zarchiver.widget.bottomsheet.ViewDragHelper;

/* renamed from: ru.zdevs.zarchiver.service.e */
public interface C0144e extends IInterface {

    /* renamed from: ru.zdevs.zarchiver.service.e$a */
    public static abstract class C0145a extends Binder implements C0144e {

        /* renamed from: ru.zdevs.zarchiver.service.e$a$a */
        private static class C0162a implements C0144e {
            /* renamed from: a */
            private IBinder f457a;

            C0162a(IBinder iBinder) {
                this.f457a = iBinder;
            }

            public void ArchiveAddFiles(String str, String str2, String str3, String str4, String str5, int i) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    obtain.writeString(str);
                    obtain.writeString(str2);
                    obtain.writeString(str3);
                    obtain.writeString(str4);
                    obtain.writeString(str5);
                    obtain.writeInt(i);
                    this.f457a.transact(11, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void ArchiveAddFilesMulti(String str, String str2, String str3, List<String> list, List<String> list2, int i) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    obtain.writeString(str);
                    obtain.writeString(str2);
                    obtain.writeString(str3);
                    obtain.writeStringList(list);
                    obtain.writeStringList(list2);
                    obtain.writeInt(i);
                    this.f457a.transact(12, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void ArchiveCompress(int i, String str, String str2, String str3, List<String> list, String str4, int i2) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    obtain.writeString(str2);
                    obtain.writeString(str3);
                    obtain.writeStringList(list);
                    obtain.writeString(str4);
                    obtain.writeInt(i2);
                    this.f457a.transact(1, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void ArchiveCompressMulti(List<String> list, String str, List<String> list2, String str2, int i) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    obtain.writeStringList(list);
                    obtain.writeString(str);
                    obtain.writeStringList(list2);
                    obtain.writeString(str2);
                    obtain.writeInt(i);
                    this.f457a.transact(2, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void ArchiveCreateFolder(String str, String str2, String str3, String str4, int i) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    obtain.writeString(str);
                    obtain.writeString(str2);
                    obtain.writeString(str3);
                    obtain.writeString(str4);
                    obtain.writeInt(i);
                    this.f457a.transact(15, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void ArchiveDelFiles(String str, String str2, String str3, String str4, int i) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    obtain.writeString(str);
                    obtain.writeString(str2);
                    obtain.writeString(str3);
                    obtain.writeString(str4);
                    obtain.writeInt(i);
                    this.f457a.transact(13, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void ArchiveExtract(int i, String str, String str2, String str3, String str4, String str5, int i2) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    obtain.writeString(str2);
                    obtain.writeString(str3);
                    obtain.writeString(str4);
                    obtain.writeString(str5);
                    obtain.writeInt(i2);
                    this.f457a.transact(3, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void ArchiveExtractMulti(int i, List<String> list, List<String> list2, List<String> list3, List<String> list4, List<String> list5, int i2) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    obtain.writeInt(i);
                    obtain.writeStringList(list);
                    obtain.writeStringList(list2);
                    obtain.writeStringList(list3);
                    obtain.writeStringList(list4);
                    obtain.writeStringList(list5);
                    obtain.writeInt(i2);
                    this.f457a.transact(4, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void ArchiveOpenFile(String str, String str2, String str3, String str4, String str5, int i) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    obtain.writeString(str);
                    obtain.writeString(str2);
                    obtain.writeString(str3);
                    obtain.writeString(str4);
                    obtain.writeString(str5);
                    obtain.writeInt(i);
                    this.f457a.transact(5, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void ArchiveRenFile(String str, String str2, String str3, String str4, String str5, int i) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    obtain.writeString(str);
                    obtain.writeString(str2);
                    obtain.writeString(str3);
                    obtain.writeString(str4);
                    obtain.writeString(str5);
                    obtain.writeInt(i);
                    this.f457a.transact(14, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void ArchiveTest(String str, String str2, String str3) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    obtain.writeString(str);
                    obtain.writeString(str2);
                    obtain.writeString(str3);
                    this.f457a.transact(6, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void ArchiveTestMulti(List<String> list, List<String> list2, List<String> list3) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    obtain.writeStringList(list);
                    obtain.writeStringList(list2);
                    obtain.writeStringList(list3);
                    this.f457a.transact(7, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void Copy(String str, String str2, List<String> list, int i) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    obtain.writeString(str);
                    obtain.writeString(str2);
                    obtain.writeStringList(list);
                    obtain.writeInt(i);
                    this.f457a.transact(8, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void GUIStatus(int i) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    obtain.writeInt(i);
                    this.f457a.transact(17, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public AskOverwriteInfo GetAskOverwrite(int i) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    obtain.writeInt(i);
                    this.f457a.transact(23, obtain, obtain2, 0);
                    obtain2.readException();
                    AskOverwriteInfo askOverwriteInfo = obtain2.readInt() != 0 ? (AskOverwriteInfo) AskOverwriteInfo.CREATOR.createFromParcel(obtain2) : null;
                    obtain2.recycle();
                    obtain.recycle();
                    return askOverwriteInfo;
                } catch (Throwable th) {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public int GetProgPercent(int i) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    obtain.writeInt(i);
                    this.f457a.transact(22, obtain, obtain2, 0);
                    obtain2.readException();
                    int readInt = obtain2.readInt();
                    return readInt;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public String GetProgText(int i) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    obtain.writeInt(i);
                    this.f457a.transact(21, obtain, obtain2, 0);
                    obtain2.readException();
                    String readString = obtain2.readString();
                    return readString;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public int GetStatusTask(int i) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    obtain.writeInt(i);
                    this.f457a.transact(24, obtain, obtain2, 0);
                    obtain2.readException();
                    int readInt = obtain2.readInt();
                    return readInt;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void HideNotification(int i) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    obtain.writeInt(i);
                    this.f457a.transact(18, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void Move(String str, String str2, List<String> list, int i) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    obtain.writeString(str);
                    obtain.writeString(str2);
                    obtain.writeStringList(list);
                    obtain.writeInt(i);
                    this.f457a.transact(9, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void Remove(String str, List<String> list, int i) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    obtain.writeString(str);
                    obtain.writeStringList(list);
                    obtain.writeInt(i);
                    this.f457a.transact(10, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void RestartGUI() {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    this.f457a.transact(26, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void SetOverwrite(int i, int i2) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    obtain.writeInt(i);
                    obtain.writeInt(i2);
                    this.f457a.transact(20, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void SetPassword(int i, String str) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    this.f457a.transact(19, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void SetSettings() {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    this.f457a.transact(16, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void SetStatusTask(int i, int i2) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    obtain.writeInt(i);
                    obtain.writeInt(i2);
                    this.f457a.transact(25, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public IBinder asBinder() {
                return this.f457a;
            }
        }

        public C0145a() {
            attachInterface(this, "ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
        }

        public static C0144e asInterface(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
            return (queryLocalInterface == null || !(queryLocalInterface instanceof C0144e)) ? new C0162a(iBinder) : (C0144e) queryLocalInterface;
        }

        public IBinder asBinder() {
            return this;
        }

        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
            int GetProgPercent;
            switch (i) {
                case 1:
                    parcel.enforceInterface("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    ArchiveCompress(parcel.readInt(), parcel.readString(), parcel.readString(), parcel.readString(), parcel.createStringArrayList(), parcel.readString(), parcel.readInt());
                    parcel2.writeNoException();
                    return true;
                case 2:
                    parcel.enforceInterface("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    ArchiveCompressMulti(parcel.createStringArrayList(), parcel.readString(), parcel.createStringArrayList(), parcel.readString(), parcel.readInt());
                    parcel2.writeNoException();
                    return true;
                case 3:
                    parcel.enforceInterface("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    ArchiveExtract(parcel.readInt(), parcel.readString(), parcel.readString(), parcel.readString(), parcel.readString(), parcel.readString(), parcel.readInt());
                    parcel2.writeNoException();
                    return true;
                case 4:
                    parcel.enforceInterface("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    ArchiveExtractMulti(parcel.readInt(), parcel.createStringArrayList(), parcel.createStringArrayList(), parcel.createStringArrayList(), parcel.createStringArrayList(), parcel.createStringArrayList(), parcel.readInt());
                    parcel2.writeNoException();
                    return true;
                case 5:
                    parcel.enforceInterface("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    ArchiveOpenFile(parcel.readString(), parcel.readString(), parcel.readString(), parcel.readString(), parcel.readString(), parcel.readInt());
                    parcel2.writeNoException();
                    return true;
                case Actions.CHECK_ACTION_RENAME /*6*/:
                    parcel.enforceInterface("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    ArchiveTest(parcel.readString(), parcel.readString(), parcel.readString());
                    parcel2.writeNoException();
                    return true;
                case ZArchiverExtInterface.COMPRESSION_LAVEL_MAX /*7*/:
                    parcel.enforceInterface("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    ArchiveTestMulti(parcel.createStringArrayList(), parcel.createStringArrayList(), parcel.createStringArrayList());
                    parcel2.writeNoException();
                    return true;
                case ViewDragHelper.EDGE_BOTTOM /*8*/:
                    parcel.enforceInterface("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    Copy(parcel.readString(), parcel.readString(), parcel.createStringArrayList(), parcel.readInt());
                    parcel2.writeNoException();
                    return true;
                case 9:
                    parcel.enforceInterface("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    Move(parcel.readString(), parcel.readString(), parcel.createStringArrayList(), parcel.readInt());
                    parcel2.writeNoException();
                    return true;
                case 10:
                    parcel.enforceInterface("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    Remove(parcel.readString(), parcel.createStringArrayList(), parcel.readInt());
                    parcel2.writeNoException();
                    return true;
                case 11:
                    parcel.enforceInterface("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    ArchiveAddFiles(parcel.readString(), parcel.readString(), parcel.readString(), parcel.readString(), parcel.readString(), parcel.readInt());
                    parcel2.writeNoException();
                    return true;
                case 12:
                    parcel.enforceInterface("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    ArchiveAddFilesMulti(parcel.readString(), parcel.readString(), parcel.readString(), parcel.createStringArrayList(), parcel.createStringArrayList(), parcel.readInt());
                    parcel2.writeNoException();
                    return true;
                case 13:
                    parcel.enforceInterface("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    ArchiveDelFiles(parcel.readString(), parcel.readString(), parcel.readString(), parcel.readString(), parcel.readInt());
                    parcel2.writeNoException();
                    return true;
                case 14:
                    parcel.enforceInterface("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    ArchiveRenFile(parcel.readString(), parcel.readString(), parcel.readString(), parcel.readString(), parcel.readString(), parcel.readInt());
                    parcel2.writeNoException();
                    return true;
                case ViewDragHelper.EDGE_ALL /*15*/:
                    parcel.enforceInterface("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    ArchiveCreateFolder(parcel.readString(), parcel.readString(), parcel.readString(), parcel.readString(), parcel.readInt());
                    parcel2.writeNoException();
                    return true;
                case 16:
                    parcel.enforceInterface("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    SetSettings();
                    parcel2.writeNoException();
                    return true;
                case 17:
                    parcel.enforceInterface("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    GUIStatus(parcel.readInt());
                    parcel2.writeNoException();
                    return true;
                case 18:
                    parcel.enforceInterface("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    HideNotification(parcel.readInt());
                    parcel2.writeNoException();
                    return true;
                case 19:
                    parcel.enforceInterface("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    SetPassword(parcel.readInt(), parcel.readString());
                    parcel2.writeNoException();
                    return true;
                case 20:
                    parcel.enforceInterface("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    SetOverwrite(parcel.readInt(), parcel.readInt());
                    parcel2.writeNoException();
                    return true;
                case 21:
                    parcel.enforceInterface("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    String GetProgText = GetProgText(parcel.readInt());
                    parcel2.writeNoException();
                    parcel2.writeString(GetProgText);
                    return true;
                case 22:
                    parcel.enforceInterface("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    GetProgPercent = GetProgPercent(parcel.readInt());
                    parcel2.writeNoException();
                    parcel2.writeInt(GetProgPercent);
                    return true;
                case 23:
                    parcel.enforceInterface("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    AskOverwriteInfo GetAskOverwrite = GetAskOverwrite(parcel.readInt());
                    parcel2.writeNoException();
                    if (GetAskOverwrite != null) {
                        parcel2.writeInt(1);
                        GetAskOverwrite.writeToParcel(parcel2, 1);
                    } else {
                        parcel2.writeInt(0);
                    }
                    return true;
                case 24:
                    parcel.enforceInterface("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    GetProgPercent = GetStatusTask(parcel.readInt());
                    parcel2.writeNoException();
                    parcel2.writeInt(GetProgPercent);
                    return true;
                case 25:
                    parcel.enforceInterface("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    SetStatusTask(parcel.readInt(), parcel.readInt());
                    parcel2.writeNoException();
                    return true;
                case 26:
                    parcel.enforceInterface("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    RestartGUI();
                    parcel2.writeNoException();
                    return true;
                case 1598968902:
                    parcel2.writeString("ru.zdevs.zarchiver.service.ZArchiverServiceConnect");
                    return true;
                default:
                    return super.onTransact(i, parcel, parcel2, i2);
            }
        }
    }

    void ArchiveAddFiles(String str, String str2, String str3, String str4, String str5, int i);

    void ArchiveAddFilesMulti(String str, String str2, String str3, List<String> list, List<String> list2, int i);

    void ArchiveCompress(int i, String str, String str2, String str3, List<String> list, String str4, int i2);

    void ArchiveCompressMulti(List<String> list, String str, List<String> list2, String str2, int i);

    void ArchiveCreateFolder(String str, String str2, String str3, String str4, int i);

    void ArchiveDelFiles(String str, String str2, String str3, String str4, int i);

    void ArchiveExtract(int i, String str, String str2, String str3, String str4, String str5, int i2);

    void ArchiveExtractMulti(int i, List<String> list, List<String> list2, List<String> list3, List<String> list4, List<String> list5, int i2);

    void ArchiveOpenFile(String str, String str2, String str3, String str4, String str5, int i);

    void ArchiveRenFile(String str, String str2, String str3, String str4, String str5, int i);

    void ArchiveTest(String str, String str2, String str3);

    void ArchiveTestMulti(List<String> list, List<String> list2, List<String> list3);

    void Copy(String str, String str2, List<String> list, int i);

    void GUIStatus(int i);

    AskOverwriteInfo GetAskOverwrite(int i);

    int GetProgPercent(int i);

    String GetProgText(int i);

    int GetStatusTask(int i);

    void HideNotification(int i);

    void Move(String str, String str2, List<String> list, int i);

    void Remove(String str, List<String> list, int i);

    void RestartGUI();

    void SetOverwrite(int i, int i2);

    void SetPassword(int i, String str);

    void SetSettings();

    void SetStatusTask(int i, int i2);
}
