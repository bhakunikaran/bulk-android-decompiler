package ru.zdevs.zarchiver.service.p005a;

import java.io.File;
import ru.zdevs.zarchiver.archiver.C2JBridge;
import ru.zdevs.zarchiver.p004b.C0075c;
import ru.zdevs.zarchiver.service.C0159b;
import ru.zdevs.zarchiver.service.ZArchiverService;
import ru.zdevs.zarchiver.tool.C0202q;

/* renamed from: ru.zdevs.zarchiver.service.a.c */
public class C0151c extends C0148h {
    /* renamed from: d */
    private String f415d;
    /* renamed from: e */
    private String f416e;
    /* renamed from: f */
    private String f417f;
    /* renamed from: g */
    private int f418g;

    public C0151c(ZArchiverService zArchiverService, int i) {
        this(zArchiverService, i, 0);
    }

    public C0151c(ZArchiverService zArchiverService, int i, int i2) {
        super(zArchiverService, (byte) 12, i, i2);
    }

    /* renamed from: a */
    public void m480a(String str) {
        this.f415d = str;
    }

    /* renamed from: a */
    public void m481a(String str, int i) {
        this.f417f = str;
        this.f418g = i;
    }

    public void a_() {
        C0075c c0075c;
        boolean z;
        C0075c c0075c2 = null;
        String a = C0202q.m727a(this.a);
        File file = new File(a, this.f416e);
        if (file.mkdir()) {
            boolean c;
            if ((this.f418g & 1) == 1) {
                C0075c b = m469b();
                c0075c2 = b;
                c = C0159b.m534c(b, this.c, this.f415d, this.f417f, this.f416e, a);
            } else {
                c = C2JBridge.cAddFiles(this.c, this.f415d, this.f417f, this.f416e, a);
            }
            file.delete();
            c0075c = c0075c2;
            z = c;
        } else {
            c0075c = null;
            z = false;
        }
        m468a(z ? 1179648 : 1114112);
        if (c0075c != null) {
            c0075c.mo54c();
        }
        if (this.a != null && z) {
            this.a.m453a(this.c);
        }
    }

    /* renamed from: b */
    public void m482b(String str) {
        this.f416e = str;
    }
}
