package ru.zdevs.zarchiver.service;

import android.content.Context;
import android.content.res.XmlResourceParser;
import java.util.Calendar;
import java.util.Locale;
import ru.zdevs.zarchiver.R;
import ru.zdevs.zarchiver.tool.C0166c;

/* renamed from: ru.zdevs.zarchiver.service.c */
public class C0160c {
    /* renamed from: a */
    public static int f449a = 866;
    /* renamed from: b */
    public static boolean f450b = false;
    /* renamed from: c */
    public static boolean f451c = true;
    /* renamed from: d */
    public static boolean f452d = true;

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    /* renamed from: a */
    public static void m537a(android.content.Context r6) {
        /*
        r0 = 0;
        r4 = 1;
        r2 = r6.getApplicationContext();
        r1 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x0089 }
        r1.<init>();	 Catch:{ Exception -> 0x0089 }
        r3 = r2.getPackageName();	 Catch:{ Exception -> 0x0089 }
        r1 = r1.append(r3);	 Catch:{ Exception -> 0x0089 }
        r3 = "_preferences";
        r1 = r1.append(r3);	 Catch:{ Exception -> 0x0089 }
        r1 = r1.toString();	 Catch:{ Exception -> 0x0089 }
        r3 = 4;
        r1 = r2.getSharedPreferences(r1, r3);	 Catch:{ Exception -> 0x0089 }
        r3 = "bSetUTimeByRoot_off";
        r3 = r1.contains(r3);	 Catch:{ Exception -> 0x0092 }
        if (r3 != 0) goto L_0x0090;
    L_0x002a:
        if (r0 != 0) goto L_0x0030;
    L_0x002c:
        r0 = android.preference.PreferenceManager.getDefaultSharedPreferences(r2);
    L_0x0030:
        r1 = "iOEMCP";
        r3 = "0";
        r1 = r0.getString(r1, r3);
        r1 = java.lang.Integer.parseInt(r1);
        f449a = r1;
        r1 = "bSetUTimeByRoot_off";
        r3 = 0;
        r1 = r0.getBoolean(r1, r3);
        f450b = r1;
        r1 = "iGUIConfirmRewrite";
        r1 = r0.getBoolean(r1, r4);
        f451c = r1;
        r1 = f451c;
        ru.zdevs.zarchiver.archiver.C2JBridge.f196a = r1;
        r1 = "i7ZUsePipe";
        r1 = r0.getBoolean(r1, r4);
        f452d = r1;
        r1 = f449a;
        r3 = 700; // 0x2bc float:9.81E-43 double:3.46E-321;
        if (r1 > r3) goto L_0x0088;
    L_0x0061:
        r1 = ru.zdevs.zarchiver.service.C0160c.m538b(r2);
        f449a = r1;
        r0 = r0.edit();
        r1 = "iOEMCP";
        r2 = new java.lang.StringBuilder;
        r2.<init>();
        r3 = "";
        r2 = r2.append(r3);
        r3 = f449a;
        r2 = r2.append(r3);
        r2 = r2.toString();
        r0.putString(r1, r2);
        r0.commit();
    L_0x0088:
        return;
    L_0x0089:
        r1 = move-exception;
        r5 = r1;
        r1 = r0;
        r0 = r5;
    L_0x008d:
        ru.zdevs.zarchiver.tool.C0166c.m556a(r0);
    L_0x0090:
        r0 = r1;
        goto L_0x002a;
    L_0x0092:
        r0 = move-exception;
        goto L_0x008d;
        */
        throw new UnsupportedOperationException("Method not decompiled: ru.zdevs.zarchiver.service.c.a(android.content.Context):void");
    }

    /* renamed from: b */
    public static int m538b(Context context) {
        String c = C0160c.m539c(context);
        return c.startsWith(Locale.SIMPLIFIED_CHINESE.toString()) ? 936 : (c.startsWith(Locale.TRADITIONAL_CHINESE.toString()) || c.startsWith(Locale.TAIWAN.toString())) ? 950 : c.startsWith(Locale.JAPANESE.toString()) ? 932 : !c.startsWith(Locale.FRENCH.toString()) ? c.startsWith(Locale.KOREAN.toString()) ? 949 : !c.startsWith(Locale.CANADA_FRENCH.toString()) ? (c.startsWith("ru") || c.startsWith("uk")) ? 866 : c.startsWith("ar") ? 720 : c.startsWith("tr") ? 857 : c.startsWith("pt") ? 860 : c.startsWith("he") ? 862 : c.startsWith("el") ? 737 : (c.startsWith("lv") || c.startsWith("lt") || c.startsWith("et")) ? 775 : c.startsWith("en") ? 437 : (c.startsWith("es") || c.startsWith("fr") || c.startsWith("de")) ? 850 : 866 : 863 : 863;
    }

    /* renamed from: c */
    private static String m539c(Context context) {
        XmlResourceParser xmlResourceParser = null;
        String locale = Locale.getDefault().toString();
        if (locale.startsWith("en")) {
            String id = Calendar.getInstance().getTimeZone().getID();
            if (!(id == null || id.startsWith("America"))) {
                xmlResourceParser = context.getResources().getXml(R.xml.time_zones_by_country);
                while (xmlResourceParser.getEventType() != 1) {
                    if (xmlResourceParser.getEventType() != 2) {
                        xmlResourceParser.next();
                    } else {
                        String name = xmlResourceParser.getName();
                        if (name == null) {
                            break;
                        }
                        try {
                            if (name.equals("timezone")) {
                                name = xmlResourceParser.getAttributeValue(null, "code");
                                if (xmlResourceParser.next() == 4) {
                                    String text = xmlResourceParser.getText();
                                    if (text != null && id.equals(text)) {
                                        if (name.equals("ru") || name.equals("ua") || name.equals("by") || name.equals("kz")) {
                                            locale = "ru";
                                        } else if (name.equals("de")) {
                                            locale = "de";
                                        } else if (name.equals("cn") || name.equals("hk")) {
                                            locale = Locale.SIMPLIFIED_CHINESE.toString();
                                        } else if (name.equals("tw")) {
                                            locale = Locale.TRADITIONAL_CHINESE.toString();
                                        } else if (name.equals("fr")) {
                                            locale = "fr";
                                        } else if (name.equals("jp")) {
                                            locale = Locale.JAPANESE.toString();
                                        } else if (name.equals("kp") || name.equals("kr")) {
                                            locale = Locale.KOREAN.toString();
                                        } else if (name.equals("es")) {
                                            locale = "es";
                                        } else if (name.equals("il") || name.equals("sy") || name.equals("sa") || name.equals("ae")) {
                                            locale = "ar";
                                        } else if (id.startsWith("Europe")) {
                                            locale = name;
                                        }
                                    }
                                } else {
                                    continue;
                                }
                            } else {
                                xmlResourceParser.next();
                            }
                        } catch (Throwable e) {
                            C0166c.m556a(e);
                            if (locale.startsWith("en")) {
                                C0166c.m558c("ServiceSettings", "Detect by time zone failed :(");
                            }
                        } finally {
                            if (xmlResourceParser != null) {
                                xmlResourceParser.close();
                            }
                        }
                    }
                }
                if (xmlResourceParser != null) {
                    xmlResourceParser.close();
                }
                if (locale.startsWith("en")) {
                    C0166c.m558c("ServiceSettings", "Detect by time zone failed :(");
                }
            }
        }
        return locale;
    }
}
