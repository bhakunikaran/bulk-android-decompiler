package ru.zdevs.zarchiver.service;

import ru.zdevs.zarchiver.ZArchiverExtInterface;
import ru.zdevs.zarchiver.archiver.C2JBridge;
import ru.zdevs.zarchiver.tool.C0166c;
import ru.zdevs.zarchiver.widget.bottomsheet.ViewDragHelper;

/* renamed from: ru.zdevs.zarchiver.service.d */
public class C0161d {
    /* renamed from: a */
    public static final int[] f453a = new int[5];
    /* renamed from: b */
    public static final byte[] f454b = new byte[5];
    /* renamed from: c */
    public static final int[] f455c = new int[5];
    /* renamed from: d */
    public static final String[] f456d = new String[5];

    /* renamed from: a */
    public static int m540a(int i) {
        synchronized (f453a) {
            for (int i2 = 0; i2 < 5; i2++) {
                if (i2 != i) {
                    if ((f453a[i2] & 1048576) == 0) {
                        return i2;
                    }
                }
            }
            return -1;
        }
    }

    /* renamed from: a */
    public static void m541a() {
        for (int i = 0; i < 5; i++) {
            f453a[i] = 1048576;
            f454b[i] = (byte) 0;
            f455c[i] = 0;
            f456d[i] = "";
        }
    }

    /* renamed from: a */
    public static void m542a(ZArchiverService zArchiverService, int i, int i2) {
        int i3 = 1;
        synchronized (f453a) {
            if ((f453a[i] & 2097152) == 2097152) {
                if (i2 == 2162688 || i2 == 15) {
                    int[] iArr = f453a;
                    iArr[i] = iArr[i] & -2097153;
                }
                if (i2 != 15) {
                    return;
                }
            }
            if (i2 == 2097152) {
                int[] iArr2 = f453a;
                iArr2[i] = iArr2[i] | 2097152;
                return;
            } else if ((f453a[i] & 1048576) == 1048576 && i2 == 15) {
                try {
                    zArchiverService.m464d(i, 0);
                } catch (Throwable e) {
                    C0166c.m556a(e);
                }
                return;
            } else {
                if ((f453a[i] & 15) != 15 || i2 == 0) {
                    f453a[i] = i2;
                } else {
                    iArr = f453a;
                    iArr[i] = iArr[i] | i2;
                }
                if (i2 < 255) {
                    switch (f454b[i]) {
                        case (byte) -127:
                        case (byte) -121:
                        case (byte) -117:
                        case (byte) 1:
                        case (byte) 3:
                        case (byte) 5:
                        case ZArchiverExtInterface.COMPRESSION_LAVEL_MAX /*7*/:
                        case ViewDragHelper.EDGE_BOTTOM /*8*/:
                        case (byte) 11:
                            C2JBridge.cSetStatus(i, (byte) i2);
                            if (i2 == 0) {
                                C2JBridge.cSetOption(1, C0160c.f449a);
                                if (!C0160c.f452d) {
                                    i3 = 0;
                                }
                                C2JBridge.cSetOption(4, i3);
                                break;
                            }
                            break;
                        case (byte) 4:
                        case (byte) 10:
                            break;
                    }
                    if (i2 == 15) {
                        C2JBridge.m200b(i);
                        C0159b.m526a(i);
                    }
                } else if ((i2 & 1048576) == 1048576) {
                    try {
                        C2JBridge.m200b(i);
                    } catch (Throwable e2) {
                        C0166c.m556a(e2);
                    }
                    try {
                        zArchiverService.m464d(i, 0);
                        zArchiverService.m452a();
                    } catch (Throwable e22) {
                        C0166c.m556a(e22);
                    }
                }
            }
        }
    }

    /* renamed from: b */
    public static boolean m543b() {
        boolean z = false;
        synchronized (f453a) {
            for (int i = 0; i < 5; i++) {
                if ((f453a[i] & 1048576) == 0) {
                    z = true;
                    break;
                }
            }
        }
        return z;
    }

    /* renamed from: b */
    public static boolean m544b(int i) {
        boolean z = false;
        synchronized (f453a) {
            for (int i2 = 0; i2 < 5; i2++) {
                if (i2 != i) {
                    if ((f453a[i2] & 1048576) == 0) {
                        z = true;
                        break;
                    }
                }
            }
        }
        return z;
    }

    /* renamed from: c */
    public static int m545c() {
        synchronized (f453a) {
            for (int i = 0; i < 5; i++) {
                if ((f453a[i] & 1048576) != 0) {
                    return i;
                }
            }
            return -1;
        }
    }
}
