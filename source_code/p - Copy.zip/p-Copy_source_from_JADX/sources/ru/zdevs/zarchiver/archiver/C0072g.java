package ru.zdevs.zarchiver.archiver;

/* renamed from: ru.zdevs.zarchiver.archiver.g */
public class C0072g {
    /* renamed from: d */
    private static C0072g f247d;
    /* renamed from: a */
    public String f248a;
    /* renamed from: b */
    public String f249b;
    /* renamed from: c */
    public int f250c;

    public C0072g() {
        f247d = this;
        C0072g.m302b();
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    /* renamed from: a */
    public static java.lang.String m297a(java.lang.String r4, boolean r5) {
        /*
        if (r4 == 0) goto L_0x0006;
    L_0x0002:
        r0 = f247d;
        if (r0 != 0) goto L_0x0009;
    L_0x0006:
        r0 = "";
    L_0x0008:
        return r0;
    L_0x0009:
        r1 = f247d;
        monitor-enter(r1);
        r0 = f247d;	 Catch:{ all -> 0x0016 }
        r0 = r0.f248a;	 Catch:{ all -> 0x0016 }
        if (r0 != 0) goto L_0x0019;
    L_0x0012:
        r0 = "";
        monitor-exit(r1);	 Catch:{ all -> 0x0016 }
        goto L_0x0008;
    L_0x0016:
        r0 = move-exception;
        monitor-exit(r1);	 Catch:{ all -> 0x0016 }
        throw r0;
    L_0x0019:
        r0 = f247d;	 Catch:{ all -> 0x0016 }
        r0 = r0.f248a;	 Catch:{ all -> 0x0016 }
        r0 = r0.endsWith(r4);	 Catch:{ all -> 0x0016 }
        if (r0 == 0) goto L_0x003e;
    L_0x0023:
        r0 = f247d;	 Catch:{ all -> 0x0016 }
        r0 = r0.f249b;	 Catch:{ all -> 0x0016 }
        if (r0 == 0) goto L_0x003e;
    L_0x0029:
        if (r5 == 0) goto L_0x0039;
    L_0x002b:
        r0 = f247d;	 Catch:{ all -> 0x0016 }
        r0 = r0.f249b;	 Catch:{ all -> 0x0016 }
        r2 = "\\";
        r3 = "\\\\";
        r0 = r0.replace(r2, r3);	 Catch:{ all -> 0x0016 }
    L_0x0037:
        monitor-exit(r1);	 Catch:{ all -> 0x0016 }
        goto L_0x0008;
    L_0x0039:
        r0 = f247d;	 Catch:{ all -> 0x0016 }
        r0 = r0.f249b;	 Catch:{ all -> 0x0016 }
        goto L_0x0037;
    L_0x003e:
        monitor-exit(r1);	 Catch:{ all -> 0x0016 }
        r0 = "";
        goto L_0x0008;
        */
        throw new UnsupportedOperationException("Method not decompiled: ru.zdevs.zarchiver.archiver.g.a(java.lang.String, boolean):java.lang.String");
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    /* renamed from: a */
    public static java.lang.String m298a(boolean r4) {
        /*
        r0 = f247d;
        if (r0 != 0) goto L_0x0007;
    L_0x0004:
        r0 = "";
    L_0x0006:
        return r0;
    L_0x0007:
        r1 = f247d;
        monitor-enter(r1);
        r0 = f247d;	 Catch:{ all -> 0x0014 }
        r0 = r0.f248a;	 Catch:{ all -> 0x0014 }
        if (r0 != 0) goto L_0x0017;
    L_0x0010:
        r0 = "";
        monitor-exit(r1);	 Catch:{ all -> 0x0014 }
        goto L_0x0006;
    L_0x0014:
        r0 = move-exception;
        monitor-exit(r1);	 Catch:{ all -> 0x0014 }
        throw r0;
    L_0x0017:
        r0 = f247d;	 Catch:{ all -> 0x0014 }
        r0 = r0.f249b;	 Catch:{ all -> 0x0014 }
        if (r0 == 0) goto L_0x0032;
    L_0x001d:
        if (r4 == 0) goto L_0x002d;
    L_0x001f:
        r0 = f247d;	 Catch:{ all -> 0x0014 }
        r0 = r0.f249b;	 Catch:{ all -> 0x0014 }
        r2 = "\\";
        r3 = "\\\\";
        r0 = r0.replace(r2, r3);	 Catch:{ all -> 0x0014 }
    L_0x002b:
        monitor-exit(r1);	 Catch:{ all -> 0x0014 }
        goto L_0x0006;
    L_0x002d:
        r0 = f247d;	 Catch:{ all -> 0x0014 }
        r0 = r0.f249b;	 Catch:{ all -> 0x0014 }
        goto L_0x002b;
    L_0x0032:
        monitor-exit(r1);	 Catch:{ all -> 0x0014 }
        r0 = "";
        goto L_0x0006;
        */
        throw new UnsupportedOperationException("Method not decompiled: ru.zdevs.zarchiver.archiver.g.a(boolean):java.lang.String");
    }

    /* renamed from: a */
    public static void m299a(String str, String str2, int i) {
        if (f247d != null) {
            synchronized (f247d) {
                f247d.f248a = str;
                f247d.f249b = str2;
                f247d.f250c = i;
            }
        }
    }

    /* renamed from: a */
    public static boolean m300a(String str) {
        boolean z = false;
        if (!(str == null || f247d == null)) {
            synchronized (f247d) {
                if (f247d.f248a == null) {
                } else if (!f247d.f248a.endsWith(str) || f247d.f249b == null || f247d.f249b.length() <= 0) {
                } else {
                    z = true;
                }
            }
        }
        return z;
    }

    /* renamed from: a */
    public static boolean m301a(String str, int i) {
        boolean z = false;
        if (!(str == null || f247d == null)) {
            synchronized (f247d) {
                if (f247d.f248a == null) {
                } else if (f247d.f248a.endsWith(str)) {
                    if (i == f247d.f250c) {
                        z = true;
                    }
                }
            }
        }
        return z;
    }

    /* renamed from: b */
    public static void m302b() {
        if (f247d != null) {
            synchronized (f247d) {
                f247d.f248a = null;
                f247d.f249b = null;
            }
        }
    }

    /* renamed from: a */
    public void m303a() {
        C0072g.m302b();
        f247d = null;
    }
}
