package ru.zdevs.zarchiver.archiver;

import android.os.AsyncTask;
import java.io.File;
import java.util.List;
import ru.zdevs.zarchiver.fs.ZViewFS.FSFileInfo;
import ru.zdevs.zarchiver.p003a.C0049e;

/* renamed from: ru.zdevs.zarchiver.archiver.f */
public interface C0059f {
    /* renamed from: a */
    List<C0066d> mo30a(String str, String str2, boolean z, Thread thread);

    /* renamed from: a */
    FSFileInfo mo31a(String str, AsyncTask<?, ?, ?> asyncTask);

    /* renamed from: a */
    FSFileInfo mo32a(List<String> list, AsyncTask<?, ?, ?> asyncTask);

    /* renamed from: a */
    void mo33a();

    /* renamed from: a */
    void mo34a(int i);

    /* renamed from: a */
    void mo35a(File file);

    /* renamed from: a */
    void mo36a(String str, int i, long j);

    /* renamed from: a */
    void mo37a(String str, long j, int i, int i2);

    /* renamed from: a */
    void mo38a(String str, List<C0049e> list, AsyncTask<?, ?, ?> asyncTask);

    /* renamed from: a */
    boolean mo39a(String str);

    /* renamed from: b */
    String mo40b();

    /* renamed from: b */
    void mo41b(String str);

    /* renamed from: c */
    void mo42c();

    /* renamed from: d */
    int mo43d();

    /* renamed from: e */
    int mo44e();

    /* renamed from: f */
    String mo45f();

    /* renamed from: g */
    boolean mo46g();

    /* renamed from: h */
    String mo47h();

    /* renamed from: i */
    float mo48i();
}
