package ru.zdevs.zarchiver.archiver;

import android.app.Activity;
import android.content.Context;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.widget.Toast;
import java.io.File;
import java.util.List;
import ru.zdevs.zarchiver.Actions;
import ru.zdevs.zarchiver.C0136e;
import ru.zdevs.zarchiver.R;
import ru.zdevs.zarchiver.ZArchiverExtInterface;
import ru.zdevs.zarchiver.dialog.ZDialog;
import ru.zdevs.zarchiver.dialog.ZDialog.OnCancelListener;
import ru.zdevs.zarchiver.dialog.ZDialog.OnOkListener;
import ru.zdevs.zarchiver.dialog.ZEnterPwdDialog;
import ru.zdevs.zarchiver.p004b.C0073a;
import ru.zdevs.zarchiver.p004b.C0075c;
import ru.zdevs.zarchiver.p004b.C0086l;
import ru.zdevs.zarchiver.settings.Settings;
import ru.zdevs.zarchiver.tool.C0166c;
import ru.zdevs.zarchiver.tool.C0200o;
import ru.zdevs.zarchiver.widget.bottomsheet.ViewDragHelper;

/* renamed from: ru.zdevs.zarchiver.archiver.e */
public class C0071e {
    /* renamed from: a */
    private static Context f245a;
    /* renamed from: b */
    private static C0136e f246b;

    /* renamed from: ru.zdevs.zarchiver.archiver.e$a */
    private static class C0070a implements Runnable {
        /* renamed from: a */
        private final Context f241a;
        /* renamed from: b */
        private final C0136e f242b;
        /* renamed from: c */
        private final Object f243c;
        /* renamed from: d */
        private final C0059f f244d = C0061a.m208b();

        /* renamed from: ru.zdevs.zarchiver.archiver.e$a$1 */
        class C00681 implements OnOkListener {
            /* renamed from: a */
            final /* synthetic */ C0070a f239a;

            C00681(C0070a c0070a) {
                this.f239a = c0070a;
            }

            public void onOk(ZDialog zDialog) {
                C0072g.m299a(this.f239a.f244d.mo40b(), ((ZEnterPwdDialog) zDialog).getPassword(), 1);
                synchronized (this.f239a.f243c) {
                    this.f239a.f243c.notifyAll();
                }
            }
        }

        /* renamed from: ru.zdevs.zarchiver.archiver.e$a$2 */
        class C00692 implements OnCancelListener {
            /* renamed from: a */
            final /* synthetic */ C0070a f240a;

            C00692(C0070a c0070a) {
                this.f240a = c0070a;
            }

            public void onCancel(ZDialog zDialog) {
                C0072g.m302b();
                if (this.f240a.f244d != null) {
                    this.f240a.f244d.mo34a(13);
                }
                C2JBridge.cSetStatus(0, 15);
                synchronized (this.f240a.f243c) {
                    this.f240a.f243c.notifyAll();
                }
            }
        }

        C0070a(C0136e c0136e, Context context, Object obj) {
            this.f242b = c0136e;
            this.f241a = context;
            this.f243c = obj;
        }

        public void run() {
            ZEnterPwdDialog zEnterPwdDialog = new ZEnterPwdDialog(this.f242b, this.f241a);
            zEnterPwdDialog.setTaskID(0);
            zEnterPwdDialog.setOnOkListener(new C00681(this));
            zEnterPwdDialog.setOnCancelListener(new C00692(this));
            zEnterPwdDialog.show();
        }
    }

    /* renamed from: a */
    public static int m285a() {
        long maxMemory = Settings.getMaxMemory();
        return maxMemory > ((long) ((C0071e.m287a(9, true) * 12) * 1024)) ? 9 : maxMemory > ((long) ((C0071e.m287a(7, true) * 12) * 1024)) ? 7 : 5;
    }

    /* renamed from: a */
    public static int m286a(int i) {
        long maxMemory = (Settings.getMaxMemory() - ((long) (C0071e.m287a(i, true) * 1024))) / 1024;
        int i2 = i <= 0 ? 0 : i <= 1 ? 16 : i <= 3 ? 128 : i <= 5 ? 2048 : 4096;
        if (maxMemory < ((long) i2)) {
            for (int i3 = 2; i3 <= 64; i3 *= 2) {
                int i4 = i2 / i3;
                if (maxMemory > ((long) i4)) {
                    maxMemory = (long) i4;
                    break;
                }
            }
        } else {
            maxMemory = (long) i2;
        }
        return (int) maxMemory;
    }

    /* renamed from: a */
    public static int m287a(int i, boolean z) {
        int i2 = 16;
        int i3 = 0;
        if (i < 5) {
            return z ? 1 : 0;
        } else {
            long maxMemory = Settings.getMaxMemory() / 1024;
            if (i >= 9) {
                if (maxMemory < 200) {
                    i2 = 10;
                } else if (maxMemory >= 384) {
                    if (maxMemory < 512) {
                        i2 = 28;
                    } else if (maxMemory < 768) {
                        i2 = 32;
                    } else {
                        if (z) {
                            i3 = 64;
                        }
                        i2 = i3;
                    }
                }
            } else if (i >= 7) {
                if (maxMemory < 200) {
                    i2 = 8;
                } else if (maxMemory < 384) {
                    i2 = 10;
                } else if (maxMemory >= 512) {
                    if (maxMemory < 768) {
                        i2 = 24;
                    } else {
                        if (z) {
                            i3 = 32;
                        }
                        i2 = i3;
                    }
                }
            } else if (maxMemory < 200) {
                i2 = 5;
            } else if (maxMemory < 384) {
                i2 = 8;
            } else if (maxMemory < 512) {
                i2 = 10;
            } else if (maxMemory >= 768) {
                if (z) {
                    i3 = 16;
                }
                i2 = i3;
            }
            return i2;
        }
    }

    /* renamed from: a */
    public static String m288a(Context context, int i) {
        switch (i) {
            case 1:
                return context.getString(R.string.ERROR_UNKNOWN_FORMAT);
            case 2:
                return context.getString(R.string.ERROR_WRONG_PASSWORD);
            case 3:
                return context.getString(R.string.ERROR_IS_NOT_ARCHIVE);
            case 4:
                return context.getString(R.string.ERROR_OUT_OF_MEMORY);
            case 5:
                return context.getString(R.string.ERROR_CRC_ERROR);
            case Actions.CHECK_ACTION_RENAME /*6*/:
                return context.getString(R.string.ERROR_DATA_ERROR);
            case ZArchiverExtInterface.COMPRESSION_LAVEL_MAX /*7*/:
                return context.getString(R.string.ERROR_UNSUPORTED_METOD);
            case ViewDragHelper.EDGE_BOTTOM /*8*/:
                return context.getString(R.string.MES_DONT_SUPPORT_EDIT);
            default:
                return null;
        }
    }

    /* renamed from: a */
    public static String m289a(List<String> list) {
        StringBuilder stringBuilder = new StringBuilder();
        for (String append : list) {
            stringBuilder.append('\\').append(append);
        }
        return stringBuilder.toString();
    }

    /* renamed from: a */
    public static String m290a(String[] strArr) {
        StringBuilder stringBuilder = new StringBuilder();
        for (String append : strArr) {
            stringBuilder.append('\\').append(append);
        }
        return stringBuilder.toString();
    }

    /* renamed from: a */
    public static void m291a(C0136e c0136e, Context context, String str) {
        synchronized (c0136e) {
            C0071e.m293b(c0136e, context, str);
        }
    }

    /* renamed from: b */
    public static int m292b() {
        return C0071e.m286a(Integer.parseInt(Settings.sLevel7z));
    }

    /* renamed from: b */
    private static void m293b(C0136e c0136e, final Context context, String str) {
        f246b = c0136e;
        f245a = context;
        PowerManager powerManager = (PowerManager) context.getSystemService("power");
        File file = new File(str);
        boolean z = true;
        while (z) {
            WakeLock wakeLock;
            boolean z2;
            String str2 = "";
            if (C0072g.m300a(str)) {
                str2 = str2 + "\\-p" + C0072g.m297a(str, true);
            }
            boolean z3 = !(file.exists() && file.canRead()) && !str.startsWith("/SAF") && !str.startsWith("/uri/") && Settings.sRoot && C0073a.m304f() && C0200o.m710a(file) == (byte) 2;
            C0059f b = C0061a.m209b(!z3);
            C2JBridge.f198c = b;
            C2JBridge.f198c.mo35a(file);
            if (powerManager != null) {
                WakeLock newWakeLock = powerManager.newWakeLock(1, "ZArchiverList");
                newWakeLock.acquire();
                wakeLock = newWakeLock;
            } else {
                wakeLock = null;
            }
            if (z3) {
                C0073a c0075c = new C0075c();
                c0075c.m308a(0);
                if (c0075c.mo52b()) {
                    if (!C0086l.m350a(c0075c, str, str2, (Settings.s7zOptions & 4) != 0) && b.mo44e() <= 0 && b.mo43d() == 0) {
                        b.mo34a(3);
                    }
                } else {
                    b.mo34a(200);
                }
                c0075c.mo54c();
            } else {
                C2JBridge.cSetOption(1, Settings.sOEMCP);
                C2JBridge.cSetOption(4, Settings.s7zOptions & 4);
                if (!C2JBridge.cList(0, str, str2) && b.mo44e() <= 0 && b.mo43d() == 0) {
                    b.mo34a(3);
                }
            }
            if (wakeLock != null) {
                wakeLock.release();
            }
            if (C2JBridge.f198c != null) {
                C2JBridge.f198c.mo42c();
            } else {
                b.mo33a();
            }
            C2JBridge.f198c = null;
            if (b.mo43d() != 2) {
                z2 = false;
            } else if (context instanceof Activity) {
                ((Activity) context).runOnUiThread(new Runnable() {
                    public void run() {
                        Toast.makeText(context, context.getString(R.string.ERROR_WRONG_PASSWORD), 0).show();
                    }
                });
                z2 = z;
            } else {
                z2 = z;
            }
            z = z2;
        }
        f246b = null;
        f245a = null;
    }

    /* renamed from: c */
    public static int m294c() {
        return C0071e.m287a(Integer.parseInt(Settings.sLevel7z), false);
    }

    /* renamed from: d */
    public static String m295d() {
        if (f245a == null) {
            C2JBridge.cSetStatus(0, 15);
            return "";
        }
        C0072g.m302b();
        Object obj = new Object();
        if (f245a instanceof Activity) {
            ((Activity) f245a).runOnUiThread(new C0070a(f246b, f245a, obj));
        }
        synchronized (obj) {
            try {
                obj.wait();
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
        }
        try {
            ZDialog a = f246b.m398a(0, 2);
            if (a != null) {
                a.close();
            }
        } catch (Throwable e2) {
            C0166c.m556a(e2);
        }
        return C0072g.m298a(false);
    }

    /* renamed from: e */
    public static void m296e() {
        if (C2JBridge.f198c != null) {
            C2JBridge.f198c = null;
            C2JBridge.cSetStatus(0, 15);
        }
    }
}
