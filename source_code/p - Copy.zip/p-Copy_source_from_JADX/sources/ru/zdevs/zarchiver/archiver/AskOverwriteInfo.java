package ru.zdevs.zarchiver.archiver;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class AskOverwriteInfo implements Parcelable {
    public static final Creator<AskOverwriteInfo> CREATOR = new C00601();
    /* renamed from: a */
    public String f190a;
    /* renamed from: b */
    public long f191b;
    /* renamed from: c */
    public int f192c;
    /* renamed from: d */
    public String f193d;
    /* renamed from: e */
    public long f194e;
    /* renamed from: f */
    public int f195f;

    /* renamed from: ru.zdevs.zarchiver.archiver.AskOverwriteInfo$1 */
    static class C00601 implements Creator<AskOverwriteInfo> {
        C00601() {
        }

        /* renamed from: a */
        public AskOverwriteInfo m193a(Parcel parcel) {
            return new AskOverwriteInfo(parcel);
        }

        /* renamed from: a */
        public AskOverwriteInfo[] m194a(int i) {
            return new AskOverwriteInfo[i];
        }

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return m193a(parcel);
        }

        public /* synthetic */ Object[] newArray(int i) {
            return m194a(i);
        }
    }

    public AskOverwriteInfo(Parcel parcel) {
        this.f190a = parcel.readString();
        this.f191b = parcel.readLong();
        this.f192c = parcel.readInt();
        this.f193d = parcel.readString();
        this.f194e = parcel.readLong();
        this.f195f = parcel.readInt();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.f190a);
        parcel.writeLong(this.f191b);
        parcel.writeInt(this.f192c);
        parcel.writeString(this.f193d);
        parcel.writeLong(this.f194e);
        parcel.writeInt(this.f195f);
    }
}
