package ru.zdevs.zarchiver.archiver;

import android.os.AsyncTask;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import ru.zdevs.zarchiver.fs.ZViewFS.FSFileInfo;
import ru.zdevs.zarchiver.p003a.C0049e;
import ru.zdevs.zarchiver.tool.C0166c;

/* renamed from: ru.zdevs.zarchiver.archiver.c */
public class C0065c implements C0059f {
    /* renamed from: a */
    private String f224a;
    /* renamed from: b */
    private long f225b;
    /* renamed from: c */
    private List<C0066d> f226c = new ArrayList();
    /* renamed from: d */
    private long f227d;
    /* renamed from: e */
    private String f228e;
    /* renamed from: f */
    private String f229f;
    /* renamed from: g */
    private int f230g;

    /* renamed from: ru.zdevs.zarchiver.archiver.c$a */
    private class C0064a implements Comparator<C0066d> {
        /* renamed from: a */
        final /* synthetic */ C0065c f223a;

        private C0064a(C0065c c0065c) {
            this.f223a = c0065c;
        }

        /* renamed from: a */
        public int m250a(C0066d c0066d, C0066d c0066d2) {
            if (c0066d.m275b() != null) {
                return c0066d.m275b().compareTo(c0066d2.m275b());
            }
            throw new IllegalArgumentException();
        }

        public /* synthetic */ int compare(Object obj, Object obj2) {
            return m250a((C0066d) obj, (C0066d) obj2);
        }
    }

    public C0065c() {
        mo33a();
    }

    /* renamed from: a */
    public List<C0066d> mo30a(String str, String str2, boolean z, Thread thread) {
        Throwable e;
        List<C0066d> arrayList = new ArrayList();
        for (C0066d c0066d : this.f226c) {
            if ((z || !c0066d.m280g()) && c0066d.m275b().startsWith(str)) {
                String substring;
                String b = c0066d.m275b();
                try {
                    int lastIndexOf = b.lastIndexOf(47);
                    substring = lastIndexOf > 0 ? b.substring(lastIndexOf) : b;
                    try {
                        b = substring.toLowerCase(Locale.getDefault());
                    } catch (Exception e2) {
                        e = e2;
                        C0166c.m556a(e);
                        if (b.matches(str2)) {
                            arrayList.add(new C0066d(substring, c0066d.m275b(), c0066d.m278e(), c0066d.m277d(), c0066d.m281h()));
                        }
                        return arrayList;
                    }
                } catch (Throwable e3) {
                    e = e3;
                    substring = b;
                    C0166c.m556a(e);
                    if (b.matches(str2)) {
                        arrayList.add(new C0066d(substring, c0066d.m275b(), c0066d.m278e(), c0066d.m277d(), c0066d.m281h()));
                    }
                    return arrayList;
                }
                if (b.matches(str2)) {
                    arrayList.add(new C0066d(substring, c0066d.m275b(), c0066d.m278e(), c0066d.m277d(), c0066d.m281h()));
                }
                if (thread != null && thread.isInterrupted()) {
                    break;
                }
            }
        }
        return arrayList;
    }

    /* renamed from: a */
    public FSFileInfo mo31a(String str, AsyncTask<?, ?, ?> asyncTask) {
        C0066d c0066d;
        FSFileInfo fSFileInfo = new FSFileInfo();
        int i = -1;
        int i2 = -1;
        if (str.equals("/")) {
            fSFileInfo.mSize = this.f225b;
            fSFileInfo.mIsFile = false;
        }
        Object obj = null;
        try {
            int size = this.f226c.size();
            int i3 = 0;
            while (i3 < size) {
                if (asyncTask != null && asyncTask.isCancelled()) {
                    return null;
                }
                Object obj2;
                int i4;
                c0066d = (C0066d) this.f226c.get(i3);
                if ((c0066d.m275b() + '/').startsWith(str + '/')) {
                    fSFileInfo.mSize += c0066d.m278e();
                    i2 = i2 == -1 ? i3 : i2;
                    obj2 = 1;
                    i4 = i3;
                } else if (obj != null) {
                    break;
                } else {
                    obj2 = obj;
                    i4 = i;
                }
                i3++;
                i = i4;
                obj = obj2;
            }
        } catch (Throwable e) {
            C0166c.m556a(e);
        }
        if (i2 == -1) {
            return null;
        }
        if (i == i2) {
            c0066d = (C0066d) this.f226c.get(i);
            fSFileInfo.mIsFile = !c0066d.m280g();
            fSFileInfo.mSize = c0066d.m278e();
            fSFileInfo.mLastMod = (long) c0066d.m277d();
            fSFileInfo.mIsLink = (c0066d.m281h() & 4) != 0;
            return fSFileInfo;
        }
        c0066d = (C0066d) this.f226c.get(i2);
        if (c0066d.m275b().compareTo(str) == 0 && c0066d.m280g()) {
            fSFileInfo.mIsFile = false;
            fSFileInfo.mLastMod = (long) c0066d.m277d();
            fSFileInfo.mIsLink = (c0066d.m281h() & 4) != 0;
        } else {
            fSFileInfo.mIsFile = false;
        }
        return fSFileInfo;
    }

    /* renamed from: a */
    public FSFileInfo mo32a(List<String> list, AsyncTask<?, ?, ?> asyncTask) {
        FSFileInfo fSFileInfo = new FSFileInfo();
        for (String str : list) {
            Object obj = null;
            for (C0066d c0066d : this.f226c) {
                if (asyncTask != null && asyncTask.isCancelled()) {
                    return null;
                }
                Object obj2;
                if (!(c0066d.m275b() + '/').startsWith(str + '/')) {
                    if (obj != null) {
                        break;
                    }
                    obj2 = obj;
                } else {
                    fSFileInfo.mSize += c0066d.m278e();
                    obj2 = 1;
                }
                obj = obj2;
            }
        }
        return fSFileInfo;
    }

    /* renamed from: a */
    public void mo33a() {
        this.f224a = "";
        this.f225b = 0;
        this.f226c.clear();
        this.f227d = 0;
        this.f228e = "";
        this.f229f = null;
        this.f230g = 0;
    }

    /* renamed from: a */
    public void mo34a(int i) {
        this.f230g = i;
    }

    /* renamed from: a */
    public void mo35a(File file) {
        mo33a();
        this.f224a = file.getAbsolutePath();
        this.f225b = file.length();
        C0166c.m557b("ArchiveContentStoreOld", "Start list: " + this.f224a);
    }

    /* renamed from: a */
    public void mo36a(String str, int i, long j) {
        this.f229f = str;
    }

    /* renamed from: a */
    public void mo37a(String str, long j, int i, int i2) {
        this.f226c.add(new C0066d(null, !str.startsWith("/") ? '/' + str : str, j, i, i2));
        if ((i2 & 1) == 0) {
            this.f227d += j;
        }
    }

    /* renamed from: a */
    public void mo38a(String str, List<C0049e> list, AsyncTask<?, ?, ?> asyncTask) {
        if (!str.endsWith("/")) {
            str = str + '/';
        }
        int length = str.length();
        Object obj = null;
        for (C0066d c0066d : this.f226c) {
            if (asyncTask == null || !asyncTask.isCancelled()) {
                Object obj2;
                if (c0066d.m275b().startsWith(str)) {
                    int indexOf;
                    try {
                        Object obj3;
                        int i;
                        indexOf = c0066d.m275b().indexOf(47, length);
                        if (indexOf < 0) {
                            indexOf = c0066d.m275b().length();
                            obj3 = null;
                        } else {
                            i = 1;
                        }
                        if (indexOf < length) {
                            obj = 1;
                        } else {
                            String substring = c0066d.m275b().substring(length, indexOf);
                            for (C0049e c0049e : list) {
                                if (c0049e.mo28e().equals(substring)) {
                                    boolean z = c0066d.m280g() || obj3 != null;
                                    if (z == c0049e.m107b()) {
                                        obj2 = null;
                                        break;
                                    }
                                }
                            }
                            indexOf = 1;
                            if (obj2 != null) {
                                i = c0066d.m281h() | (obj3 != null ? 1 : 0);
                                list.add(new C0049e(substring, (i & 1) != 0 ? (byte) 2 : (byte) 0, (i & 2) != 0 ? (byte) 30 : (byte) 0, (long) c0066d.m277d(), c0066d.m278e()));
                            }
                            obj2 = 1;
                        }
                    } catch (Throwable e) {
                        C0166c.m556a(e);
                        indexOf = 1;
                    }
                } else if (obj == null) {
                    obj2 = obj;
                } else {
                    return;
                }
                obj = obj2;
            } else {
                return;
            }
        }
    }

    /* renamed from: a */
    public boolean mo39a(String str) {
        if (this.f224a == null || str == null) {
            return false;
        }
        C0166c.m557b("ArchiveContentStoreOld", "Compare: " + this.f224a + " and " + str);
        return this.f224a.endsWith(str);
    }

    /* renamed from: b */
    public String mo40b() {
        return this.f224a;
    }

    /* renamed from: b */
    public void mo41b(String str) {
        this.f228e = str;
    }

    /* renamed from: c */
    public void mo42c() {
        Collections.sort(this.f226c, new C0064a());
        C0166c.m557b("ArchiveContentStoreOld", "Stop list: " + this.f224a);
    }

    /* renamed from: d */
    public int mo43d() {
        return this.f230g;
    }

    /* renamed from: e */
    public int mo44e() {
        return this.f226c == null ? 0 : this.f226c.size();
    }

    /* renamed from: f */
    public String mo45f() {
        return this.f228e == null ? "" : this.f228e;
    }

    /* renamed from: g */
    public boolean mo46g() {
        return this.f228e != null && this.f228e.length() > 0;
    }

    /* renamed from: h */
    public String mo47h() {
        return this.f229f;
    }

    /* renamed from: i */
    public float mo48i() {
        return (this.f224a == null || this.f224a.length() <= 0) ? -1.0f : this.f227d == 0 ? 1.0f : ((float) this.f225b) / ((float) this.f227d);
    }
}
