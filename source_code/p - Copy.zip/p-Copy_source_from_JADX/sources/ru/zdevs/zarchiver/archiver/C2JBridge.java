package ru.zdevs.zarchiver.archiver;

import android.content.pm.PackageManager;
import android.util.Log;
import java.util.ArrayList;
import java.util.List;
import ru.zdevs.zarchiver.ZArchiver;
import ru.zdevs.zarchiver.dialog.ZFileInfoDialog;
import ru.zdevs.zarchiver.p004b.C0073a;
import ru.zdevs.zarchiver.p004b.C0090p;
import ru.zdevs.zarchiver.service.C0160c;
import ru.zdevs.zarchiver.service.C0161d;
import ru.zdevs.zarchiver.service.ZArchiverService;
import ru.zdevs.zarchiver.tool.C0166c;
import ru.zdevs.zarchiver.tool.C0178g;
import ru.zdevs.zarchiver.tool.C0179h;

public class C2JBridge {
    /* renamed from: a */
    public static boolean f196a = true;
    /* renamed from: b */
    public static boolean f197b;
    /* renamed from: c */
    public static C0059f f198c = null;
    /* renamed from: d */
    public static String[] f199d = new String[5];
    /* renamed from: e */
    public static int[] f200e = new int[5];
    /* renamed from: f */
    public static AskOverwriteInfo[] f201f = new AskOverwriteInfo[5];
    /* renamed from: g */
    public static String[] f202g = new String[5];
    /* renamed from: h */
    public static C0073a f203h;
    /* renamed from: i */
    private static ZArchiverService f204i = null;
    /* renamed from: j */
    private static String[] f205j = new String[5];
    /* renamed from: k */
    private static int[] f206k = new int[5];
    /* renamed from: l */
    private static Object[] f207l = new Object[5];
    /* renamed from: m */
    private static Object[] f208m = new Object[5];
    /* renamed from: n */
    private static List<C0179h> f209n;

    static {
        f197b = false;
        try {
            System.loadLibrary("handler");
            System.loadLibrary("mime");
            System.loadLibrary("p7zip");
            System.loadLibrary("unarc");
            System.loadLibrary("control");
            f197b = true;
        } catch (Error e) {
            C0166c.m554a(e);
            f197b = false;
        }
    }

    /* renamed from: a */
    public static void m195a(int i) {
        f205j[i] = "";
        f199d[i] = "";
        f200e[i] = 0;
        f206k[i] = 0;
        f202g[i] = "";
    }

    /* renamed from: a */
    public static void m196a(int i, int i2) {
        if (f207l[i] != null) {
            try {
                f206k[i] = i2;
                synchronized (f207l[i]) {
                    f207l[i].notifyAll();
                }
            } catch (Exception e) {
                Log.e("C2JBridge", "Error on set overwrite");
            }
        }
    }

    /* renamed from: a */
    public static void m197a(int i, String str) {
        if (f208m[i] != null) {
            try {
                f205j[i] = str;
                synchronized (f208m[i]) {
                    f208m[i].notifyAll();
                }
            } catch (Exception e) {
                Log.e("SetPassword", "Error on set pass");
            }
        }
    }

    /* renamed from: a */
    public static void m198a(ZArchiverService zArchiverService) {
        f204i = zArchiverService;
    }

    /* renamed from: a */
    public static boolean m199a(ZArchiver zArchiver) {
        if (f197b) {
            load(zArchiver.getPackageManager(), zArchiver);
        }
        return f197b;
    }

    /* renamed from: b */
    public static void m200b(int i) {
        if (f208m[i] != null) {
            m197a(i, "");
        }
        if (f207l[i] != null) {
            m196a(i, 18);
        }
    }

    public static native boolean cAddFiles(int i, String str, String str2, String str3, String str4);

    public static native boolean cCompres(int i, String str, String str2, String str3, String str4);

    public static native boolean cDelFiles(int i, String str, String str2, String str3, String str4);

    public static native boolean cExtract(int i, String str, String str2, String str3, String str4, int i2);

    public static native boolean cList(int i, String str, String str2);

    public static native boolean cRename(int i, String str, String str2, String str3, String str4);

    public static native void cSetOption(int i, int i2);

    public static native void cSetStatus(int i, int i2);

    public static native boolean cTest(int i, String str, String str2);

    public static int jAddFileToList(int i, String str, long j, int i2, int i3) {
        if (i >= 5 || f198c == null) {
            return -1;
        }
        synchronized (f198c) {
            f198c.mo37a(str, j, i2, i3);
        }
        return 0;
    }

    public static int jAllocLargePage(int i) {
        C0166c.m557b("C2JBridge", "jAllocLargePage " + i);
        if (f209n == null) {
            f209n = new ArrayList();
        }
        C0179h a = C0179h.m622a(i);
        if (a == null) {
            return 0;
        }
        synchronized (f209n) {
            f209n.add(a);
        }
        return a.m623a();
    }

    public static void jArchiveInfo(int i, String str, int i2, long j, int i3) {
        if (i >= 5) {
            ZFileInfoDialog.setArchiveInfo(str, i2, j, i3);
        } else if (f198c != null) {
            f198c.mo36a(str, i2, j);
        }
    }

    public static int jAskOverwrite(int i, String str, long j, int i2, String str2, long j2, int i3) {
        if (i >= 5) {
            C0178g.m599a(str);
            return 18;
        } else if (!f196a) {
            f206k[i] = 17;
            return 17;
        } else if (f204i == null) {
            return 18;
        } else {
            if (C0161d.f454b[i] == (byte) 5 || C0161d.f455c[i] != 0) {
                f206k[i] = 1;
                return 1;
            }
            f201f[i] = new AskOverwriteInfo();
            f201f[i].f190a = str;
            f201f[i].f191b = j;
            f201f[i].f192c = i2;
            f201f[i].f193d = str2;
            f201f[i].f194e = j2;
            f201f[i].f195f = i3;
            if (f207l[i] == null) {
                f207l[i] = new Object();
            }
            f204i.m462c(i, 2);
            try {
                synchronized (f207l[i]) {
                    f207l[i].wait();
                }
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
            f204i.m464d(i, 2);
            return f206k[i];
        }
    }

    public static void jFileExtracted(int i, String str) {
        if (i >= 5) {
            C0178g.m599a(str);
        } else if (f204i != null && C0161d.f454b[i] == (byte) 5 && str != null && str.length() > 0) {
            int lastIndexOf = str.lastIndexOf("/");
            if (lastIndexOf < 0 || lastIndexOf + 1 >= str.length()) {
                C0161d.f456d[i] = str;
            } else {
                C0161d.f456d[i] = str.substring(lastIndexOf + 1);
            }
        }
    }

    public static void jFileUTime(String str, int i) {
        if (f203h != null && C0160c.f450b) {
            try {
                synchronized (f203h) {
                    C0090p.m356a(f203h, str, 1000 * ((long) i));
                }
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
        }
    }

    public static void jFreeLargePage(int i) {
        C0166c.m557b("C2JBridge", "jFreeLargePage " + i);
        if (f209n == null) {
            f209n = new ArrayList();
        }
        synchronized (f209n) {
            for (C0179h c0179h : f209n) {
                if (c0179h.m623a() == i) {
                    c0179h.m624b();
                    f209n.remove(c0179h);
                    break;
                }
            }
        }
    }

    public static String jGetPassword(int i) {
        C0166c.m557b("C2JBridge", "jGetPassword");
        if (i >= 5) {
            return C0072g.m298a(false);
        }
        if (f198c != null) {
            return C0072g.m300a(f198c.mo40b()) ? C0072g.m298a(false) : C0071e.m295d();
        } else {
            if (f208m[i] == null) {
                f208m[i] = new Object();
            }
            if (f204i != null) {
                f204i.m462c(i, 1);
            }
            try {
                synchronized (f208m[i]) {
                    f208m[i].wait();
                }
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
            if (f204i != null) {
                f204i.m464d(i, 1);
            }
            return f205j[i];
        }
    }

    public static void jSetComment(int i, String str) {
        if (i < 5) {
            if (f198c != null) {
                f198c.mo41b(str);
            }
            if (f204i != null) {
                f204i.m463c(i, str);
            }
            C0166c.m558c("C2JBridge", "Set comment: " + str);
        }
    }

    public static void jSetProcessPercent(int i, int i2) {
        C0166c.m557b("C2JBridge", "jSetProcessPercent: " + i2);
        if (i >= 5) {
            C0178g.m605b(i2);
            return;
        }
        f200e[i] = i2;
        if (f204i != null) {
            f204i.m458b(i, i2);
        }
    }

    public static void jSetProcessText(int i, String str) {
        if (i < 5) {
            f199d[i] = str;
            if (f204i != null) {
                f204i.m455a(i, str);
            }
        }
    }

    public static void jSetTaskCompleted(int i, boolean z) {
        if (i >= 5) {
            C0178g.m609e();
            return;
        }
        if (!(f204i == null || (C0161d.f454b[i] & -128) == -128)) {
            ZArchiverService zArchiverService = f204i;
            boolean z2 = (C0161d.f453a[i] & 15) == 15 || (f206k[i] & 8) == 8;
            zArchiverService.m461b(i, z, z2);
            C0161d.m542a(f204i, i, z ? 1179648 : 1114112);
        }
        C0166c.m558c("C2JBridge", "jSetTaskCompleted " + (z ? "true" : "false"));
        if (f207l[i] != null) {
            f207l[i] = null;
        }
        if (f208m[i] != null) {
            f208m[i] = null;
        }
    }

    public static void jShowMessage(int i, int i2, String str, boolean z) {
        if (i < 5) {
            if (i2 == 2) {
                C0072g.m302b();
                if (f198c != null) {
                    f198c.mo34a(2);
                }
            }
            if (f204i != null) {
                f204i.m459b(i, i2, str);
            }
        }
    }

    public static native void load(PackageManager packageManager, ZArchiver zArchiver);
}
