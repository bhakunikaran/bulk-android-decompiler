package ru.zdevs.zarchiver.archiver;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import ru.zdevs.zarchiver.fs.ZViewFS.FSFileInfo;

/* renamed from: ru.zdevs.zarchiver.archiver.d */
public class C0066d {
    /* renamed from: a */
    private String f231a;
    /* renamed from: b */
    private String f232b;
    /* renamed from: c */
    private long f233c;
    /* renamed from: d */
    private int f234d;
    /* renamed from: e */
    private int f235e;
    /* renamed from: f */
    private List<C0066d> f236f;
    /* renamed from: g */
    private C0066d f237g;

    public C0066d(String str, long j, int i, int i2) {
        this.f231a = str;
        this.f232b = null;
        this.f233c = j;
        this.f234d = i;
        this.f235e = i2;
        if (m280g()) {
            this.f236f = new ArrayList();
        } else {
            this.f236f = null;
        }
        this.f237g = null;
    }

    public C0066d(String str, String str2, long j, int i, int i2) {
        this(str, j, i, i2);
        this.f232b = str2;
    }

    /* renamed from: a */
    public C0066d m270a(String str) {
        if (this.f236f == null) {
            return null;
        }
        for (C0066d c0066d : this.f236f) {
            if (c0066d.f231a.equals(str)) {
                return c0066d;
            }
        }
        return null;
    }

    /* renamed from: a */
    public FSFileInfo m271a() {
        FSFileInfo fSFileInfo = new FSFileInfo();
        fSFileInfo.mIsFile = !m280g();
        fSFileInfo.mLastMod = 1000 * ((long) this.f234d);
        fSFileInfo.mSize = this.f233c;
        return fSFileInfo;
    }

    /* renamed from: a */
    protected void m272a(int i) {
        this.f234d = i;
    }

    /* renamed from: a */
    protected void m273a(long j) {
        this.f233c = j;
    }

    /* renamed from: a */
    protected boolean m274a(C0066d c0066d) {
        if (this.f236f == null) {
            return false;
        }
        c0066d.f237g = this;
        return this.f236f.add(c0066d);
    }

    /* renamed from: b */
    public String m275b() {
        if (this.f232b != null) {
            return this.f232b;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append('/');
        stringBuilder.append(this.f231a);
        for (C0066d c0066d = this.f237g; c0066d.f237g != null; c0066d = c0066d.f237g) {
            stringBuilder.insert(0, c0066d.f231a);
            stringBuilder.insert(0, '/');
        }
        return stringBuilder.toString();
    }

    /* renamed from: c */
    public String m276c() {
        return this.f231a;
    }

    /* renamed from: d */
    public int m277d() {
        return this.f234d;
    }

    /* renamed from: e */
    public long m278e() {
        return this.f233c;
    }

    /* renamed from: f */
    public boolean m279f() {
        return (this.f235e & 2) != 0;
    }

    /* renamed from: g */
    public boolean m280g() {
        return (this.f235e & 1) != 0;
    }

    /* renamed from: h */
    public int m281h() {
        return this.f235e;
    }

    /* renamed from: i */
    protected Collection<C0066d> m282i() {
        return this.f236f;
    }
}
