package ru.zdevs.zarchiver;

import android.content.Context;
import android.content.res.Resources;
import android.os.Build.VERSION;
import android.view.ContextThemeWrapper;
import java.util.List;
import ru.zdevs.zarchiver.p003a.C0056l;
import ru.zdevs.zarchiver.settings.Settings;
import ru.zdevs.zarchiver.tool.C0202q;
import ru.zdevs.zarchiver.widget.bottomsheet.ViewDragHelper;

/* renamed from: ru.zdevs.zarchiver.d */
public class C0093d {
    /* renamed from: a */
    private Context f286a = null;

    public C0093d(Context context) {
        this.f286a = context;
        if (VERSION.SDK_INT <= 19) {
            if (Settings.sActionbarColor != 0) {
                if (Settings.sTheme == (byte) 0) {
                    this.f286a = new ContextThemeWrapper(this.f286a, R.style.AppTheme.Dark.Material.Color);
                } else {
                    this.f286a = new ContextThemeWrapper(this.f286a, R.style.AppTheme.Light.Material.Color);
                }
            } else if (Settings.sTheme == (byte) 2) {
                this.f286a = new ContextThemeWrapper(this.f286a, R.style.AppTheme.Light);
            }
        } else if (Settings.sTheme == (byte) 2) {
            this.f286a = new ContextThemeWrapper(this.f286a, R.style.AppTheme.Light);
        } else if (Settings.sTheme == (byte) 0 && C0058a.m149c()) {
            this.f286a = new ContextThemeWrapper(this.f286a, R.style.AppTheme.Dark);
        }
    }

    /* renamed from: a */
    public void m374a(List<C0056l> list, int i) {
        m375a(list, i, "");
    }

    /* renamed from: a */
    public void m375a(List<C0056l> list, int i, String str) {
        Resources resources = this.f286a.getResources();
        switch (i) {
            case 1:
                list.add(new C0056l(i, resources.getString(R.string.MENU_VIEW), C0202q.m725a(this.f286a, (int) R.attr.menuIconView)));
                return;
            case 2:
                list.add(new C0056l(i, resources.getString(R.string.MENU_OPEN), C0202q.m725a(this.f286a, (int) R.attr.menuIconOpen), !Settings.sOpenFile));
                return;
            case 4:
                list.add(new C0056l(i, resources.getString(R.string.MENU_EXTRACT_TO), C0202q.m725a(this.f286a, (int) R.attr.menuIconExtract)));
                return;
            case 5:
                list.add(new C0056l(i, resources.getString(R.string.MENU_EXTRACT_TO_CURRENT_DIR), C0202q.m725a(this.f286a, (int) R.attr.menuIconExtract)));
                return;
            case Actions.CHECK_ACTION_RENAME /*6*/:
                list.add(new C0056l(i, resources.getString(R.string.MENU_EXTRACT_TO_DIR) + " " + str, str, C0202q.m725a(this.f286a, (int) R.attr.menuIconExtract)));
                return;
            case ZArchiverExtInterface.COMPRESSION_LAVEL_MAX /*7*/:
                list.add(new C0056l(i, resources.getString(R.string.MENU_COMPRESS_TO), C0202q.m725a(this.f286a, (int) R.attr.menuIconCompress)));
                return;
            case ViewDragHelper.EDGE_BOTTOM /*8*/:
            case 9:
                list.add(new C0056l(i, resources.getString(R.string.MENU_COMPRESS_AS) + " " + str, str, C0202q.m725a(this.f286a, (int) R.attr.menuIconCompress)));
                return;
            case 10:
                list.add(new C0056l(i, resources.getString(R.string.MENU_TEST), C0202q.m725a(this.f286a, (int) R.attr.menuIconTest)));
                return;
            case 14:
                list.add(new C0056l(i, resources.getString(R.string.MENU_ALL_SELECT), C0202q.m725a(this.f286a, (int) R.attr.menuIconSelectAll_menu)));
                return;
            case ViewDragHelper.EDGE_ALL /*15*/:
                list.add(new C0056l(i, resources.getString(R.string.MENU_CLEAR_SELECT), C0202q.m725a(this.f286a, (int) R.attr.menuIconSelectClear_menu)));
                return;
            case 16:
                list.add(new C0056l(i, resources.getString(R.string.MENU_INVERT_SELECT), C0202q.m725a(this.f286a, (int) R.attr.menuIconSelectInvert_menu)));
                return;
            case 18:
                list.add(new C0056l(i, resources.getString(R.string.MENU_OPEN_AS_ARC), C0202q.m725a(this.f286a, (int) R.attr.menuIconView), Settings.sOpenFile));
                return;
            case 20:
                list.add(new C0056l(i, resources.getString(R.string.MENU_SHARE), C0202q.m725a(this.f286a, (int) R.attr.menuIconSend)));
                return;
            case 22:
                list.add(new C0056l(i, resources.getString(R.string.MENU_INFO), C0202q.m725a(this.f286a, (int) R.attr.menuIconInfo)));
                return;
            case 23:
            case 56:
                list.add(new C0056l(i, resources.getString(R.string.MENU_DELETE), C0202q.m725a(this.f286a, (int) R.attr.menuIconDelete)));
                return;
            case 24:
                list.add(new C0056l(i, resources.getString(R.string.MENU_COPY), C0202q.m725a(this.f286a, (int) R.attr.menuIconCopy)));
                return;
            case 25:
                list.add(new C0056l(i, resources.getString(R.string.MENU_CUT), C0202q.m725a(this.f286a, (int) R.attr.menuIconCut)));
                return;
            case 26:
                list.add(new C0056l(i, resources.getString(R.string.MENU_PAST), C0202q.m725a(this.f286a, (int) R.attr.menuIconPast)));
                return;
            case 27:
            case 57:
                list.add(new C0056l(i, resources.getString(R.string.MENU_RENAME), C0202q.m725a(this.f286a, (int) R.attr.menuIconRename)));
                return;
            case 70:
                list.add(new C0056l(i, resources.getString(R.string.MENU_FAVORITE_ADD), C0202q.m725a(this.f286a, (int) R.attr.menuIconAddToFavorite)));
                return;
            case 71:
                list.add(new C0056l(i, resources.getString(R.string.MENU_FAVORITE_DEL), C0202q.m725a(this.f286a, (int) R.attr.menuIconDelete)));
                return;
            case 72:
                list.add(new C0056l(i, resources.getString(R.string.MENU_RENAME), C0202q.m725a(this.f286a, (int) R.attr.menuIconRename)));
                return;
            case 90:
                list.add(new C0056l(i, resources.getString(R.string.MENU_SETTINGS), C0202q.m725a(this.f286a, (int) R.attr.menuIconSettings)));
                return;
            case 91:
                list.add(new C0056l(i, resources.getString(R.string.MENU_MULTISELECT), C0202q.m725a(this.f286a, (int) R.attr.menuIconMultiSelect_menu)));
                return;
            case 92:
                list.add(new C0056l(i, resources.getString(R.string.MENU_EXTRACT_TO_CURRENT_DIR), C0202q.m725a(this.f286a, (int) R.attr.menuIconTo)));
                return;
            case 93:
                list.add(new C0056l(i, resources.getString(R.string.MENU_PAST), C0202q.m725a(this.f286a, (int) R.attr.menuIconTo)));
                return;
            case 94:
                list.add(new C0056l(i, resources.getString(R.string.MENU_NEW), C0202q.m725a(this.f286a, (int) R.attr.menuIconCompress)));
                return;
            case 95:
                list.add(new C0056l(i, resources.getString(R.string.BTN_OK), C0202q.m725a(this.f286a, (int) R.attr.menuIconOk)));
                return;
            case 96:
                list.add(new C0056l(i, resources.getString(R.string.BTN_CANCEL), C0202q.m725a(this.f286a, (int) R.attr.menuIconCancel)));
                return;
            case 97:
                list.add(new C0056l(i, resources.getString(R.string.MENU_EXIT), C0202q.m725a(this.f286a, (int) R.attr.menuIconClose)));
                return;
            case 98:
                list.add(new C0056l(i, resources.getString(R.string.MENU_PERMISSIONS), C0202q.m725a(this.f286a, (int) R.attr.menuIconPermission)));
                return;
            default:
                return;
        }
    }
}
