package ru.zdevs.zarchiver.io;

import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.util.Locale;
import ru.zdevs.zarchiver.tool.C0166c;

public class ZAIO {
    /* renamed from: a */
    private static ContentResolver f395a;

    /* renamed from: a */
    public static void m425a(Context context) {
        if (context != null) {
            f395a = context.getApplicationContext().getContentResolver();
        } else {
            f395a = null;
        }
    }

    public static int openFd(InputStream inputStream) {
        if (inputStream == null) {
            return -1;
        }
        try {
            FileDescriptor fd = ((FileInputStream) inputStream).getFD();
            if (fd == null) {
                return -1;
            }
            Method method = fd.getClass().getMethod("getInt$", new Class[0]);
            if (method == null) {
                return -1;
            }
            Integer num = (Integer) method.invoke(fd, new Object[0]);
            return num == null ? -1 : num.intValue();
        } catch (Throwable e) {
            C0166c.m556a(e);
            return -1;
        }
    }

    public static InputStream openInputStream(String str, int i) {
        C0166c.m557b("ZAIO", "Open: " + str);
        if (f395a == null) {
            return null;
        }
        String str2 = "\"*+,:;<=>?\\[]|";
        str2 = str.replace("/uri/", "content://");
        for (int i2 = 0; i2 < "\"*+,:;<=>?\\[]|".length(); i2++) {
            str2 = str2.replace(String.format(Locale.ENGLISH, "$%02d", new Object[]{Integer.valueOf(i2)}), String.valueOf("\"*+,:;<=>?\\[]|".charAt(i2)));
        }
        try {
            return f395a.openInputStream(Uri.parse(str2.replace("%2F/", "%2F").replace("%3A/", "%3A")));
        } catch (Throwable e) {
            C0166c.m556a(e);
            return null;
        }
    }

    public static OutputStream openOutputStream(String str, int i) {
        return null;
    }
}
