package ru.zdevs.zarchiver.io;

import android.annotation.TargetApi;
import android.content.ContentResolver;
import android.content.Context;
import android.content.UriPermission;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.ParcelFileDescriptor;
import android.provider.DocumentsContract;
import android.util.Log;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import ru.zdevs.zarchiver.tool.C0166c;
import ru.zdevs.zarchiver.tool.C0187l;
import ru.zdevs.zarchiver.tool.C0187l.C0186a;
import ru.zdevs.zarchiver.tool.C0199n;
import ru.zdevs.zarchiver.tool.C0199n.C0198a;
import ru.zdevs.zarchiver.tool.C0202q;

@TargetApi(21)
public class LollipopExtSD {
    /* renamed from: a */
    private static Context f389a;
    /* renamed from: b */
    private static List<C0142a> f390b;
    /* renamed from: c */
    private static ContentResolver f391c;
    /* renamed from: d */
    private static boolean f392d = false;
    /* renamed from: e */
    private static int f393e = 0;
    /* renamed from: f */
    private static String[] f394f;

    public static class DIR {
        /* renamed from: a */
        private String f381a;
        /* renamed from: b */
        private int f382b;
        /* renamed from: c */
        private long f383c;
        /* renamed from: d */
        private long f384d;

        public DIR(String str, int i, long j, long j2) {
            this.f381a = str;
            this.f382b = i;
            this.f383c = j;
            this.f384d = j2;
        }

        public String getName() {
            return this.f381a;
        }

        public long getSize() {
            return this.f383c;
        }

        public long getTime() {
            return this.f384d;
        }

        public int getType() {
            return this.f382b;
        }
    }

    /* renamed from: ru.zdevs.zarchiver.io.LollipopExtSD$a */
    public static class C0142a {
        /* renamed from: a */
        public String f385a;
        /* renamed from: b */
        public Uri f386b = null;
        /* renamed from: c */
        public String f387c;
        /* renamed from: d */
        public String f388d;

        public C0142a(C0198a c0198a) {
            this.f385a = c0198a.f541a;
            this.f387c = c0198a.f542b;
            this.f388d = c0198a.f543c;
        }
    }

    /* renamed from: a */
    private static void m423a(Context context) {
        if (VERSION.SDK_INT >= 21) {
            List<C0198a> b = C0199n.m695b(context, 12);
            if (b != null && b.size() > 0) {
                for (C0198a c0198a : b) {
                    if (!(c0198a.f543c == null || c0198a.m684a())) {
                        f390b.add(new C0142a(c0198a));
                    }
                }
            }
        }
    }

    /* renamed from: a */
    private static boolean m424a(String str, boolean z) {
        AutoCloseable query;
        Object e;
        Throwable th;
        if (str == null || f389a == null) {
            return false;
        }
        C0142a storage = getStorage(str);
        if (storage == null) {
            Log.e("LollipopExtSD", "Not found storage for path: " + str);
            return false;
        } else if (storage.f386b == null) {
            Log.e("LollipopExtSD", "Need request permission for: " + storage.f387c);
            return false;
        } else {
            Uri uri = storage.f386b;
            String[] e2 = C0202q.m744e(str.substring(storage.f387c.length() + 1));
            Uri buildChildDocumentsUriUsingTree = DocumentsContract.buildChildDocumentsUriUsingTree(uri, DocumentsContract.getDocumentId(uri));
            String[] strArr = new String[]{"_display_name", "mime_type", "document_id"};
            int i = 0;
            Uri uri2 = uri;
            while (i < e2.length) {
                Uri uri3;
                try {
                    query = f391c.query(buildChildDocumentsUriUsingTree, strArr, null, null, null);
                    uri3 = null;
                    while (query.moveToNext()) {
                        try {
                            if (query.getString(0) != null && query.getString(0).equals(e2[i])) {
                                if ((i + 1 != e2.length || z) && query.getString(1) != null && !"vnd.android.document/directory".equals(query.getString(1))) {
                                    C0166c.m557b("LollipopExtSD", "Failed search Uri: " + e2[i] + " is file!");
                                    i = e2.length;
                                    uri2 = null;
                                    break;
                                }
                                uri3 = DocumentsContract.buildDocumentUriUsingTree(uri2, query.getString(2));
                            }
                        } catch (Exception e3) {
                            e = e3;
                        }
                    }
                    closeQuery(query);
                } catch (Exception e4) {
                    e = e4;
                    query = null;
                    uri3 = null;
                    try {
                        Log.w("LollipopExtSD", "Failed query: " + e);
                        closeQuery(query);
                        if (uri3 == null) {
                            return i != e2.length ? false : false;
                        } else {
                            buildChildDocumentsUriUsingTree = DocumentsContract.buildChildDocumentsUriUsingTree(uri3, DocumentsContract.getDocumentId(uri3));
                            i++;
                            uri2 = uri3;
                        }
                    } catch (Throwable th2) {
                        th = th2;
                    }
                } catch (Throwable th3) {
                    th = th3;
                    query = null;
                }
                if (uri3 == null) {
                    break;
                }
                buildChildDocumentsUriUsingTree = DocumentsContract.buildChildDocumentsUriUsingTree(uri3, DocumentsContract.getDocumentId(uri3));
                i++;
                uri2 = uri3;
            }
            if (i != e2.length && r8 != null) {
                return true;
            }
        }
        closeQuery(query);
        throw th;
    }

    public static int chdir(String str) {
        String name = Thread.currentThread().getThreadGroup().getName();
        if (name == null) {
            return -1;
        }
        int charAt = name.charAt(0) - 48;
        if (charAt < 0 || charAt >= f394f.length) {
            return -1;
        }
        f394f[charAt] = str;
        return 0;
    }

    public static int close(int i) {
        return 0;
    }

    public static void closeQuery(AutoCloseable autoCloseable) {
        try {
            autoCloseable.close();
        } catch (Exception e) {
        }
    }

    public static ContentResolver getContentResolver() {
        return f391c;
    }

    public static C0142a getStorage(String str) {
        for (C0142a c0142a : f390b) {
            if (str.startsWith(c0142a.f387c)) {
                return c0142a;
            }
        }
        return null;
    }

    public static String getUnavailableStorageID() {
        if (f390b == null) {
            return null;
        }
        for (C0142a c0142a : f390b) {
            if (c0142a.f386b == null) {
                return c0142a.f388d;
            }
        }
        return null;
    }

    public static Uri getUriFromPath(String str, boolean z, boolean z2) {
        AutoCloseable query;
        Object e;
        Throwable th;
        if (str == null || f389a == null) {
            return null;
        }
        for (C0142a c0142a : f390b) {
            if (str.startsWith(c0142a.f387c)) {
                break;
            }
        }
        C0142a c0142a2 = null;
        if (c0142a2 == null) {
            Log.e("LollipopExtSD", "Not found storage for path: " + str);
            return null;
        } else if (c0142a2.f386b == null) {
            Log.e("LollipopExtSD", "Need request permission for: " + c0142a2.f387c);
            return null;
        } else {
            Uri uri = c0142a2.f386b;
            if (c0142a2.f387c.equals(str)) {
                return DocumentsContract.buildChildDocumentsUriUsingTree(uri, DocumentsContract.getDocumentId(uri));
            }
            String[] e2 = C0202q.m744e(str.substring(c0142a2.f387c.length() + 1));
            String[] strArr = new String[]{"_display_name", "mime_type", "document_id"};
            int i = 0;
            Uri uri2 = uri;
            Uri buildChildDocumentsUriUsingTree = DocumentsContract.buildChildDocumentsUriUsingTree(uri, DocumentsContract.getDocumentId(uri));
            while (i < e2.length) {
                try {
                    query = f391c.query(buildChildDocumentsUriUsingTree, strArr, null, null, null);
                    uri = null;
                    while (query.moveToNext()) {
                        try {
                            if (query.getString(0) != null && query.getString(0).equals(e2[i])) {
                                if ((i + 1 != e2.length || z) && query.getString(1) != null && !"vnd.android.document/directory".equals(query.getString(1))) {
                                    C0166c.m557b("LollipopExtSD", "Failed search Uri: " + e2[i] + " is file!");
                                    i = e2.length;
                                    uri2 = null;
                                    break;
                                }
                                uri = DocumentsContract.buildDocumentUriUsingTree(uri2, query.getString(2));
                            }
                        } catch (Exception e3) {
                            e = e3;
                        }
                    }
                    closeQuery(query);
                } catch (Exception e4) {
                    e = e4;
                    query = null;
                    uri = null;
                    try {
                        Log.w("LollipopExtSD", "Failed query: " + e);
                        closeQuery(query);
                        if (uri != null) {
                            buildChildDocumentsUriUsingTree = DocumentsContract.buildChildDocumentsUriUsingTree(uri, DocumentsContract.getDocumentId(uri));
                            i++;
                            uri2 = uri;
                        } else {
                            if (i != e2.length) {
                                if (!z2) {
                                    while (i < e2.length) {
                                        if (i + 1 == e2.length) {
                                        }
                                        C0166c.m555a("getUriFromPath", "Create folder: " + e2[i]);
                                        uri2 = DocumentsContract.createDocument(f391c, uri2, "vnd.android.document/directory", e2[i]);
                                        if (uri2 == null) {
                                            break;
                                        }
                                        i++;
                                    }
                                } else {
                                    return null;
                                }
                            }
                            return uri2;
                        }
                    } catch (Throwable th2) {
                        th = th2;
                    }
                } catch (Throwable th3) {
                    th = th3;
                    query = null;
                }
                if (uri != null) {
                    break;
                }
                buildChildDocumentsUriUsingTree = DocumentsContract.buildChildDocumentsUriUsingTree(uri, DocumentsContract.getDocumentId(uri));
                i++;
                uri2 = uri;
            }
            if (i != e2.length) {
                if (!z2) {
                    return null;
                }
                while (i < e2.length) {
                    if (i + 1 == e2.length || z) {
                        C0166c.m555a("getUriFromPath", "Create folder: " + e2[i]);
                        uri2 = DocumentsContract.createDocument(f391c, uri2, "vnd.android.document/directory", e2[i]);
                    } else {
                        try {
                            C0166c.m555a("getUriFromPath", "Create file: " + e2[i]);
                            uri2 = DocumentsContract.createDocument(f391c, uri2, "", e2[i]);
                        } catch (Throwable th4) {
                            C0166c.m556a(th4);
                            return null;
                        }
                    }
                    if (uri2 == null) {
                        break;
                    }
                    i++;
                }
            }
            return uri2;
        }
        closeQuery(query);
        throw th4;
    }

    public static String getVolumeIdFromTreeUri(Uri uri) {
        String[] split = DocumentsContract.getTreeDocumentId(uri).split(":");
        return split.length > 0 ? split[0] : null;
    }

    public static boolean isCorrect(Uri uri, C0198a c0198a) {
        boolean z;
        String volumeIdFromTreeUri = getVolumeIdFromTreeUri(uri);
        Uri buildDocumentUriUsingTree = DocumentsContract.buildDocumentUriUsingTree(uri, DocumentsContract.getTreeDocumentId(uri));
        for (C0142a c0142a : f390b) {
            if (c0142a.f388d.equals(volumeIdFromTreeUri)) {
                c0142a.f386b = buildDocumentUriUsingTree;
                f392d = true;
                z = true;
                break;
            }
        }
        z = false;
        if (!z) {
            return false;
        }
        File file = new File(c0198a.f542b + "/Android");
        if (!file.exists()) {
            file = new File(c0198a.f542b);
        }
        File file2 = new File(file, ".za_sd_check");
        if (isExist(file2, false) || file2.exists()) {
            remove(file2);
            z = !file2.exists();
        } else {
            try {
                OutputStream openOutStream = openOutStream(file2.getAbsolutePath());
                if (openOutStream != null) {
                    openOutStream.close();
                }
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
            z = file2.exists();
            remove(file2);
        }
        return z;
    }

    public static boolean isExist(File file, boolean z) {
        return !f392d ? false : m424a(file.getAbsolutePath(), z);
    }

    public static boolean isExternalRW(String str) {
        if (str == null) {
            return false;
        }
        for (C0142a c0142a : f390b) {
            if (str.startsWith(c0142a.f387c)) {
                return c0142a.f388d != null;
            }
        }
        return false;
    }

    public static boolean isUse(String str) {
        if (!f392d || str == null) {
            return false;
        }
        for (C0142a c0142a : f390b) {
            if (str.startsWith(c0142a.f387c)) {
                return c0142a.f386b != null;
            }
        }
        return false;
    }

    public static boolean isWritePermission(Context context) {
        if (f390b == null || f390b.size() == 0) {
            return true;
        }
        if (f393e == 0) {
            f393e = 1;
            for (C0142a c0142a : f390b) {
                if (c0142a.f386b == null && !C0143a.m434d(c0142a.f387c)) {
                    f393e = 2;
                    break;
                }
            }
        }
        return f393e == 1;
    }

    public static int mkdir(String str) {
        return (!f392d || new File(str).exists() || getUriFromPath(str, true, true) == null) ? -1 : 0;
    }

    public static boolean mkdir(File file) {
        return (!f392d || file == null) ? false : file.exists() || getUriFromPath(file.getAbsolutePath(), true, true) != null;
    }

    public static int open(String str, int i) {
        boolean z = false;
        if (!f392d) {
            return -1;
        }
        try {
            if (str.charAt(0) != '/') {
                String name = Thread.currentThread().getThreadGroup().getName();
                if (name != null) {
                    int charAt = name.charAt(0) - 48;
                    if (charAt >= 0 && charAt < f394f.length && f394f[charAt] != null) {
                        str = f394f[charAt] + str;
                    }
                }
            }
            if ((i & 1027) != 0) {
                z = true;
            }
            Uri uriFromPath = getUriFromPath(str, false, z);
            if (uriFromPath == null) {
                return -2;
            }
            String str2 = "r";
            if ((i & 3) != 0) {
                str2 = str2 + "w";
            }
            if ((i & 1024) == 1024) {
                str2 = str2 + "a";
            }
            if ((i & 2048) == 2048) {
                str2 = str2 + "t";
            }
            ParcelFileDescriptor openFileDescriptor = f391c.openFileDescriptor(uriFromPath, str2);
            if (openFileDescriptor == null) {
                return -3;
            }
            int detachFd = openFileDescriptor.detachFd();
            C0166c.m557b("LollipopExtSD", "Open file with FD: " + detachFd);
            return detachFd;
        } catch (Throwable e) {
            C0166c.m556a(e);
            return -4;
        }
    }

    public static InputStream openInStream(String str) {
        InputStream inputStream = null;
        if (f392d) {
            try {
                Uri uriFromPath = getUriFromPath(str, false, true);
                if (uriFromPath != null) {
                    inputStream = f391c.openInputStream(uriFromPath);
                }
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
        } else {
            Log.e("LollipopExtSD", "get stream failed! Not init Lollipop hack!");
        }
        return inputStream;
    }

    public static OutputStream openOutStream(String str) {
        OutputStream outputStream = null;
        if (f392d) {
            try {
                Uri uriFromPath = getUriFromPath(str, false, true);
                if (uriFromPath != null) {
                    outputStream = f391c.openOutputStream(uriFromPath);
                }
            } catch (Throwable e) {
                C0166c.m556a(e);
            }
        } else {
            Log.e("LollipopExtSD", "get stream failed! Not init Lollipop hack!");
        }
        return outputStream;
    }

    public static DIR[] opendir(String str) {
        if (!f392d || str == null || !str.startsWith("/SAF")) {
            return null;
        }
        List<C0186a> a = C0187l.m664a(str);
        if (a == null) {
            return null;
        }
        DIR[] dirArr = new DIR[a.size()];
        int i = 0;
        for (C0186a c0186a : a) {
            int i2 = i + 1;
            dirArr[i] = new DIR(c0186a.f527a, c0186a.f528b ? 4 : 0, c0186a.f530d, c0186a.f529c);
            i = i2;
        }
        return dirArr;
    }

    public static Cursor query(Uri uri, String[] strArr) {
        return f391c == null ? null : f391c.query(uri, strArr, null, null, null);
    }

    public static int remove(String str) {
        boolean z = false;
        if (!f392d) {
            return -1;
        }
        Uri uriFromPath = getUriFromPath(str, false, false);
        if (uriFromPath == null) {
            return -1;
        }
        try {
            if (!DocumentsContract.deleteDocument(f391c, uriFromPath)) {
                z = true;
            }
            return z;
        } catch (Throwable e) {
            C0166c.m556a(e);
            return -1;
        }
    }

    public static boolean remove(File file) {
        boolean z = false;
        if (f392d) {
            Uri uriFromPath = getUriFromPath(file.getAbsolutePath(), file.isDirectory(), z);
            if (uriFromPath != null) {
                try {
                    z = DocumentsContract.deleteDocument(f391c, uriFromPath);
                } catch (Throwable e) {
                    C0166c.m556a(e);
                }
            }
        } else {
            Log.e("LollipopExtSD", "Remove failed! Not init Lollipop hack!");
        }
        return z;
    }

    public static int rename(String str, String str2) {
        if (!f392d) {
            return -1;
        }
        String[] e = C0202q.m744e(str);
        String[] e2 = C0202q.m744e(str2);
        if (e.length != e2.length) {
            return -1;
        }
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < e.length - 1; i++) {
            if (!e[i].equals(e2[i])) {
                return -1;
            }
            stringBuilder.append("/");
            stringBuilder.append(e[i]);
        }
        return !renameTo(stringBuilder.toString(), e[e.length + -1], e2[e2.length + -1]) ? -1 : 0;
    }

    public static boolean renameTo(String str, String str2, String str3) {
        if (!f392d || str == null || str2 == null || str3 == null) {
            return false;
        }
        Uri uriFromPath = getUriFromPath(str + "/" + str2, false, false);
        if (uriFromPath == null) {
            return false;
        }
        try {
            return DocumentsContract.renameDocument(f391c, uriFromPath, str3) != null;
        } catch (Throwable e) {
            C0166c.m556a(e);
            return false;
        }
    }

    public static void setContext(Context context) {
        if (f389a != context) {
            f389a = context;
            f390b = new ArrayList();
            f391c = null;
            f392d = false;
            f393e = 0;
            f394f = new String[5];
            if (context != null) {
                m423a(context);
            }
            if (f390b.size() > 0) {
                f391c = context.getApplicationContext().getContentResolver();
                List persistedUriPermissions = f391c.getPersistedUriPermissions();
                for (int i = 0; i < persistedUriPermissions.size(); i++) {
                    Uri uri = ((UriPermission) persistedUriPermissions.get(i)).getUri();
                    String volumeIdFromTreeUri = getVolumeIdFromTreeUri(uri);
                    if (volumeIdFromTreeUri != null) {
                        Uri buildDocumentUriUsingTree = DocumentsContract.buildDocumentUriUsingTree(uri, DocumentsContract.getTreeDocumentId(uri));
                        for (C0142a c0142a : f390b) {
                            if (volumeIdFromTreeUri.equals(c0142a.f388d)) {
                                c0142a.f386b = buildDocumentUriUsingTree;
                                f392d = true;
                                break;
                            }
                        }
                    }
                }
            }
        }
    }
}
